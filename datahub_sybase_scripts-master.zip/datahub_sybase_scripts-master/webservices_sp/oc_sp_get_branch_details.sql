----version V2 : Added column 'timestamp' for service_call_type INT and CMB 
----version V1
use #<oc>
go

setuser "dbo"
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_get_branch_details')
begin
	drop procedure sp_get_branch_details
end
go



create procedure sp_get_branch_details 
		 @branch_num_physical char(3)
		 ,@app_id char(10)
		 ,@line_of_business char(10)
		 ,@req_time_stamp char(25)
AS


	declare   
		@last_data_date       	char(8),   
		@start_time	        datetime,                          
		@proc_name	        varchar(35),                                                  
		@input_parm	        varchar(175),         
		@debug_flag	        char(1),
		@syb_error_code		int ,
		@custom_error_code	int,
		@no_of_records		int
	
BEGIN

		select
                @debug_flag = debug_flag
        FROM
                #<oc>..si_service_debug_config
        WHERE
                service_id='sp_get_branch_details'



        if(@debug_flag='Y')
        begin
                select @start_time=getdate()
                select @proc_name=object_name(@@procid)
                select @input_parm = @branch_num_physical+","+ @app_id+","+ @line_of_business+","+ convert(varchar(25),@req_time_stamp)
        end

	SELECT
		  branch_num       
		, branch_name      
		, region_code      
		, branch_mgr_ia_num
		, branch_address1  
		, branch_address2  
		, branch_address3  
		, branch_address4  
		, postal_code      
		, branch_phone_num 
		, email_address    
		, modify_by        
		, mgr_name         
		, mgr_phone        
		, fr_mgr_name      
		, fr_mgr_phone 
		, modify_timestamp as updt_last_tmstp
	FROM
		#<sb>..si_branch_master
	WHERE
		branch_num = @branch_num_physical


	select @syb_error_code = @@error , @no_of_records = @@rowcount 
		
		if @syb_error_code <> 0    
		begin   
	
			raiserror 20150 "Query to employee directory details failed."

			select @custom_error_code = @@error
			
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_branch_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
			
			return @custom_error_code
		end 
	
	
	
	if(@debug_flag="Y")   
	begin   
			insert into #<oc>..si_branch_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 ) 
	end   
			
			
	return 0
END

go

grant Execute  on sp_get_branch_details to spica_ws
go

grant Execute  on sp_get_branch_details to readall
go

