use #<oc>
go

setuser "dbo"
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_get_emp_dir_details')
begin
	drop procedure sp_get_emp_dir_details
end
go



create procedure sp_get_emp_dir_details 
		 --@nt_logon_id varchar(9),
		 @userid char(9)
		 ,@domain char(17)
		 ,@app_id char(10)
		 ,@line_of_business char(10)
		 ,@req_time_stamp char(25)
		 
AS
	declare   
		@last_data_date       	char(8),   
		@start_time	        datetime,                          
		@proc_name	        varchar(35),                                                  
		@input_parm	        varchar(175),         
		@debug_flag	        char(1),
		@syb_error_code		int ,
		@custom_error_code	int,
		@no_of_records		int
		
BEGIN

		select
                @debug_flag = debug_flag
        FROM
                #<oc>..si_service_debug_config
        WHERE
                service_id='sp_get_emp_dir_details'



        if(@debug_flag='Y')
        begin
                select @start_time=getdate()
                select @proc_name=object_name(@@procid)
                select @input_parm = @userid+"," + @domain+","+ @app_id+","+ @line_of_business+","+ convert(varchar(25),@req_time_stamp)
        end

	SELECT
		 last_name                  
		, first_name                 
		, initials                   
		, phone                      
		, phone_ext                  
		, phone_centrex              
		, transit                    
		, mgr_indicator              
		, post_office                
		, primary_email_id 
		, internet_id+'@'+internet_domain primary_email_id_p		
		, secondary_post_office      
		, secondary_email_id         
		, other_phone                
		, other_phone_ext            
		, other_phone_centrex        
		, other_phone_desc           
		, fax_number                 
		, title                      
		, email_delegate             
		, address                    
		, address_city               
		, address_province           
		, address_country            
		, address_postal_code        
		, field_head_quarters_number 
		, company_name               
		, expire_flag                
		, status_flag                
		, update_flag                
		, employee_num               
		, mgr_employee_num           
		, position_num               
		, corporate_name             
		, comment                    
		, dual_rpt_mgr_employee_num  
		, dual_rpt_mgr_position_num  
		, mgr_level_indicator        
		, mgr_position_num           
		, date_stamp                 
		, occupation_code            
		, business_unit              
		, group_name                 
		, addendum_record_indicator  
		, business_responsibility    
		, internet_id                
		, internet_domain            
		, event_mgr_key              
		, event_mgr_status           
		, ACF2_userid                
		, search_last_name           
		, search_first_name          
		, administrator_type         
		, employee_type              
		, dual_reporting_transit     
		, nt_domain                  
		, company_number             
		, gender                     
		, exchange_directory_name    
		, nt_logon_id                
		, mailing_transit            
		, server_name                
		, alternate_last_name        
		, business_function_geog_unit
		, business_purpose           
		, business_address           
		, business_address_floor     
		, business_address_location  
		, business_address_building  
		, business_address_group_name

	FROM
		#<sb>..si_enterprise_directory
	WHERE
		--nt_logon_id = @nt_logon_id
		--AND 
		nt_domain = @domain 
		AND employee_num = @userid


    select @syb_error_code = @@error , @no_of_records = @@rowcount 
		
		if @syb_error_code <> 0    
		begin   
	
			raiserror 20151 "Query to employee directory details failed."

			select @custom_error_code = @@error
			
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_emp_dir_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
			
			return @custom_error_code
		end 
	
	
	
	if(@debug_flag="Y")   
	begin   
			insert into #<oc>..si_emp_dir_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 ) 
	end   
			
	return 0

	
END

go



grant Execute  on sp_get_emp_dir_details to spica_ws
go

grant Execute  on sp_get_emp_dir_details to readall
go

