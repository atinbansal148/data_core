--V2 Added one paramter for primary_email_id for GIS Emailer
use #<oc>
go

 
declare @ext int , @user varchar(255), @cdate datetime
set @ext = 0
set @user = suser_name()
set @cdate = getdate()
select @ext = count(*) from #<oc>..si_service_debug_config where service_id = 'sp_search_emp_dir_details' 
if (@ext < 1)
begin
insert into #<oc>..si_service_debug_config(service_id,client_id,debug_flag,description,created_by,created_date,modified_by,modified_date)
values('sp_search_emp_dir_details','Gis','Y','Advanced Employee Service',@user,@cdate,@user,@cdate)
end
else
begin
update #<oc>..si_service_debug_config set debug_flag = 'Y',modified_by=@user,modified_date=@cdate where service_id = 'sp_search_emp_dir_details'
end
--V2 Added update to enable debug flag
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_search_emp_dir_details')
begin
	drop procedure sp_search_emp_dir_details
end
go



create procedure sp_search_emp_dir_details 
		  @domain char(17) = NULL
		 ,@userid char(9) = NULL
		 ,@nt_logon_id varchar(9)= NULL
		 ,@first_name char(20) = NULL
		 ,@last_name char(25) = NULL
		 ,@primary_email_id char(8) = NULL
		 ,@app_id char(10) = NULL
		 ,@line_of_business char(10) = NULL
		 ,@req_time_stamp char(25) = NULL
		 ,@transaction_id char(40)= NULL
		 --V2 Added Paarmeter primary_email_id
		 
AS
	declare   
		@last_data_date         char(8),   
		@start_time	        datetime,                          
		@proc_name	        varchar(35),                                                  
		@input_parm	        varchar(590),         
		@debug_flag	        char(1),
		@syb_error_code		int ,
		@custom_error_code	int,
		@no_of_records		int
		--V2 Increase parmater lenght for debug to include new paramter
BEGIN
     
	select
                @debug_flag = debug_flag
        FROM
                #<oc>..si_service_debug_config
        WHERE
                service_id='sp_search_emp_dir_details'
               
	select @domain = lower(@domain)
    select @nt_logon_id = lower(ltrim(rtrim(@nt_logon_id)))
	select @userid = ltrim(rtrim(@userid))
	select @first_name = lower(ltrim(rtrim(@first_name)))
	select @last_name =  lower(ltrim(rtrim(@last_name)))
	select @primary_email_id =  lower(ltrim(rtrim(@primary_email_id)))
    if @domain = ''
	set @domain = null

	if(@debug_flag='Y')
        begin
                select @start_time=getdate()
                select @proc_name=object_name(@@procid)
                select @input_parm = @domain + "," + @userid+","+ @nt_logon_id + "," + @first_name + "," + @last_name + "," + @app_id+","+ @line_of_business+","+ convert(varchar(25),@req_time_stamp)+","+@transaction_id
        end
 
  
SELECT 
		  last_name                  
		, first_name                 
		, initials                   
		, phone                      
		, phone_ext                  
		, phone_centrex              
		, transit                    
		, mgr_indicator              
		, post_office                
		, primary_email_id
		, internet_id + "@" + internet_domain as primary_email_id_p
		, secondary_post_office      
		, secondary_email_id         
		, other_phone                
		, other_phone_ext            
		, other_phone_centrex        
		, other_phone_desc           
		, fax_number                 
		, title                      
		, email_delegate             
		, address                    
		, address_city               
		, address_province           
		, address_country            
		, address_postal_code        
		, field_head_quarters_number 
		, company_name               
		, expire_flag                
		, status_flag                
		, update_flag                
		, employee_num              
		, mgr_employee_num           
		, position_num               
		, corporate_name             
		, comment                    
		, dual_rpt_mgr_employee_num  
		, dual_rpt_mgr_position_num  
		, mgr_level_indicator        
		, mgr_position_num           
		, date_stamp                 
		, occupation_code            
		, business_unit              
		, group_name                 
		, addendum_record_indicator  
		, business_responsibility    
		, internet_id                
		, internet_domain            
		, event_mgr_key              
		, event_mgr_status           
		, ACF2_userid                
		, search_last_name           
		, search_first_name          
		, administrator_type         
		, employee_type              
		, dual_reporting_transit     
		, nt_domain               
		, company_number             
		, gender                     
		, exchange_directory_name    
		, nt_logon_id                
		, mailing_transit            
		, server_name                
		, alternate_last_name        
		, business_function_geog_unit
		, business_purpose           
		, business_address           
		, business_address_floor     
		, business_address_location  
		, business_address_building  
		, business_address_group_name
	FROM
		#<sb>..si_employee
	WHERE 	
	
		lower(ltrim(rtrim(nt_domain))) =
                CASE WHEN @domain is not NULL
                     THEN @domain 	
		     ELSE lower(ltrim(rtrim(nt_domain)))
		END		
		AND
		isnull(lower(ltrim(rtrim(nt_logon_id))),'T') =
                CASE WHEN @nt_logon_id is not NULL
                     THEN @nt_logon_id 	
		     ELSE isnull(lower(ltrim(rtrim(nt_logon_id))),'T')
		END
		
             AND
	         ltrim(rtrim(employee_num)) =
	         CASE WHEN @userid is not NULL
		      THEN  @userid
		 ELSE ltrim(rtrim(employee_num))
	        END
		 
	     AND
                 isnull(lower(ltrim(rtrim(first_name))),'T') = 
	         CASE WHEN @first_name is not NULL
	              THEN @first_name
		 ELSE isnull(lower(ltrim(rtrim(first_name))),'T')
	     END
             AND
	         lower(ltrim(rtrim(last_name))) = 
	         CASE WHEN @last_name is not NULL
		       THEN @last_name
	  	 ELSE lower(ltrim(rtrim(last_name)))
	     END
			 AND
	         isnull(lower(ltrim(rtrim(primary_email_id))),'T') = 
	         CASE WHEN @primary_email_id is not NULL
		       THEN @primary_email_id
	  	 ELSE isnull(lower(ltrim(rtrim(primary_email_id))),'T')
	     END
 
       --V2 Changed where clasue to include primary_email_id and avoiding null bug for ltrim and rtrim
 
        select @syb_error_code = @@error , @no_of_records = @@rowcount

		if @syb_error_code <> 0    
		begin   
	
			raiserror 20151 "Query to employee details failed."

			select @custom_error_code = @@error
			
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_emp_dir_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
			
			return @custom_error_code
		end 
		
	if(@debug_flag="Y")   
	begin   
			insert into #<oc>..si_emp_dir_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 ) 
	end   
			
	return 0
	
END

go

grant Execute  on sp_search_emp_dir_details to spica_ws
go

