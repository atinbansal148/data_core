-----Version v1 : base version of Security service for Prism project

use #<oc>
go

if exists (SELECT * from sysobjects where type = 'P' and name = 'sp_security_intraday_service' )
BEGIN
	drop procedure sp_security_intraday_service
END
go


create proc sp_security_intraday_service
@min_update_time_stamp	char(25)=NULL,
@app_id	char(10),
@line_of_business	char(10),
@req_time_stamp char(25),
@transaction_id varchar(40)
AS

/*
--Defect fix for format of effct_dt 
--Date 14 Nov 2014


--SRS Version 0.4
---Code Version 0.4
--Added 1 new field 'security_classification_ida' to synch the output fields with the Basic Security Web Service that is being created for PRISM GIS.
Apply below rules in sequence.
1) IF ida_code = 460 OR 700 OR  800 then  �MUTUAL FUND�
2) ELSE IF ida_code = 8000 OR 8100 then "OPTION"
3) ELSE IF Ida_code >= 0 and ida_code <= 900 OR ida_code = 5100 then
�EQUITY�
4) ELSE IF ida_code >= 2000 then  �FIXED INCOME�

*/

declare
		@start_time           datetime,
		@proc_name            varchar(35),
		@input_parm           varchar(120),
		@debug_flag           char(1),
		@syb_error_code       int ,
		@custom_error_code    int,
		@no_of_records        int
		
	
		
BEGIN

		SET plan optgoal allrows_oltp
	
		SELECT @debug_flag = debug_flag FROM #<oc>..si_service_debug_config WHERE service_id=object_name(@@procid)
		
		
		
		if(@debug_flag='Y')
		BEGIN
			SELECT @start_time=getdate()
			SELECT @proc_name=object_name(@@procid)
			SELECT @input_parm = @min_update_time_stamp +","+ @app_id+","+ @line_of_business+","+ @req_time_stamp+","+ @transaction_id
		END
		
		IF (LTRIM(@min_update_time_stamp) = NULL)
		BEGIN
			SELECT @min_update_time_stamp = dateadd(dd, -10, getdate())
		END
		
		
		SELECT
			top 5000 ---To avoid performance issue
			ms.security_adp_nbr,
			ms.msd_class1_cd +ms.msd_class2_cd + ms.msd_class3_cd +	ms.msd_class4_cd +ms.msd_class5_cd +ms.msd_class6_cd +ms.msd_class7_cd msd_class_cd,
			ms.security_ida_cd,
			ms.currency_cd,
			ms.country_origin_cd,
			ms.royalty_ind,
			ms.remic_ind,
			ms.reit_ind,
			ms.uts_canadian_cd,
			ms.etf_ind,
			ms.issr_type_cd,
			ms.annuity_cd,
			ms.class_industry_cd,
			ms.sic_cd,
			ms.sector_cd ,
			ms.action_cd ,	
			ms.updt_last_tmstp ,
			ms.expiration_dt expiration_dt_wrt,
			ms.payment_freq_cd ,			
			ms.issue_dt ,
			--tsec_xref_key details
			b.cross_reference_cd cdn_symbol,
			c.cross_reference_cd us_symbol,
			d.cross_reference_cd isin,
			e.cross_reference_cd cusip,
			f.cross_reference_cd sedol,	
			convert(char(6),isnull(op.occ_optn_sym_id,'')) +  isnull(convert(char(6),op.expiration_dt,12),'      ') +
			case 
				when ms.msd_class1_cd = '6' AND ms.msd_class3_cd = '5' then 'P'
				when ms.msd_class1_cd = '6' AND ms.msd_class3_cd = '4' then 'C'
				else ' '
			end
			+ isnull( cast( (left('00000',5-len(substring(convert(varchar,op.strike_price_amt),1,(charindex(".",convert(varchar,op.strike_price_amt)))-1))) + substring(convert(varchar,op.strike_price_amt),1,(charindex(".",convert(varchar,op.strike_price_amt)))-1)) as char(5)) ,'') 
			+ isnull(substring(convert(varchar,op.strike_price_amt),(charindex(".",convert(varchar,op.strike_price_amt)))+1,3),'') option_symbology,
			--tsecurity_desc details
			g.desc_sec_txt desc_sec_txt_e1,
			h.desc_sec_txt desc_sec_txt_e2,
			i.desc_sec_txt desc_sec_txt_e3,
			j.desc_sec_txt desc_sec_txt_f1,
			k.desc_sec_txt desc_sec_txt_f2,
			l.desc_sec_txt desc_sec_txt_f3,
			--Bond Details
			convert(char(10),bo.maturity_dt,101) maturity_dt,
			bo.interest_rt,
			convert(char(10),bo.coupon_first_dt,101) coupon_first_dt,
			convert(char(10),bo.dated_dt,101) dated_dt,
			bo.dated_dt_cd,
			bo.date_coupon_cd,
			bo.evaluation_bond_cd,
			bo.cmo_ind,
			bo.pool_nbr,
			convert(char(10),bo.pay_interest_dt,101) pay_interest_dt,	
			--factor rate details
			fr.factor_rt,
			convert(char(10),fr.factor_dt,101) factor_dt,
			convert(char(10),bo.accrue_start_dt,101) accrue_start_dt,
			bo.accrue_end_dt ,
			cp.call_dt, 
			cp.call_prc_amt ,
			pp.put_dt, 
			pp.put_prc_amt,
			--Option details
			CASE
				WHEN ms.security_ida_cd = '8000' THEN 'C'
				WHEN ms.security_ida_cd = '8100' THEN 'P'
			END call_or_put,
			convert(char(10),op.expiration_dt,101) expiration_dt,
			op.strike_price_amt,
			op.factor_pct,
			op.scrty_adp_base_nbr,
			op.type_option_cd,
			op.occ_optn_sym_id,
			-- tdvdnd_sec_master details
			convert(char(10),tdv.payable_dt,101) payable_dt,
			tdv.dvdnd_rt ,
			tdv.currency_incm_cd ,
			convert(char(10),tdv.record_dt,101) record_dt,
			convert(char(10),tdv.xdte_dt,101)  xdte_dt,
			--tsec_trd_exchange details
			tec.exchange_msd_cd exchange_msd_cd_cdn,
			teu.exchange_msd_cd exchange_msd_cd_us,
			--tsecurity_rating details
			sr_m.rating_cd rating_cd_moody,
			sr_s.rating_cd 'rating_cd_s&p',			
			tc.elig_rsp_cd, 
			tc.province_cd,
			--Code changes on 14 Nov 2014
			--convert(char(10),ec.effct_dt,101) effct_dt, 
			CASE	
				WHEN ec.effct_dt <> NULL THEN 
					substring(ec.effct_dt, 6,2) +'/'+ substring(ec.effct_dt, 9,2) +'/' + substring(ec.effct_dt, 1,4) 
				ELSE
					ec.effct_dt
			END effct_dt,			
			convert(char(10),ec.trmnt_dt,101) trmnt_dt, 
			ec.elgbl_cd,
			--Code changes on 17 Oct
			CASE
				WHEN (ms.security_ida_cd = '0460' OR ms.security_ida_cd = '0700' OR ms.security_ida_cd = '0800') THEN 'MUTUAL FUND'
				WHEN (ms.security_ida_cd = '8000' OR ms.security_ida_cd = '8100')  THEN 'OPTION'
				WHEN (ms.security_ida_cd >= '2000' AND ms.security_ida_cd != '5100')  THEN 'FIXED INCOME' 
				ELSE 'EQUITY'
			END security_classification_ida,
			--od_mutual_fund_xref details
			mf.company_code,
			mf.fund_code			
		From
			#<bp>..tmsd_base ms
			LEFT OUTER JOIN #<bp>..tbond_data bo 	ON ms.security_adp_nbr = bo.security_adp_nbr
			LEFT OUTER JOIN #<bp>..tfactor_rate fr 	ON ms.security_adp_nbr = fr.security_adp_nbr AND fr.periodic_cd='1'
			LEFT OUTER JOIN #<bp>..toption_data op 	ON ms.security_adp_nbr = op.security_adp_nbr
			LEFT OUTER JOIN #<bp>..tsec_trd_exchange tec ON ms.security_adp_nbr = tec.security_adp_nbr 	and tec.country_cd = 'CA' and tec.exch_primary_ind = 'Y' 				
			LEFT OUTER JOIN #<bp>..tsec_trd_exchange teu ON ms.security_adp_nbr = teu.security_adp_nbr 	and teu.country_cd = 'US' and teu.exch_primary_ind = 'Y' 				
			LEFT OUTER JOIN #<bp>..tsec_xref_key b   ON ms.security_adp_nbr = b.security_adp_nbr and b.type_xref_cd ='CN'
			LEFT OUTER JOIN #<bp>..tsec_xref_key c   ON ms.security_adp_nbr = c.security_adp_nbr and c.type_xref_cd ='SY'
			LEFT OUTER JOIN #<bp>..tsec_xref_key d   ON ms.security_adp_nbr = d.security_adp_nbr and d.type_xref_cd ='IS'
			LEFT OUTER JOIN #<bp>..tsec_xref_key e   ON ms.security_adp_nbr = e.security_adp_nbr and e.type_xref_cd ='CU'
			LEFT OUTER JOIN #<bp>..tsec_xref_key f   ON ms.security_adp_nbr = f.security_adp_nbr and f.type_xref_cd ='SD'
			LEFT OUTER JOIN #<bp>..tsecurity_desc g  ON ms.security_adp_nbr = g.security_adp_nbr and g.language_cd='E' and g.line_txt_nbr=1
			LEFT OUTER JOIN #<bp>..tsecurity_desc h  ON ms.security_adp_nbr = h.security_adp_nbr and h.language_cd='E' and h.line_txt_nbr=2
			LEFT OUTER JOIN #<bp>..tsecurity_desc i  ON ms.security_adp_nbr = i.security_adp_nbr and i.language_cd='E' and i.line_txt_nbr=3
			LEFT OUTER JOIN #<bp>..tsecurity_desc j  ON ms.security_adp_nbr = j.security_adp_nbr and j.language_cd='F' and j.line_txt_nbr=1
			LEFT OUTER JOIN #<bp>..tsecurity_desc k  ON ms.security_adp_nbr = k.security_adp_nbr and k.language_cd='F' and k.line_txt_nbr=2
			LEFT OUTER JOIN #<bp>..tsecurity_desc l  ON ms.security_adp_nbr = l.security_adp_nbr and l.language_cd='F' and l.line_txt_nbr=3
			LEFT OUTER JOIN #<bp>..tsecurity_rating sr_m   ON ms.security_adp_nbr = sr_m.security_adp_nbr and sr_m.vendor_cd='MOODY' 
			LEFT OUTER JOIN #<bp>..tsecurity_rating sr_s   ON ms.security_adp_nbr = sr_s.security_adp_nbr and sr_s.vendor_cd='S&P' 
			LEFT OUTER JOIN #<bp>..tdvdnd_sec_master tdv   ON ms.security_adp_nbr = tdv.security_adp_nbr and tdv.sequence_nbr=1 and tdv.client_nbr = '0069'
			LEFT OUTER JOIN #<od>..od_mutual_fund_xref mf  ON ms.security_adp_nbr = mf.whole_adp_sec_num						
			LEFT OUTER JOIN #<bp>..tcall_price cp ON ms.security_adp_nbr = cp.security_adp_nbr
			LEFT OUTER JOIN #<bp>..tput_price pp ON ms.security_adp_nbr = pp.security_adp_nbr
			LEFT OUTER JOIN #<bp>..ttrnsfr_client_dat tc ON ms.security_adp_nbr = tc.security_adp_nbr
			LEFT OUTER JOIN #<bp>..telgbly_cd_ovrrd ec ON ms.security_adp_nbr = ec.security_adp_nbr	and ec.client_number >''
		WHERE	
			ms.updt_last_tmstp >= @min_update_time_stamp and
			(ms.action_cd = 'I' or ms.action_cd='C' )       

	
		SELECT @syb_error_code = @@error , @no_of_records = @@rowcount

		if @syb_error_code <> 0
		BEGIN

		    raiserror 30087 "Query to retrieve Security Intra-day details failed."

		    SELECT @custom_error_code=@@error

		    if(@debug_flag="Y")
		    BEGIN
				insert into #<oc>..si_security_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		    END

		    return @custom_error_code
		END
	
	
    	if(@debug_flag='Y')
    	BEGIN
			insert into #<oc>..si_security_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
    	END

	return 0

END
go
		
grant Execute  on sp_security_intraday_service to spica_ws 
go


