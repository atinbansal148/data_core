
use #<oc>
go

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_get_multi_client_performance' )
BEGIN
        DROP PROCEDURE sp_get_multi_client_performance 
END
GO

CREATE PROCEDURE sp_get_multi_client_performance
	@account char(600),
	@currency_cd char(3) = NULL,
	@ror_method char(2) = NULL,
        @app_id char(10),
	@line_of_business char(10),
	@req_time_stamp char(25),
	@transaction_id char(40)= NULL

AS
BEGIN
    DECLARE @pos int
    DECLARE @piece char(30)
	
    DECLARE   
    @start_time             datetime,
    @proc_name              varchar(35),
    @input_parm    	    varchar(1000),
    @debug_flag             char(1),
    @syb_error_code         int ,
    @custom_error_code      int,
    @no_of_records          int,
    @branch_num             char(3),
    @account_num            char(5)

    SELECT @currency_cd = ltrim(rtrim(@currency_cd))
    SELECT @ror_method  = ltrim(rtrim(@ror_method))
    SELECT @account     = ltrim(rtrim(@account))
    
    SELECT
      @debug_flag = debug_flag
    FROM
      #<oc>..si_service_debug_config
    WHERE
      service_id='sp_get_multi_client_performance'

    if(@debug_flag='Y')     
    begin
       select @start_time=getdate()
       select @proc_name=object_name(@@procid)
       select @input_parm =  @account +","+ @currency_cd +","+ @ror_method +","+ @app_id+","+@line_of_business+","+ 
                             @req_time_stamp+","+@transaction_id
    end


    CREATE TABLE #tmp_account_list (branch_num char(3), account_num char(5))
	
	SELECT @pos = charindex(',' , @account)
   
	while @pos <> 0
	BEGIN
		SELECT @piece = LEFT( @account , @pos-1 )
		select @branch_num = substring( @account,  1,3),
		       @account_num = substring( @account, 4,5)
		INSERT INTO #tmp_account_list VALUES ( @branch_num, @account_num )
		SELECT @account = stuff( @account, 1, @pos, NULL )
		SELECT @pos = charindex(',' , @account )
	END

     SELECT  @branch_num = substring( @account,  1,3)
     SELECT  @account_num = substring( @account, 4,5)

     INSERT INTO #tmp_account_list VALUES ( @branch_num, @account_num )

    
    SELECT 
	    cl_perf.branch_cd,
		cl_perf.account_cd,
		cl_perf.currency_cd,
		cl_perf.ror_method,
		cl_perf.acctlobid,
		cl_perf.rr_cd,
		cl_perf.ror_1mth,
		cl_perf.ror_3mth,
		cl_perf.ror_6mth,
		cl_perf.ror_9mth,
		cl_perf.ror_prev_yr,
		cl_perf.ror_ytd,
		cl_perf.ror_1yr,
		cl_perf.ror_3yr,
		cl_perf.ror_3yr_ann,
		cl_perf.ror_5yr,
		cl_perf.ror_5yr_ann,
		cl_perf.ror_10yr,
		cl_perf.ror_10yr_ann,
		cl_perf.ror_si,
		cl_perf.ror_si_ann,
		cl_perf.unrealized_gainloss_amt,
		cl_perf.unrealized_gainloss_pct,
		cl_perf.business_date,
		cl_perf.modify_by,	
                cl_perf.updt_last_tmstp
	FROM #<sb>..si_cl_performance cl_perf
	     INNER JOIN #tmp_account_list acc_list ON
	     cl_perf.branch_cd = acc_list.branch_num
	     AND cl_perf.account_cd = acc_list.account_num
	WHERE
	    cl_perf.branch_cd > ''
	    AND cl_perf.account_cd > ''
	    AND cl_perf.currency_cd > ''
	    AND cl_perf.ror_method > ''
        AND
            ltrim(rtrim(cl_perf.currency_cd)) =
            CASE WHEN @currency_cd is not NULL
                 THEN @currency_cd
                 ELSE ltrim(rtrim(cl_perf.currency_cd))
            END
        AND
            ltrim(rtrim(cl_perf.ror_method)) =
            CASE WHEN @ror_method is not NULL
                 THEN  @ror_method
            ELSE ltrim(rtrim(cl_perf.ror_method))
            END
         
            
     select @syb_error_code = @@error , @no_of_records = @@rowcount

     if @syb_error_code <> 0
     begin

        raiserror 20081 "Query to retrieve client performance detail failed."

        select @custom_error_code=@@error

        if(@debug_flag="Y")
        begin
            insert into #<oc>..si_cl_performance_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,
	                                                  getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
        end

        return @custom_error_code
     end
  
     if(@debug_flag='Y')
     begin
	   insert into #<oc>..si_cl_performance_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
     end

     return 0

END
go

GRANT EXECUTE  on sp_get_multi_client_performance to spica_ws

go

