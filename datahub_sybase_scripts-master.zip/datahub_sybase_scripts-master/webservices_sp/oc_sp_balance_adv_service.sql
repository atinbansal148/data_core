-----Version v1 : Base Version

USE #<oc>
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_balance_adv_service' )
BEGIN
	DROP PROCEDURE sp_balance_adv_service
END
GO


CREATE proc sp_balance_adv_service
@branch_cd CHAR(3)=NULL,
@account_cd CHAR(5)=NULL,
@type_account_cd CHAR(1)=NULL,
@currency_cd CHAR(3)=NULL,
@service_call_type CHAR(3),
@app_id CHAR(10),
@line_of_business CHAR(10),
@req_time_stamp CHAR(25),
@transaction_id CHAR(40)
AS

DECLARE

	@start_time datetime,
	@proc_name varchar(35),
	@input_parm varchar(255),
	@debug_flag char(1),
	@syb_error_code int ,
	@custom_error_code int,
	@no_of_records int,
	@action1 char(1),
	@action2 char(1)

BEGIN

	SELECT
		@debug_flag = debug_flag
	FROM
		#<oc>..si_service_debug_config
	WHERE
		service_id='sp_balance_adv_service'


	IF(@debug_flag='Y')
	BEGIN

		SELECT @start_time=getdate()
		SELECT @proc_name=object_name(@@procid)
		SELECT @input_parm=@branch_cd+','+@account_cd+','+@type_account_cd+','+@currency_cd+','+@service_call_type+','+@app_id+','+@line_of_business+','+@req_time_stamp+','+@transaction_id

	END


	IF ( @service_call_type = 'CMB' )
	BEGIN

		SELECT @action1 = '%' , @action2 = '%'

	END

	IF ( @service_call_type = 'INT' )
	BEGIN

		SELECT @action1 = 'I' , @action2 = 'U'

	END

	IF ( @service_call_type = 'PRV' )
	BEGIN

		SELECT @action1 = 'A' , @action2 = 'U'

	END

	IF(      LTRIM(@type_account_cd) = NULL  )
	BEGIN

		SELECT @type_account_cd = '%'

	END

	IF(      LTRIM(@currency_cd) = NULL  )
	BEGIN

		SELECT @currency_cd = '%'

	END

	SELECT
	
		ttypbal.branch_cd,
		ttypbal.account_cd,
		ttypbal.type_account_cd,
		CASE
			WHEN @currency_cd = '254' then 'FE'
			ELSE ttypbal.currency_cd
		END currency_cd,
		ttypbal.ydys_trade_dt_amt,
		ttypbal.tdys_trade_dt_amt,
		CASE
			WHEN ttypbal.ydys_trade_dt_amt + ttypbal.tdys_trade_dt_amt IS NULL THEN 0
			ELSE ttypbal.ydys_trade_dt_amt + ttypbal.tdys_trade_dt_amt
		END tdys_trade_dt_amt_total,
		ttypbal.ydys_settlm_dt_amt,
		ttypbal.tdys_settlm_dt_amt,
		CASE
			WHEN ttypbal.ydys_settlm_dt_amt + ttypbal.tdys_settlm_dt_amt IS NULL THEN 0
			ELSE ttypbal.ydys_settlm_dt_amt + ttypbal.tdys_settlm_dt_amt
		END tdys_settlm_dt_amt_total,
		ttypbal.ydys_hse_exces_amt,
		ttypbal.ydys_equity_pct,
		ttypbal.ydys_equity_amt,
		ttypbal.ydys_mrkt_val_amt,
		ttypbal.class_acct_mrgn_cd,
		ttypbal.action,
		ttypbal.rr_cd,
		ttypbal.updt_last_tmstp
	
	FROM
	
		#<bp>..tacc_type_balance ttypbal
	
	WHERE
	
		ttypbal.client_nbr = '0069' AND
		ttypbal.branch_cd = @branch_cd AND
		ttypbal.account_cd = @account_cd AND
		ttypbal.currency_cd LIKE ( @currency_cd ) AND
		ttypbal.type_account_cd like ( @type_account_cd  )AND
		( ttypbal.action LIKE ( @action1 ) OR  ttypbal.action like ( @action2 ))
	
	
	SELECT @syb_error_code = @@error , @no_of_records = @@rowcount
	
	IF ( @syb_error_code <> 0 )
	BEGIN
	
		IF ( @service_call_type = 'CMB')
		BEGIN
			raiserror 60001 "Query to retrieve combined balance details failed"
			SELECT @custom_error_code=@@error
		END
		IF ( @service_call_type = 'INT')
		BEGIN
			raiserror 60001 "Query to retrieve intraday balance details failed"
			SELECT @custom_error_code=@@error
		END
		IF ( @service_call_type = 'PRV')
		BEGIN
			raiserror 60001 "Query to retrieve previous day balance details failed"
			SELECT @custom_error_code=@@error
		END
	
		IF (@debug_flag='Y')
		BEGIN
			INSERT INTO #<oc>..si_balance_adv_sa_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		END
	
		RETURN @custom_error_code
	
	END
	
	
	IF (@debug_flag='Y')
	BEGIN
		INSERT INTO #<oc>..si_balance_adv_sa_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 )
	END
	
	RETURN

END
GO

GRANT EXECUTE ON sp_balance_adv_service TO spica_ws
GO

