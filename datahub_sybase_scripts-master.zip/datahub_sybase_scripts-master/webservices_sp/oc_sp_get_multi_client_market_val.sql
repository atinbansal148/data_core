
use #<oc>
go

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_get_multi_client_market_val' )
BEGIN
        DROP PROCEDURE sp_get_multi_client_market_val 
END
GO

CREATE PROCEDURE sp_get_multi_client_market_val
	@rbc_business varchar(2),
	@pcdid_adno varchar(1200),
        @app_id char(10),
	@line_of_business char(10),
	@req_time_stamp char(25),
	@transaction_id char(40)= NULL

AS
BEGIN
    DECLARE @pos int
    DECLARE @piece char(30)
	
    DECLARE   
    @start_time             datetime,
    @proc_name              varchar(35),
    @input_parm    	    varchar(1400),
    @debug_flag             char(1),
    @syb_error_code         int ,
    @custom_error_code      int,
    @no_of_records          int
	
    SELECT
        @debug_flag = debug_flag
    FROM
        #<oc>..si_service_debug_config
    WHERE
        service_id='sp_get_multi_client_market_val'
	
    if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @rbc_business+","+ @pcdid_adno +","+ @app_id+","+@line_of_business+","+ @req_time_stamp+","+@transaction_id
    end
	
		
    CREATE TABLE #tmp_pcdid_adno (pcdid_adno char(16))
	
	SELECT @pos = charindex(',' , @pcdid_adno)
   
	while @pos <> 0
	BEGIN
		SELECT @piece = LEFT( @pcdid_adno , @pos-1 )
		INSERT INTO #tmp_pcdid_adno VALUES ( @piece)
		SELECT @pcdid_adno = stuff( @pcdid_adno, 1, @pos, NULL )
		SELECT @pos = charindex(',' , @pcdid_adno )
	END

    INSERT INTO #tmp_pcdid_adno VALUES ( @pcdid_adno )
	

	SELECT 
	    acc.arngid,
            acc.acctno,
            acc.cs_source_ind rbc_business,
	    clnt.pcdid_adno,
	    car.rltntypid,
	    car.rltntypdesc,
	    acc.acctstatusid,
            acc.acctstatusdesc,
	    acc.prodcatcd,
	    acc.prodcatdesc,
	    acc.acctlobid,		
	    acc.acctloblngdsc,
	    acc.internationalind,
	    acc.feetypecode,
	    acc.feetypedesc,
	    acc.acctiacode,
	    acc.branchcode,
	    acc.acctopendt,
	    acc.acctclosedt,
	    acc.modify_timestamp updt_last_tmstp
	 INTO #acct_detail 
	 FROM #<sb>..si_cs_account acc
        INNER JOIN #<sb>..si_cs_clntacctrltns car
            ON acc.arngid = car.arngid
	       AND acc.cs_source_ind = car.cs_source_ind
        LEFT JOIN #<sb>..si_cs_client clnt
            ON  clnt.ipid = car.ipid
		AND clnt.cs_source_ind = car.cs_source_ind
        INNER JOIN #tmp_pcdid_adno tmp
	    ON clnt.pcdid_adno = tmp.pcdid_adno
	 WHERE acc.arngid >= 0
	      AND clnt.ipid >= 0 
	      AND acc.cs_source_ind = @rbc_business

    	SELECT 
	   acct_list.arngid,
     	    acct_list.acctno,
            substring(acct_list.acctno,1,3) branch_cd,
    	    substring(acct_list.acctno,4,8) account_cd,
            acct_list.rbc_business,
	    acct_list.pcdid_adno,
	    acct_list.rltntypid,
	    acct_list.rltntypdesc,
	    acct_list.acctstatusid,
            acct_list.acctstatusdesc,
	    acct_list.prodcatcd,
	    acct_list.prodcatdesc,
	    acct_list.acctlobid,		
	    acct_list.acctloblngdsc,
	    acct_list.internationalind,
	    acct_list.feetypecode,
	    acct_list.feetypedesc,
	    acct_list.acctiacode,
	    acct_list.branchcode,
	    acct_list.acctopendt,
	    acct_list.acctclosedt,
	    acct_list.updt_last_tmstp
	INTO  #acct_detail_br
	FROM #acct_detail acct_list
	
	SELECT 
	    acct_list.arngid,
     	    acct_list.acctno,
            acct_list.branch_cd,
    	    acct_list.account_cd,
            acct_list.rbc_business,
	    acct_list.pcdid_adno,
		 bal.currency_cd,
	    bal.market_val_tot_amt,
	    bal.equity_total_amt,
	    bal.equity_total_amt - bal.market_val_tot_amt cash_balance_total_amt,
	    bal.house_bal_call_amt,
	    acct_list.rltntypid,
	    acct_list.rltntypdesc,
	    acct_list.acctstatusid,
            acct_list.acctstatusdesc,
	    acct_list.prodcatcd,
	    acct_list.prodcatdesc,
	    acct_list.acctlobid,		
	    acct_list.acctloblngdsc,
	    acct_list.internationalind,
	    acct_list.feetypecode,
	    acct_list.feetypedesc,
	    acct_list.acctiacode,
	    acct_list.branchcode,
	    acct_list.acctopendt,
	    acct_list.acctclosedt,
    	aad.shortname,
	    acct_list.updt_last_tmstp
	INTO #acct_detail_add 
   FROM #acct_detail_br acct_list INNER JOIN #<sb>..si_cs_acctaddress aad
	   ON aad.arngid = acct_list.arngid
	   AND aad.cs_source_ind = acct_list.rbc_business
	   LEFT JOIN #<sb>..si_balance bal
		 ON acct_list.branch_cd = bal.branch_cd
		 AND acct_list.account_cd = bal.account_cd
	  
    
    if ( @rbc_business = 'DS' )
    BEGIN	
	SELECT 
            final.rbc_business,
            final.branch_cd,
            final.account_cd,
	    final.pcdid_adno,	
	    final.currency_cd,
	    final.market_val_tot_amt,
	    final.equity_total_amt,
	    final.cash_balance_total_amt,
	    final.house_bal_call_amt,
	    final.rltntypid,
	    final.rltntypdesc,
	    final.acctstatusid,
            final.acctstatusdesc,
	    final.prodcatcd,
	    final.prodcatdesc,
	    final.acctlobid,		
	    final.acctloblngdsc,
	    final.internationalind,
	    final.feetypecode,
	    final.feetypedesc,
	    final.acctiacode,
	    final.branchcode,
	    final.acctopendt,
	    final.acctclosedt,
	    final.shortname,
	    final.updt_last_tmstp	
	FROM #acct_detail_add final
	WHERE  final.rltntypid IN ( 'A','CA' )
        AND final.acctstatusid IN ('A','C','CC','CD')
	ORDER BY 
	    final.market_val_tot_amt DESC,
	    final.acctno ASC,
	    final.currency_cd ASC
		
    END
	
    if ( @rbc_business = 'DI' )
    BEGIN	
	SELECT 
            final.rbc_business,
            final.branch_cd,
            final.account_cd,
	    final.pcdid_adno,	
	    final.currency_cd,
	    final.market_val_tot_amt,
	    final.equity_total_amt,
	    final.cash_balance_total_amt,
	    final.house_bal_call_amt,
	    final.rltntypid,
	    final.rltntypdesc,
	    final.acctstatusid,
            final.acctstatusdesc,
	    final.prodcatcd,
	    final.prodcatdesc,
	    final.acctlobid,		
	    final.acctloblngdsc,
	    final.internationalind,
	    final.feetypecode,
	    final.feetypedesc,
	    final.acctiacode,
	    final.branchcode,
	    final.acctopendt,
	    final.acctclosedt,
	    final.shortname,
	    final.updt_last_tmstp	
	FROM #acct_detail_add final
	WHERE  final.rltntypid IN ( 'A','CA','AA','C2','CT' )
        AND final.acctstatusid IN ('A','AR','C')
	ORDER BY 
	    final.market_val_tot_amt DESC,
	    final.acctno ASC,
	    final.currency_cd ASC
	
    END
			
     select @syb_error_code = @@error , @no_of_records = @@rowcount

     if @syb_error_code <> 0
     begin

        raiserror 20081 "Query to retrieve client market value detail failed."

        select @custom_error_code=@@error

        if(@debug_flag="Y")
        begin
            insert into #<oc>..si_cl_market_val_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,
	                                                  getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
        end

        return @custom_error_code
     end
  
     if(@debug_flag='Y')
     begin
	insert into #<oc>..si_cl_market_val_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
     end

     return 0

END
go

GRANT EXECUTE  on sp_get_multi_client_market_val to spica_ws

go

