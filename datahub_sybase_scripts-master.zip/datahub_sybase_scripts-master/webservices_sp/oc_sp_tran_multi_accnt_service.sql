--- v12 : March 29, 2017: Changed Inner Join to Left join to inclued Transaction History text results same as single SP
--- v11 : March 18, 2017: Fix for issue identified during DS/DI implementation
--- v10 : New changes as per SRS 0.90 dated 09-01-2015
--- v8 : Added logic for transaction_category, intraday_flag, and debit_credit_cd
--- v5 : addition of conditions to handle the optional input parameters
--- v4 : Removed the filter for entry_cd 
--- v3 : Changed the logging for debug condition and the error codes
--- v2 : Removed the empty record set for error condition and changed the field names as per the SRS
--- v1 : Base version

-----------------------------------------------------------------------------
-- DDL for Stored Procedure '#<od>.dbo.sp_tran_multi_accnt_service'
-----------------------------------------------------------------------------

print '<<<<< CREATING Stored Procedure - "#<oc>.dbo.sp_tran_multi_accnt_service" >>>>>'
go 

use #<oc>
go

IF EXISTS (SELECT 1 FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'sp_tran_multi_accnt_service' AND u.name = 'dbo' AND o.type = 'P')
BEGIN
	setuser 'dbo'
	drop procedure sp_tran_multi_accnt_service
END
go 



IF (@@error != 0)
BEGIN
	PRINT "Error CREATING Stored Procedure '#<od>.dbo.sp_tran_multi_accnt_service'"
	SELECT syb_quit()
END
go



setuser 'dbo'
go 




create procedure sp_tran_multi_accnt_service
@account        varchar(512) ,
@start_date   char(8),    
@end_date   char(8),
@currency_cd  		 char(3)=NULL,
@investment_category	 varchar(30)=NULL,
@transaction_category		 varchar(60)=NULL,
@symbol			 char(20)=NULL,
@desc_history_txt	 varchar(30)=NULL,
@app_id			 char(10),
@line_of_business	char(10),
@req_time_stamp		char(25)

AS   



declare   
@last_data_date       	char(8),   
@start_time	        datetime,                          
@proc_name	        varchar(35),                                                  
@input_parm	        varchar(800),         
@debug_flag	        char(1),	
@var    		int,	 
@accnt_length 		int,
--@entry_code_length	int ,
@syb_error_code		int ,
@custom_error_code	int,
@no_of_records		int


BEGIN 

	set plan optgoal allrows_oltp
	set store_index off
	select @debug_flag = debug_flag from #<oc>..si_service_debug_config  where service_id="sp_tran_multi_accnt_service"   
	
	if(@debug_flag="Y")   
	begin   
	
		select @start_time=getdate()                
		select @proc_name=object_name(@@procid)   
		select @input_parm = @account+","+ @start_date+","+ @end_date+","+ @currency_cd+","+ @investment_category+","+@transaction_category+","+ @symbol+","+ @desc_history_txt+","+ @app_id+","+ @line_of_business+","+ @req_time_stamp
	 
	end  

	-- If the input currency_cd, investment_category, symbol, entry_cd, desc_history_txt is null then default it to %

	if ( ltrim(@currency_cd) = NULL )
	begin
		select @currency_cd = '%'
	end	 

	if ( ltrim(@investment_category) = NULL )
	begin
		select @investment_category = '%'
	end	 
	
	if ( ltrim(@transaction_category) = NULL )
	begin
		select @transaction_category = '%'
	end	 													
																		
	if ( ltrim(@symbol) = NULL )
	begin
		select @symbol = '%'
	end
																											
	if ( ltrim(@desc_history_txt) = NULL )
		begin
			select @desc_history_txt = '%'
		end
	else
		begin
			select @desc_history_txt= '%' + ltrim(@desc_history_txt) + '%'
		end
	
	
	--- check if complete accnts passed. Should be in multiples of 8 ( branch_cd + account_cd )
	
	select @accnt_length = char_length ( @account )
	
	select @syb_error_code = @@error 
	
	if ( ((@accnt_length%8) <> 0) OR (@syb_error_code <> 0) )
	begin
	
		raiserror 20028 "Incorrect account numbers passed to service."
	
		select @custom_error_code=@@error
	
		if(@debug_flag="Y")   
		begin   
			insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
		end   
	
		return @custom_error_code
	
	end
	

	--- table for multi accounts and inserting the multiple accnts into the table
	
	SELECT
		branch_num ,account_num
	INTO
		#tmp_acc_number
	FROM
		#<oh>..txn_hist_online
	WHERE 
		1=2

	
	select @var = 1
	
	while ( @var < @accnt_length )
	begin
		insert into #tmp_acc_number values ( substring(@account,@var,3) , substring(@account,@var+3,5) )
		
		select @syb_error_code = @@error
			
		if @syb_error_code <> 0   
		begin   
		 	
			raiserror 20029 "Query to process multiple account list failed."

			select @custom_error_code=@@error
		
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
	
			return @custom_error_code
		end   

		select @var = @var + 8
	end
	



	/*
	--- table for multi entry codes 

	SELECT
		entry_code	
	INTO
		#tmp_entry_code
	FROM
		#<oh>..txn_hist_online
	WHERE
		1=2



	-- check the entry_cd . If exists then insert into the temp table

	select @entry_code_length = char_length ( ltrim(@entry_cd) )
	
	select @syb_error_code = @@error
	
	if ( @entry_code_length > 1 )
	begin

		if ( ((@entry_code_length%3) <> 0) OR ( @syb_error_code <> 0) )
		begin

			raiserror 20030 "Incorrect entry codes passed to service."

			select @custom_error_code=@@error
		
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
	
			return @custom_error_code

		end

		select @var = 1

		while ( @var < @entry_code_length )
		begin
			insert into #tmp_entry_code values ( substring(@entry_cd,@var,3) )
			
			select @syb_error_code = @@error
			
			if @syb_error_code <> 0   
			begin   
		 	
				raiserror 20031 "Query to process multiple entry code list failed."

				select @custom_error_code=@@error
		
				if(@debug_flag="Y")   
				begin   
					insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
				end   
	
				return @custom_error_code
			end   
			
			select @var = @var + 3 
		end
	end
	else
	begin
			insert into #tmp_entry_code values ( "%" )
			
			select @syb_error_code = @@error
			
			if @syb_error_code <> 0   
			begin   
		 	
				raiserror 20031 "Query to process multiple entry code list failed."

				select @custom_error_code=@@error
		
				if(@debug_flag="Y")   
				begin   
					insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
				end   
	
				return @custom_error_code
			end   
	end
	*/

	
	/*   
	#<doc>   
	#	get last business date from si_batch_loader_status   
	#	batch_loader_status table record 'taccount_history' is updated at end of bpsa transaction loading   
	#	the data date in this control record determine how transaction history is   
	#	to be retrieved from txn_hist_online table and taccount_history.    
	#</doc>   
	*/   
	
	if exists (select * from #<oc>..si_batch_loader_status where table_name = 'taccount_history' )   
	begin   
		select 
			@last_data_date = isnull(max(last_data_date),convert(char(8),getdate(),112)) 
		from   
			#<oc>..si_batch_loader_status    
		where  
			table_name = 'taccount_history'    
	end   
	
		
	select 	
		a.branch_num   branch_cd,   
		a.account_num  account_cd,   
		a.currency_code currency_cd,   
		a.acct_type type_account_cd,   
		case 
			when a.trid = "G" then "A"   
			else a.trid   
		end type_tran_ch_cd,   
		case    
			when ((a.trid = "C" and a.entry_code = "DIV") or (a.trid = "D" and a.entry_code = "INT")) then "B"   
			else a.bs_code   
		--Commented and changed column name for v11 change
		--end  action,   
		end  action_bs,   
		a.cancel_code	,   
		a.seq_no seq_nbr	,   
		convert(char(8),a.trade_date,112)        trade_dt ,   
		convert(char(8),a.settle_date,112)  trade_settle_dt,   
		a.qty	transaction_qty,	
		case    
			when a.trid = "C" or a.trid = "D" then (a.amt + a.withhold_tax )   
			else a.amt   
		end transaction_amt,   
		ltrim(a.sec_desc1) desc_history_txt1,
		ltrim(a.sec_desc2) desc_history_txt2,
		ltrim(a.sec_desc3) desc_history_txt3,
		ltrim(a.sec_desc4) desc_history_txt4,
		ltrim(a.sec_desc5) desc_history_txt5,
		ltrim(a.sec_desc6) desc_history_txt6,   
		a.entry_code 	entry_cd,   
		case   
			when a.batch_code = "$+" or a.entry_code = "" or a.batch_code = "XD" then "  "   
			else a.batch_code   
		end batch_cd,   
		case   
			when a.price <> 0 then convert(char(9), a.price)    
			else "         "   
		end price_trd_amt_txt,   
		a.cdn_symbol cdn_symbol,
		a.us_symbol us_symbol,
		case  
			when ((a.ida_sec_no='08000') or (a.ida_sec_no='08100'))  then  
			case
				when  a.issue_currency in  ("002" ,"000") then 'ca'
				else 'us' 
			end
			when ltrim(a.cdn_symbol) is not NULL or   
				((a.issue_currency = "002" or a.issue_currency = "000") and ltrim(a.cdn_symbol) is not NULL and ltrim(a.us_symbol) is not NULL) then "ca"   
			when ltrim(a.us_symbol) is not NULL or ((a.issue_currency = "001") and ltrim(a.cdn_symbol) is not NULL and ltrim(a.us_symbol) is not NULL) then "us"   
			else "us"   
		end market,  
		isnull(convert(money,a.strike_price_amt), 0) strike_price_amt,         
		case    
			when (a.ida_sec_no='08000') then 'C'   
			when (a.ida_sec_no='08100') then 'P'   
		else  " "    
		end call_or_put,   
		isnull(convert(char(10),expiration_dt,101),"          ") expiration_dt,
		isnull(a.ods_investment_category,"") investment_category,   
		convert(char(8),a.processing_date,112) transaction_dt   ,
		a.adp_sec_num,
		a.transaction_category,
		'N' intraday_flag,
		a.debit_credit_cd,

		--Code changes on 14 Jan 2015 for SRS version 0.9
		case 
			when a.msd_class_code <> NULL then substring(a.msd_class_code,1,5) + '  ' 
			else a.msd_class_code 
		end msd_class_cd,
		substring(a.ida_sec_no,2,4) security_ida_cd
	into   
		#tmp1   
	from  
		#<oh>..txn_hist_online a  
		, #tmp_acc_number t
		--, #tmp_entry_code e
	where  
		a.branch_num  >= ""                       and   
		a.account_num >= ""                       and  
		a.branch_num  = t.branch_num              and   
		a.account_num = t.account_num              and   
		--a.entry_code like e.entry_code      and   -------- Added for MOD for multi entry code
		a.processing_date >= @start_date  and   
		a.processing_date <= @end_date  and   
		a.processing_date <= @last_data_date and   
		(a.trid <> "A" or ( a.trid = "A" and a.effective_date > @last_data_date) ) and   
		a.trid <> "Z" and a.trid <> "M"  and   
		( a.batch_code not like "Q%" or    
		(a.batch_code like "Q%" and (a.qty <> 0 or    
		((a.trid = "C" or a.trid = "D") and (a.amt + a.withhold_tax <> 0) ) or   
		((a.trid <> "C" and a.trid <> "D") and a.amt <> 0)) ) ) and   
		a.batch_code <> "CV" 
		-- Added as a part of MOD
		and a.currency_code like @currency_cd
		and a.transaction_category like ltrim(@transaction_category)
		--and	a.ods_investment_category like @investment_category
		and a.sec_desc1 + " " + a.sec_desc2 + " " + a.sec_desc3 + " " + a.sec_desc4 + " " + a.sec_desc5 + " " + a.sec_desc6 like @desc_history_txt
	
	
	
		select @syb_error_code = @@error
			
		if @syb_error_code <> 0   
		begin   
		 	
				raiserror 20021 "Query to retrieve historical transactions failed."

				select @custom_error_code=@@error
		
				if(@debug_flag="Y")   
				begin   
					insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
				end   
	
				return @custom_error_code
		end   
	
	
	if @last_data_date < @end_date   
	begin   
		--get sec desc from taccount_hist_txt for real time transaction   

		select 
			a.client_nbr,   
			a.branch_cd,      
			a.account_cd,    
			a.currency_cd,   
			a.transaction_dt,   
			a.security_adp_nbr,    
			a.type_account_cd,   
			a.type_tran_ch_cd,   
			a.seq_nbr,     
			case   
				when b.txt_line_nbr=1 then ltrim(b.desc_history_txt)    
				else convert(char(30), '')   
			end txt1,   
			case   
				when b.txt_line_nbr=2 then ltrim(b.desc_history_txt)    
				else convert(char(30), '')   
			end txt2,   
			case   
				when b.txt_line_nbr=3 then ltrim(b.desc_history_txt)    
				else convert(char(30), '')   
			end txt3,   
			case   
				when b.txt_line_nbr=4 then ltrim(b.desc_history_txt)    
				else convert(char(30), '')   
			end txt4,   
			case   
				when b.txt_line_nbr=5 then ltrim(b.desc_history_txt)    
				else convert(char(30), '')   
			end txt5,   
			case   
				when b.txt_line_nbr=6 then ltrim(b.desc_history_txt)    
				else convert(char(30), '')   
			end txt6   ,
			case    
				when a.type_tran_ch_cd = "C" and a.entry_cd = "DIV" and a.transaction_qty = 0 and a.transaction_amt < 0 then "B"   
				when a.type_tran_ch_cd = "C" and a.entry_cd = "DIV" and a.transaction_qty = 0 and a.transaction_amt >= 0 then "S"   
				when  a.transaction_amt >= 0 then "B"   
				else  "S"   
			--Commented and changed column name for v11 change
			--end   action,   
			end   action_bs,   
			isnull(convert(char(8), a.trade_dt,112), convert(char(8), a.transaction_dt, 112))                   trade_dt,   
			isnull(convert(char(8), a.trade_settle_dt,112), convert(char(8), a.transaction_dt, 112))           trade_settle_dt,   
			a.transaction_qty            transaction_qty,   
			( 0 - a.transaction_amt ) transaction_amt,  
			a.entry_cd entry_cd,   
			case    
				when a.entry_cd = "" or a.batch_cd = "$+" or a.batch_cd = "XD" then ""   
				else a.batch_cd   
			end  batch_cd,   
			a.price_trd_amt_txt          price_trd_amt_txt,   
			CASE
				WHEN sign(a.transaction_amt) = -1 THEN "C"
				ELSE "D"
			--Added new column for v11 change
			--END debit_credit_cd
			END debit_credit_cd,
			a.action action
		into   
			#descpart   
		from 
			#<bp>..taccount_history a (index taccount_history_idc),   
			#<bp>..taccount_hist_txt b (index taccount_hist_txt_idc)  ,
			#tmp_acc_number t	
		where  
			a.client_nbr	  >= ""                       and   
			a.branch_cd        >= ""                      and   
			a.account_cd       >= ""                      and   
			a.client_nbr	  = "0069"		      and   
			a.branch_cd        = t.branch_num             and   
			a.account_cd       = t.account_num            and   
			a.action 	  = "I"                       and /* note : I for real time, A for batch */   
			a.client_nbr       *= b.client_nbr             and   
			a.branch_cd        *= b.branch_cd              and   
			a.account_cd       *= b.account_cd             and   
			a.currency_cd      *= b.currency_cd            and   
			a.transaction_dt   *= b.transaction_dt         and   
			a.security_adp_nbr *= b.security_adp_nbr       and   
			a.type_tran_ch_cd  *= b.type_tran_ch_cd        and   
			a.type_account_cd  *= b.type_account_cd        and   
			a.seq_nbr          *= b.seq_nbr                
		--Commented and changed innser join to left join for v12 change	(same as single accoint sp)
		
		select @syb_error_code = @@error
			
		if @syb_error_code <> 0   
		begin   
		 	
				raiserror 20022 "Query to retrieve security description failed."

				select @custom_error_code=@@error
		
				if(@debug_flag="Y")   
				begin   
					insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
				end   
	
				return @custom_error_code
		end  
	
		
		--combine desc lines into single line   

		select 	
			client_nbr,   
			branch_cd,      
			account_cd,    
			currency_cd,   
			transaction_dt,   
			security_adp_nbr,    
			type_account_cd,   
			type_tran_ch_cd,   
			seq_nbr,  
			max(txt1) sec_desc1,
			max(txt2) sec_desc2,
			max(txt3) sec_desc3,
			max(txt4) sec_desc4,
			max(txt5) sec_desc5,
			max(txt6) sec_desc6,
			--Commented and changed column name for v11 change
			--max(action)	action,
			max(action_bs)	action_bs,
			max(trade_dt)	trade_dt,
			max(trade_settle_dt)	trade_settle_dt,
			max(transaction_qty)	transaction_qty,
			max(transaction_amt)	transaction_amt,
			max(entry_cd)	entry_cd,
			max(batch_cd)	batch_cd,
			max(price_trd_amt_txt)	price_trd_amt_txt,
			--Added new column for v11 change
			--max(debit_credit_cd)	debit_credit_cd
			max(debit_credit_cd)	debit_credit_cd,
			max(action) action
		into   
			#desc   
		from   
			#descpart   
		group by 
			client_nbr,branch_cd,account_cd,currency_cd,transaction_dt,security_adp_nbr,type_tran_ch_cd,type_account_cd,seq_nbr   
		
		
		
		select @syb_error_code = @@error
			
		if @syb_error_code <> 0   
		begin   
		 	
				raiserror 20023 "Query to combine security description failed."

				select @custom_error_code=@@error
		
				if(@debug_flag="Y")   
				begin   
					insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
				end   
	
				return @custom_error_code
		end   
		
		-- retrieve real time transaction from taccount_history table   

		select 
			b.branch_cd                  ,   
			b.account_cd                 ,   
			b.currency_cd                ,   
			b.type_account_cd            ,   
			b.type_tran_ch_cd            ,   
			--Commented and changed column name for v11 change			
			--b.action, 
			b.action_bs,			
			""    cancel_code,   
			convert(char(4), b.seq_nbr)  seq_nbr,   
			b.trade_dt,   
			b.trade_settle_dt,   
			b.transaction_qty            transaction_qty,   
			b.transaction_amt,  
			b.sec_desc1 desc_history_txt1,
			b.sec_desc2 desc_history_txt2,
			b.sec_desc3 desc_history_txt3,
			b.sec_desc4 desc_history_txt4,
			b.sec_desc5 desc_history_txt5,
			b.sec_desc6 desc_history_txt6,
			b.entry_cd entry_cd,   
			b.batch_cd,   
			b.price_trd_amt_txt          price_trd_amt_txt,   
			c.cdn_symbol cdn_symbol,
			c.us_symbol us_symbol,
			case  
				when ltrim(c.cdn_symbol) is not NULL or   
				((c.issue_currency = "002" or c.issue_currency = "000") and ltrim(c.cdn_symbol) is not NULL and   
				ltrim(c.us_symbol) is not NULL)   
				then "ca"   
				when ltrim(c.us_symbol) is not NULL or   
				((c.issue_currency = "001") and ltrim(c.cdn_symbol) is not NULL and   
				ltrim(c.us_symbol) is not NULL)   
				then "us"   
				else "us"   
			end market,   
			c.ods_investment_category investment_category,   
			b.security_adp_nbr,   
			convert(char(8), b.transaction_dt, 112) transaction_dt,
			'' transaction_category,
			'Y' intraday_flag,
			b.debit_credit_cd,
			--Code changes on 14 Jan 2015 for SRS version 0.9
			(m.msd_class1_cd + m.msd_class2_cd + m.msd_class3_cd + m.msd_class4_cd + m.msd_class5_cd + m.msd_class6_cd + m.msd_class7_cd) as 'msd_class_cd',
			m.security_ida_cd
		into   
			#tmp3   
		from 
			--#<bp>..taccount_history a (index taccount_history_idc),   
			#desc b  ,
			#<od>..od_security_master c (index od_security_master_ind0),   
			--#tmp_acc_number t,
			#<bp>..tmsd_base m
		where  
			b.client_nbr	  = "0069"		     and   
			b.action		  = "I"			     and /* I for real time, A for batch */   
			b.type_tran_ch_cd  <> "Z" 		      and   
			b.type_tran_ch_cd  <> "M" 		      and   
			( b.batch_cd 	  not like "Q%" 	      or   
			( b.batch_cd	  like "Q%" and    
			( b.transaction_qty <> 0 or b.transaction_amt <> 0 )) ) and    
			b.batch_cd 	  <> "CV" 		      and   
			--	Commented by TCS on 11th Jan 2013 to remove filtering of currency code
			--	a.currency_cd in ("000","001","002")  and    
			--c.adp_sec_num      >= ""                      and   
			b.security_adp_nbr *= c.adp_sec_num   		    and
			b.security_adp_nbr *= m.security_adp_nbr
		
		
		
		
		select @syb_error_code = @@error
			
		if @syb_error_code <> 0   
		begin   
		 	
				raiserror 20024 "Query to retrieve real time transactions failed."

				select @custom_error_code=@@error
		
				if(@debug_flag="Y")   
				begin   
					insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
				end   
	
				return @custom_error_code
		end
		
		--add option data to real time transaction   
		
		select 
			a.branch_cd,   
			a.account_cd,   
			a.currency_cd,   
			a.type_account_cd,   
			a.type_tran_ch_cd,   
			--Commented and changed column name for v11 change				
			--a.action, 
			a.action_bs, 			
			a.cancel_code,   
			a.seq_nbr,   
			a.trade_dt,   
			a.trade_settle_dt,   
			a.transaction_qty,   
			a.transaction_amt,   
			a.desc_history_txt1 ,		
			a.desc_history_txt2 ,	
			a.desc_history_txt3 ,	
			a.desc_history_txt4 ,	
			a.desc_history_txt5 ,	
			a.desc_history_txt6 ,	
			convert(varchar(3), isnull(ltrim(rtrim(a.entry_cd)),"")) entry_cd,   
			convert(varchar(2), isnull(ltrim(rtrim(a.batch_cd)),"")) batch_cd,   
			a.price_trd_amt_txt,   
			a.cdn_symbol cdn_symbol,
			a.us_symbol us_symbol,
			case  
				when (c.security_ida_cd = '8000' or c.security_ida_cd = '8100') then    
				case  
					when c.currency_cd in ('000', '002') then 'ca'  
					else 'us'  
				end  
				else  a.market  
			end market,  
			case   
				when (c.security_ida_cd = '8000' or c.security_ida_cd = '8100')  then   
				case   
					when b.strike_price_amt is not NULL and b.strike_price_amt <> 0 then convert(money, b.strike_price_amt)     
					else convert(money,0)   
				end    
				else convert(money,0)   
			end  strike_price_amt,        		   
			case   
				when c.security_ida_cd  = '8000'  then 'C'    
				when c.security_ida_cd  = '8100'  then 'P'    
				else   " "   
			end call_or_put,            
			case   
				when (c.security_ida_cd = '8000' or c.security_ida_cd = '8100')   then isnull(upper(convert(char(10),b.expiration_dt,101)),'          ')   
				else  "  "   
			end  expiration_dt,   
			isnull(a.investment_category,"") investment_category,               
			a.transaction_dt,
			a.security_adp_nbr,
			a.transaction_category,
			a.intraday_flag,
			a.debit_credit_cd,
			--Code changes on 14 Jan 2015 for SRS version 0.9
			a.msd_class_cd,
			a.security_ida_cd
		into   
			#tmp4	   
		from   
			#tmp3 a,    
			#<bp>..tmsd_base c (index tmsd_base_idc),          /* Code modified by TCS for CWMT Essentials 2012 */   
			#<bp>..toption_data b (index toption_data_idc )   
		where  
			b.security_adp_nbr >= ""                 and   
			a.security_adp_nbr *= b.security_adp_nbr and   
			a.security_adp_nbr *= c.security_adp_nbr  	/* Code modified by TCS for CWMT Essentials 2012 */   
		
		
		
		
		select @syb_error_code = @@error
			
		if @syb_error_code <> 0   
		begin   
		 	
				raiserror 20025 "Query to retrieve option data for real time transaction failed."

				select @custom_error_code=@@error
		
				if(@debug_flag="Y")   
				begin   
					insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
				end   
	
				return @custom_error_code
		end   
		
		
		--combine transaction history + real time transaction  and return to caller sort by br, acct and trade date (decending order for trade date )   
	
		select 
			#tmp4.branch_cd,
			#tmp4.account_cd,
			#tmp4.currency_cd,
			#tmp4.type_account_cd,
			#tmp4.type_tran_ch_cd,
			--Commented and changed column name for v11 change	
			--#tmp4.action,
			#tmp4.action_bs as action,
			#tmp4.cancel_code,
			#tmp4.seq_nbr,
			#tmp4.trade_dt,
			#tmp4.trade_settle_dt,
			#tmp4.transaction_qty     ,
			#tmp4.transaction_amt      ,
			#tmp4.desc_history_txt1             ,
			#tmp4.desc_history_txt2             ,
			#tmp4.desc_history_txt3             ,
			#tmp4.desc_history_txt4             ,
			#tmp4.desc_history_txt5             ,
			#tmp4.desc_history_txt6             ,
			#tmp4.entry_cd,
			#tmp4.batch_cd,
			#tmp4.price_trd_amt_txt,
			#tmp4.cdn_symbol  ,
			#tmp4.us_symbol   ,
			#tmp4.security_adp_nbr,
			#tmp4.market,
			#tmp4.strike_price_amt        ,
			#tmp4.call_or_put,
			#tmp4.expiration_dt,
			#tmp4.investment_category           ,
			#tmp4.transaction_dt,
			#tmp4.transaction_category,
			#tmp4.intraday_flag,
			#tmp4.debit_credit_cd,
			--Code changes on 14 Jan 2015 for SRS version 0.9
			#tmp4.msd_class_cd,
			#tmp4.security_ida_cd
		from 
			#tmp4   
			--, #tmp_entry_code e
		where 
			transaction_dt >= @start_date   
			and transaction_dt <= @end_date    
			--and #tmp4.entry_cd like e.entry_code
			and #tmp4.currency_cd like @currency_cd
			and	#tmp4.investment_category like @investment_category
			and ( isnull(#tmp4.cdn_symbol,'') like @symbol OR isnull(#tmp4.us_symbol,'') like @symbol)
			and #tmp4.desc_history_txt1 + " " + #tmp4.desc_history_txt2 + " " + #tmp4.desc_history_txt3 + " " + #tmp4.desc_history_txt4 + " " + #tmp4.desc_history_txt5 + " " + #tmp4.desc_history_txt6 like @desc_history_txt
		union
		select 
			#tmp1.branch_cd,
			#tmp1.account_cd,
			#tmp1.currency_cd,
			#tmp1.type_account_cd,
			#tmp1.type_tran_ch_cd,
			--Commented and changed column name for v11 change
			--#tmp1.action,
			#tmp1.action_bs as action,
			#tmp1.cancel_code,
			#tmp1.seq_nbr,
			#tmp1.trade_dt,
			#tmp1.trade_settle_dt,
			#tmp1.transaction_qty     ,
			#tmp1.transaction_amt      ,
			#tmp1.desc_history_txt1             ,
			#tmp1.desc_history_txt2             ,
			#tmp1.desc_history_txt3             ,
			#tmp1.desc_history_txt4             ,
			#tmp1.desc_history_txt5             ,
			#tmp1.desc_history_txt6             ,
			#tmp1.entry_cd,
			#tmp1.batch_cd,
			#tmp1.price_trd_amt_txt,
			#tmp1.cdn_symbol  ,
			#tmp1.us_symbol   ,
			#tmp1.adp_sec_num security_adp_nbr,
			#tmp1.market,
			#tmp1.strike_price_amt        ,
			#tmp1.call_or_put,
			#tmp1.expiration_dt,
			#tmp1.investment_category           ,
			#tmp1.transaction_dt,
			#tmp1.transaction_category,
			#tmp1.intraday_flag,
			#tmp1.debit_credit_cd,
			--Code changes on 14 Jan 2015 for SRS version 0.9
			#tmp1.msd_class_cd,
			#tmp1.security_ida_cd
		from 
			#tmp1 
		where 
			( isnull(#tmp1.cdn_symbol,'') like @symbol OR isnull(#tmp1.us_symbol,'') like @symbol)
			and #tmp1.investment_category like @investment_category
		order by 
			branch_cd, account_cd, currency_cd, trade_dt desc    
		
		select @syb_error_code = @@error , @no_of_records = @@rowcount 
		
		if @syb_error_code <> 0    
		begin   
	
			raiserror 20026 "Query to provide final combined transactions failed."

			select @custom_error_code = @@error
			
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
			
			return @custom_error_code
		end   
		
		
		end  --------- end of condition---if @last_data_date < @end_date  
	
	else   
	
	begin   

		select 
			#tmp1.branch_cd,
			#tmp1.account_cd,
			#tmp1.currency_cd,
			#tmp1.type_account_cd,
			#tmp1.type_tran_ch_cd,
			--Commented and changed column name for v11 change
			--#tmp1.action,
			#tmp1.action_bs as action,
			#tmp1.cancel_code,
			#tmp1.seq_nbr,
			#tmp1.trade_dt,
			#tmp1.trade_settle_dt,
			#tmp1.transaction_qty     ,
			#tmp1.transaction_amt      ,
			#tmp1.desc_history_txt1             ,
			#tmp1.desc_history_txt2             ,
			#tmp1.desc_history_txt3             ,
			#tmp1.desc_history_txt4             ,
			#tmp1.desc_history_txt5             ,
			#tmp1.desc_history_txt6             ,
			#tmp1.entry_cd,
			#tmp1.batch_cd,
			#tmp1.price_trd_amt_txt,
			#tmp1.cdn_symbol  ,
			#tmp1.us_symbol   ,
			#tmp1.adp_sec_num security_adp_nbr,
			#tmp1.market,
			#tmp1.strike_price_amt        ,
			#tmp1.call_or_put,
			#tmp1.expiration_dt,
			#tmp1.investment_category           ,
			#tmp1.transaction_dt,
			#tmp1.transaction_category,
			#tmp1.intraday_flag,
			#tmp1.debit_credit_cd,
			--Code changes on 14 Jan 2015 for SRS version 0.9
			#tmp1.msd_class_cd,
			#tmp1.security_ida_cd
		from 
			#tmp1 
		where 
			( isnull(#tmp1.cdn_symbol,'') like @symbol OR isnull( #tmp1.us_symbol,'') like @symbol)
			and #tmp1.investment_category like @investment_category
		order by 
			branch_cd, account_cd, currency_cd, trade_dt desc   
		
		select @syb_error_code = @@error , @no_of_records = @@rowcount 
		
		if @syb_error_code <> 0    
		begin   
	
			raiserror 20027 "Query to provide final historical transactions failed."

			select @custom_error_code = @@error
			
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
			
			return @custom_error_code
		end   
		
	end 

	if(@debug_flag="Y")   
	begin   
			insert into #<oc>..si_transaction_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 ) 
	end   
			
	return 0	
	
END   


go 

Grant Execute on dbo.sp_tran_multi_accnt_service to spica_ws 
go



