-----Version V4 : MFT+1 + DI Enhancements and Performance Improvement
-----Version V3 : Added new column 'Timestamp' for service_call_type INT and CMB and removed condition action = 'A' for PRV
-----Version v2 : changed the error handling and addition os optimization goal
-----Version v1 : base version


use #<oc>
go

use #<oc>
go

declare @ext int , @user varchar(255), @cdate datetime 
set @ext = 0
set @user = suser_name()
set @cdate = getdate()
select @ext = count(*) from #<oc>..si_service_debug_config where service_id = 'sp_position_service' 
if (@ext < 1)
begin
insert into #<oc>..si_service_debug_config(service_id,client_id,debug_flag,description,created_by,created_date,modified_by,modified_date)
values('sp_position_service','TradeLink','Y','Advanced Position Service',@user,@cdate,@user,@cdate)
end
else
begin
update #<oc>..si_service_debug_config set debug_flag = 'Y',modified_by=@user,modified_date=@cdate where service_id = 'sp_position_service'
end
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_position_service' )
begin
	drop procedure sp_position_service
end
go


create proc sp_position_service
@branch_cd char(3),
@account_cd	char(5) ,
@service_call_type	char(3) ,
@app_id	char(10),
@line_of_business	char(10),
@req_time_stamp char(25)
AS


declare
        @start_time             datetime,
        @proc_name              varchar(35),
        @input_parm    			varchar(75),
        @debug_flag             char(1),
	@syb_error_code         int ,
	@custom_error_code      int,
	@no_of_records          int,
	@action1				char(1),
	@action2				char(1)

BEGIN

	--set plan optgoal allrows_oltp
	-- set compatibility_mode on
        set plan optlevel ase_default
	
	select
		@debug_flag = debug_flag
	FROM
		#<oc>..si_service_debug_config
	WHERE
		service_id='sp_position_service'
	
	 
	
	if(@debug_flag='Y')
	begin
		select @start_time=getdate()
		select @proc_name=object_name(@@procid)
		select @input_parm = @branch_cd+","+ @account_cd + "," + @service_call_type+","+ @app_id+","+ @line_of_business+","+ @req_time_stamp
	end
	
	 
	
	if ( @service_call_type = 'CMB' )
	begin
		select @action1 = '%' , @action2 = '%'
	end
	
	
	if ( @service_call_type = 'INT' )
	begin
		select @action1 = 'I' , @action2 = 'U'
	end
	
	-- Create #final_result T+1 Change 
	CREATE TABLE #final_result
	(
	   branch_cd                    char(3)         NULL,
	   account_cd                   char(5)         NULL,
	   currency_cd                  char(3)         NULL,
	   type_account_cd              char(1)         NULL,
	   cdn_symbol                   char(20)        NULL,
	   us_symbol                    char(20)        NULL,
	   market                       varchar(2)      NULL,
	   security_adp_nbr             char(7)         NULL,
	   desc_sec_txt_e1              char(30)        NULL,
	   desc_sec_txt_e2              char(30)        NULL,
	   desc_sec_txt_e3              char(30)        NULL,
	   security_ida_cd              char(4)         NULL,
	   msd_class_cd                 varchar(7)      NULL,
	   investment_category          varchar(30)     NULL,
	   call_or_put                  varchar(1)      NULL,
	   expiration_dt                varchar(10)     NULL,
	   strike_price_amt             decimal(16,8)   NULL,
	   trade_dt_qty_yesterday       decimal(17,5)   NULL,
	   today_total_qty_delta        decimal(17,5)   NULL,
	   today_total_qty_combined     decimal(18,5)   NULL,
	   market_value_amt             decimal(17,2)   NULL,
	   holder_price_txt             char(11)        NULL,
	   maturity_dt                  char(10)        NULL,
	   interest_rt                  decimal(11,8)   NULL,
	   action                       char(1)         NULL,
	   bk_cost_amt                  decimal(17,2)   NULL,
	   position_margin              decimal(38,2)   NULL,
	   activity_last_dt             char(10)        NULL,
	   settlement_dt_qty_yesterday  decimal(17,5)   NULL,
	   settlement_dt_qty_combined   decimal(18,5)   NULL,
	   rr_cd                        char(3)         NULL,
	   desc_sec_txt_f1              char(30)        NULL,
	   desc_sec_txt_f2              char(30)        NULL,
	   desc_sec_txt_f3              char(30)        NULL,
	   royalty_ind                  char(1)         NULL,
	   remic_ind                    char(1)         NULL,
	   reit_ind                     char(1)         NULL,
	   uts_canadian_cd              char(1)         NULL,
	   etf_ind                      char(1)         NULL,
	   annuity_cd                   char(1)         NULL,
	   cmo_ind                      char(1)         NULL,
	   pool_nbr                     char(8)         NULL,
	   bk_cost_amt_org              decimal(17,2)   NULL,
	   err_cd_trade_dt              char(2)         NULL,
	   lmu_dt_ind_trade_dt          char(1)         NULL,
	   msd_price                    numeric(16,4)   NULL,
	   isin                         varchar(20)     NULL,
	   dated_dt                     char(10)        NULL,
	   date_coupon_cd               char(4)         NULL,
	   class_level_one              char(3)         NULL,
	   class_level_two              char(3)         NULL,
	   class_level_three            char(3)         NULL,
	   class_level_four             char(3)         NULL,
	   acc_int_td					decimal(17,2)   NULL,
	   updt_last_tmstp              datetime        NULL
	)  
	
	
	
	-- Create #tmp_fxrate T+1 Change 
	--select currency_cd,cnvrt_trd_crrna_rt into #tmp_fxrate from #<sb>..si_fxrate having processing_dt =  max(cast(processing_dt as date))
	declare @mxprocessingdt varchar(10)
	select top 1 @mxprocessingdt =convert(varchar(10),BUSINESS_DATE,101)
	from #<sb>..SPICA_TABLE_LOAD_STATUS 
	where TABLE_NAME = 'si_fxrate'
	and STATUS = 'GOOD'
	order by BUSINESS_DATE desc
	select currency_cd,cnvrt_trd_crrna_rt into #tmp_fxrate from spica_batch..si_fxrate where processing_dt =  @mxprocessingdt
	
	
	
	if ( @service_call_type = 'CMB' ) OR ( @service_call_type = 'INT' )
	begin
	
		SELECT
			tsechldr.client_nbr,
			tsechldr.branch_cd,
			tsechldr.account_cd,
			tsechldr.currency_cd,
			tsechldr.type_account_cd,
			tsechldr.security_adp_nbr,
			--Code changes by TCS on Jun 10			
			CASE
				WHEN ( patindex("%[^0-9.-]%", tsechldr.holder_price_txt) > 0) THEN convert(money,0)
				ELSE convert(money,tsechldr.holder_price_txt)
			END holder_price_txt_num,			
			--As it is value from BPSA
			tsechldr.holder_price_txt,			
			tsechldr.trade_dt_qty,
			tsechldr.today_total_qty,
			tsechldr.market_value_amt,
			tsechldr.mrgn_hous_rqmt_amt,
			tsechldr.activity_last_dt,
			tsechldr.settlement_dt_qty,
			tsechldr.rr_cd,
			tsechldr.action,
			tsechldr.updt_last_tmstp
		INTO #tmp1		
		FROM
			#<bp>..taccount_sec_hldr tsechldr
		WHERE
			tsechldr.client_nbr = '0069'
			AND tsechldr.branch_cd = @branch_cd
			AND tsechldr.account_cd = @account_cd
			AND ( tsechldr.action like ( @action1) OR tsechldr.action like ( @action2 ))
	
	
	
	
		-----------------DI Enhancements MFT+1----------------------
		-- Getting new Positions using si security -- T+1 Change

		select distinct a.* into #tmp_new_taccsechldrm
		from #tmp1 a left join #<sb>..si_security sisec on a.security_adp_nbr = sisec.security_adp_nbr 
		where sisec.security_adp_nbr is null
		 
		-- Getting count of new Positions  -- T+1 Change
		
		declare @newpositioncount int 
		set @newpositioncount = 0
		select  @newpositioncount = count(*) from #tmp_new_taccsechldrm	 
		 
		
	if @newpositioncount > 0 
	begin
	   insert into #final_result
		SELECT a.branch_cd,
			a.account_cd,
			a.currency_cd,
			a.type_account_cd,
			e.cross_reference_cd cdn_symbol,
			f.cross_reference_cd us_symbol,
			CASE
				WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN
				CASE
					WHEN b.currency_cd in ('000','002') then  'ca'
					ELSE 'us'
				END
				WHEN ltrim(e.type_xref_cd) IS NOT NULL and ltrim(f.type_xref_cd) IS NULL THEN "ca"
				WHEN ltrim(e.type_xref_cd) IS NULL and ltrim(f.type_xref_cd) IS NOT NULL  THEN "us"
				WHEN ltrim(e.type_xref_cd) IS NULL and ltrim(f.type_xref_cd) IS NULL THEN
				CASE
					WHEN b.currency_cd in ('000','002') then 'ca'
					ELSE 'us'
				END
				WHEN ltrim(e.type_xref_cd) IS NOT NULL and ltrim(f.type_xref_cd) IS NOT NULL  then
				CASE
					WHEN a.currency_cd in ('000','002') THEN 'ca'
					WHEN a.currency_cd = '001' THEN 'us'
					WHEN a.currency_cd NOT in ('000','001','002') AND b.currency_cd in ('000','002') THEN 'ca'
					ELSE 'us'
				END
			END market ,
			a.security_adp_nbr,
			g.desc_sec_txt desc_sec_txt_e1,
			h.desc_sec_txt desc_sec_txt_e2,
			i.desc_sec_txt desc_sec_txt_e3,
			b.security_ida_cd,
			b.msd_class1_cd+b.msd_class2_cd+b.msd_class3_cd+b.msd_class4_cd+b.msd_class5_cd+b.msd_class6_cd+b.msd_class7_cd msd_class_cd,
			sm.ods_investment_category investment_category ,
			CASE
				WHEN b.security_ida_cd = '8000' THEN 'C'
				WHEN b.security_ida_cd = '8100' THEN 'P'
			END call_or_put,
			CASE	
				WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN convert(char(10),op.expiration_dt,101) 
			END expiration_dt,
			CASE
				WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN op.strike_price_amt
			END strike_price_amt ,
			a.trade_dt_qty trade_dt_qty_yesterday,
			a.today_total_qty today_total_qty_delta,
			a.trade_dt_qty + a.today_total_qty today_total_qty_combined,
			CASE
				--Added by TCS on 19th May
				--Code changes by TCS on 10 Jun
				WHEN sm.ods_investment_category = 'FUNDS' THEN CONVERT(decimal(17,2), a.holder_price_txt_num * a.trade_dt_qty)
				WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN CONVERT(decimal(17,2), convert(money,a.holder_price_txt_num) * a.trade_dt_qty * isnull(op.factor_pct,100))
				ELSE a.market_value_amt
			END market_value_amt,			
			a.holder_price_txt,		 
			convert(char(10),bo.maturity_dt,101) maturity_dt,
			bo.interest_rt interest_rt,
			a.action,
			CASE
				WHEN c.err_cd = 'SE' or c.err_cd = 'ME' or c.err_cd = 'RE' or c.err_cd = 'XE' then 0
				ELSE c.bk_cost_amt
			END  bk_cost_amt,
			CASE
				WHEN  b.security_ida_cd ='8000' OR b.security_ida_cd ='8100'  THEN d.house_rqrmt_amt
				ELSE a.mrgn_hous_rqmt_amt
			END position_margin ,
			convert(char(10),a.activity_last_dt,101) activity_last_dt,
			a.settlement_dt_qty settlement_dt_qty_yesterday,
			a.settlement_dt_qty + a.today_total_qty settlement_dt_qty_combined,
			a.rr_cd,
			j.desc_sec_txt desc_sec_txt_f1,
			k.desc_sec_txt desc_sec_txt_f2,
			l.desc_sec_txt desc_sec_txt_f3,
			b.royalty_ind,
			b.remic_ind,
			b.reit_ind,
			b.uts_canadian_cd,
			b.etf_ind,
			b.annuity_cd,
			bo.cmo_ind,
			bo.pool_nbr,
			c.bk_cost_amt bk_cost_amt_org,
			c.err_cd err_cd_trade_dt,
			c.lmu_dt_ind lmu_dt_ind_trade_dt,
			0.0 msd_price,
			CASE WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN isi.cross_reference_cd else isix.cross_reference_cd end isin,
			convert(varchar(10),bo.dated_dt,101)  dated_dt,
			bo.date_coupon_cd date_coupon_cd,					
			null class_level_one,--sisec.class_level_one,
			null class_level_two,--sisec.class_level_two,
			null class_level_three,--sisec.class_level_three,
			null class_level_four,--sisec.class_level_four,	
			null acc_int_td,
			a.updt_last_tmstp
		FROM
			#tmp_new_taccsechldrm a
			LEFT OUTER JOIN #<bp>..tmsd_base b ON a.security_adp_nbr = b.security_adp_nbr
			LEFT OUTER JOIN #<bp>..tsec_xref_key e ON b.security_adp_nbr = e.security_adp_nbr and e.type_xref_cd = 'CN'
			LEFT OUTER JOIN #<bp>..tsec_xref_key f ON b.security_adp_nbr = f.security_adp_nbr and f.type_xref_cd = 'SY'
			LEFT OUTER JOIN #<sb>..tcan_mrgn_optn_vw d  ON a.client_nbr   = d.client_nbr AND
									a.branch_cd        = d.branch_cd AND
									a.account_cd       = d.account_cd AND
									a.currency_cd      = d.currency_cd AND
									a.security_adp_nbr = d.security_adp_nbr
			LEFT OUTER JOIN #<bp>..tcan_td_bk_cst_ps c  ON a.client_nbr       = c.client_nbr AND
									a.branch_cd        = c.branch_cd AND
									a.account_cd       = c.account_cd AND
									a.currency_cd      = c.currency_cd AND
									a.type_account_cd  = c.type_account_cd AND
									a.security_adp_nbr = c.security_adp_nbr
			LEFT OUTER JOIN #<bp>..tsecurity_desc g  ON b.security_adp_nbr = g.security_adp_nbr and g.language_cd='E' and g.line_txt_nbr=1
			LEFT OUTER JOIN #<bp>..tsecurity_desc h  ON b.security_adp_nbr = h.security_adp_nbr and h.language_cd='E' and h.line_txt_nbr=2
			LEFT OUTER JOIN #<bp>..tsecurity_desc i  ON b.security_adp_nbr = i.security_adp_nbr and i.language_cd='E' and i.line_txt_nbr=3
			LEFT OUTER JOIN #<bp>..tsecurity_desc j  ON b.security_adp_nbr = j.security_adp_nbr and j.language_cd='F' and j.line_txt_nbr=1
			LEFT OUTER JOIN #<bp>..tsecurity_desc k  ON b.security_adp_nbr = k.security_adp_nbr and k.language_cd='F' and k.line_txt_nbr=2
			LEFT OUTER JOIN #<bp>..tsecurity_desc l  ON b.security_adp_nbr = l.security_adp_nbr and l.language_cd='F' and l.line_txt_nbr=3	
			LEFT OUTER JOIN #<bp>..tbond_data bo 	ON b.security_adp_nbr = bo.security_adp_nbr
			LEFT OUTER JOIN #<bp>..toption_data op 	ON b.security_adp_nbr = op.security_adp_nbr
			LEFT OUTER JOIN #<bp>..tsec_xref_key isi	ON op.scrty_adp_base_nbr=isi.security_adp_nbr  AND isi.type_xref_cd = 'IS'
			LEFT OUTER JOIN #<bp>..tsec_xref_key isix	ON a.security_adp_nbr=isix.security_adp_nbr AND isix.type_xref_cd = 'IS'			
			LEFT OUTER JOIN #<od>..od_security_master sm ON b.security_adp_nbr = sm.adp_sec_num
			
			--select * from #final_result
		end
	
	
			-- Inserting result of old Positions into Temp Result table -- T+1 Change
	 	 insert into #final_result
		 SELECT  a.branch_cd,					 
		a.account_cd,
		a.currency_cd,
		a.type_account_cd,					
		sisec.cdn_symbol,
		sisec.us_symbol,
		case	WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN
			CASE
				WHEN  sisec.currency_cd IN ('000','002') THEN 'ca' 
				ELSE  'us' 
			END
			WHEN sisec.cdn_symbol IS NOT NULL AND sisec.us_symbol IS NULL THEN "ca"
			WHEN sisec.us_symbol  IS NOT NULL AND sisec.cdn_symbol IS NULL THEN "us"						
			WHEN sisec.cdn_symbol IS NULL AND sisec.us_symbol IS NULL THEN  
			CASE
				WHEN sisec.currency_cd IN ('000','002') THEN 'ca'
				ELSE 'us'
			END
			WHEN sisec.cdn_symbol IS NOT NULL AND sisec.us_symbol IS NOT NULL THEN
			CASE
				WHEN a.currency_cd IN ('000','002') THEN 'ca'
				WHEN a.currency_cd = '001' THEN 'us'
				WHEN a.currency_cd NOT IN ('000','001','002') AND sisec.currency_cd IN ('000','002') THEN 'ca'
				ELSE 'us'
			END
		END market ,
		a.security_adp_nbr, 
		sisec.desc_sec_txt_e1 ,
		sisec.desc_sec_txt_e2 ,
		sisec.desc_sec_txt_e3 ,
		sisec.security_ida_cd ,
		sisec.msd_class_cd,					 
		sisec.investment_category,
		sisec.call_or_put,
		sisec.expiration_dt,
		sisec.strike_price_amt, 
		a.trade_dt_qty trade_dt_qty_yesterday,
		a.today_total_qty today_total_qty_delta,
		a.trade_dt_qty + a.today_total_qty today_total_qty_combined,
		CASE			
			WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN CONVERT(decimal(17,2), convert(money,a.holder_price_txt_num) * a.trade_dt_qty * isnull(sisec.factor_pct,100))
			ELSE a.market_value_amt
		END market_value_amt,
					a.holder_price_txt,
					sisec.maturity_dt,				 
					sisec.interest_rt,
					a.action,
					CASE
						WHEN o.err_cd = 'SE' OR o.err_cd = 'ME' OR o.err_cd = 'RE' OR o.err_cd = 'XE' THEN 0
						ELSE o.bk_cost_amt
					END  bk_cost_amt,
					CASE
						WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100'  THEN d.house_rqrmt_amt
						ELSE a.mrgn_hous_rqmt_amt
					END position_margin,
					convert(char(10),a.activity_last_dt,101) activity_last_dt,
					a.settlement_dt_qty settlement_dt_qty_yesterday,
					a.settlement_dt_qty + a.today_total_qty settlement_dt_qty_combined,
					a.rr_cd,
					sisec.desc_sec_txt_f1,
					sisec.desc_sec_txt_f2,
					sisec.desc_sec_txt_f3,
					sisec.royalty_ind ,
					sisec.remic_ind ,	
					sisec.reit_ind,		
					sisec.uts_canadian_cd,	
					sisec.etf_ind,		
					sisec.annuity_cd,	
					sisec.cmo_ind,	
					sisec.pool_nbr,
					o.bk_cost_amt bk_cost_amt_org,
					o.err_cd err_cd_trade_dt,
					o.lmu_dt_ind lmu_dt_ind_trade_dt,					
					case WHEN isnull(p.price,0.0) = 0.0 then 0.0 when a.currency_cd = '000' then convert(decimal(16,4),p.price) else convert(decimal(16,4),p.price/fx.cnvrt_trd_crrna_rt) end as msd_price,						
					CASE WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN sisecy.isin else sisec.isin end isin,					
					sisec.dated_dt,
					sisec.date_coupon_cd,					 
					sisec.class_level_one,
					sisec.class_level_two,
					sisec.class_level_three,
					sisec.class_level_four,
					null acc_int_td,
					a.updt_last_tmstp
					 
	FROM 
		#tmp1 a
		left join       #tmp_new_taccsechldrm np		on 	a.security_adp_nbr = np.security_adp_nbr AND
															a.client_nbr       = np.client_nbr AND
															a.branch_cd        = np.branch_cd  AND
															a.account_cd       = np.account_cd AND
															a.currency_cd      = np.currency_cd  	
		LEFT OUTER JOIN #<sb>..si_security  sisec  		ON a.security_adp_nbr = sisec.security_adp_nbr
		LEFT OUTER JOIN #<sb>..si_security  sisecy      ON sisecy.security_adp_nbr = sisec.scrty_adp_base_nbr															
		LEFT OUTER JOIN #<bp>..tcan_td_bk_cst_ps  o		ON	a.client_nbr       =  o.client_nbr		AND 
															a.branch_cd        = o.branch_cd 		AND
															a.account_cd       = o.account_cd 		AND
															a.currency_cd      = o.currency_cd 		AND
															a.type_account_cd  = o.type_account_cd	AND
															a.security_adp_nbr = o.security_adp_nbr 													
		LEFT OUTER JOIN #<sb>..si_security_price p		 ON	a.security_adp_nbr = p.security_adp_nbr 		
		LEFT OUTER JOIN #tmp_fxrate fx 					ON  a.currency_cd = fx.currency_cd		
		LEFT OUTER JOIN #<sb>..tcan_mrgn_optn_vw d  ON a.client_nbr   = d.client_nbr AND
									a.branch_cd        = d.branch_cd AND
									a.account_cd       = d.account_cd AND
									a.currency_cd      = d.currency_cd AND
									a.security_adp_nbr = d.security_adp_nbr
		where np.security_adp_nbr is null and (sisec.security_adp_nbr > '')
	 
	
	
			
	    select * from #final_result
		select @syb_error_code = @@error , @no_of_records = @@rowcount

	end

	
	
	

	if ( @service_call_type = 'PRV' )
	begin
	
		select
			a.branch_cd,
			a.account_cd,
			a.currency_cd,
			a.type_account_cd,
			a.market,
			a.security_adp_nbr,
			a.trade_dt_qty ,
			a.today_total_qty ,
			a.today_total_qty_combined ,
			a.market_value_amt,
			a.holder_price_txt,
			a.action,
			a.bk_cost_amt_trade_dt , 
			a.position_margin,
			a.activity_last_dt,
			a.settlement_dt_qty ,
			a.settlement_dt_qty_combined,
			a.rr_cd,  
			a.bk_cost_amt_trade_dt_org ,
			a.err_cd_trade_dt,
			a.lmu_dt_ind_trade_dt,
			a.modify_timestamp	
		into #si_position_tmp from #<sb>..si_position a
		where a.branch_cd = @branch_cd
		AND a.account_cd = @account_cd
		
		SELECT 
			a.branch_cd,
			a.account_cd,
			a.currency_cd,
			a.type_account_cd,
			s.cdn_symbol,
			s.us_symbol,
			a.market,
			a.security_adp_nbr,
			s.desc_sec_txt_e1,
			s.desc_sec_txt_e2,
			s.desc_sec_txt_e3,
			s.security_ida_cd, 
			s.msd_class_cd,
			s.investment_category,
			s.call_or_put,
			s.expiration_dt,
			s.strike_price_amt,
			a.trade_dt_qty trade_dt_qty_yesterday,
			a.today_total_qty today_total_qty_delta,
			a.today_total_qty_combined ,
			--Added by TCS on 19th May
			--a.market_value_amt
			--Changed by TCS on Jun 10 converting holder_price_txt to numeric for calculation			
			CASE						
				WHEN s.investment_category = 'FUNDS' AND (patindex("%[^0-9.-]%", a.holder_price_txt) = 0) THEN CONVERT(decimal(17,2), convert(money,a.holder_price_txt) * a.trade_dt_qty)
				WHEN s.investment_category = 'FUNDS' AND (patindex("%[^0-9.-]%", a.holder_price_txt) > 0) THEN CONVERT(decimal(17,2), 0)
				ELSE a.market_value_amt
			END	market_value_amt, 
			a.holder_price_txt,
			s.maturity_dt,
			s.interest_rt,
			a.action,
			--Code changes on 16 June
			--a.bk_cost_amt,
			a.bk_cost_amt_trade_dt bk_cost_amt, 
			a.position_margin,
			a.activity_last_dt,
			a.settlement_dt_qty settlement_dt_qty_yesterday,
			a.settlement_dt_qty_combined,
			a.rr_cd, 
			s.desc_sec_txt_f1,
			s.desc_sec_txt_f2,
			s.desc_sec_txt_f3,
			s.royalty_ind,
			s.remic_ind,
			s.reit_ind,
			s.uts_canadian_cd,
			s.etf_ind,
			s.annuity_cd,
			s.cmo_ind,
			s.pool_nbr,
			a.bk_cost_amt_trade_dt_org bk_cost_amt_org,
			a.err_cd_trade_dt,
			a.lmu_dt_ind_trade_dt,
			case when isnull(p.price,0.0) = 0.0 then 0.0 when a.currency_cd = '000' then convert(decimal(16,4),p.price) else convert(decimal(16,4),p.price/fx.cnvrt_trd_crrna_rt) end as msd_price,
				CASE WHEN s.security_ida_cd ='8000' OR s.security_ida_cd ='8100' then sisecy.isin else s.isin end isin,
				s.dated_dt,
				s.date_coupon_cd,
				s.class_level_one,
				s.class_level_two,
				s.class_level_three,
				s.class_level_four,
				null acc_int_td,--it.accrued_interest_td,
				a.modify_timestamp updt_last_tmstp			 
		FROM
			#si_position_tmp a ,
			#<sb>..si_security s,
			#<sb>..si_security sisecy ,
			#<sb>..si_security_price p,
			#tmp_fxrate fx	
		WHERE	
			a.branch_cd = @branch_cd
			AND a.account_cd = @account_cd
			AND a.security_adp_nbr *= s.security_adp_nbr
			AND s.scrty_adp_base_nbr *= sisecy.security_adp_nbr
			AND a.security_adp_nbr *= p.security_adp_nbr
			AND a.currency_cd *= fx.currency_cd
		--	AND a.action = 'A'
	
	
		select @syb_error_code = @@error , @no_of_records = @@rowcount

	end

	
	if ( @syb_error_code <> 0 ) 
	begin
		if ( @service_call_type = 'CMB')
		begin
			raiserror 20041 "Query to retrieve combined positions detail failed."
			select @custom_error_code=@@error
		end
		if ( @service_call_type = 'INT')
		begin
			raiserror 20042 "Query to retrieve intraday positions detail failed."
			select @custom_error_code=@@error
		end
		if ( @service_call_type = 'PRV')
		begin
			raiserror 20043 "Query to retrieve previous day positions detail failed."
			select @custom_error_code=@@error
		end

		if(@debug_flag="Y")
		begin
			insert into #<oc>..si_position_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		end

		return @custom_error_code
	end


	if(@debug_flag="Y")
	begin
		insert into #<oc>..si_position_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 )
	end

	return 

	
END
go
		
grant Execute  on sp_position_service to spica_ws 
go

