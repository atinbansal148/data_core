use #<oc>
go

IF OBJECT_ID('dbo.sp_marketvalue_multi_accnt_service') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.sp_marketvalue_multi_accnt_service
    IF OBJECT_ID('dbo.sp_marketvalue_multi_accnt_service') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.sp_marketvalue_multi_accnt_service >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.sp_marketvalue_multi_accnt_service >>>'
END
go
create procedure dbo.sp_marketvalue_multi_accnt_service
@account	varchar(810) ,
@app_id	char(10),
@line_of_business	char(10),
@req_time_stamp char(25),
@transaction_id varchar(40)
AS


declare
        @start_time             datetime,
        @proc_name              varchar(35),
        @input_parm    		varchar(610),
        @debug_flag             char(1),
	@syb_error_code         int ,
	@custom_error_code      int,
	@no_of_records          int,		
	@var			int,
	@accnt_length 		int

BEGIN

	set plan optgoal allrows_oltp
	set compatibility_mode on

	select
		@debug_flag = debug_flag
	FROM
		si_service_debug_config
	WHERE
		service_id= object_name(@@procid)
		
	
	if(@debug_flag='Y')
	begin
		select @start_time=getdate()
		select @proc_name=object_name(@@procid)
		select @input_parm = @account+","+ @app_id+","+ @line_of_business+","+ @req_time_stamp +","+ @transaction_id 
	end
	
	
	select @accnt_length = char_length ( @account ) 
	select @syb_error_code = @@error

    if ( ((@accnt_length%8) <> 0) OR (@syb_error_code <> 0) )
    begin
                raiserror 20064 "Incorrect account numbers passed to service."

                select @custom_error_code=@@error

                if(@debug_flag="Y")
                begin
                        insert into si_marketvalue_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records, @syb_error_code ,@custom_error_code )
                end

                return @custom_error_code
    end
	
	
		
	CREATE TABLE #tmp_acc_number
	(
	branch_cd char(3) NOT NULL,
	account_cd char(5) NOT NULL
	)
	LOCK DATAROWS
	
	
	select @var = 1
	
	while ( @var < @accnt_length )
	begin
		insert into #tmp_acc_number values ( substring(@account,@var,3) , substring(@account,@var+3,5) )
		
		select @syb_error_code = @@error
			 
		if @syb_error_code <> 0
        begin

            raiserror 20065 "Query to process multiple account list failed."

            select @custom_error_code=@@error

			if(@debug_flag="Y")
			begin
                insert into si_marketvalue_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
            end

            return @custom_error_code
        end
		
		select @var = @var + 8
	end
	
	select
		siv.branch_cd,
		siv.account_cd,
		siv.rr_cd,
		siv.currency_cd,
		siv.market_value_amt,
		siv.book_value_amt,
		siv.book_cost_error_ind,
		substring(siv.as_of_date, 5,2) + '/' + substring(siv.as_of_date, 7,2) + '/' + substring(siv.as_of_date, 1,4) as_of_date,
		siv.modify_timestamp updt_last_tmstp		
    from 
		#<sb>..si_marketvalue siv,
		#tmp_acc_number tan
    where 
		siv.branch_cd = tan.branch_cd
    and siv.account_cd = tan.account_cd
    
    
	select @syb_error_code = @@error , @no_of_records = @@rowcount

	
	if ( @syb_error_code <> 0 ) 
	begin
        raiserror 20099 "Query to retrieve previous day market value failed."
        select @custom_error_code=@@error

		if(@debug_flag="Y")
		begin
			insert into si_marketvalue_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		end

		return @syb_error_code
	end


	if(@debug_flag="Y")
	begin
		insert into si_marketvalue_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 )
	end

	return 

	
END
go


IF OBJECT_ID('dbo.sp_marketvalue_multi_accnt_service') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.sp_marketvalue_multi_accnt_service >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.sp_marketvalue_multi_accnt_service >>>'
go

GRANT EXECUTE ON dbo.sp_marketvalue_multi_accnt_service TO spica_ws
go
