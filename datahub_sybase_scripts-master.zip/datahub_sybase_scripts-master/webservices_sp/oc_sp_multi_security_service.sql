
use #<oc>
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_multi_security_service' )
begin
	drop procedure sp_multi_security_service
end
go


create proc sp_multi_security_service
@security_identifier_type    char(7),
@security_identifier_value   varchar(2100),
@app_id                      char(10),
@line_of_business            char(10),
@req_time_stamp              char(25),
@transaction_id              varchar(40)
AS


declare
    @start_time             datetime,
    @proc_name              varchar(35),
    @input_parm             varchar(1200),
    @debug_flag             char(1),
    @syb_error_code         int ,
    @custom_error_code      int,
    @no_of_records          int,
    @adp_sec_val            char(7),
    @isin_val               char(20),
    @cusip_val              char(20),
    @cn_sym_val             char(20),
    @us_sym_val             char(20),
	@dummy_start_time       datetime

BEGIN

	-- set plan optgoal allrows_oltp
	set compatibility_mode on 
	set plan optlevel ase_default 

	-- check logging to table 
	select @debug_flag = debug_flag FROM #<oc>..si_service_debug_config WHERE service_id='sp_multi_security_service'
	
	if(@debug_flag='Y')
	begin
		select @start_time=getdate()
		select @proc_name=object_name(@@procid)
		select @input_parm = @transaction_id+","+@security_identifier_type+","+@security_identifier_value
	end

	/*
	select @security_identifier_length = char_length ( @security_identifier_value )
	
	select @syb_error_code = @@error 
	
	if ( ((@security_identifier_length%7) <> 0) OR (@syb_error_code <> 0) )
	begin	
		raiserror 30085 "Incorrect number of security identifiers passed to service."
		select @custom_error_code=@@error
		if(@debug_flag="Y")
		begin   
			insert into #<oc>..si_security_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		end
		return @custom_error_code	
	end
	 */

	--Create temp table to hold input securities
	create table #security_adp_nbr_list ( security_adp_nbr char(7) )
    
	-- Create temp table to hold non-security input
	create table #non_security_adp_nbr_list ( non_security_adp_nbr char(20))
	
	DECLARE @pos int
	DECLARE @piece char(30)
    
	if @security_identifier_type = 'adp_sec' 
	begin
	   SELECT @pos = charindex(',' , @security_identifier_value)
	   while @pos <> 0
	   BEGIN
		  SELECT @piece = LEFT( @security_identifier_value , @pos-1 )
		   INSERT INTO #security_adp_nbr_list VALUES ( @piece)
		   SELECT @security_identifier_value = stuff( @security_identifier_value, 1, @pos, NULL )
		   SELECT @pos = charindex(',' , @security_identifier_value )
	   END
	   INSERT INTO #security_adp_nbr_list VALUES ( @security_identifier_value)
	end
	else if (    (@security_identifier_type = 'isin') or (@security_identifier_type = 'cusip') 
	          or (@security_identifier_type = 'cn_sym') or (@security_identifier_type = 'us_sym') )
	begin
	   SELECT @pos = charindex(',' , @security_identifier_value)
	   while @pos <> 0
	   BEGIN
		   SELECT @piece = LEFT( @security_identifier_value , @pos-1 )
		   INSERT INTO #non_security_adp_nbr_list VALUES ( @piece)
		   SELECT @security_identifier_value = stuff( @security_identifier_value, 1, @pos, NULL )
		   SELECT @pos = charindex(',' , @security_identifier_value )
	   END
	   INSERT INTO #non_security_adp_nbr_list VALUES ( @security_identifier_value)
	end
	else
	begin
		raiserror 30085 "Invalid security_identifier_type provided."
		select @custom_error_code=@@error	
		if(@debug_flag="Y")
		begin
			insert into #<oc>..si_security_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		end
		return @custom_error_code
	end

	if @security_identifier_type = 'adp_sec' 
	begin
      --Dummy entry to let the parser run on adp_sec condition firt to avoid any delay due to if conditions
	  select @dummy_start_time=getdate()
	end
	else if @security_identifier_type = 'isin' 		
	begin
		INSERT INTO
		#security_adp_nbr_list
		select b.security_adp_nbr 
		from #<bp>..tsec_xref_key b, #non_security_adp_nbr_list sl2
		where 
		b.type_xref_cd ='IS' 
		and b.cross_reference_cd = sl2.non_security_adp_nbr
	end
	else if @security_identifier_type = 'cusip' 		
	begin
		INSERT INTO
		#security_adp_nbr_list
		select b.security_adp_nbr 
		from #<bp>..tsec_xref_key b, #non_security_adp_nbr_list sl2
		where 
		b.type_xref_cd ='CU' 
		and b.cross_reference_cd = sl2.non_security_adp_nbr
	end
	else if @security_identifier_type = 'cn_sym' 		
	begin
		INSERT INTO
		#security_adp_nbr_list
		select b.security_adp_nbr 
		from #<bp>..tsec_xref_key b, #non_security_adp_nbr_list sl2
		where 
		b.type_xref_cd ='CN' 
		and b.cross_reference_cd = sl2.non_security_adp_nbr
	end
	else if @security_identifier_type = 'us_sym' 		
	begin
		INSERT INTO
		#security_adp_nbr_list
		select b.security_adp_nbr 
		from #<bp>..tsec_xref_key b, #non_security_adp_nbr_list sl2
		where 
		b.type_xref_cd ='SY' 
		and b.cross_reference_cd = sl2.non_security_adp_nbr
	end
	else
	begin
		raiserror 30085 "Invalid security_identifier_type provided."
		select @custom_error_code=@@error	
		if(@debug_flag="Y")
		begin
			insert into #<oc>..si_security_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		end
		return @custom_error_code
	end
	
	SELECT DISTINCT tel.client_number, 
	                tel.security_adp_nbr, 
	                tel.effct_dt, 
	                tel.trmnt_dt,
			tel.elgbl_cd
       INTO #telgbly_cd_ovrrd_tmp
       FROM #<bp>..telgbly_cd_ovrrd tel INNER JOIN #security_adp_nbr_list sec_tmp
       ON tel.security_adp_nbr = sec_tmp.security_adp_nbr
       WHERE tel.client_number = '0069'
       AND tel.security_adp_nbr > ''
	
	SELECT
		tsec.security_adp_nbr,
		tsec.issue_when_ind,
		tsec.country_cd,
		tsec.type_price_cd,
		tsec.price_sec_amt,
		tsec.price_set_dt
	INTO #tsec_price
	FROM
		#<bp>..tsec_price tsec,
		#security_adp_nbr_list t1
	WHERE
		tsec.security_adp_nbr = t1.security_adp_nbr
		AND tsec.issue_when_ind = 'N'
		
	SELECT
		ms.security_adp_nbr,
		ms.msd_class1_cd +ms.msd_class2_cd + ms.msd_class3_cd +	ms.msd_class4_cd +ms.msd_class5_cd +ms.msd_class6_cd +ms.msd_class7_cd msd_class_cd,
		ms.security_ida_cd,
		ms.currency_cd,
		ms.country_origin_cd,
		ms.royalty_ind,
		ms.remic_ind,
		ms.reit_ind,
		ms.uts_canadian_cd,
		ms.etf_ind,
		ms.issr_type_cd,
		ms.annuity_cd,
		ms.class_industry_cd,
		ms.sic_cd,
		ms.sector_cd ,
		ms.action_cd ,
		ms.updt_last_tmstp ,
		ms.expiration_dt expiration_dt_wrt,
		ms.payment_freq_cd ,
		ms.issue_dt ,
		--tsec_xref_key details
		b.cross_reference_cd cdn_symbol,
		c.cross_reference_cd us_symbol,
		d.cross_reference_cd isin,
		e.cross_reference_cd cusip,
		f.cross_reference_cd sedol,	
		convert(char(6),isnull(op.occ_optn_sym_id,'')) +  isnull(convert(char(6),op.expiration_dt,12),'      ') +
		case 
			when ms.msd_class1_cd = '6' AND ms.msd_class3_cd = '5' then 'P'
			when ms.msd_class1_cd = '6' AND ms.msd_class3_cd = '4' then 'C'
			else ' '
		end
		+ isnull( cast( (left('00000',5-len(substring(convert(varchar,op.strike_price_amt),1,(charindex(".",convert(varchar,op.strike_price_amt)))-1))) + substring(convert(varchar,op.strike_price_amt),1,(charindex(".",convert(varchar,op.strike_price_amt)))-1)) as char(5)) ,'') 
		+ isnull(substring(convert(varchar,op.strike_price_amt),(charindex(".",convert(varchar,op.strike_price_amt)))+1,3),'') option_symbology,
		--tsecurity_desc details
		g.desc_sec_txt desc_sec_txt_e1,
		h.desc_sec_txt desc_sec_txt_e2,
		i.desc_sec_txt desc_sec_txt_e3,
		j.desc_sec_txt desc_sec_txt_f1,
		k.desc_sec_txt desc_sec_txt_f2,
		l.desc_sec_txt desc_sec_txt_f3,
		--Bond Details
		convert(char(10),bo.maturity_dt,101) maturity_dt,
		bo.interest_rt,
		convert(char(10),bo.coupon_first_dt,101) coupon_first_dt,
		convert(char(10),bo.dated_dt,101) dated_dt,
		bo.dated_dt_cd,
		bo.date_coupon_cd,
		bo.evaluation_bond_cd,
		bo.cmo_ind,
		bo.pool_nbr,
		convert(char(10),bo.pay_interest_dt,101) pay_interest_dt,	
		--factor rate details
		fr.factor_rt,
		convert(char(10),fr.factor_dt,101) factor_dt,
		convert(char(10),bo.accrue_start_dt,101) accrue_start_dt,
		bo.accrue_end_dt ,
		cp.call_dt, 
		cp.call_prc_amt ,
		pp.put_dt, 
		pp.put_prc_amt,
		--Option details
		CASE
			WHEN ms.security_ida_cd = '8000' THEN 'C'
			WHEN ms.security_ida_cd = '8100' THEN 'P'
		END call_or_put,
		convert(char(10),op.expiration_dt,101) expiration_dt,
		op.strike_price_amt,
		op.factor_pct,
		op.scrty_adp_base_nbr,
		op.type_option_cd,
		op.occ_optn_sym_id,
		-- tdvdnd_sec_master details
		convert(char(10),tdv.payable_dt,101) payable_dt,
		tdv.dvdnd_rt ,
		tdv.currency_incm_cd ,
		convert(char(10),tdv.record_dt,101) record_dt,
		convert(char(10),tdv.xdte_dt,101)  xdte_dt,
		--tsec_trd_exchange details
		tec.exchange_msd_cd exchange_msd_cd_cdn,
		teu.exchange_msd_cd exchange_msd_cd_us,
		--tsecurity_rating details
		sr_m.rating_cd rating_cd_moody,
		sr_s.rating_cd 'rating_cd_s&p',			
		tc.elig_rsp_cd, 
		tc.province_cd,
		--Code changes on 14 Nov 2014
		--convert(char(10),ec.effct_dt,101) effct_dt, 
		CASE	
			WHEN ec.effct_dt <> NULL THEN 
			substring(ec.effct_dt, 6,2) +'/'+ substring(ec.effct_dt, 9,2) +'/' + substring(ec.effct_dt, 1,4) 
			ELSE
			ec.effct_dt
		END effct_dt,
			
		convert(char(10),ec.trmnt_dt,101) trmnt_dt, 
		ec.elgbl_cd,
		--Code changes on 17 Oct
		CASE
			WHEN (ms.security_ida_cd = '0460' OR ms.security_ida_cd = '0700' OR ms.security_ida_cd = '0800') THEN 'MUTUAL FUND'
			WHEN (ms.security_ida_cd = '8000' OR ms.security_ida_cd = '8100')  THEN 'OPTION'
			WHEN (ms.security_ida_cd >= '2000' AND ms.security_ida_cd != '5100')  THEN 'FIXED INCOME' 
			ELSE 'EQUITY'
		END security_classification_ida,
		--od_mutual_fund_xref details
		mf.company_code,
		mf.fund_code,
		tpc.price_sec_amt price_sec_amt_cdn_closing,
		CASE
			WHEN tpc.price_set_dt <> NULL THEN tpc.price_set_dt
			WHEN tpch.price_set_dt <> NULL THEN tpch.price_set_dt
			WHEN tpcl.price_set_dt <> NULL THEN tpcl.price_set_dt
			WHEN tpca.price_set_dt <> NULL THEN tpca.price_set_dt
			ELSE NULL
		END price_set_dt_cdn,
		tpu.price_sec_amt price_sec_amt_usd_closing,
		CASE
			WHEN tpu.price_set_dt <> NULL THEN tpu.price_set_dt
			WHEN tpuh.price_set_dt <> NULL THEN tpuh.price_set_dt
			WHEN tpul.price_set_dt <> NULL THEN tpul.price_set_dt
			WHEN tpua.price_set_dt <> NULL THEN tpua.price_set_dt
			ELSE NULL
		END price_set_dt_usd,
		thp.source_pricing_cd,
		thp.price_house_amt,
		--si_security details
		si.class_level_one,
		si.class_level_two,
		si.class_level_three,
		si.class_level_four
	From
		#<bp>..tmsd_base ms
		LEFT OUTER JOIN #<bp>..tbond_data bo 	ON ms.security_adp_nbr = bo.security_adp_nbr
		LEFT OUTER JOIN #<bp>..tfactor_rate fr 	ON ms.security_adp_nbr = fr.security_adp_nbr AND fr.periodic_cd='1'
		LEFT OUTER JOIN #<bp>..toption_data op 	ON ms.security_adp_nbr = op.security_adp_nbr
		LEFT OUTER JOIN #<bp>..tsec_trd_exchange tec ON ms.security_adp_nbr = tec.security_adp_nbr 	and tec.country_cd = 'CA' and tec.exch_primary_ind = 'Y'
		LEFT OUTER JOIN #<bp>..tsec_trd_exchange teu ON ms.security_adp_nbr = teu.security_adp_nbr 	and teu.country_cd = 'US' and teu.exch_primary_ind = 'Y'
		LEFT OUTER JOIN #<bp>..tsec_xref_key b   ON ms.security_adp_nbr = b.security_adp_nbr and b.type_xref_cd ='CN'
		LEFT OUTER JOIN #<bp>..tsec_xref_key c   ON ms.security_adp_nbr = c.security_adp_nbr and c.type_xref_cd ='SY'
		LEFT OUTER JOIN #<bp>..tsec_xref_key d   ON ms.security_adp_nbr = d.security_adp_nbr and d.type_xref_cd ='IS'
		LEFT OUTER JOIN #<bp>..tsec_xref_key e   ON ms.security_adp_nbr = e.security_adp_nbr and e.type_xref_cd ='CU'
		LEFT OUTER JOIN #<bp>..tsec_xref_key f   ON ms.security_adp_nbr = f.security_adp_nbr and f.type_xref_cd ='SD'
		LEFT OUTER JOIN #<bp>..tsecurity_desc g  ON ms.security_adp_nbr = g.security_adp_nbr and g.language_cd='E' and g.line_txt_nbr=1
		LEFT OUTER JOIN #<bp>..tsecurity_desc h  ON ms.security_adp_nbr = h.security_adp_nbr and h.language_cd='E' and h.line_txt_nbr=2
		LEFT OUTER JOIN #<bp>..tsecurity_desc i  ON ms.security_adp_nbr = i.security_adp_nbr and i.language_cd='E' and i.line_txt_nbr=3
		LEFT OUTER JOIN #<bp>..tsecurity_desc j  ON ms.security_adp_nbr = j.security_adp_nbr and j.language_cd='F' and j.line_txt_nbr=1
		LEFT OUTER JOIN #<bp>..tsecurity_desc k  ON ms.security_adp_nbr = k.security_adp_nbr and k.language_cd='F' and k.line_txt_nbr=2
		LEFT OUTER JOIN #<bp>..tsecurity_desc l  ON ms.security_adp_nbr = l.security_adp_nbr and l.language_cd='F' and l.line_txt_nbr=3
		LEFT OUTER JOIN #<bp>..tsecurity_rating sr_m   ON ms.security_adp_nbr = sr_m.security_adp_nbr and sr_m.vendor_cd='MOODY' 
		LEFT OUTER JOIN #<bp>..tsecurity_rating sr_s   ON ms.security_adp_nbr = sr_s.security_adp_nbr and sr_s.vendor_cd='S&P' 
		LEFT OUTER JOIN #<bp>..tdvdnd_sec_master tdv   ON ms.security_adp_nbr = tdv.security_adp_nbr and tdv.sequence_nbr=1 and tdv.client_nbr = '0069'
		LEFT OUTER JOIN #<od>..od_mutual_fund_xref mf  ON ms.security_adp_nbr = mf.whole_adp_sec_num						
		LEFT OUTER JOIN #<bp>..tcall_price cp ON ms.security_adp_nbr = cp.security_adp_nbr
		LEFT OUTER JOIN #<bp>..tput_price pp ON ms.security_adp_nbr = pp.security_adp_nbr and pp.put_dt >''
		LEFT OUTER JOIN #<bp>..ttrnsfr_client_dat tc ON ms.security_adp_nbr = tc.security_adp_nbr
		LEFT OUTER JOIN #telgbly_cd_ovrrd_tmp ec ON ms.security_adp_nbr = ec.security_adp_nbr
		LEFT OUTER JOIN #tsec_price tpc ON ms.security_adp_nbr = tpc.security_adp_nbr and tpc.issue_when_ind = 'N' and tpc.country_cd = 'CA' and tpc.type_price_cd = 'C'
		LEFT OUTER JOIN #tsec_price tpch ON ms.security_adp_nbr = tpch.security_adp_nbr and tpch.issue_when_ind = 'N' and tpch.country_cd = 'CA' and tpch.type_price_cd = 'H'
		LEFT OUTER JOIN #tsec_price tpcl ON ms.security_adp_nbr = tpcl.security_adp_nbr and tpcl.issue_when_ind = 'N' and tpcl.country_cd = 'CA' and tpcl.type_price_cd = 'L'
		LEFT OUTER JOIN #tsec_price tpca ON ms.security_adp_nbr = tpca.security_adp_nbr and tpca.issue_when_ind = 'N' and tpca.country_cd = 'CA' and tpca.type_price_cd = 'A'
		LEFT OUTER JOIN #tsec_price tpu ON ms.security_adp_nbr = tpu.security_adp_nbr and tpu.issue_when_ind = 'N' and tpu.country_cd = 'US' and tpu.type_price_cd = 'C'
		LEFT OUTER JOIN #tsec_price tpuh ON ms.security_adp_nbr = tpuh.security_adp_nbr and tpuh.issue_when_ind = 'N' and tpuh.country_cd = 'US' and tpuh.type_price_cd = 'H'
		LEFT OUTER JOIN #tsec_price tpul ON ms.security_adp_nbr = tpul.security_adp_nbr and tpul.issue_when_ind = 'N' and tpul.country_cd = 'US' and tpul.type_price_cd = 'L'
		LEFT OUTER JOIN #tsec_price tpua ON ms.security_adp_nbr = tpua.security_adp_nbr and tpua.issue_when_ind = 'N' and tpua.country_cd = 'US' and tpua.type_price_cd = 'A'
		LEFT OUTER JOIN #security_adp_nbr_list tmp ON ms.security_adp_nbr = tmp.security_adp_nbr
		LEFT OUTER JOIN #<bp>..thouse_price thp ON thp.client_nbr = '0069' and ms.security_adp_nbr = thp.security_adp_nbr and thp.issue_when_ind = 'N'
		LEFT OUTER JOIN #<sb>..si_security si ON ms.security_adp_nbr = si.security_adp_nbr
     WHERE 
	ms.security_adp_nbr = tmp.security_adp_nbr


	select @syb_error_code = @@error , @no_of_records = @@rowcount

        if @syb_error_code <> 0
        begin

            raiserror 30086 "Query to retrieve Security details failed."

            select @custom_error_code=@@error

            if(@debug_flag="Y")
            begin
                insert into #<oc>..si_security_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
            end

            return @custom_error_code
        end

    	if(@debug_flag='Y')
    	begin
    	insert into #<oc>..si_security_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
    	end

	return 0

END
go
		
grant Execute  on sp_multi_security_service to spica_ws 
go


