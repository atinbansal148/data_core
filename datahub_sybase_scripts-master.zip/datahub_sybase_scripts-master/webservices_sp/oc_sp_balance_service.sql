-----Version v6 : added new column 'Timestamp' for service_call_type INT and CMB and removed condition action = 'A' for PRV
-----Version v5 : added balance view code logic into this code
-----Version v2 : chnaged the error handling and addition os optimization goal
-----Version v1 : base version

use #<oc>
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_balance_service' )
begin
	drop procedure sp_balance_service
end
go


create proc sp_balance_service
@branch_cd char(3),
@account_cd	char(5) ,
@service_call_type      char(3) ,
@app_id	char(10),
@line_of_business	char(10),
@req_time_stamp char(25)
AS


declare
        @start_time             datetime,
        @proc_name              varchar(35),
        @input_parm    			varchar(75),
        @debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@no_of_records          int

BEGIN

        set plan optgoal allrows_oltp
		
	select
                @debug_flag = debug_flag
        FROM
                #<oc>..si_service_debug_config
        WHERE
                service_id='sp_balance_service'




        if(@debug_flag='Y')
        begin
                select @start_time=getdate()
                select @proc_name=object_name(@@procid)
                select @input_parm = @branch_cd+","+ @account_cd + "," + @service_call_type+","+ @app_id+","+ @line_of_business+","+ @req_time_stamp
        end

		
	
    if ( @service_call_type = 'CMB' )
	begin

	select	branch_cd       ,
			account_cd      ,
			currency_cd     ,
			convert ( decimal ( 17,2), sum (market_val_tot_amt))        market_val_tot_amt,
			convert ( decimal ( 17,2), sum (equity_total_amt))  equity_total_amt,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_cash))    ydys_trade_dt_amt_cash,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_cash))      tdys_trade_dt_amt_delta_cash,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_cash))      tdys_trade_dt_amt_total_cash,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_aft))     ydys_trade_dt_amt_aft,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_aft))       tdys_trade_dt_amt_delta_aft,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_aft))       tdys_trade_dt_amt_total_aft,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_short))   ydys_trade_dt_amt_short,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_short))     tdys_trade_dt_amt_delta_short,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_short))     tdys_trade_dt_amt_total_short,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_cod))     ydys_trade_dt_amt_cod,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_cod))       tdys_trade_dt_amt_delta_cod,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_cod))       tdys_trade_dt_amt_total_cod,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_cash))   ydys_settlm_dt_amt_cash,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_cash))     tdys_settlm_dt_amt_delta_cash,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_cash))     tdys_settlm_dt_amt_total_cash,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_aft))    ydys_settlm_dt_amt_aft,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_aft))      tdys_settlm_dt_amt_delta_aft,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_aft))      tdys_settlm_dt_amt_total_aft,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_short))  ydys_settlm_dt_amt_short,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_short))    tdys_settlm_dt_amt_delta_short,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_short))    tdys_settlm_dt_amt_total_short,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_cod))    ydys_settlm_dt_amt_cod,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_cod))      tdys_settlm_dt_amt_delta_cod,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_cod))      tdys_settlm_dt_amt_total_cod,
			convert ( decimal ( 17,2), sum (house_bal_call_amt)) house_bal_call_amt,
			convert ( decimal ( 17,2), sum (cod_equity))        cod_equity,
			convert ( decimal ( 17,2), sum (cod_market_value))  cod_market_value
			--Adding new column on 13 Mar 2015 as per change in requirement		
			,max(updt_last_tmstp) as updt_last_tmstp

			FROM  
				( 
				
				select 
					bal.branch_cd ,
					bal.account_cd ,
					case 
						when currency_cd = '254' then 'FE'
						else currency_cd
					end currency_cd,
					convert(money, 0) market_val_tot_amt,  
					convert(money, 0) equity_total_amt,
					case
						when ( type_account_cd = '1' OR type_account_cd = '2' ) then ydys_trade_dt_amt	
						else 0
					end ydys_trade_dt_amt_cash ,
					case
						when ( type_account_cd = '1' OR type_account_cd = '2' ) then tdys_trade_dt_amt	
						else 0
					end tdys_trade_dt_amt_delta_cash ,
					case
						when ( type_account_cd = '1' OR type_account_cd = '2' ) then (ydys_trade_dt_amt + tdys_trade_dt_amt	)
						else 0
					end tdys_trade_dt_amt_total_cash ,
					case
						when type_account_cd = '3' then ydys_trade_dt_amt
						else 0
					end ydys_trade_dt_amt_aft ,
					case
						when type_account_cd = '3' then tdys_trade_dt_amt
						else 0
					end tdys_trade_dt_amt_delta_aft ,
					case
						when type_account_cd = '3' then (ydys_trade_dt_amt + tdys_trade_dt_amt)
						else 0
					end tdys_trade_dt_amt_total_aft ,
					case
						when type_account_cd = '5' then ydys_trade_dt_amt
						else 0
					end ydys_trade_dt_amt_short ,
					case
						when type_account_cd = '5' then tdys_trade_dt_amt
						else 0
					end tdys_trade_dt_amt_delta_short ,
					case
						when type_account_cd = '5' then (ydys_trade_dt_amt + tdys_trade_dt_amt)
						else 0
					end tdys_trade_dt_amt_total_short ,
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_trade_dt_amt
						else 0
					end ydys_trade_dt_amt_cod ,
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then tdys_trade_dt_amt
						else 0
					end tdys_trade_dt_amt_delta_cod ,
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then (ydys_trade_dt_amt + tdys_trade_dt_amt)
						else 0
					end tdys_trade_dt_amt_total_cod ,
					case
						when ( type_account_cd = '1' OR type_account_cd = '2' ) then ydys_settlm_dt_amt	
						else 0
					end ydys_settlm_dt_amt_cash ,
					case
						when ( type_account_cd = '1' OR type_account_cd = '2' ) then tdys_settlm_dt_amt	
						else 0
					end tdys_settlm_dt_amt_delta_cash ,
					case
						when ( type_account_cd = '1' OR type_account_cd = '2' ) then (ydys_settlm_dt_amt + tdys_settlm_dt_amt	)
						else 0
					end tdys_settlm_dt_amt_total_cash ,
					case
						when type_account_cd = '3' then ydys_settlm_dt_amt
						else 0
					end ydys_settlm_dt_amt_aft ,
					case
						when type_account_cd = '3' then tdys_settlm_dt_amt
						else 0
					end tdys_settlm_dt_amt_delta_aft ,
					case
						when type_account_cd = '3' then (ydys_settlm_dt_amt + tdys_settlm_dt_amt)
						else 0
					end tdys_settlm_dt_amt_total_aft ,
					case
						when type_account_cd = '5' then ydys_settlm_dt_amt
						else 0
					end ydys_settlm_dt_amt_short ,
					case
						when type_account_cd = '5' then tdys_settlm_dt_amt
						else 0
					end tdys_settlm_dt_amt_delta_short ,
					case
						when type_account_cd = '5' then (ydys_settlm_dt_amt + tdys_settlm_dt_amt)
						else 0
					end tdys_settlm_dt_amt_total_short ,
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_settlm_dt_amt
						else 0
					end ydys_settlm_dt_amt_cod ,
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then tdys_settlm_dt_amt
						else 0
					end tdys_settlm_dt_amt_delta_cod ,
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then (ydys_settlm_dt_amt + tdys_settlm_dt_amt)
						else 0
					end tdys_settlm_dt_amt_total_cod ,
					convert(money, 0) house_bal_call_amt,		
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_equity_amt
						else 0
					end cod_equity,
					case
						when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_mrkt_val_amt
						else 0
					end cod_market_value,
					action,
					updt_last_tmstp
				FROM  
					#<bp>..tacc_type_balance bal
				WHERE
					client_nbr = '0069'
					AND bal.branch_cd = @branch_cd
					AND bal.account_cd = @account_cd
				
				UNION ALL
				
				select  
					bal.branch_cd,
					bal.account_cd,
					case 
						when  currency_cd = '254' then 'FE'
						else   currency_cd
					end currency_cd,
					market_val_tot_amt ,
					equity_total_amt ,
					convert(money,0) ydys_trade_dt_amt_cash,
					convert(money,0) tdys_trade_dt_amt_delta_cash,
					convert(money,0) tdys_trade_dt_amt_total_cash,
					convert(money,0) ydys_trade_dt_amt_aft,
					convert(money,0) tdys_trade_dt_amt_delta_aft,
					convert(money,0) tdys_trade_dt_amt_total_aft,
					convert(money,0) ydys_trade_dt_amt_short,
					convert(money,0) tdys_trade_dt_amt_delta_short,
					convert(money,0) tdys_trade_dt_amt_total_short,
					convert(money,0) ydys_trade_dt_amt_cod,
					convert(money,0) tdys_trade_dt_amt_delta_cod,
					convert(money,0) tdys_trade_dt_amt_total_cod,
					convert(money,0) ydys_settlm_dt_amt_cash,
					convert(money,0) tdys_settlm_dt_amt_delta_cash,
					convert(money,0) tdys_settlm_dt_amt_total_cash,
					convert(money,0) ydys_settlm_dt_amt_aft,
					convert(money,0) tdys_settlm_dt_amt_delta_aft,
					convert(money,0) tdys_settlm_dt_amt_total_aft,
					convert(money,0) ydys_settlm_dt_amt_short,
					convert(money,0) tdys_settlm_dt_amt_delta_short,
					convert(money,0) tdys_settlm_dt_amt_total_short,
					convert(money,0) ydys_settlm_dt_amt_cod,
					convert(money,0) tdys_settlm_dt_amt_delta_cod,
					convert(money,0) tdys_settlm_dt_amt_total_cod,
					house_bal_call_amt house_bal_call_amt,
					convert(money,0) cod_equity,
					convert(money,0) cod_market_value,
					action,
					-- As per SRS updt_last_tmstp is to be picked from table tacc_type_balance hence this is updated with default value.  
					'1900-01-01 00:00:00.000' as updt_last_tmstp  
				FROM
					#<bp>..taccount_balance bal
				WHERE
					client_nbr = '0069'
					AND bal.branch_cd = @branch_cd
					AND bal.account_cd = @account_cd
				) a
			GROUP BY
			branch_cd,account_cd,currency_cd
			ORDER BY
			branch_cd,account_cd,currency_cd



		select @syb_error_code = @@error , @no_of_records = @@rowcount

        if @syb_error_code <> 0
        begin

            raiserror 20081 "Query to retrieve combined balance detail failed."

            select @custom_error_code=@@error

            if(@debug_flag="Y")
            begin
                insert into #<oc>..si_balance_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
            end

            return @custom_error_code
        end
		
	end



    if ( @service_call_type = 'INT' )
	begin

	select	
			branch_cd       ,
			account_cd      ,
			currency_cd     ,
			convert ( decimal ( 17,2), sum (market_val_tot_amt))        market_val_tot_amt,
			convert ( decimal ( 17,2), sum (equity_total_amt))  equity_total_amt,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_cash))    ydys_trade_dt_amt_cash,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_cash))      tdys_trade_dt_amt_delta_cash,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_cash))      tdys_trade_dt_amt_total_cash,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_aft))     ydys_trade_dt_amt_aft,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_aft))       tdys_trade_dt_amt_delta_aft,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_aft))       tdys_trade_dt_amt_total_aft,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_short))   ydys_trade_dt_amt_short,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_short))     tdys_trade_dt_amt_delta_short,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_short))     tdys_trade_dt_amt_total_short,
			convert ( decimal ( 17,2), sum (ydys_trade_dt_amt_cod))     ydys_trade_dt_amt_cod,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_delta_cod))       tdys_trade_dt_amt_delta_cod,
			convert ( decimal ( 17,2), sum (tdys_trade_dt_amt_total_cod))       tdys_trade_dt_amt_total_cod,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_cash))   ydys_settlm_dt_amt_cash,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_cash))     tdys_settlm_dt_amt_delta_cash,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_cash))     tdys_settlm_dt_amt_total_cash,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_aft))    ydys_settlm_dt_amt_aft,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_aft))      tdys_settlm_dt_amt_delta_aft,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_aft))      tdys_settlm_dt_amt_total_aft,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_short))  ydys_settlm_dt_amt_short,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_short))    tdys_settlm_dt_amt_delta_short,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_short))    tdys_settlm_dt_amt_total_short,
			convert ( decimal ( 17,2), sum (ydys_settlm_dt_amt_cod))    ydys_settlm_dt_amt_cod,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_delta_cod))      tdys_settlm_dt_amt_delta_cod,
			convert ( decimal ( 17,2), sum (tdys_settlm_dt_amt_total_cod))      tdys_settlm_dt_amt_total_cod,
			convert ( decimal ( 17,2), sum (house_bal_call_amt)) house_bal_call_amt,
			convert ( decimal ( 17,2), sum (cod_equity))        cod_equity,
			convert ( decimal ( 17,2), sum (cod_market_value))  cod_market_value
			--Adding new column on 13 Mar 2015 as per change in requirement		
			,max(updt_last_tmstp) as updt_last_tmstp
			FROM  ( 
			select 
				bal.branch_cd ,
				bal.account_cd ,
				case 
					when currency_cd = '254' then 'FE'
					else currency_cd
				end currency_cd,
				convert(money, 0) market_val_tot_amt,  
				convert(money, 0) equity_total_amt,
				case
					when ( type_account_cd = '1' OR type_account_cd = '2' ) then ydys_trade_dt_amt	
					else 0
				end ydys_trade_dt_amt_cash ,
				case
					when ( type_account_cd = '1' OR type_account_cd = '2' ) then tdys_trade_dt_amt	
					else 0
				end tdys_trade_dt_amt_delta_cash ,
				case
					when ( type_account_cd = '1' OR type_account_cd = '2' ) then (ydys_trade_dt_amt + tdys_trade_dt_amt	)
					else 0
				end tdys_trade_dt_amt_total_cash ,
				case
					when type_account_cd = '3' then ydys_trade_dt_amt
					else 0
				end ydys_trade_dt_amt_aft ,
				case
					when type_account_cd = '3' then tdys_trade_dt_amt
					else 0
				end tdys_trade_dt_amt_delta_aft ,
				case
					when type_account_cd = '3' then (ydys_trade_dt_amt + tdys_trade_dt_amt)
					else 0
				end tdys_trade_dt_amt_total_aft ,
				case
					when type_account_cd = '5' then ydys_trade_dt_amt
					else 0
				end ydys_trade_dt_amt_short ,
				case
					when type_account_cd = '5' then tdys_trade_dt_amt
					else 0
				end tdys_trade_dt_amt_delta_short ,
				case
					when type_account_cd = '5' then (ydys_trade_dt_amt + tdys_trade_dt_amt)
					else 0
				end tdys_trade_dt_amt_total_short ,
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_trade_dt_amt
					else 0
				end ydys_trade_dt_amt_cod ,
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then tdys_trade_dt_amt
					else 0
				end tdys_trade_dt_amt_delta_cod ,
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then (ydys_trade_dt_amt + tdys_trade_dt_amt)
					else 0
				end tdys_trade_dt_amt_total_cod ,
				case
					when ( type_account_cd = '1' OR type_account_cd = '2' ) then ydys_settlm_dt_amt	
					else 0
				end ydys_settlm_dt_amt_cash ,
				case
					when ( type_account_cd = '1' OR type_account_cd = '2' ) then tdys_settlm_dt_amt	
					else 0
				end tdys_settlm_dt_amt_delta_cash ,
				case
					when ( type_account_cd = '1' OR type_account_cd = '2' ) then (ydys_settlm_dt_amt + tdys_settlm_dt_amt	)
					else 0
				end tdys_settlm_dt_amt_total_cash ,
				case
					when type_account_cd = '3' then ydys_settlm_dt_amt
					else 0
				end ydys_settlm_dt_amt_aft ,
				case
					when type_account_cd = '3' then tdys_settlm_dt_amt
					else 0
				end tdys_settlm_dt_amt_delta_aft ,
				case
					when type_account_cd = '3' then (ydys_settlm_dt_amt + tdys_settlm_dt_amt)
					else 0
				end tdys_settlm_dt_amt_total_aft ,
				case
					when type_account_cd = '5' then ydys_settlm_dt_amt
					else 0
				end ydys_settlm_dt_amt_short ,
				case
					when type_account_cd = '5' then tdys_settlm_dt_amt
					else 0
				end tdys_settlm_dt_amt_delta_short ,
				case
					when type_account_cd = '5' then (ydys_settlm_dt_amt + tdys_settlm_dt_amt)
					else 0
				end tdys_settlm_dt_amt_total_short ,
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_settlm_dt_amt
					else 0
				end ydys_settlm_dt_amt_cod ,
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then tdys_settlm_dt_amt
					else 0
				end tdys_settlm_dt_amt_delta_cod ,
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then (ydys_settlm_dt_amt + tdys_settlm_dt_amt)
					else 0
				end tdys_settlm_dt_amt_total_cod ,
				convert(money, 0) house_bal_call_amt,		
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_equity_amt
					else 0
				end cod_equity,
				case
					when ( type_account_cd = '8' OR type_account_cd = '9' ) then ydys_mrkt_val_amt
					else 0
				end cod_market_value,
				action,
				updt_last_tmstp
			FROM  
				#<bp>..tacc_type_balance bal
			WHERE
				client_nbr = '0069'
				AND bal.branch_cd = @branch_cd
				AND bal.account_cd = @account_cd
				--AND ( action = "I" OR action = "U" )
			UNION ALL
			
			select  
				bal.branch_cd,
				bal.account_cd,
				case when  currency_cd = '254' then 'FE'
				else   currency_cd
				end currency_cd,
				market_val_tot_amt ,
				equity_total_amt ,
				convert(money,0) ydys_trade_dt_amt_cash,
				convert(money,0) tdys_trade_dt_amt_delta_cash,
				convert(money,0) tdys_trade_dt_amt_total_cash,
				convert(money,0) ydys_trade_dt_amt_aft,
				convert(money,0) tdys_trade_dt_amt_delta_aft,
				convert(money,0) tdys_trade_dt_amt_total_aft,
				convert(money,0) ydys_trade_dt_amt_short,
				convert(money,0) tdys_trade_dt_amt_delta_short,
				convert(money,0) tdys_trade_dt_amt_total_short,
				convert(money,0) ydys_trade_dt_amt_cod,
				convert(money,0) tdys_trade_dt_amt_delta_cod,
				convert(money,0) tdys_trade_dt_amt_total_cod,
				convert(money,0) ydys_settlm_dt_amt_cash,
				convert(money,0) tdys_settlm_dt_amt_delta_cash,
				convert(money,0) tdys_settlm_dt_amt_total_cash,
				convert(money,0) ydys_settlm_dt_amt_aft,
				convert(money,0) tdys_settlm_dt_amt_delta_aft,
				convert(money,0) tdys_settlm_dt_amt_total_aft,
				convert(money,0) ydys_settlm_dt_amt_short,
				convert(money,0) tdys_settlm_dt_amt_delta_short,
				convert(money,0) tdys_settlm_dt_amt_total_short,
				convert(money,0) ydys_settlm_dt_amt_cod,
				convert(money,0) tdys_settlm_dt_amt_delta_cod,
				convert(money,0) tdys_settlm_dt_amt_total_cod,
				house_bal_call_amt house_bal_call_amt,
				convert(money,0) cod_equity,
				convert(money,0) cod_market_value,
				action,
				-- As per SRS updt_last_tmstp is to be picked from table tacc_type_balance hence this is updated with default value.
				'1900-01-01 00:00:00.000' as updt_last_tmstp
			FROM
				#<bp>..taccount_balance bal
			WHERE
				client_nbr = '0069'
				AND bal.branch_cd = @branch_cd
				AND bal.account_cd = @account_cd
				--AND ( action = "I" OR action = "U" )
			) a
		GROUP BY
		branch_cd,account_cd,currency_cd
		having  (max(action) = "I" OR max(action) = "U")
		ORDER BY
		branch_cd,account_cd,currency_cd




		select @syb_error_code = @@error , @no_of_records = @@rowcount

        if @syb_error_code <> 0
        begin

            raiserror 20082 "Query to retrieve intra day balance detail failed."

            select @custom_error_code=@@error

            if(@debug_flag="Y")
            begin
                insert into #<oc>..si_balance_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
            end

            return @custom_error_code
        end
		
	end


    if ( @service_call_type = 'PRV' )
	begin

	SELECT
		 branch_cd
		,account_cd
		,currency_cd
		,convert ( decimal ( 17 , 2) ,market_val_tot_amt) market_val_tot_amt
		,convert ( decimal ( 17 , 2) ,equity_total_amt) equity_total_amt
		--Code changes on 11 Jun
		,convert ( decimal ( 17 , 2) ,ydys_trade_dt_amt_type1 + ydys_trade_dt_amt_type2) ydys_trade_dt_amt_cash
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_delta_type1 + tdys_trade_dt_amt_delta_type2) tdys_trade_dt_amt_delta_cash
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_total_type1 + tdys_trade_dt_amt_total_type2) tdys_trade_dt_amt_total_cash
		,convert ( decimal ( 17 , 2) ,ydys_trade_dt_amt_type3) ydys_trade_dt_amt_aft
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_delta_type3) tdys_trade_dt_amt_delta_aft
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_total_type3) tdys_trade_dt_amt_total_aft
		,convert ( decimal ( 17 , 2) ,ydys_trade_dt_amt_type5) ydys_trade_dt_amt_short
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_delta_type5) tdys_trade_dt_amt_delta_short
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_total_type5) tdys_trade_dt_amt_total_short
		,convert ( decimal ( 17 , 2) ,ydys_trade_dt_amt_type8 + ydys_trade_dt_amt_type9) ydys_trade_dt_amt_cod
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_delta_type8 + tdys_trade_dt_amt_delta_type9) tdys_trade_dt_amt_delta_cod
		,convert ( decimal ( 17 , 2) ,tdys_trade_dt_amt_total_type8 + tdys_trade_dt_amt_total_type9) tdys_trade_dt_amt_total_cod
		,convert ( decimal ( 17 , 2) ,ydys_settlm_dt_amt_type1 + ydys_settlm_dt_amt_type2) ydys_settlm_dt_amt_cash
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_delta_type1 + tdys_settlm_dt_amt_delta_type2) tdys_settlm_dt_amt_delta_cash
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_total_type1 + tdys_settlm_dt_amt_total_type2) tdys_settlm_dt_amt_total_cash
		,convert ( decimal ( 17 , 2) ,ydys_settlm_dt_amt_type3) ydys_settlm_dt_amt_aft
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_delta_type3) tdys_settlm_dt_amt_delta_aft
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_total_type3) tdys_settlm_dt_amt_total_aft
		,convert ( decimal ( 17 , 2) ,ydys_settlm_dt_amt_type5) ydys_settlm_dt_amt_short
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_delta_type5) tdys_settlm_dt_amt_delta_short
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_total_type5) tdys_settlm_dt_amt_total_short
		,convert ( decimal ( 17 , 2) ,ydys_settlm_dt_amt_type8 + ydys_settlm_dt_amt_type9) ydys_settlm_dt_amt_cod
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_delta_type8 + tdys_settlm_dt_amt_delta_type9) tdys_settlm_dt_amt_delta_cod
		,convert ( decimal ( 17 , 2) ,tdys_settlm_dt_amt_total_type8 + tdys_settlm_dt_amt_total_type9) tdys_settlm_dt_amt_total_cod
		,convert ( decimal ( 17 , 2) ,house_bal_call_amt) house_bal_call_amt
		,convert ( decimal ( 17 , 2) ,equity_type8 + equity_type9) cod_equity
		,convert ( decimal ( 17 , 2) ,market_value_type8 + market_value_type9) cod_market_value
		--Adding new column on 13 Mar 2015 as per change in requirement	
		,modify_timestamp updt_last_tmstp
	FROM
		#<sb>..si_balance
	WHERE
		branch_cd = @branch_cd
		AND account_cd = @account_cd
		--removing on 13 Mar 2015 as per change in requirement		
		-- AND action = 'A'
	ORDER BY
		branch_cd, account_cd , currency_cd




	select @syb_error_code = @@error , @no_of_records = @@rowcount

        if @syb_error_code <> 0
        begin

            raiserror 20083 "Query to retrieve previous day balance detail failed."

            select @custom_error_code=@@error

            if(@debug_flag="Y")
            begin
                insert into #<oc>..si_balance_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
            end

            return @custom_error_code
        end
		
	end

	
    	if(@debug_flag='Y')
    	begin
			insert into #<oc>..si_balance_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
    	end

	return 0



		
END
go
		
grant Execute  on sp_balance_service to spica_ws 
go


