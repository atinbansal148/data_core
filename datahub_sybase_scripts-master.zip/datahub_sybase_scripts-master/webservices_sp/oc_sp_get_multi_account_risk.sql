
use #<oc>
go

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_get_multi_account_risk' )
BEGIN
        DROP PROCEDURE sp_get_multi_account_risk 
END
GO

CREATE PROCEDURE sp_get_multi_account_risk
	@account char(600),
        @app_id char(10),
	@line_of_business char(10),
	@req_time_stamp char(25),
	@transaction_id char(40)= NULL

AS
BEGIN
    DECLARE @pos int
    DECLARE @piece char(30)
	
    DECLARE   
    @start_time             datetime,
    @proc_name              varchar(35),
    @input_parm    	    varchar(1000),
    @debug_flag             char(1),
    @syb_error_code         int ,
    @custom_error_code      int,
    @no_of_records          int,
    @branch_num             char(3),
    @account_num            char(5)

    SELECT @account     = ltrim(rtrim(@account))

    SELECT
      @debug_flag = debug_flag
    FROM
      #<oc>..si_service_debug_config
    WHERE
      service_id='sp_get_multi_account_risk'

    if(@debug_flag='Y')     
    begin
       select @start_time=getdate()
       select @proc_name=object_name(@@procid)
       select @input_parm =  @account +","+ @app_id+","+@line_of_business+","+@req_time_stamp+","+@transaction_id
    end


    CREATE TABLE #tmp_account_list (branch_num char(3), account_num char(5))
	
	SELECT @pos = charindex(',' , @account)
   
	while @pos <> 0
	BEGIN
		SELECT @piece = LEFT( @account , @pos-1 )
		select @branch_num = substring( @account,  1,3),
		       @account_num = substring( @account, 4,5)
		INSERT INTO #tmp_account_list VALUES ( @branch_num, @account_num )
		SELECT @account = stuff( @account, 1, @pos, NULL )
		SELECT @pos = charindex(',' , @account )
	END

     SELECT  @branch_num = substring( @account,  1,3)
     SELECT  @account_num = substring( @account, 4,5)

     INSERT INTO #tmp_account_list VALUES ( @branch_num, @account_num )

    SELECT 
        gss_acc.branch_cd,
        gss_acc.account_cd,
        gss_acc.low_risk_target_amt,
        gss_acc.low_risk_target_pct,
        gss_acc.low_risk_actual_amt,
        gss_acc.low_risk_actual_pct,
        gss_acc.medium_risk_target_amt,
        gss_acc.medium_risk_target_pct,
        gss_acc.medium_risk_actual_amt,
        gss_acc.medium_risk_actual_pct,
        gss_acc.mediumhigh_risk_target_amt,
        gss_acc.mediumhigh_risk_target_pct,
        gss_acc.mediumhigh_risk_actual_amt,
        gss_acc.mediumhigh_risk_actual_pct,
        gss_acc.high_risk_target_amt,
        gss_acc.high_risk_target_pct,
        gss_acc.high_risk_actual_amt,
        gss_acc.high_risk_actual_pct,
        gss_acc.unavailable_risk_target_amt,
        gss_acc.unavailable_risk_target_pct,
        gss_acc.unavailable_risk_actual_amt,
        gss_acc.unavailable_risk_actual_pct, 
	gss_acc.business_date,
	gss_acc.modify_by,	
        gss_acc.updt_last_tmstp
    FROM #<sb>..si_gss_account_risk gss_acc
       INNER JOIN #tmp_account_list acc_list ON
	     gss_acc.branch_cd = acc_list.branch_num
	     AND gss_acc.account_cd = acc_list.account_num
    WHERE gss_acc.branch_cd > ''
    AND gss_acc.account_cd > ''
            
     select @syb_error_code = @@error , @no_of_records = @@rowcount

     if @syb_error_code <> 0
     begin

        raiserror 20081 "Query to retrieve client performance detail failed."

        select @custom_error_code=@@error

        if(@debug_flag="Y")
        begin
            insert into #<oc>..si_gss_account_risk_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,
	                                                  getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
        end

        return @custom_error_code
     end
  
     if(@debug_flag='Y')
     begin
	   insert into #<oc>..si_gss_account_risk_ma_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
     end

     return 0

END
go

GRANT EXECUTE  on sp_get_multi_account_risk to spica_ws

go

