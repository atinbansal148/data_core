
use #<oc>
go

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_get_asset_allocation' )
BEGIN
        DROP PROCEDURE sp_get_asset_allocation 
END
GO

CREATE PROCEDURE sp_get_asset_allocation
     @branch_cd char(3),
     @account_cd char(5),
	 @currency_cd char(3) = NULL,
     @app_id char(10),
     @line_of_business char(10),
     @req_time_stamp char(25),
     @transaction_id char(40)= NULL

AS
BEGIN
   	
    DECLARE   
    @start_time             datetime,
    @proc_name              varchar(35),
    @input_parm    	        varchar(75),
    @debug_flag             char(1),
    @syb_error_code         int ,
    @custom_error_code      int,
    @no_of_records          int
	
    SELECT @currency_cd = ltrim(rtrim(@currency_cd))
	
	SELECT
        @debug_flag = debug_flag
    FROM
        #<oc>..si_service_debug_config
    WHERE
        service_id='sp_get_asset_allocation'
	
    if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @branch_cd+","+@account_cd+","+ @currency_cd +","+ @app_id+","+@line_of_business+","+ @req_time_stamp+","+@transaction_id
    end	
    
    SELECT 
	     ast_alloc.branch_cd,
	     ast_alloc.account_cd,
	     ast_alloc.currency_cd,
	     ast_alloc.acctlobid,
	     ast_alloc.rr_cd,
	     ast_alloc.alternative_amt,
	     ast_alloc.alternative_pct,
	     ast_alloc.cash_and_equivalent_amt,
	     ast_alloc.cash_and_equivalent_pct,
	     ast_alloc.commodities_amt,
	     ast_alloc.commodities_pct,
		 ast_alloc.equity_amt,
		 ast_alloc.equity_pct,
		 ast_alloc.fixed_income_amt,
		 ast_alloc.fixed_income_pct,
		 ast_alloc.other_unclassified_amt,
		 ast_alloc.other_unclassified_pct,
		 ast_alloc.business_date,
		 ast_alloc.modify_by,
		 ast_alloc.updt_last_tmstp
	FROM #<sb>..si_cl_asset_allocation ast_alloc
    WHERE ast_alloc.branch_cd = @branch_cd
	    AND ast_alloc.account_cd = @account_cd
		AND
            ltrim(rtrim(ast_alloc.currency_cd)) =
            CASE WHEN @currency_cd is not NULL
                 THEN @currency_cd
                 ELSE ltrim(rtrim(ast_alloc.currency_cd))
            END
        
	  	  
	 select @syb_error_code = @@error , @no_of_records = @@rowcount

     if @syb_error_code <> 0
     begin

        raiserror 20081 "Query to retrieve client asset allocation detail failed."

        select @custom_error_code=@@error

        if(@debug_flag="Y")
        begin
            insert into #<oc>..si_cl_asset_allocation_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
        end

        return @custom_error_code
     end
  
     if(@debug_flag='Y')
     begin
	   insert into #<oc>..si_cl_asset_allocation_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
     end

     return 0 
END
go

GRANT EXECUTE  on sp_get_asset_allocation to spica_ws

go

