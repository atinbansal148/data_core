
use #<oc>
go

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_get_account_risk' )
BEGIN
        DROP PROCEDURE sp_get_account_risk 
END
GO

CREATE PROCEDURE sp_get_account_risk
	@branch_cd char(3),
	@account_cd char(5),
        @app_id char(10),
	@line_of_business char(10),
	@req_time_stamp char(25),
	@transaction_id char(40)= NULL

AS
BEGIN
    DECLARE   
    @start_time             datetime,
    @proc_name              varchar(35),
    @input_parm    	    varchar(75),
    @debug_flag             char(1),
    @syb_error_code         int ,
    @custom_error_code      int,
    @no_of_records          int

    SELECT
        @debug_flag = debug_flag
    FROM
        #<oc>..si_service_debug_config
    WHERE
        service_id='sp_get_account_risk'
	
    if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @branch_cd+","+ @account_cd +","+ @app_id+","+@line_of_business+","+ @req_time_stamp+","+@transaction_id
    end


    SELECT 
        gss_acc.branch_cd,
        gss_acc.account_cd,
        gss_acc.low_risk_target_amt,
        gss_acc.low_risk_target_pct,
        gss_acc.low_risk_actual_amt,
        gss_acc.low_risk_actual_pct,
        gss_acc.medium_risk_target_amt,
        gss_acc.medium_risk_target_pct,
        gss_acc.medium_risk_actual_amt,
        gss_acc.medium_risk_actual_pct,
        gss_acc.mediumhigh_risk_target_amt,
        gss_acc.mediumhigh_risk_target_pct,
        gss_acc.mediumhigh_risk_actual_amt,
        gss_acc.mediumhigh_risk_actual_pct,
        gss_acc.high_risk_target_amt,
        gss_acc.high_risk_target_pct,
        gss_acc.high_risk_actual_amt,
        gss_acc.high_risk_actual_pct,
        gss_acc.unavailable_risk_target_amt,
        gss_acc.unavailable_risk_target_pct,
        gss_acc.unavailable_risk_actual_amt,
        gss_acc.unavailable_risk_actual_pct,
	gss_acc.business_date,
	gss_acc.modify_by,	
        gss_acc.updt_last_tmstp
    FROM #<sb>..si_gss_account_risk gss_acc
	WHERE
	    gss_acc.branch_cd = @branch_cd
 	AND gss_acc.account_cd = @account_cd
            
     select @syb_error_code = @@error , @no_of_records = @@rowcount

     if @syb_error_code <> 0
     begin

        raiserror 20081 "Query to retrieve gss account risk detail failed."

        select @custom_error_code=@@error

        if(@debug_flag="Y")
        begin
            insert into #<oc>..si_gss_account_risk_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,
	                                                  getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
        end

        return @custom_error_code
     end
  
     if(@debug_flag='Y')
     begin
	   insert into #<oc>..si_gss_account_risk_sa_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
     end

     return 0

END
go

GRANT EXECUTE  on sp_get_account_risk to spica_ws

go

