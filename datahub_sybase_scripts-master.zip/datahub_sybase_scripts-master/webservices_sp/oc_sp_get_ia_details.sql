use #<oc>
go

setuser "dbo"
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_get_ia_details')
begin
	drop procedure sp_get_ia_details
end
go



create procedure sp_get_ia_details 
		 @ia_code char(3)
		 ,@app_id char(10)
		 --,@business_id char(10)
		,@line_of_business char(10)
		,@req_time_stamp char(25)
AS
	declare   
		@last_data_date       	char(8),   
		@start_time	        datetime,                          
		@proc_name	        varchar(35),                                                  
		@input_parm	        varchar(175),         
		@debug_flag	        char(1),
		@syb_error_code		int ,
		@custom_error_code	int,
		@no_of_records		int


BEGIN


		select
                @debug_flag = debug_flag
        FROM
                #<oc>..si_service_debug_config
        WHERE
                service_id='sp_get_ia_details'



        if(@debug_flag='Y')
        begin
                select @start_time=getdate()
                select @proc_name=object_name(@@procid)
                select @input_parm = @ia_code+","+ @app_id+","+ @line_of_business+","+ convert(varchar(25),@req_time_stamp)
        end

	SELECT
		i.ia_num ia_code
		,i.branch_num  
		, i.ia_name     
		, i.ia_phone_num
		, i.budget_comm 
		, i.rg_code     
		, i.dept_code   
		--, i.modify_date 
		--, i.modify_by   		
		, b.branch_name      
		, b.region_code      
		, b.branch_mgr_ia_num
		, b.branch_address1  
		, b.branch_address2  
		, b.branch_address3  
		, b.branch_address4  
		, b.postal_code      
		, b.branch_phone_num 
		, b.email_address    
		--, b.modify_date      
		--, b.modify_by        
		, b.mgr_name         
		, b.mgr_phone        
		, b.fr_mgr_name      
		, b.fr_mgr_phone     
	FROM
		#<sb>..si_ia_master i
		, #<sb>..si_branch_master b
	WHERE
		i.ia_num = @ia_code
		AND i.branch_num = b.branch_num	



	select @syb_error_code = @@error , @no_of_records = @@rowcount 
		
		if @syb_error_code <> 0    
		begin   
	
			raiserror 20152 "Query to provide Investment Agent details failed."

			select @custom_error_code = @@error
			
			if(@debug_flag="Y")   
			begin   
				insert into #<oc>..si_ia_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code ) 
			end   
			
			return @custom_error_code
		end 
	
	
	
	if(@debug_flag="Y")   
	begin   
			insert into #<oc>..si_ia_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 ) 
	end   
			
	return 0
	
END

go



grant Execute  on sp_get_ia_details to spica_ws
go

grant Execute  on sp_get_ia_details to readall
go

