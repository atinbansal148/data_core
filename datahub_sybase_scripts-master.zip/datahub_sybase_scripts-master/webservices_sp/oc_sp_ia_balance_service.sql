-----Version v1 : base version [14 Aug 2017, TCS]

use #<oc>
go

declare @ext int , @user varchar(255), @cdate datetime
set @ext = 0
set @user = suser_name()
set @cdate = getdate()
select @ext = count(*) from #<oc>..si_service_debug_config where service_id = 'sp_ia_balance_service' 
if (@ext < 1)
begin
insert into #<oc>..si_service_debug_config(service_id,client_id,debug_flag,description,created_by,created_date,modified_by,modified_date)
values('sp_ia_balance_service','GIS','Y','GLASS Integration',@user,@cdate,@user,@cdate)
end
else
begin
update #<oc>..si_service_debug_config set debug_flag = 'Y',modified_by=@user,modified_date=@cdate where service_id = 'sp_ia_balance_service'
end

go

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_ia_balance_service')
BEGIN
	DROP PROCEDURE sp_ia_balance_service
END
GO
-- exec spica_online_chnl..sp_ia_balance_service '1BB1CJ22M','4','C','234','ly00','ds','20140101 12:12:12.333','txt1'
-- exec spica_online_chnl..sp_ia_balance_service '1BB1CJ22M2WN32232332832A33A35A','','D','','ly00','ds','20140101 12:12:12.333','txt1'
-- 1BB 1CJ 22M 2WN 322 323 328 32A 33A 35A 35B 39A 3G3 4C7 4JY 4JZ 4K2 5NN 7F1 AAB AE2 AFX BPE BTF BTM BVP BXK CSP CTY EWG F3K F4F F6A FY5 G4Z GCT GZL HEP J3Q JY5 KXV L4B LCT LHY MHX NFF NHF NLE NRJ P8B PAS PKH PXG R8G RS9 RX7 SET TVE WQF 

CREATE PROCEDURE sp_ia_balance_service 
   @rr_cd_range                VARCHAR (31),
   @type_account_cd            VARCHAR (2),
   @debit_credit_ind           VARCHAR (2),
   @currency_cd                VARCHAR (4),
   @app_id                     CHAR (10) = NULL,
   @line_of_business           CHAR (10) = NULL,
   @req_time_stamp             CHAR (25) = NULL,
   @transaction_id             CHAR (40) = NULL
AS
BEGIN
	declare @page_size INT
	set @page_size = 50
	SET COMPATIBILITY_MODE ON
	SET PLAN OPTLEVEL ASE_DEFAULT
	 
    DECLARE
      @proc_name                        VARCHAR (35),
      @query                            VARCHAR (14000),
      @input_parm                       VARCHAR (1400),
      @debug_flag                       CHAR (1),
      @var                              INT,
      @accnt_length                     INT,
      @syb_error_code                   INT,
      @custom_error_code                INT,
      @rr_cd_length                     INT,       
      @no_of_records                    INT,
      @start_time                       DATETIME,
      @maxrows                          INT,          
      @clause                           INT,
      @position                         INT,    
	  @tablename						varchar(50),
	  @message							varchar(100),
	  @type_account_cd_length			INT,
	  @debit_credit_ind_length			INT,
	  @currency_cd_length				INT
	  
	  
	  
	set @start_time = getdate()
 
	select @proc_name=object_name(@@procid)	
		  
	SELECT
		@debug_flag = debug_flag
	FROM
		#<oc>..si_service_debug_config
	WHERE
		service_id=@proc_name

	select @tablename = 'si_ia_balance_log'
	
	IF (@debug_flag='Y')
	BEGIN
		SELECT @start_time=getdate()
		--SELECT @proc_name=object_name(@@procid)+'('+convert(varchar,@@spid)+')'
		SELECT @input_parm = @rr_cd_range +","+ @type_account_cd +","+ @debit_credit_ind +","+ @currency_cd +","+ @req_time_stamp
	END

	SET @custom_error_code = dbo.fn_validate_ws_audit_fields(@app_id,@line_of_business,@req_time_stamp,@transaction_id)
	
	IF ( @custom_error_code > 0)
	BEGIN
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code			 
	END	 
	 
	SELECT @rr_cd_length = len (LTRIM(RTRIM((@rr_cd_range))))
	SELECT @type_account_cd_length = len (LTRIM(RTRIM((@type_account_cd))))
	SELECT @debit_credit_ind_length = len (LTRIM(RTRIM((@debit_credit_ind))))
	SELECT @currency_cd_length = len (LTRIM(RTRIM((@currency_cd))))
 
	SELECT @syb_error_code = @@error
	
	 
	IF(@rr_cd_length is null or @rr_cd_length < 3 or @rr_cd_length > 30)	
	BEGIN
		set @message = "Incorrect rr_cd code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END
	
	if(LTRIM(RTRIM((@rr_cd_range))) like '%[^a-zA-Z0-9]%')
	begin
		set @message = "Incorrect rr_cd Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	end
	 
	
	IF(LTRIM(RTRIM((@rr_cd_range))) IS NOT NULL)
	IF (((@rr_cd_length%3) <> 0) )
	BEGIN
		set @message = "Incorrect rr_cd Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END

	IF(LTRIM(RTRIM((@type_account_cd))) IS NOT NULL)
	IF (((@type_account_cd_length) <> 1) )
	BEGIN
		set @message = "Incorrect type_account_cd Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END
	
	IF(LTRIM(RTRIM((@type_account_cd))) IS NOT NULL)
	IF (((@type_account_cd) like '%[^1-9]%') )
	BEGIN
		set @message = "Incorrect type_account_cd Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END
	
	IF(LTRIM(RTRIM((@debit_credit_ind))) IS NOT NULL)
	IF (((@debit_credit_ind_length) <> 1) )
	BEGIN
		set @message = "Incorrect debit_credit_ind Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END
	
	IF(LTRIM(RTRIM((@debit_credit_ind))) IS NOT NULL)
	IF (((@debit_credit_ind) like '%[^C-D]%') )
	BEGIN
		set @message = "Incorrect debit_credit_ind Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END
	
	IF(LTRIM(RTRIM((@currency_cd))) IS NOT NULL)
	IF (((@currency_cd_length) <> 3) )
	BEGIN
		set @message = "Incorrect currency_cd Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END
	
	IF(LTRIM(RTRIM((@currency_cd))) IS NOT NULL)
	IF (((@currency_cd) like '%[^0-9]%') )
	BEGIN
		set @message = "Incorrect currency_cd Code range passed to service." 
		raiserror 17042 @message
		SELECT @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code	
	END
	
	CREATE TABLE #tmp_ia_number
	(
		rr_cd        	CHAR(3)       	NOT NULL
	)
	
	SELECT @var = 1
	WHILE ( @var < @rr_cd_length )
	BEGIN
		INSERT INTO #tmp_ia_number VALUES (SUBSTRING(@rr_cd_range,@var,3))
		SELECT @syb_error_code = @@error
		IF @syb_error_code <> 0
		BEGIN				
			set @message = "Failed to process IA range." 
			raiserror 17055 @message
			SELECT @custom_error_code=@@error
			exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
			RETURN @custom_error_code
		END
		SELECT @var = @var + 3
	END
	

	SELECT  
		iam.id,
		tmpia.rr_cd
		into #tmp_iaid
		FROM #tmp_ia_number tmpia		
		LEFT JOIN #<sb>..si_cs_ia_master iam ON tmpia.rr_cd = iam.acctiacode	 

	SELECT  
	attr.branch_cd,
	attr.account_cd,
	tmpia.rr_cd,
	fee.feetypecode,
	fee.feetypedesc,
	acc.acctdefadp,
	acc.acctdefadpdesc
		into #tmp_account_list
		FROM #tmp_iaid tmpia		
		LEFT JOIN #<sb>..si_account_attributes attr ON tmpia.id = attr.siiama_id
		LEFT JOIN #<sb>..si_feetype fee ON attr.sifety_id = fee.id
		LEFT JOIN #<sb>..si_account_plan acc ON attr.siacpl_id = acc.id
		and attr.siiama_id > 0

-- select * from #tmp_account_list


	-- SELECT  
	-- attr.branch_cd,
	-- attr.account_cd,
	-- tmpia.rr_cd,
	-- fee.feetypecode,
	-- fee.feetypedesc,
	-- acc.acctdefadp,
	-- acc.acctdefadpdesc
	-- 	into #tmp_account_list
	-- 	FROM #tmp_ia_number tmpia		
	-- 	INNER JOIN #<sb>..si_cs_ia_master iam ON tmpia.rr_cd = iam.acctiacode	 
	-- 	INNER JOIN #<sb>..si_account_attributes attr ON iam.id = attr.siiama_id
	-- 	LEFT JOIN #<sb>..si_feetype fee ON attr.sifety_id = fee.id
	-- 	LEFT JOIN #<sb>..si_account_plan acc ON attr.siacpl_id = acc.id
	-- 	WHERE iam.id > 0 and iam.source_ind > '' and iam.acctiacode > ''
		
	
	-- create unique clustered index tmp_account_list_ind1 on #tmp_account_list(branch_cd,account_cd)
	
		SELECT
		tacc.branch_cd,
		tacc.account_cd,
		tacc.type_account_cd,
		case when tacc.currency_cd = '254' then 'FE' else tacc.currency_cd end as currency_cd,
		tacc.ydys_trade_dt_amt,
		tacc.tdys_trade_dt_amt,
		tacc.ydys_trade_dt_amt + tacc.tdys_trade_dt_amt as tdys_trade_dt_amt_total,
		tacc.ydys_settlm_dt_amt,
		tacc.tdys_settlm_dt_amt,
		tacc.ydys_settlm_dt_amt + tacc.tdys_settlm_dt_amt as tdys_settlm_dt_amt_total,
		tacc.ydys_hse_exces_amt,
		tacc.ydys_equity_pct,
		tacc.ydys_equity_amt,
		tacc.ydys_mrkt_val_amt,
		tacc.class_acct_mrgn_cd,
		tacc.action,
		tacc.rr_cd,
		tmpac.feetypecode,
		tmpac.feetypedesc,
		tmpac.acctdefadp,
		tmpac.acctdefadpdesc,
		party.na_line_txt as na_line_txt_1
		FROM #tmp_account_list tmpac
		INNER JOIN #<bp>..tacc_type_balance tacc ON  tacc.client_nbr = '0069' and  tacc.branch_cd = tmpac.branch_cd AND tacc.account_cd = tmpac.account_cd
		LEFT JOIN #<bp>..tacc_party_ff_na party ON  party.client_nbr = '0069' and tacc.branch_cd = party.branch_cd AND tacc.account_cd = party.account_cd AND party.ap_seq_nbr = 1 AND party.na_line_seq_nbr= 1 
		where
			(ltrim(rtrim(@type_account_cd)) is null or tacc.type_account_cd = @type_account_cd)
		AND (ltrim(rtrim(@currency_cd)) is null or tacc.currency_cd = @currency_cd)
		AND ((@debit_credit_ind = 'C' and tdys_trade_dt_amt+ydys_settlm_dt_amt < 0)	
			or (@debit_credit_ind = 'D' and tdys_trade_dt_amt+ydys_settlm_dt_amt > 0) 
			or (ltrim(rtrim(@debit_credit_ind)) is null and tdys_trade_dt_amt+ydys_settlm_dt_amt != 0))
		order by tacc.ydys_settlm_dt_amt + tacc.tdys_settlm_dt_amt desc, tacc.branch_cd, tacc.account_cd, tacc.type_account_cd, tacc.currency_cd
		--order by tacc.branch_cd, tacc.account_cd, tacc.type_account_cd, tacc.currency_cd, tacc.ydys_settlm_dt_amt + tacc.tdys_settlm_dt_amt desc

	SELECT @syb_error_code = @@error , @no_of_records = @@rowcount
		
		 
		
		IF ( @syb_error_code <> 0) 
		BEGIN
		set @message = "ia_balance_service Failed"
		raiserror 17040 @message		 
		select @custom_error_code=@@error
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,@message
		RETURN @custom_error_code
		END
		
		exec spica_online_chnl..sp_insert_log @debug_flag,@tablename,@app_id,@line_of_business,@input_parm,@transaction_id,@start_time,@no_of_records,0,@custom_error_code,@@spid,'SUCCESSFUL'
		
	RETURN
END
GO

GRANT EXECUTE ON sp_ia_balance_service TO datahub_ws 
GO
