----V2 MF T+1 Changes
USE #<oc>
GO

declare @ext int , @user varchar(255), @cdate datetime
set @ext = 0
set @user = suser_name()
set @cdate = getdate()
select @ext = count(*) from #<oc>..si_service_debug_config where service_id = 'sp_pos_adv_multi_accnt_service' 
if (@ext < 1)
begin
insert into #<oc>..si_service_debug_config(service_id,client_id,debug_flag,description,created_by,created_date,modified_by,modified_date)
values('sp_pos_adv_multi_accnt_service','TradeLink','Y','Advanced Position Multi Account Service',@user,@cdate,@user,@cdate)
end
else
begin
update #<oc>..si_service_debug_config set debug_flag = 'Y',modified_by=@user,modified_date=@cdate where service_id = 'sp_pos_adv_multi_accnt_service'
end

go

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_pos_adv_multi_accnt_service' )
BEGIN
	DROP PROCEDURE sp_pos_adv_multi_accnt_service
END
GO


CREATE proc sp_pos_adv_multi_accnt_service
@account	varchar(512) ,
@security_identifier_type CHAR(7)=NULL,
@security_identifier_value CHAR(20)=NULL,
@type_account_cd CHAR(1)=NULL,
@currency_cd CHAR(3)=NULL,
@service_call_type CHAR(3),
@app_id CHAR(10),
@line_of_business CHAR(10),
@req_time_stamp CHAR(25),
@transaction_id CHAR(40)
AS

DECLARE
	@start_time				datetime,
	@proc_name				varchar(35),
	@input_parm				varchar(255),
	@debug_flag				char(1),
	@syb_error_code			int ,
	@custom_error_code		int,
	@no_of_records			int,
	@action1				char(1),
	@action2				char(1),
	@security_adp_nbr		varchar(20),
	@company_code			varchar(20),
	@position_underlying_sec_symbol	varchar(20),
	@var					int,
	@accnt_length 			int,
	@table_extract          char(1)

BEGIN	

	--SET plan optgoal allrows_oltp
	--SET compatibility_mode on
	set plan optlevel ase_default

	SELECT 
		@debug_flag = debug_flag 
	FROM 
		#<oc>..si_service_debug_config  
	WHERE 
		service_id='sp_pos_adv_multi_accnt_service'	
		
	IF(@debug_flag='Y')
	BEGIN
		SELECT @start_time=getdate()            
		SELECT @proc_name=object_name(@@procid)  
		SELECT @input_parm=@account+','+@security_identifier_type+','+@security_identifier_value+','+@type_account_cd+','+@currency_cd+','+@service_call_type+','+@app_id+','+@line_of_business+','+@req_time_stamp+','+@transaction_id
	END
		
	SELECT @accnt_length = char_length ( @account ) 
	SELECT @syb_error_code = @@error


	IF ( ((@accnt_length%8) <> 0) OR (@syb_error_code <> 0) )
    BEGIN
                raiserror 50004 "Incorrect account numbers passed to service."

                SELECT @custom_error_code=@@error

                IF(@debug_flag="Y")
                BEGIN
                        INSERT INTO #<oc>..si_position_adv_ma_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
                END

                RETURN @custom_error_code
    END	
	
	SELECT 
		 branch_cd
		,account_cd
	INTO 
		#tmp_acc_number
	FROM 
		#<bp>..taccount_sec_hldr
	WHERE 1=2
	
	
	SELECT @var = 1
	
	WHILE ( @var < @accnt_length )
	BEGIN
		INSERT INTO #tmp_acc_number VALUES ( SUBSTRING(@account,@var,3) , SUBSTRING(@account,@var+3,5) )
		
		SELECT @syb_error_code = @@error
			 
		IF @syb_error_code <> 0
        BEGIN

            raiserror 50005 "Query to process multiple account list failed."

            select @custom_error_code=@@error

			IF(@debug_flag="Y")
			BEGIN
                INSERT INTO #<oc>..si_position_adv_ma_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
            END

            RETURN @custom_error_code
        END
		
		SELECT @var = @var + 8
	END
	
	IF ( @service_call_type = 'CMB' )
	BEGIN
		SELECT @action1 = '%' , @action2 = '%'
	END
	
	IF ( @service_call_type = 'INT' )
	BEGIN
		SELECT @action1 = 'I' , @action2 = 'U'
	END

	IF ( LTRIM(RTRIM(@security_identifier_value)) = NULL )
	BEGIN
		SELECT @security_identifier_type = NULL
	END

	
	IF ( @security_identifier_type = 'ADP_SEC' )
	BEGIN
		SELECT @security_adp_nbr = LTRIM(RTRIM(@security_identifier_value))
	END
	ELSE
	BEGIN
		SELECT @security_adp_nbr = '%'
	END
	
	
	
	IF(	 LTRIM(@type_account_cd) = NULL  )
	BEGIN
		SELECT @type_account_cd = '%'
	END
	
	IF(	 LTRIM(@currency_cd) = NULL  )
	BEGIN
		SELECT @currency_cd = '%'
	END
	
	SELECT security_adp_nbr 
	INTO #tseclist
	FROM 
		#<sb>..si_security
	WHERE
		1=2
		
	IF ( @security_identifier_type = 'MF_COM' )
	BEGIN

		SELECT @table_extract = 'Y'
		INSERT INTO #tseclist
		SELECT security_adp_nbr
		FROM 
			#<sb>..si_security sisec
		WHERE
			sisec.company_code =@security_identifier_value 
	END
	ELSE IF ( @security_identifier_type = 'UND_SEC' )
	BEGIN
                SELECT @table_extract = 'Y'
		SELECT security_adp_nbr
		INTO #tsxk
		FROM
			#<bp>..tsec_xref_key
		WHERE
			type_xref_cd IN ( 'CN' ,'SY') AND
			cross_reference_cd = @security_identifier_value

		INSERT INTO #tseclist
		SELECT optn.security_adp_nbr
		FROM
			#<bp>..toption_data optn,
			#tsxk t
		WHERE
			optn.scrty_adp_base_nbr = t.security_adp_nbr
		UNION
		SELECT opt.security_adp_nbr
		FROM
			#<bp>..toption_data opt
		WHERE
			opt.occ_optn_sym_id = @security_identifier_value

	END
	ELSE
	BEGIN
		SELECT @table_extract = 'N'
	END	
	
 
	-- Create #result T+1 Change 
	CREATE TABLE #result
	(
	   branch_cd                    char(3)         NULL,
	   account_cd                   char(5)         NULL,
	   currency_cd                  char(3)         NULL,
	   type_account_cd              char(1)         NULL,
	   cdn_symbol                   char(20)        NULL,
	   us_symbol                    char(20)        NULL,
	   market                       varchar(2)      NULL,
	   security_adp_nbr             char(7)         NULL,
	   underlying_cdn_symbol        varchar(20)     NULL,
	   underlying_us_symbol         varchar(20)     NULL,
	   scrty_adp_base_nbr           char(7)         NULL,
	   occ_optn_sym_id              char(6)         NULL,
	   company_code                 char(3)         NULL,
	   memo_holder_sub_cd_1         varchar(2)      NULL,
	   memo_holder_qty_1            decimal(17,5)   NULL,
	   memo_holder_sub_cd_2         varchar(2)      NULL,
	   memo_holder_qty_2            decimal(17,5)   NULL,
	   memo_holder_sub_cd_3         varchar(2)      NULL,
	   memo_holder_qty_3            decimal(17,5)   NULL,
	   desc_sec_txt_e1              char(30)        NULL,
	   desc_sec_txt_e2              char(30)        NULL,
	   desc_sec_txt_e3              char(30)        NULL,
	   security_ida_cd              char(4)         NULL,
	   msd_class_cd                 varchar(7)      NULL,
	   investment_category          varchar(30)     NULL,
	   call_or_put                  varchar(1)      NULL,
	   expiration_dt                varchar(10)     NULL,
	   strike_price_amt             decimal(16,8)   NULL,
	   trade_dt_qty_yesterday       decimal(17,5)   NULL,
	   today_total_qty_delta        decimal(17,5)   NULL,
	   today_total_qty_combined     decimal(18,5)   NULL,
	   market_value_amt             decimal(17,2)   NULL,
	   holder_price_txt             char(11)        NULL,
	   maturity_dt                  char(10)        NULL,
	   interest_rt                  decimal(11,8)   NULL,
	   action                       char(1)         NULL,
	   bk_cost_amt                  decimal(17,2)   NULL,
	   position_margin              decimal(38,2)   NULL,
	   activity_last_dt             char(10)        NULL,
	   settlement_dt_qty_yesterday  decimal(17,5)   NULL,
	   settlement_dt_qty_combined   decimal(18,5)   NULL,
	   rr_cd                        char(3)         NULL,
	   desc_sec_txt_f1              char(30)        NULL,
	   desc_sec_txt_f2              char(30)        NULL,
	   desc_sec_txt_f3              char(30)        NULL,
	   royalty_ind                  char(1)         NULL,
	   remic_ind                    char(1)         NULL,
	   reit_ind                     char(1)         NULL,
	   uts_canadian_cd              char(1)         NULL,
	   etf_ind                      char(1)         NULL,
	   annuity_cd                   char(1)         NULL,
	   cmo_ind                      char(1)         NULL,
	   pool_nbr                     char(8)         NULL,
	   bk_cost_amt_org              decimal(17,2)   NULL,
	   err_cd_trade_dt              char(2)         NULL,
	   lmu_dt_ind_trade_dt          char(1)         NULL,
	   msd_price                    numeric(16,4)   NULL,
	   isin                         varchar(20)     NULL,
	   dated_dt                     char(10)        NULL,
	   date_coupon_cd               char(4)         NULL,
	   class_level_one              char(3)         NULL,
	   class_level_two              char(3)         NULL,
	   class_level_three            char(3)         NULL,
	   class_level_four             char(3)         NULL,
	   updt_last_tmstp              datetime        NULL
	)  
	
	-- Create #tmp_fxrate T+1 Change 
	select currency_cd,cnvrt_trd_crrna_rt into #tmp_fxrate from #<sb>..si_fxrate having processing_dt =  max(cast(processing_dt as date))
	
	IF ( @service_call_type = 'CMB' ) OR ( @service_call_type = 'INT' )
	BEGIN
	
		SELECT	tsechldr.branch_cd,
				tsechldr.account_cd,
				tsechldr.currency_cd,
				tsechldr.type_account_cd,
				tsechldr.security_adp_nbr,
			    tsechldr.issue_when_ind, 
				tsechldr.seq_nbr, 
				tsechldr.client_nbr, 
				tsechldr.trade_dt_qty,
				tsechldr.today_total_qty,
				CASE
					WHEN ( patindex("%[^0-9.-]%", tsechldr.holder_price_txt) > 0) THEN convert(money,0)
					ELSE convert(money,tsechldr.holder_price_txt)
				END holder_price_txt_num,
				tsechldr.holder_price_txt,	
				tsechldr.action,
				tsechldr.activity_last_dt,
				tsechldr.settlement_dt_qty,
				tsechldr.rr_cd,
				tsechldr.market_value_amt,
				tsechldr.mrgn_hous_rqmt_amt,
				tsechldr.updt_last_tmstp
			INTO	#temptaccsechldr
			FROM 	#<bp>..taccount_sec_hldr tsechldr
			WHERE 	
				1=2

				
            IF ( @table_extract = 'Y' )
			BEGIN
			    INSERT INTO #temptaccsechldr
			    SELECT  tsechldr.branch_cd,
			    tsechldr.account_cd,
			    tsechldr.currency_cd,
			    tsechldr.type_account_cd,
			    tsechldr.security_adp_nbr,
				tsechldr.issue_when_ind,
				tsechldr.seq_nbr,
				tsechldr.client_nbr,
				tsechldr.trade_dt_qty,
				tsechldr.today_total_qty,
				CASE
					WHEN ( patindex("%[^0-9.-]%", tsechldr.holder_price_txt) > 0) THEN convert(money,0)
					ELSE convert(money,tsechldr.holder_price_txt)
				END holder_price_txt_num,
				tsechldr.holder_price_txt,
				tsechldr.action,
				tsechldr.activity_last_dt,
				tsechldr.settlement_dt_qty,
				tsechldr.rr_cd,
				tsechldr.market_value_amt,
				tsechldr.mrgn_hous_rqmt_amt,
				tsechldr.updt_last_tmstp
				FROM    #<bp>..taccount_sec_hldr tsechldr,
						#tseclist tsl,
						#tmp_acc_number t
				WHERE   tsechldr.client_nbr = '0069' AND
						tsechldr.branch_cd > '' AND 
						tsechldr.account_cd > '' AND 
						tsechldr.currency_cd > '' AND  
						tsechldr.type_account_cd > ''AND
						tsechldr.security_adp_nbr > '' AND 
						tsechldr.issue_when_ind > '' AND
						tsechldr.seq_nbr > -1 AND
						tsechldr.branch_cd  = t.branch_cd  AND
						tsechldr.account_cd = t.account_cd AND
						tsechldr.security_adp_nbr = 
								CASE WHEN @security_adp_nbr  = '%'
								    THEN tsechldr.security_adp_nbr
								 ELSE @security_adp_nbr
								END 
                                AND tsechldr.type_account_cd =
                                CASE WHEN @type_account_cd = '%'
								 THEN tsechldr.type_account_cd
								 ELSE  @type_account_cd 
								END
								AND tsechldr.currency_cd = 
								 CASE WHEN @currency_cd = '%'
								 THEN tsechldr.currency_cd
								 ELSE @currency_cd 
								END
								AND
								tsechldr.security_adp_nbr = tsl.security_adp_nbr 
                                AND
                                ( tsechldr.action =
                                  CASE WHEN @action1 = '%'
                                     THEN tsechldr.action
                                  ELSE	@action1								 
								  END
								  OR
								  tsechldr.action =
                                  CASE WHEN @action2 = '%'
                                     THEN tsechldr.action
                                  ELSE	@action2								 
								  END
								)
				END
				ELSE
                BEGIN
                INSERT INTO #temptaccsechldr
                SELECT  tsechldr.branch_cd,
                        tsechldr.account_cd,
                        tsechldr.currency_cd,
                        tsechldr.type_account_cd,
                        tsechldr.security_adp_nbr,
                        tsechldr.issue_when_ind,
                        tsechldr.seq_nbr,
                        tsechldr.client_nbr,
                        tsechldr.trade_dt_qty,
                        tsechldr.today_total_qty,
                        CASE
                                WHEN ( patindex("%[^0-9.-]%", tsechldr.holder_price_txt) > 0) THEN convert(money,0)
                                ELSE convert(money,tsechldr.holder_price_txt)
                        END holder_price_txt_num,
                        tsechldr.holder_price_txt,
                        tsechldr.action,
                        tsechldr.activity_last_dt,
                        tsechldr.settlement_dt_qty,
                        tsechldr.rr_cd,
                        tsechldr.market_value_amt,
                        tsechldr.mrgn_hous_rqmt_amt,
			tsechldr.updt_last_tmstp
                FROM    #<bp>..taccount_sec_hldr tsechldr,
						#tmp_acc_number t
                WHERE   tsechldr.client_nbr = '0069' AND
						tsechldr.branch_cd > '' AND 
						tsechldr.account_cd > '' AND 
						tsechldr.currency_cd > '' AND  
						tsechldr.type_account_cd > ''AND
						tsechldr.security_adp_nbr > '' AND 
						tsechldr.issue_when_ind > '' AND
						tsechldr.seq_nbr > -1 AND
                                tsechldr.branch_cd  = t.branch_cd  AND
                                tsechldr.account_cd = t.account_cd AND
                                tsechldr.security_adp_nbr = 
								CASE WHEN @security_adp_nbr  = '%'
								    THEN tsechldr.security_adp_nbr
								 ELSE @security_adp_nbr
								END 
                                AND tsechldr.type_account_cd =
                                CASE WHEN @type_account_cd = '%'
								 THEN tsechldr.type_account_cd
								 ELSE  @type_account_cd 
								END
								AND tsechldr.currency_cd = 
								 CASE WHEN @currency_cd = '%'
								 THEN tsechldr.currency_cd
								 ELSE @currency_cd 
								END								 
                                AND
                                ( tsechldr.action =
                                  CASE WHEN @action1 = '%'
                                     THEN tsechldr.action
                                  ELSE	@action1								 
								  END
								  OR
								  tsechldr.action =
                                  CASE WHEN @action2 = '%'
                                     THEN tsechldr.action
                                  ELSE	@action2								 
								  END
								)
                END

				
			SELECT 	rownum = identity(32),
					tshm.client_nbr,
					tshm.branch_cd,
					tshm.account_cd,
					tshm.currency_cd,
					tshm.type_account_cd,
					tshm.security_adp_nbr,
					tshm.issue_when_ind,
					tshm.seq_nbr,
					tshm.memo_holder_cd,
					tshm.memo_holder_sub_cd,
					tshm.memo_holder_qty
			INTO	#temptaccmemo
			FROM	#<bp>..tacc_sec_hldr_memo  tshm,
					#tmp_acc_number t
			WHERE	tshm.client_nbr = '0069'		AND
					tshm.branch_cd > '' AND 
					tshm.account_cd > '' AND 
					tshm.currency_cd > '' AND  
					tshm.type_account_cd > ''AND
					tshm.security_adp_nbr > '' AND 
					tshm.issue_when_ind > '' AND
					tshm.seq_nbr > -1 AND
					tshm.memo_holder_cd  > '' AND 
					tshm.memo_holder_sub_cd  > '' AND					
					tshm.branch_cd = t.branch_cd	AND
					tshm.account_cd = t.account_cd 
			ORDER BY 	
					tshm.client_nbr,
					tshm.branch_cd,
					tshm.account_cd,
					tshm.currency_cd,
					tshm.type_account_cd,
					tshm.security_adp_nbr,
					tshm.issue_when_ind,
					tshm.seq_nbr,
					tshm.memo_holder_cd,
					tshm.memo_holder_sub_cd

	
			
			SELECT	a.client_nbr, 
					a.branch_cd,
					a.account_cd,
					a.currency_cd,
					a.type_account_cd,
					a.security_adp_nbr,
					a.issue_when_ind,
					a.seq_nbr,
					MIN(memo_holder_sub_cd_1) memo_holder_sub_cd_1,
					MIN(memo_holder_qty_1) memo_holder_qty_1,
					MIN(memo_holder_sub_cd_2) memo_holder_sub_cd_2,
					MIN(memo_holder_qty_2) memo_holder_qty_2,
					MIN(memo_holder_sub_cd_3) memo_holder_sub_cd_3,
					MIN(memo_holder_qty_3) memo_holder_qty_3
			INTO	#tmemo
			FROM	(
					SELECT	client_nbr,
							branch_cd,
							account_cd,
							currency_cd,
							type_account_cd,
							security_adp_nbr,
							issue_when_ind,
							seq_nbr,
							CASE 
							WHEN  rownum = MIN ( rownum ) THEN memo_holder_sub_cd
							END memo_holder_sub_cd_1 ,
							CASE 
							WHEN  rownum = MIN ( rownum ) THEN memo_holder_qty
							END memo_holder_qty_1 ,
							CASE 
							WHEN  rownum = MIN ( rownum ) +1  THEN memo_holder_sub_cd
							END memo_holder_sub_cd_2 ,
							CASE 
							WHEN  rownum = MIN ( rownum ) +1  THEN memo_holder_qty
							END memo_holder_qty_2 ,
							CASE 
							WHEN  rownum = MIN ( rownum ) +2 THEN memo_holder_sub_cd
							END memo_holder_sub_cd_3 ,
							CASE 
							WHEN  rownum = MIN ( rownum ) +2  THEN memo_holder_qty
							END memo_holder_qty_3 
					FROM	#temptaccmemo
					GROUP BY
							client_nbr, 
							branch_cd,
							account_cd,
							currency_cd,
							type_account_cd,
							security_adp_nbr,
							issue_when_ind,
							seq_nbr
					)a
					GROUP BY
							a.client_nbr, 
							a.branch_cd,
							a.account_cd,
							a.currency_cd,
							a.type_account_cd,
							a.security_adp_nbr,
							a.issue_when_ind,
							a.seq_nbr

			
			select
			       tsechldr.branch_cd,
			       tsechldr.account_cd,
			       tsechldr.currency_cd,
			       tsechldr.type_account_cd,
			       tsechldr.security_adp_nbr,
			       tsechldr.issue_when_ind,
			       tsechldr.seq_nbr,
			       tsechldr.client_nbr,
			       tsechldr.trade_dt_qty,
			       tsechldr.today_total_qty,
			       tsechldr.holder_price_txt_num,
			       tsechldr.holder_price_txt,
			       tsechldr.action,
			       tsechldr.activity_last_dt,
			       tsechldr.settlement_dt_qty,
			       tsechldr.rr_cd,
			       tsechldr.market_value_amt,
			       tsechldr.mrgn_hous_rqmt_amt,
			       tsechldr.updt_last_tmstp,
			       sum(m.house_rqrmt_amt) house_rqrmt_amt
			 INTO #taccsechldrm
			 FROM
			    #temptaccsechldr tsechldr
			 LEFT OUTER JOIN #<bp>..tcan_mrgn_optn m
			 ON      tsechldr.client_nbr       = m.client_nbr AND
			         tsechldr.branch_cd        = m.branch_cd AND
			         tsechldr.account_cd       = m.account_cd AND
			         tsechldr.currency_cd      = m.currency_cd AND
			         tsechldr.security_adp_nbr = m.security_adp_nbr
			 GROUP BY
			   tsechldr.client_nbr,tsechldr.branch_cd,tsechldr.account_cd,tsechldr.currency_cd,tsechldr.type_account_cd,tsechldr.security_adp_nbr
		
	-- Getting new Positions using si security -- T+1 Change

	select distinct a.* into #tmp_new_taccsechldrm
	from #taccsechldrm a left join #<sb>..si_security sisec on a.security_adp_nbr = sisec.security_adp_nbr 
	where sisec.security_adp_nbr is null
	 
	-- Getting count of new Positions  -- T+1 Change
	
	declare @newpositioncount int 
	set @newpositioncount = 0
	select  @newpositioncount = count(*) from #tmp_new_taccsechldrm	 
	
	
	-- inserting result of new Positions into temp table -- T+1 Change
	if @newpositioncount > 0 
	begin
	insert into #result
	SELECT	a.branch_cd,
					a.account_cd,
					a.currency_cd,
					a.type_account_cd,
					c.cross_reference_cd cdn_symbol,
					d.cross_reference_cd us_symbol,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN
						CASE
							WHEN  b.currency_cd IN ('000','002') THEN 'ca' 
							ELSE  'us' 
						END
						WHEN LTRIM(c.type_xref_cd) IS NOT NULL AND LTRIM(d.type_xref_cd) IS NULL THEN "ca"
						WHEN LTRIM(c.type_xref_cd) IS NULL AND LTRIM(d.type_xref_cd) IS NOT NULL  THEN "us"
						WHEN LTRIM(c.type_xref_cd) IS NULL AND LTRIM(d.type_xref_cd) IS NULL THEN
						CASE
							WHEN b.currency_cd IN ('000','002') THEN 'ca'
							ELSE 'us'
						END
						WHEN LTRIM(c.type_xref_cd) IS NOT NULL AND LTRIM(d.type_xref_cd) IS NOT NULL  THEN
						CASE
							WHEN a.currency_cd IN ('000','002') THEN 'ca'
							WHEN a.currency_cd = '001' THEN 'us'
							WHEN a.currency_cd NOT IN ('000','001','002') AND b.currency_cd IN ('000','002') THEN 'ca'
							ELSE 'us'
						END
					END market,
					a.security_adp_nbr,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN y.cross_reference_cd 
					END	underlying_cdn_symbol,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN z.cross_reference_cd
					END underlying_us_symbol,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN e.scrty_adp_base_nbr 
					END scrty_adp_base_nbr,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN e.occ_optn_sym_id
					END occ_optn_sym_id,
					null company_code,
					tm.memo_holder_sub_cd_1,
					tm.memo_holder_qty_1,
					tm.memo_holder_sub_cd_2,
					tm.memo_holder_qty_2,
					tm.memo_holder_sub_cd_3,
					tm.memo_holder_qty_3,
					h.desc_sec_txt desc_sec_txt_e1,
					i.desc_sec_txt desc_sec_txt_e2,
					j.desc_sec_txt desc_sec_txt_e3,
					b.security_ida_cd,
					b.msd_class1_cd+b.msd_class2_cd+b.msd_class3_cd+b.msd_class4_cd+b.msd_class5_cd+b.msd_class6_cd +b.msd_class7_cd msd_class_cd,
					null investment_category,
					CASE
						WHEN b.security_ida_cd = '8000' THEN 'C'
						WHEN b.security_ida_cd = '8100' THEN 'P'
					END call_or_put,
					CASE	
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN convert(char(10),e.expiration_dt,101) 
					END expiration_dt,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN e.strike_price_amt
					END strike_price_amt,
					a.trade_dt_qty trade_dt_qty_yesterday,
					a.today_total_qty today_total_qty_delta,
					a.trade_dt_qty + a.today_total_qty today_total_qty_combined,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN CONVERT(decimal(17,2), convert(money,a.holder_price_txt_num) * a.trade_dt_qty * isnull(e.factor_pct,100))
						ELSE a.market_value_amt
					END market_value_amt,
					a.holder_price_txt,
					convert(char(10),q.maturity_dt,101) maturity_dt,			
					q.interest_rt interest_rt,
					a.action,
					CASE
						WHEN o.err_cd = 'SE' OR o.err_cd = 'ME' OR o.err_cd = 'RE' OR o.err_cd = 'XE' THEN 0
						ELSE o.bk_cost_amt
					END  bk_cost_amt,
					CASE
						WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100'  THEN a.house_rqrmt_amt
						ELSE a.mrgn_hous_rqmt_amt
					END position_margin,
					convert(char(10),a.activity_last_dt,101) activity_last_dt,
					a.settlement_dt_qty settlement_dt_qty_yesterday,
					a.settlement_dt_qty + a.today_total_qty settlement_dt_qty_combined,
					a.rr_cd,
					k.desc_sec_txt desc_sec_txt_f1,
					l.desc_sec_txt desc_sec_txt_f2,
					m.desc_sec_txt desc_sec_txt_f3,
					b.royalty_ind,
					b.remic_ind,
					b.reit_ind,
					b.uts_canadian_cd,
					b.etf_ind,
					b.annuity_cd,
					q.cmo_ind,
					q.pool_nbr,
					o.bk_cost_amt bk_cost_amt_org,
					o.err_cd err_cd_trade_dt,
					o.lmu_dt_ind lmu_dt_ind_trade_dt,
					0.0 msd_price,
					CASE WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN isi.cross_reference_cd else isix.cross_reference_cd end isin,
					convert(varchar(10),q.dated_dt,101)  dated_dt,
					q.date_coupon_cd date_coupon_cd,					
					null class_level_one,--sisec.class_level_one,
					null class_level_two,--sisec.class_level_two,
					null class_level_three,--sisec.class_level_three,
					null class_level_four,--sisec.class_level_four,	
					a.updt_last_tmstp				
				FROM 
					#tmp_new_taccsechldrm a
					LEFT OUTER JOIN #<bp>..tmsd_base b		ON	a.security_adp_nbr = b.security_adp_nbr
					LEFT OUTER JOIN #<bp>..toption_data e   ON b.security_adp_nbr = e.security_adp_nbr and e.security_adp_nbr is not null
					LEFT OUTER JOIN #<bp>..tsec_xref_key c  ON b.security_adp_nbr = c.security_adp_nbr AND c.type_xref_cd = 'CN'
					LEFT OUTER JOIN #<bp>..tsec_xref_key d  ON b.security_adp_nbr = d.security_adp_nbr AND d.type_xref_cd = 'SY'
					LEFT OUTER JOIN #<bp>..tsec_xref_key y 	ON e.scrty_adp_base_nbr=y.security_adp_nbr AND y.type_xref_cd = 'CN'
					LEFT OUTER JOIN #<bp>..tsec_xref_key z	ON e.scrty_adp_base_nbr=z.security_adp_nbr AND z.type_xref_cd = 'SY' 
					LEFT OUTER JOIN #<bp>..tsec_xref_key isi	ON e.scrty_adp_base_nbr=isi.security_adp_nbr  AND isi.type_xref_cd = 'IS'
					LEFT OUTER JOIN #<bp>..tsec_xref_key isix	ON a.security_adp_nbr=isix.security_adp_nbr AND isix.type_xref_cd = 'IS'
					LEFT OUTER JOIN #tmemo	tm						ON	a.currency_cd = tm.currency_cd 			AND	
																		a.issue_when_ind = tm.issue_when_ind 	AND 
																		a.seq_nbr = tm.seq_nbr					AND 
																		a.type_account_cd = tm.type_account_cd	AND 
																		a.account_cd = tm.account_cd			AND 
																		a.branch_cd = tm.branch_cd				AND 
																		a.client_nbr = tm.client_nbr			AND 
																		a.security_adp_nbr = tm.security_adp_nbr  
					--LEFT OUTER JOIN #<od>..od_mutual_fund_xref f	ON	b.security_adp_nbr = f.whole_adp_sec_num and rtrim(f.frac_adp_sec_num) is null
					LEFT OUTER JOIN #<bp>..tsecurity_desc h			ON	b.security_adp_nbr = h.security_adp_nbr AND 
																		h.language_cd = 'E'						AND 
																		h.line_txt_nbr = 1
					LEFT OUTER JOIN #<bp>..tsecurity_desc i			ON 	b.security_adp_nbr = i.security_adp_nbr AND 
																		i.language_cd = 'E'						AND 
																		i.line_txt_nbr= 2
					LEFT OUTER JOIN #<bp>..tsecurity_desc j			ON 	b.security_adp_nbr = j.security_adp_nbr AND 
																		j.language_cd = 'E'						AND 
																		j.line_txt_nbr = 3	
					LEFT OUTER JOIN #<bp>..tsecurity_desc k			ON 	b.security_adp_nbr = k.security_adp_nbr AND 
																		k.language_cd = 'F'						AND 
																		k.line_txt_nbr = 1
					LEFT OUTER JOIN #<bp>..tsecurity_desc l			ON 	b.security_adp_nbr = l.security_adp_nbr AND 
																		l.language_cd = 'F'						AND 
																		l.line_txt_nbr = 2
					LEFT OUTER JOIN #<bp>..tsecurity_desc m			ON 	b.security_adp_nbr = m.security_adp_nbr AND 
																		m.language_cd = 'F'						AND 
																		m.line_txt_nbr = 3						
					--LEFT OUTER JOIN #<od>..od_security_master n		ON	b.security_adp_nbr = n.adp_sec_num
					LEFT OUTER JOIN #<bp>..tcan_td_bk_cst_ps o		ON	a.client_nbr       = o.client_nbr		AND
																		a.branch_cd        = o.branch_cd 		AND
																		a.account_cd       = o.account_cd 		AND
																		a.currency_cd      = o.currency_cd 		AND
																		a.type_account_cd  = o.type_account_cd	AND
																		a.security_adp_nbr = o.security_adp_nbr
					LEFT OUTER JOIN #<bp>..tbond_data q 			ON	b.security_adp_nbr = q.security_adp_nbr	
	end
	
	

		-- Inserting result of old Positions into Temp Result table -- T+1 Change
	 	insert into #result
		SELECT a.branch_cd,					 
		a.account_cd,
		a.currency_cd,
		a.type_account_cd,					
		sisec.cdn_symbol,
		sisec.us_symbol,
		case	WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN
			CASE
				WHEN  sisec.currency_cd IN ('000','002') THEN 'ca' 
				ELSE  'us' 
			END
			WHEN sisec.cdn_symbol IS NOT NULL AND sisec.us_symbol IS NULL THEN "ca"
			WHEN sisec.us_symbol  IS NOT NULL AND sisec.cdn_symbol IS NULL THEN "us"						
			WHEN sisec.cdn_symbol IS NULL AND sisec.us_symbol IS NULL THEN  
			CASE
				WHEN sisec.currency_cd IN ('000','002') THEN 'ca'
				ELSE 'us'
			END
			WHEN sisec.cdn_symbol IS NOT NULL AND sisec.us_symbol IS NOT NULL THEN
			CASE
				WHEN a.currency_cd IN ('000','002') THEN 'ca'
				WHEN a.currency_cd = '001' THEN 'us'
				WHEN a.currency_cd NOT IN ('000','001','002') AND sisec.currency_cd IN ('000','002') THEN 'ca'
				ELSE 'us'
			END
		END market ,
		a.security_adp_nbr,
		
			 CASE 
				WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN sisecy.cdn_symbol 
			 END
			 underlying_cdn_symbol,
		 
			CASE
				WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN sisecy.us_symbol
			END
		underlying_us_symbol,
		sisec.scrty_adp_base_nbr,
		sisec.occ_optn_sym_id,				 
		sisec.company_code,					 
		tm.memo_holder_sub_cd_1,
		tm.memo_holder_qty_1,
		tm.memo_holder_sub_cd_2,
		tm.memo_holder_qty_2,
		tm.memo_holder_sub_cd_3,
		tm.memo_holder_qty_3,
		sisec.desc_sec_txt_e1 ,
		sisec.desc_sec_txt_e2 ,
		sisec.desc_sec_txt_e3 ,
		sisec.security_ida_cd ,
		sisec.msd_class_cd,					 
		sisec.investment_category,
		sisec.call_or_put,
		sisec.expiration_dt,
		sisec.strike_price_amt, 
		a.trade_dt_qty trade_dt_qty_yesterday,
		a.today_total_qty today_total_qty_delta,
		a.trade_dt_qty + a.today_total_qty today_total_qty_combined,
		CASE
			WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN CONVERT(decimal(17,2), convert(money,a.holder_price_txt_num) * a.trade_dt_qty * isnull(sisec.factor_pct,100))
			ELSE a.market_value_amt
		END market_value_amt,
					a.holder_price_txt,
					sisec.maturity_dt,				 
					sisec.interest_rt,
					a.action,
					CASE
						WHEN o.err_cd = 'SE' OR o.err_cd = 'ME' OR o.err_cd = 'RE' OR o.err_cd = 'XE' THEN 0
						ELSE o.bk_cost_amt
					END  bk_cost_amt,
					CASE
						WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100'  THEN a.house_rqrmt_amt
						ELSE a.mrgn_hous_rqmt_amt
					END position_margin,
					convert(char(10),a.activity_last_dt,101) activity_last_dt,
					a.settlement_dt_qty settlement_dt_qty_yesterday,
					a.settlement_dt_qty + a.today_total_qty settlement_dt_qty_combined,
					a.rr_cd,
					sisec.desc_sec_txt_f1,
					sisec.desc_sec_txt_f2,
					sisec.desc_sec_txt_f3,
					sisec.royalty_ind ,
					sisec.remic_ind ,	
					sisec.reit_ind,		
					sisec.uts_canadian_cd,	
					sisec.etf_ind,		
					sisec.annuity_cd,	
					sisec.cmo_ind,	
					sisec.pool_nbr,
					o.bk_cost_amt bk_cost_amt_org,
					o.err_cd err_cd_trade_dt,
					o.lmu_dt_ind lmu_dt_ind_trade_dt,					
					case WHEN isnull(p.price,0.0) = 0.0 then 0.0 when a.currency_cd = '000' then convert(decimal(16,4),p.price) else convert(decimal(16,4),p.price/fx.cnvrt_trd_crrna_rt) end as msd_price,						
					CASE WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' THEN sisecy.isin else sisec.isin end isin,					
					sisec.dated_dt,
					sisec.date_coupon_cd,					 
					sisec.class_level_one,
					sisec.class_level_two,
					sisec.class_level_three,
					sisec.class_level_four,
					a.updt_last_tmstp
					 
	FROM 
		#taccsechldrm a
		left join       #tmp_new_taccsechldrm np		on 	a.security_adp_nbr = np.security_adp_nbr AND
															a.client_nbr       = np.client_nbr AND
															a.branch_cd        = np.branch_cd  AND
															a.account_cd       = np.account_cd AND
															a.currency_cd      = np.currency_cd  	
		LEFT OUTER JOIN #<sb>..si_security  sisec  		ON a.security_adp_nbr = sisec.security_adp_nbr
		LEFT OUTER JOIN #<sb>..si_security  sisecy      ON sisecy.security_adp_nbr = sisec.scrty_adp_base_nbr			
		LEFT OUTER JOIN #tmemo	tm				 		ON	a.currency_cd = tm.currency_cd 			AND	
															a.issue_when_ind = tm.issue_when_ind 	AND 
															a.seq_nbr = tm.seq_nbr					AND 
															a.type_account_cd = tm.type_account_cd	AND 
															a.account_cd = tm.account_cd			AND 
															a.branch_cd = tm.branch_cd				AND 
															a.client_nbr = tm.client_nbr			AND 
															a.security_adp_nbr = tm.security_adp_nbr		
		LEFT OUTER JOIN #<bp>..tcan_td_bk_cst_ps  o		ON	a.client_nbr       =  o.client_nbr		AND 
															a.branch_cd        = o.branch_cd 		AND
															a.account_cd       = o.account_cd 		AND
															a.currency_cd      = o.currency_cd 		AND
															a.type_account_cd  = o.type_account_cd	AND
															a.security_adp_nbr = o.security_adp_nbr 													
		LEFT OUTER JOIN #<sb>..si_security_price p		 ON	a.security_adp_nbr = p.security_adp_nbr 		
		LEFT OUTER JOIN #tmp_fxrate fx 					ON  a.currency_cd = fx.currency_cd		
		where np.security_adp_nbr is null and (sisec.security_adp_nbr > '')
 		 
	 
	 
	 
	 	   
 
		--selectin result from temptable -- T+1 Change
		select * from  #result
		
	SELECT @syb_error_code = @@error , @no_of_records = @@rowcount
	
	END
	
	IF ( @service_call_type = 'PRV' )
	BEGIN
	
		 IF ( @table_extract = 'Y' )
                BEGIN
                SELECT  sipos.branch_cd,
                                sipos.account_cd,
                                sipos.currency_cd,
                                sipos.type_account_cd,
                                sisec.cdn_symbol,
                                sisec.us_symbol,
                                sipos.market,
                                sipos.security_adp_nbr,
                                sisec.cdn_symbol underlying_cdn_symbol,
                                sisec.us_symbol underlying_us_symbol,
                                sisec.scrty_adp_base_nbr,
                                sisec.occ_optn_sym_id,
                                sisec.company_code,
                                sipos.memo_holder_sub_cd_1,
                                sipos.memo_holder_qty_1,
                                sipos.memo_holder_sub_cd_2,
                                sipos.memo_holder_qty_2,
                                sipos.memo_holder_sub_cd_3,
                                sipos.memo_holder_qty_3,
                                sisec.desc_sec_txt_e1,
                                sisec.desc_sec_txt_e2,
                                sisec.desc_sec_txt_e3,
                                sisec.security_ida_cd,
                                sisec.msd_class_cd,
                                sisec.investment_category,
                                sisec.call_or_put,
                                sisec.expiration_dt,
                                sisec.strike_price_amt,
                                sipos.trade_dt_qty trade_dt_qty_yesterday,
                                sipos.today_total_qty today_total_qty_delta,
                                sipos.today_total_qty_combined,
                                sipos.market_value_amt,
                                sipos.holder_price_txt,
                                sisec.maturity_dt,
                                sisec.interest_rt,
                                sipos.action,
                                sipos.bk_cost_amt_trade_dt bk_cost_amt,
                                sipos.position_margin,
                                sipos.activity_last_dt,
                                sipos.settlement_dt_qty settlement_dt_qty_yesterday,
                                sipos.settlement_dt_qty_combined,
                                sipos.rr_cd,
                                sisec.desc_sec_txt_f1,
                                sisec.desc_sec_txt_f2,
                                sisec.desc_sec_txt_f3,
                                sisec.royalty_ind,
                                sisec.remic_ind,
                                sisec.reit_ind,
                                sisec.uts_canadian_cd,
                                sisec.etf_ind,
                                sisec.annuity_cd,
                                sisec.cmo_ind,
                                sisec.pool_nbr,
				sipos.bk_cost_amt_trade_dt_org bk_cost_amt_org,
				sipos.err_cd_trade_dt,
				sipos.lmu_dt_ind_trade_dt,
				case when isnull(p.price,0.0) = 0.0 then 0.0 when sipos.currency_cd = '000' then convert(decimal(16,4),p.price) else convert(decimal(16,4),p.price/fx.cnvrt_trd_crrna_rt) end as msd_price,
				CASE WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' then sisecy.isin else sisec.isin end isin,				 
				sisec.dated_dt,
				sisec.date_coupon_cd,
				sisec.class_level_one,
				sisec.class_level_two,
				sisec.class_level_three,
				sisec.class_level_four,
				--it.accrued_interest_td,
				sipos.modify_timestamp updt_last_tmstp

			FROM 
				#<sb>..si_position sipos ,
                #<sb>..si_security sisec ,
				#<sb>..si_security sisecy ,
				#tseclist tsfl,
				#<sb>..si_security_price p,
				--#<sb>..si_cl_accrued_interest it,
				#tmp_fxrate fx,
 				#tmp_acc_number t
			WHERE	
				 sipos.branch_cd = t.branch_cd AND
                 sipos.account_cd = t.account_cd AND
                 sipos.security_adp_nbr *= sisec.security_adp_nbr AND
				 sipos.security_adp_nbr *= p.security_adp_nbr AND
			     sisec.scrty_adp_base_nbr *= sisecy.security_adp_nbr AND
				--sipos.security_adp_nbr *= it.security_adp_nbr AND
				 sipos.currency_cd *= fx.currency_cd AND
                 sipos.security_adp_nbr LIKE ( @security_adp_nbr )AND
                 sipos.type_account_cd LIKE ( @type_account_cd  )AND
                 sipos.currency_cd LIKE ( @currency_cd ) AND
                 sipos.security_adp_nbr = tsfl.security_adp_nbr


			SELECT @syb_error_code = @@error , @no_of_records = @@rowcount
			END
			
			ELSE
            BEGIN
            SELECT  sipos.branch_cd,
                        sipos.account_cd,
                                sipos.currency_cd,
                                sipos.type_account_cd,
                                sisec.cdn_symbol,
                                sisec.us_symbol,
                                sipos.market,
                                sipos.security_adp_nbr,
                                sisec.cdn_symbol underlying_cdn_symbol,
                                sisec.us_symbol underlying_us_symbol,
                                sisec.scrty_adp_base_nbr,
                                sisec.occ_optn_sym_id,
                                sisec.company_code,
                                sipos.memo_holder_sub_cd_1,
                                sipos.memo_holder_qty_1,
                                sipos.memo_holder_sub_cd_2,
                                sipos.memo_holder_qty_2,
                                sipos.memo_holder_sub_cd_3,
                                sipos.memo_holder_qty_3,
                                sisec.desc_sec_txt_e1,
                                sisec.desc_sec_txt_e2,
                                sisec.desc_sec_txt_e3,
                                sisec.security_ida_cd,
                                sisec.msd_class_cd,
                                sisec.investment_category,
                                sisec.call_or_put,
                                sisec.expiration_dt,
                                sisec.strike_price_amt,
                                sipos.trade_dt_qty trade_dt_qty_yesterday,
                                sipos.today_total_qty today_total_qty_delta,
                                sipos.today_total_qty_combined,
                                sipos.market_value_amt,
                                sipos.holder_price_txt,
                                sisec.maturity_dt,
                                sisec.interest_rt,
                                sipos.action,
								sipos.bk_cost_amt_trade_dt bk_cost_amt,
                                sipos.position_margin,
                                sipos.activity_last_dt,
                                sipos.settlement_dt_qty settlement_dt_qty_yesterday,
                                sipos.settlement_dt_qty_combined,
                                sipos.rr_cd,
                                sisec.desc_sec_txt_f1,
                                sisec.desc_sec_txt_f2,
                                sisec.desc_sec_txt_f3,
                                sisec.royalty_ind,
                                sisec.remic_ind,
                                sisec.reit_ind,
                                sisec.uts_canadian_cd,
                                sisec.etf_ind,
                                sisec.annuity_cd,
                                sisec.cmo_ind,
                                sisec.pool_nbr,
				sipos.bk_cost_amt_trade_dt_org bk_cost_amt_org,
				sipos.err_cd_trade_dt,
				sipos.lmu_dt_ind_trade_dt,
				case when isnull(p.price,0.0) = 0.0 then 0.0 when sipos.currency_cd = '000' then convert(decimal(16,4),p.price) else convert(decimal(16,4),p.price/fx.cnvrt_trd_crrna_rt) end as msd_price,
				CASE WHEN sisec.security_ida_cd ='8000' OR sisec.security_ida_cd ='8100' then sisecy.isin else sisec.isin end isin,
				sisec.dated_dt,
				sisec.date_coupon_cd,
				sisec.class_level_one,
				sisec.class_level_two,
				sisec.class_level_three,
				sisec.class_level_four,
				sipos.modify_timestamp updt_last_tmstp
						FROM
                                #<sb>..si_position sipos ,
                                #<sb>..si_security sisec ,
								#<sb>..si_security sisecy ,
								--#<sb>..si_cl_accrued_interest it,
								#<sb>..si_security_price p,
								#tmp_fxrate fx,	
								#tmp_acc_number t
                        WHERE
                                sipos.branch_cd = t.branch_cd AND
                                sipos.account_cd = t.account_cd AND
                                sipos.security_adp_nbr *= sisec.security_adp_nbr AND	
								sisec.scrty_adp_base_nbr *= sisecy.security_adp_nbr AND	
								sipos.security_adp_nbr *= p.security_adp_nbr AND		
								sipos.currency_cd *= fx.currency_cd AND								
                                sipos.security_adp_nbr LIKE ( @security_adp_nbr )AND
                                sipos.type_account_cd LIKE ( @type_account_cd  )AND
                                sipos.currency_cd LIKE ( @currency_cd )
                        SELECT @syb_error_code = @@error , @no_of_records = @@rowcount
                        END
	END

	
	IF ( @syb_error_code <> 0 ) 
	BEGIN
		IF ( @service_call_type = 'CMB')
		BEGIN
			raiserror 50006 "Query to retrieve combined positions detail failed."
			SELECT @custom_error_code=@@error
		END
		IF ( @service_call_type = 'INT')
		BEGIN
			raiserror 50007 "Query to retrieve intraday positions detail failed."
			SELECT @custom_error_code=@@error
		END
		IF ( @service_call_type = 'PRV')
		BEGIN
			raiserror 50008 "Query to retrieve previous day positions detail failed."
			SELECT @custom_error_code=@@error
		END

		IF (@debug_flag="Y")
		BEGIN
						INSERT INTO #<oc>..si_position_adv_ma_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
		END

		RETURN @custom_error_code
	END


	IF(@debug_flag="Y")
	BEGIN
		INSERT INTO #<oc>..si_position_adv_ma_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0 )
	END

	RETURN 
	
END
GO
		
GRANT EXECUTE ON sp_pos_adv_multi_accnt_service TO spica_ws 
GO

