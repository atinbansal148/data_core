use #<oc>
go

declare @ext int , @user varchar(255), @cdate datetime
set @ext = 0
set @user = suser_name()
set @cdate = getdate()
select @ext = count(*) from #<oc>..si_service_debug_config where service_id = 'sp_get_name_and_address_basic' 
if (@ext < 1)
begin
insert into #<oc>..si_service_debug_config(service_id,client_id,debug_flag,description,created_by,created_date,modified_by,modified_date)
values('sp_get_name_and_address_basic','GIS','Y','Basic Name And Adress',@user,@cdate,@user,@cdate)
end
else
begin
update #<oc>..si_service_debug_config set debug_flag = 'Y',modified_by=@user,modified_date=@cdate where service_id = 'sp_get_name_and_address_basic'
end

go

if exists (select * from sysobjects      
             where type = 'P' and name = 'sp_get_name_and_address_basic' )
   begin
      drop procedure sp_get_name_and_address_basic
   end
go

create procedure sp_get_name_and_address_basic
		@account_range			varchar(8100),						
		@app_id					char(10),
		@line_of_business		char(10),
		@req_time_stamp			CHAR(25),
		@transaction_id			char(40)

AS
declare  
 
		@start_time             datetime,                          
		@proc_name              varchar(35),                                                  
		@input_parm             varchar(800),         
		@debug_flag             char(1),        
		@var                    int,     
		@accnt_length           int,
		@syb_error_code         int ,
		@custom_error_code      int,
		@no_of_records          int
		
BEGIN
		
				
		--set plan optgoal allrows_oltp
		set compatibility_mode on
		set plan optlevel ase_default

		select 
			@debug_flag = debug_flag 		
		FROM 
			#<oc>..si_service_debug_config 
		WHERE 
			service_id= object_name(@@procid)--'sp_get_name_and_address_basic'		
			
		if(@debug_flag='Y')
		
		begin
			select @start_time=getdate()
			select @proc_name=object_name(@@procid)
			select @input_parm = @account_range + ","+ @app_id+","+ @line_of_business+","+ @req_time_stamp+","+ @transaction_id
		end
		
  --- check if complete account_no passed. Should be in multiples of 8 ( branch_cd + account_cd )
        
        select @accnt_length = char_length ( @account_range )
		select @syb_error_code = @@error	
		if ( ((@accnt_length%8) <> 0) OR (@syb_error_code <> 0) )
        begin
            raiserror 20074 "Incorrect account range list passed to service."
            select @custom_error_code=@@error
            if(@debug_flag="Y")
            begin
				insert into #<oc>..si_name_and_address_log  values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code)
            end
            return @custom_error_code
		end

 --- table for multi accounts and inserting the multiple accnts into the table
        
        SELECT branch_cd ,account_cd INTO #tmp_acc_number
        FROM bpsa..taccount_new WHERE  1=2
		
        select @var = 1
        
        while ( @var < @accnt_length )
        begin
                insert into #tmp_acc_number values ( substring(@account_range,@var,3) , substring(@account_range,@var+3,5) )
                
				select @syb_error_code = @@error
				if @syb_error_code <> 0
				begin
					raiserror 20075 "Query to process account range list failed."
					select @custom_error_code=@@error
				
					if(@debug_flag="Y") 
					begin
						insert into #<oc>..si_name_and_address_log  values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code)
					end
					return @custom_error_code
				end
				select @var = @var + 8
		end

        
------------------------------------------------------------------------------
--Code changes May 19 2015, addition of spad indicator
	
	select 
		an.branch_cd ,
		an.account_cd , 
		CASE	
			when rtrim(sp.user_key_txt) <> NULL then 'Y'
			else 'N'
		end spad_indicator
	into 
		#tmp_acc_number_sp
	from
		#tmp_acc_number an LEFT JOIN 
		#<bp>..tspad_info sp
	ON 
		sp.client_nbr = '0069'
		and sp.user_key_txt = an.branch_cd +'-'+ an. account_cd


------------------------------------------------------------------------------
SELECT
	tn.branch_cd ,
	tn.account_cd,
	tn.rr_cd,
	im.ia_name ia_name,  
	im.branch_num branch_num,
	tn.account_clsfn_cd,
	convert(char(10),tn.record_opened_dt, 101) record_opened_dt,
	convert(char(10),tn.record_changed_dt, 101) record_changed_dt ,
	tn.currency_cd,
	CASE 
		WHEN scm.currency_code IS NULL AND tn.currency_cd = '999' THEN 'All' 
		ELSE scm.currency_desc 
	END currency_desc,
	tn.adt_customer_cd,
	tr.rr_interest_1_txt client_card,
	tpn.first_nm first_nm_principal,	
	tpn.mi_initial_txt mi_initial_txt_principal,
	tpn.last_nm last_nm_principal,
	tpn.soc_sec_nbr soc_sec_nbr_principal,
	tpn.soc_sec_tax_cd soc_sec_tax_cd_principal,
	tpn.language_cd language_cd_principal,
	tpn.person_cmpy_cd person_cmpy_cd_principal ,
	company_nm_principal = (CASE WHEN tpn.person_cmpy_cd = 'C' THEN tpn.company_nm ELSE NULL END),
	CASE 
		WHEN tpn2.ap_type_cd = 'J' THEN 'Y' 
		ELSE 'N' 
	END joint_account_indicator,
	tpn2.first_nm first_nm_joint,
	tpn2.mi_initial_txt mi_initial_txt_joint,
	tpn2.last_nm last_nm_joint,
	company_nm_joint = (CASE WHEN tpn2.person_cmpy_cd = 'C' THEN tpn2.company_nm ELSE NULL END),
	convert(char(10), ti.birth_dt, 101) birth_dt,
	ti.short_nm short_nm,
	ti.tax_address_cd tax_address_cd,
	ti.mailing_address_cd mailing_address_cd,
	tpfn1.na_line_txt na_line_txt_1,
	tpfn2.na_line_txt na_line_txt_2,
	tpfn3.na_line_txt na_line_txt_3,
	tpfn4.na_line_txt na_line_txt_4,
	tpfn5.na_line_txt na_line_txt_5,
	tpfn6.na_line_txt na_line_txt_6,	
	tt1.type_account_cd type_account_cd_1,
	tt2.type_account_cd type_account_cd_2,
	tt3.type_account_cd type_account_cd_3,
	tt4.type_account_cd type_account_cd_4,
	tt5.type_account_cd type_account_cd_5,
	tt6.type_account_cd type_account_cd_6,
	tt7.type_account_cd type_account_cd_7,
	tt8.type_account_cd type_account_cd_8,
	tt9.type_account_cd type_account_cd_9,
	tt0.type_account_cd type_account_cd_0,
	tp.plan_type_cd plan_type_cd,
	tp.pbsa_cd,
	tp.plan_locked_cd,
	convert(char(10), tp.plan_locked_dt, 101) plan_locked_dt,
	convert(char(10), tp.plan_cls_dt, 101) plan_cls_dt,
	tp.acct_stts_cd acct_stts_cd_plan,
	tp.sps_ever_ind,
	tp.tax_cd,
	slar.rbc_business,
	slar.ds_fee_type_cd,
	slar.ds_account_category_cd,
	--Added new column on Mar 13 as per change in requirement.
	tn.updt_last_tmstp,
	--Added new column on May 19 as per change in requirement for spad indicator.
	t1.spad_indicator
FROM
	
		#<bp>..taccount_new tn 
        	INNER JOIN #tmp_acc_number_sp t1 ON tn.client_nbr = '0069' and tn.branch_cd = t1.branch_cd and tn.account_cd = t1.account_cd
		LEFT JOIN #<bp>..taccount_rr tr ON tn.client_nbr = tr.client_nbr and tn.branch_cd = tr.branch_cd and tn.account_cd = tr.account_cd		
        LEFT JOIN #<bp>..tacc_party_name tpn ON tn.client_nbr = tpn.client_nbr and tn.branch_cd = tpn.branch_cd and tn.account_cd = tpn.account_cd and tpn.ap_type_cd = 'P' 
		LEFT JOIN #<bp>..tacc_party_name tpn2 ON tn.client_nbr = tpn2.client_nbr and tn.branch_cd = tpn2.branch_cd and tn.account_cd = tpn2.account_cd and tpn2.ap_type_cd = 'J'  
		LEFT JOIN #<bp>..tpp_info ti ON tn.client_nbr = ti.client_nbr and tn.client_nbr = ti.client_nbr and tn.branch_cd = ti.branch_cd and tn.account_cd = ti.account_cd and ti.ap_seq_nbr = 1
 		LEFT JOIN #<bp>..tacc_party_ff_na tpfn1 ON tn.client_nbr = tpfn1.client_nbr and tn.branch_cd = tpfn1.branch_cd and tn.account_cd = tpfn1.account_cd and tpfn1.ap_seq_nbr = 1 and tpfn1.na_line_seq_nbr= 1 
        LEFT JOIN #<bp>..tacc_party_ff_na tpfn2 ON tn.client_nbr = tpfn2.client_nbr and tn.branch_cd = tpfn2.branch_cd and tn.account_cd = tpfn2.account_cd and tpfn2.ap_seq_nbr = 1 and tpfn2.na_line_seq_nbr= 2
        LEFT JOIN #<bp>..tacc_party_ff_na tpfn3 ON tn.client_nbr = tpfn3.client_nbr and tn.branch_cd = tpfn3.branch_cd and tn.account_cd = tpfn3.account_cd and tpfn3.ap_seq_nbr = 1 and tpfn3.na_line_seq_nbr= 3
        LEFT JOIN #<bp>..tacc_party_ff_na tpfn4 ON tn.client_nbr = tpfn4.client_nbr and tn.branch_cd = tpfn4.branch_cd and tn.account_cd = tpfn4.account_cd and tpfn4.ap_seq_nbr = 1 and tpfn4.na_line_seq_nbr= 4
        LEFT JOIN #<bp>..tacc_party_ff_na tpfn5 ON tn.client_nbr = tpfn5.client_nbr and tn.branch_cd = tpfn5.branch_cd and tn.account_cd = tpfn5.account_cd and tpfn5.ap_seq_nbr = 1 and tpfn5.na_line_seq_nbr= 5
        LEFT JOIN #<bp>..tacc_party_ff_na tpfn6 ON tn.client_nbr = tpfn6.client_nbr and tn.branch_cd = tpfn6.branch_cd and tn.account_cd = tpfn6.account_cd and tpfn6.ap_seq_nbr = 1 and tpfn6.na_line_seq_nbr= 6
        LEFT JOIN #<bp>..taccount_type tt1 ON tn.client_nbr = tt1.client_nbr and tn.branch_cd = tt1.branch_cd and tn.account_cd = tt1.account_cd and tt1.type_account_cd = '1'  
        LEFT JOIN #<bp>..taccount_type tt2 ON tn.client_nbr = tt2.client_nbr and tn.branch_cd = tt2.branch_cd and tn.account_cd = tt2.account_cd and tt2.type_account_cd = '2'   
        LEFT JOIN #<bp>..taccount_type tt3 ON tn.client_nbr = tt3.client_nbr and tn.branch_cd = tt3.branch_cd and tn.account_cd = tt3.account_cd and tt3.type_account_cd = '3'  
        LEFT JOIN #<bp>..taccount_type tt4 ON tn.client_nbr = tt4.client_nbr and tn.branch_cd = tt4.branch_cd and tn.account_cd = tt4.account_cd and tt4.type_account_cd = '4' 
        LEFT JOIN #<bp>..taccount_type tt5 ON tn.client_nbr = tt5.client_nbr and tn.branch_cd = tt5.branch_cd and tn.account_cd = tt5.account_cd and tt5.type_account_cd = '5' 
        LEFT JOIN #<bp>..taccount_type tt6 ON tn.client_nbr = tt6.client_nbr and tn.branch_cd = tt6.branch_cd and tn.account_cd = tt6.account_cd and tt6.type_account_cd = '6'
        LEFT JOIN #<bp>..taccount_type tt7 ON tn.client_nbr = tt7.client_nbr and tn.branch_cd = tt7.branch_cd and tn.account_cd = tt7.account_cd and tt7.type_account_cd = '7'
        LEFT JOIN #<bp>..taccount_type tt8 ON tn.client_nbr = tt8.client_nbr and tn.branch_cd = tt8.branch_cd and tn.account_cd = tt8.account_cd and tt8.type_account_cd = '8'
        LEFT JOIN #<bp>..taccount_type tt9 ON tn.client_nbr = tt9.client_nbr and tn.branch_cd = tt9.branch_cd and tn.account_cd = tt9.account_cd and tt9.type_account_cd = '9'
        LEFT JOIN #<bp>..taccount_type tt0 ON tn.client_nbr = tt0.client_nbr and tn.branch_cd = tt0.branch_cd and tn.account_cd = tt0.account_cd and tt0.type_account_cd = '0'
        LEFT JOIN #<bp>..tregister_plan tp ON tn.client_nbr = tp.client_nbr and tn.branch_cd = tp.branch_cd and tn.account_cd = tp.account_cd and tp.type_acct_cd = '1'
		LEFT JOIN #<sb>..si_lob_acct_range slar ON tn.branch_cd + tn.account_cd >= slar.range_start and tn.branch_cd + tn.account_cd <= slar.range_end
		LEFT JOIN #<sb>..si_ia_master im  ON tn.rr_cd=im.ia_num
		LEFT JOIN #<sb>..si_currency_master scm ON tn.currency_cd = scm.currency_code 

		SELECT @syb_error_code = @@error , @no_of_records = @@rowcount



	IF ( @syb_error_code <> 0 ) 
	BEGIN

		raiserror 20076 "Basic Name and Address Service failed."

		select @custom_error_code=@@error

		IF (@debug_flag="Y")
		BEGIN
			INSERT INTO #<oc>..si_name_and_address_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code)
		END

		RETURN @custom_error_code
	END

	IF(@debug_flag="Y")
	BEGIN
		INSERT INTO #<oc>..si_name_and_address_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
	END

	RETURN 

end
go

grant execute on sp_get_name_and_address_basic to spica_ws 
go
