use #<oc>
go

if exists (select * from sysobjects      
             where type = 'P' and name = 'sp_get_name_and_address_adv' )
   begin
      drop procedure sp_get_name_and_address_adv
   end
go

create procedure sp_get_name_and_address_adv
		@rbc_business			char(2),
		@rr_code				char(3)=NULL,
		@first_nm				char(20)=NULL,
		@last_nm				char(20)=NULL,
		@company_nm				char(35)=NULL,
		@client_card			char(20)=NULL,
		@app_id					char(10),
		@line_of_business		char(10),
		@req_time_stamp			CHAR(25),
		@transaction_id			char(40)

AS
declare  
 
		@start_time             datetime,                          
		@proc_name              varchar(35),                                                  
		@input_parm             varchar(120),         
		@debug_flag             char(1),        
		@var                    int,     
		@accnt_length           int,
		@syb_error_code         int ,
		@custom_error_code      int,
		@no_of_records          int
		
BEGIN
--		set plan optgoal allrows_oltp
--		set statistics io on
                set plan optlevel ase_default

		select 
			@debug_flag = debug_flag 		
		FROM 
			#<oc>..si_service_debug_config 
		WHERE 
			service_id= object_name(@@procid)--'sp_get_name_and_address_adv'		
			
		if(@debug_flag='Y')
		
		begin
			select @start_time=getdate()
			select @proc_name=object_name(@@procid)
			select @input_parm = @rbc_business + ","+ @rr_code + ","+ @first_nm +  ","+ @last_nm + "," + @company_nm + "," + @client_card + "," + @app_id+","+ @line_of_business+","+ @req_time_stamp+","+ @transaction_id
		end
		
		IF (LTRIM(@rbc_business) = 'AL' )
		BEGIN
			SET @rbc_business = '%' 
		END
		
		IF (LTRIM(@rr_code) = NULL )
		BEGIN
			SET @rr_code = '%' 
		END
        
		IF (LTRIM(@first_nm) = NULL )
		BEGIN
			SET @first_nm = '%' 
		END
		
		IF (LTRIM(@last_nm) = NULL )
		BEGIN
			SET @last_nm = '%' 
		END
		
		IF (LTRIM(@company_nm) = NULL )
		BEGIN
			SET @company_nm = '%' 
		END
		
		IF (LTRIM(@client_card) = NULL )
		BEGIN
			SET @client_card = '%' 
		END
		ELSE
		BEGIN
			--If client_card is populated, then always add 'A:' prefix to input value and join client_card input field with taccount_rr.rr_interest_1_txt 
			SELECT @client_card = 'A:' + LTRIM(@client_card)  		
		END
------------------------------------------------------------------------------

IF ( @client_card <> '%'  )

-- This condition will be executed if client_card is one of the input parameters passed to the SP

BEGIN

SELECT

	tr.branch_cd,
	tr.account_cd,
	tr.rr_interest_1_txt client_card,
	slar.rbc_business,
	slar.ds_fee_type_cd,
	slar.ds_account_category_cd

INTO
	#NNA_Client_Card

FROM

	#<sb>..si_lob_acct_range slar INNER JOIN #<bp>..taccount_rr tr
	ON
	tr.rr_interest_1_txt = @client_card and
	tr.client_nbr = '0069' and
	tr.branch_cd > '' and tr.account_cd > '' and
	tr.branch_cd+tr.account_cd >= slar.range_start and tr.branch_cd+tr.account_cd <=slar.range_end and
	slar.rbc_business like @rbc_business


SELECT TOP 1000 

	nt2.*,
	cc.client_card,
	cc.rbc_business,
	cc.ds_fee_type_cd,
	cc.ds_account_category_cd

FROM
	#<sb>..name_and_address_adv_cc_vw nt2
	INNER JOIN #NNA_Client_Card cc ON
	nt2.branch_cd = cc.branch_cd
	AND nt2.account_cd = cc.account_cd
	
WHERE

	ISNULL(nt2.rr_cd, '') like @rr_code AND
	ISNULL(nt2.first_nm_principal, '') like @first_nm AND
	ISNULL(nt2.last_nm_principal, '') like @last_nm AND
	(ISNULL(nt2.company_nm_principal, '') like @company_nm OR ISNULL(nt2.company_nm_joint, '') like @company_nm)

END

ELSE

-- Block for any input parameter except client_card

BEGIN

IF ( @first_nm <> '%' )

-- This condition will be executed if first_nm is one of the input parameters passed to the SP

BEGIN

SELECT

	tpn.branch_cd ,
	tpn.account_cd,
	tpn.first_nm first_nm_principal,
	tpn.mi_initial_txt mi_initial_txt_principal,
	tpn.last_nm last_nm_principal,
	tpn.soc_sec_nbr soc_sec_nbr_principal,
	tpn.soc_sec_tax_cd soc_sec_tax_cd_principal,
	tpn.language_cd language_cd_principal,
	tpn.person_cmpy_cd person_cmpy_cd_principal ,
	company_nm_principal = (CASE WHEN tpn.person_cmpy_cd = 'C' THEN tpn.company_nm ELSE NULL END),
	CASE
		WHEN tpn2.ap_type_cd = 'J' THEN 'Y'
		ELSE 'N'
	END joint_account_indicator,
	tpn2.first_nm first_nm_joint,
	tpn2.mi_initial_txt mi_initial_txt_joint,
	tpn2.last_nm last_nm_joint,
	company_nm_joint = (CASE WHEN tpn2.person_cmpy_cd = 'C' THEN tpn2.company_nm ELSE NULL END),
	slar.rbc_business,
	slar.ds_fee_type_cd,
	slar.ds_account_category_cd

INTO

	#NNA_First_Name

FROM

	#<sb>..si_lob_acct_range slar INNER JOIN 
	#<bp>..tacc_party_name tpn
	ON
	tpn.first_nm = @first_nm and
	tpn.client_nbr = '0069' and
	tpn.branch_cd > '' and tpn.account_cd > '' and
	tpn.branch_cd+tpn.account_cd >= slar.range_start and tpn.branch_cd+tpn.account_cd <= slar.range_end and
	tpn.ap_type_cd = 'P' and
	slar.rbc_business like @rbc_business LEFT JOIN
	#<bp>..tacc_party_name tpn2
	ON
	tpn2.client_nbr = '0069' and
	tpn.branch_cd = tpn2.branch_cd and tpn.account_cd = tpn2.account_cd and
	tpn2.ap_type_cd = 'J'


SELECT TOP 1000

 	nt3.*,
 	fn.first_nm_principal,
 	fn.mi_initial_txt_principal,
 	fn.last_nm_principal,
 	fn.soc_sec_nbr_principal,
 	fn.soc_sec_tax_cd_principal,
	fn.language_cd_principal,
	fn.person_cmpy_cd_principal ,
	fn.company_nm_principal,
 	fn.joint_account_indicator,
 	fn.first_nm_joint,
 	fn.mi_initial_txt_joint,
	fn.last_nm_joint,
	fn.company_nm_joint,
	fn.rbc_business,
	fn.ds_fee_type_cd,
	fn.ds_account_category_cd

 FROM

	 #<sb>..name_and_address_adv_flcomp_vw nt3
	 INNER JOIN #NNA_First_Name fn
	 ON nt3.branch_cd = fn.branch_cd
	 AND nt3.account_cd = fn.account_cd

 WHERE

	 ISNULL(nt3.rr_cd, '') like @rr_code AND
	 ISNULL(fn.last_nm_principal, '') like @last_nm AND
	 (ISNULL(fn.company_nm_principal, '') like @company_nm OR ISNULL(fn.company_nm_joint, '') like @company_nm)

END

ELSE

-- Block for any input parameter except client_card and first_nm

BEGIN

IF ( @last_nm not like "[%]" )

-- This condition will be executed if last_nm is one of the input parameters passed to the SP

BEGIN

SELECT

	tpn.branch_cd ,
	tpn.account_cd,
	tpn.first_nm first_nm_principal,
	tpn.mi_initial_txt mi_initial_txt_principal,
	tpn.last_nm last_nm_principal,
	tpn.soc_sec_nbr soc_sec_nbr_principal,
	tpn.soc_sec_tax_cd soc_sec_tax_cd_principal,
	tpn.language_cd language_cd_principal,
	tpn.person_cmpy_cd person_cmpy_cd_principal ,
	company_nm_principal = (CASE WHEN tpn.person_cmpy_cd = 'C' THEN tpn.company_nm ELSE NULL END),
	CASE
		WHEN tpn2.ap_type_cd = 'J' THEN 'Y'
		ELSE 'N'
	END joint_account_indicator,
	tpn2.first_nm first_nm_joint,
	tpn2.mi_initial_txt mi_initial_txt_joint,
	tpn2.last_nm last_nm_joint,
	company_nm_joint = (CASE WHEN tpn2.person_cmpy_cd = 'C' THEN tpn2.company_nm ELSE NULL END),
	slar.rbc_business,
	slar.ds_fee_type_cd,
	slar.ds_account_category_cd

INTO

	#NNA_Last_Name

FROM

	#<sb>..si_lob_acct_range slar INNER JOIN 
	#<bp>..tacc_party_name tpn
	ON
	tpn.last_nm = @last_nm and
	tpn.client_nbr = '0069' and
	tpn.branch_cd > '' and tpn.account_cd > '' and
	tpn.branch_cd+tpn.account_cd >= slar.range_start and tpn.branch_cd+tpn.account_cd <= slar.range_end and
	tpn.ap_type_cd = 'P' and
	slar.rbc_business like @rbc_business
	LEFT JOIN #<bp>..tacc_party_name tpn2
	ON
	tpn2.client_nbr = '0069' and
	tpn.branch_cd = tpn2.branch_cd and tpn.account_cd = tpn2.account_cd and
	tpn2.ap_type_cd = 'J'


SELECT TOP 1000

 	nt3.*,
 	lastn.first_nm_principal,
 	lastn.mi_initial_txt_principal,
 	lastn.last_nm_principal,
 	lastn.soc_sec_nbr_principal,
 	lastn.soc_sec_tax_cd_principal,
	lastn.language_cd_principal,
	lastn.person_cmpy_cd_principal ,
	lastn.company_nm_principal,
 	lastn.joint_account_indicator,
 	lastn.first_nm_joint,
 	lastn.mi_initial_txt_joint,
	lastn.last_nm_joint,
	lastn.company_nm_joint,
	lastn.rbc_business,
	lastn.ds_fee_type_cd,
	lastn.ds_account_category_cd

 FROM

	#<sb>..name_and_address_adv_flcomp_vw nt3
	 INNER JOIN #NNA_Last_Name lastn
	 ON nt3.branch_cd = lastn.branch_cd
	 AND nt3.account_cd = lastn.account_cd

 WHERE

	 ISNULL(nt3.rr_cd, '') like @rr_code AND
	 (ISNULL(lastn.company_nm_principal, '') like @company_nm OR ISNULL(lastn.company_nm_joint, '') like @company_nm)

END

-- Block for any input parameter except client_card, first_nm and last_nm

ELSE

BEGIN

IF ( @company_nm not like "[%]" )

-- This condition will be executed if company_nm is one of the input parameters passed to the SP

BEGIN

SELECT

	tpn.branch_cd ,
	tpn.account_cd,
	tpn.first_nm first_nm_principal,
	tpn.mi_initial_txt mi_initial_txt_principal,
	tpn.last_nm last_nm_principal,
	tpn.soc_sec_nbr soc_sec_nbr_principal,
	tpn.soc_sec_tax_cd soc_sec_tax_cd_principal,
	tpn.language_cd language_cd_principal,
	tpn.person_cmpy_cd person_cmpy_cd_principal ,
	company_nm_principal = (CASE WHEN tpn.person_cmpy_cd = 'C' THEN tpn.company_nm ELSE NULL END),
	CASE
		WHEN tpn2.ap_type_cd = 'J' THEN 'Y'
		ELSE 'N'
	END joint_account_indicator,
	tpn2.first_nm first_nm_joint,
	tpn2.mi_initial_txt mi_initial_txt_joint,
	tpn2.last_nm last_nm_joint,
	company_nm_joint = (CASE WHEN tpn2.person_cmpy_cd = 'C' THEN tpn2.company_nm ELSE NULL END),
	slar.rbc_business,
	slar.ds_fee_type_cd,
	slar.ds_account_category_cd

INTO

	#NNA_Company_Name

FROM

	#<sb>..si_lob_acct_range slar INNER JOIN 
	#<bp>..tacc_party_name tpn
	ON
	tpn.client_nbr = '0069' and
	tpn.branch_cd > '' and tpn.account_cd > '' and
	tpn.branch_cd+tpn.account_cd >= slar.range_start and tpn.branch_cd+tpn.account_cd <= slar.range_end and
	tpn.ap_type_cd = 'P' and
	slar.rbc_business like @rbc_business
	LEFT JOIN #<bp>..tacc_party_name tpn2
	ON
	tpn2.client_nbr = '0069' and
	tpn.branch_cd = tpn2.branch_cd and tpn.account_cd = tpn2.account_cd and
	tpn2.ap_type_cd = 'J'

WHERE

	( tpn.company_nm = @company_nm OR tpn2.company_nm = @company_nm )


SELECT TOP 1000

 	nt3.*,
 	cn.first_nm_principal,
 	cn.mi_initial_txt_principal,
 	cn.last_nm_principal,
 	cn.soc_sec_nbr_principal,
 	cn.soc_sec_tax_cd_principal,
	cn.language_cd_principal,
	cn.person_cmpy_cd_principal ,
	cn.company_nm_principal,
 	cn.joint_account_indicator,
 	cn.first_nm_joint,
 	cn.mi_initial_txt_joint,
	cn.last_nm_joint,
	cn.company_nm_joint,
	cn.rbc_business,
	cn.ds_fee_type_cd,
	cn.ds_account_category_cd

 FROM

	 #<sb>..name_and_address_adv_flcomp_vw nt3
	 INNER JOIN #NNA_Company_Name cn
	 ON nt3.branch_cd = cn.branch_cd
	 AND nt3.account_cd = cn.account_cd

 WHERE

	 ISNULL(nt3.rr_cd, '') like @rr_code
	 
END

ELSE

-- Block for any input parameter except client_card, first_nm, last_nm, company_nm

BEGIN

-- This condition will be executed if only rr_cd is passed along with rbc_business as filter criteria

SELECT TOP 1000
	tn.branch_cd ,
	tn.account_cd,
	slar.rbc_business,
	slar.ds_fee_type_cd,
	slar.ds_account_category_cd
INTO
	#naalobrracclist
FROM
	#<sb>..si_lob_acct_range slar INNER JOIN
	#<bp>..taccount_new tn
ON
	tn.client_nbr = '0069' and
	slar.rbc_business like @rbc_business and
	tn.rr_cd like @rr_code and
	tn.branch_cd > '' and 
	tn.account_cd > '' and
	tn.branch_cd+tn.account_cd >= slar.range_start and 
	tn.branch_cd+tn.account_cd <= slar.range_end 


SELECT 	
		nt1.*,
		t.rbc_business,
		t.ds_fee_type_cd,
		t.ds_account_category_cd

FROM
	#naalobrracclist t,
	#<sb>..name_and_address_adv_rrcd_vw nt1
WHERE
	t.branch_cd = nt1.branch_cd and 
	t.account_cd = nt1.account_cd

END

END

END

END

	SELECT @syb_error_code = @@error , @no_of_records = @@rowcount



	IF ( @syb_error_code <> 0 ) 
	BEGIN

		raiserror 20077 "Advanced Name and Address Service failed."

		select @custom_error_code=@@error

		IF (@debug_flag="Y")
		BEGIN
			INSERT INTO #<oc>..si_name_and_address_adv_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code)
		END

		RETURN @custom_error_code
	END

	IF(@debug_flag="Y")
	BEGIN
		INSERT INTO #<oc>..si_name_and_address_adv_log VALUES (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
	END

	RETURN 

end
go

grant execute on sp_get_name_and_address_adv to spica_ws 
go
