-----Version v1 : base version of FXRate service for Prism project
-----Version v2 : Added logic for NULL processing_dt parameter passed to SP
-----Version v3 : If processing_dt not passed, get max date from table to provide FX Rate

use #<oc>
go

if exists (select * from sysobjects where type = 'P' and name = 'sp_fxrate_service' )
begin
	drop procedure sp_fxrate_service
end
go


create proc sp_fxrate_service
@currency_cd char(3),
@processing_dt	char(10)=Null,
@app_id	char(10),
@line_of_business	char(10),
@req_time_stamp char(25),
@transaction_id varchar(40)
AS


declare
        @start_time             datetime,
        @proc_name              varchar(35),
        @input_parm    			varchar(120),
        @debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@no_of_records          int

BEGIN

        set plan optgoal allrows_oltp
		select @debug_flag = debug_flag FROM #<oc>..si_service_debug_config WHERE service_id='sp_fxrate_service'
	

	
        if(@debug_flag='Y')
        begin
                select @start_time=getdate()
                select @proc_name=object_name(@@procid)
                select @input_parm = @currency_cd+","+ @processing_dt +","+ @app_id+","+ @line_of_business+","+ @req_time_stamp+","+ @transaction_id
        end
		
		if @currency_cd = '999' 
		begin
			select @currency_cd = '%'
		end
		

		If rtrim(@processing_dt) = NULL 
		begin
			select @processing_dt = (select convert(varchar(10),max(convert(datetime, processing_dt, 101)), 101)  from #<sb>..si_fxrate)
		end
	
		Select 
			cm.currency_code,
			cm.currency_desc,
			cm.short_desc,
			cm.iso_code,
			@processing_dt processing_dt,
			CASE
				WHEN fx.currency_cd IS NOT NULL THEN 'Y'
				ELSE 'N' 
			END fxrate_available_flag,
			fx.cnvrt_trd_crrnb_rt,
			fx.cnvrt_trd_crrns_rt,
			fx.cnvrt_trd_crrna_rt
			
		FROM
			#<sb>..si_currency_master cm LEFT JOIN 
			#<sb>..si_fxrate fx
		ON
			cm.currency_code = fx.currency_cd
			AND fx.processing_dt = @processing_dt
		WHERE
			cm.currency_code like @currency_cd



		select @syb_error_code = @@error , @no_of_records = @@rowcount

        if @syb_error_code <> 0
        begin

            raiserror 30081 "Query to retrieve FX Rate details failed."

            select @custom_error_code=@@error

            if(@debug_flag="Y")
            begin
                insert into #<oc>..si_fxrate_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,@custom_error_code )
            end

            return @custom_error_code
        end
		
	

    	if(@debug_flag='Y')
    	begin
			insert into #<oc>..si_fxrate_log values (@line_of_business,@app_id,@proc_name,@input_parm,@start_time,getdate(),@no_of_records ,@syb_error_code ,0)
    	end

	return 0

END
go
		
grant Execute  on sp_fxrate_service to spica_ws 
go


