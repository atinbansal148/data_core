/*
$Header: /rtapp/stp/update_naf.sql 1     06/20/03 1:58p Tbprven $
$Log: /rtapp/stp/update_naf.sql $
 * 
 * Version 1.0
 * v1.9.7_4thQtr09
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_naf') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_naf
    IF OBJECT_ID('dbo.update_naf') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_naf >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_naf >>>'
END
go

CREATE PROC update_naf
	     @client_nbr char(4),
	     @branch_cd char(3),
	     @account_cd char(5),
	     @action     char,
	     @cana_otbd_fxd_amt		decimal(7) = null,                          
	     @cana_otbd_bnk_nbr		char(4) = null,                          
	     @cana_otbd_trns_nbr	char(5) = null,                           
	     @cana_otbd_acct_nbr	char(12) = null,                          
	     @usag_otbd_bnk_nbr		char(4) = null,                
	     @usag_otbd_trns_nbr	char(5) = null,                 
	     @usag_otbd_acct_nbr	char(12) = null,             
	     @cana_otbd_af_dy_cd	char(2) = null,                 
	     @cana_otbd_pymnt_cd	char(3) = null,                  
	     @cana_otbd_freq_cd		char(2) = null,  
	     @cana_otbd_dnus_dt		char(10) = null,  
	     @cana_otbd_dnue_dt		datetime = null,
	     @canb_otbd_fxd_amt		decimal(7) = null,            
	     @canb_otbd_af_dy_cd	char(2) = null,                 
	     @canb_otbd_pymnt_cd	char(3) = null,                  
	     @canb_otbd_freq_cd		char(2) = null,               
	     @canb_otbd_bnk_nbr		char(4) = null,                 
	     @canb_otbd_trns_nbr	char(5) = null,             
	     @canb_otbd_acct_nbr	char(12) = null,
	     @canb_otbd_dnus_dt		datetime = null,
	     @canb_otbd_dnue_dt		datetime = null,
	     @canc_otbd_fxd_amt		decimal(7) = null,            
	     @canc_otbd_af_dy_cd	char(2) = null,                
	     @canc_otbd_pymnt_cd	char(3) = null,                
	     @canc_otbd_freq_cd		char(2) = null,                 
	     @canc_otbd_bnk_nbr		char(4) = null,                
	     @canc_otbd_trns_nbr	char(5) = null,                 
	     @canc_otbd_acct_nbr	char(12) = null,
	     @canc_otbd_dnus_dt		datetime = null,
	     @canc_otbd_dnue_dt		datetime = null,     
	     @cand_inbnd_dnus_dt	datetime = null,
	     @cand_inbnd_dnue_dt	datetime = null,
	     @cane_inbnd_eft_ind	char(1) = null,                         
	     @cane_inbn_ac_ty_cd	char(1) = null,                        
	     @cane_inbnd_fxd_amt	decimal(7) = null,                     
	     @cane_inbn_af_dy_cd	char(2) = null,                         
	     @cane_inbnd_freq_cd	char(2) = null,                         
	     @cane_inbnd_bnk_nbr	char(4) = null,                         
	     @cane_inbn_trns_nbr	char(5) = null,                         
	     @cane_inbn_acct_nbr	char(12) = null,
	     @cane_inbnd_dnus_dt	datetime = null,
	     @cane_inbnd_dnue_dt	datetime = null,
	     @canf_inbnd_eft_ind	char(1) = null,                        
	     @canf_inbn_ac_ty_cd	char(1) = null,                        
	     @canf_inbnd_fxd_amt	decimal(7) = null,                   
	     @canf_inbn_af_dy_cd	char(2) = null,                        
	     @canf_inbnd_freq_cd	char(2) = null,                         
	     @canf_inbnd_bnk_nbr	char(4) = null,                         
	     @canf_inbn_trns_nbr	char(5) = null,                          
	     @canf_inbn_acct_nbr	char(12) = null,
	     @canf_inbnd_dnus_dt	datetime = null,
	     @canf_inbnd_dnue_dt	datetime = null,
	     @usag_otbd_fxd_amt		decimal(7) = null,                    
	     @usag_otbd_af_dy_cd	char(2) = null,                         
	     @usag_otbd_pymnt_cd	char(3) = null,                         
	     @usag_otbd_freq_cd		char(2) = null,
	     @usag_otbd_dnus_dt		datetime = null,
	     @usag_otbd_dnue_dt		datetime = null,
	     @usah_otbd_fxd_amt		decimal(7) = null,                     
	     @usah_otbd_af_dy_cd	char(2) = null,                          
	     @usah_otbd_pymnt_cd	char(3) = null,                     
	     @usah_otbd_freq_cd		char(2) = null,                      
	     @usah_otbd_bnk_nbr		char(4) = null,                      
	     @usah_otbd_trns_nbr	char(5) = null,                      
	     @usah_otbd_acct_nbr	char(12) = null,
	     @usah_otbd_dnus_dt		datetime = null,
	     @usah_otbd_dnue_dt		datetime = null,
	     @usaj_otbd_fxd_amt		decimal(7) = null,                  
	     @usaj_otbd_af_dy_cd	char(2) = null,                      
	     @usaj_otbd_pymnt_cd	char(3) = null,                      
	     @usaj_otbd_freq_cd		char(2) = null,                      
	     @usaj_otbd_bnk_nbr		char(4) = null,                      
	     @usaj_otbd_trns_nbr	char(5) = null,                      
	     @usaj_otbd_acct_nbr	char(12) = null,
	     @usaj_otbd_dnus_dt		datetime = null,
	     @usaj_otbd_dnue_dt		datetime = null,
	     @usak_inbnd_eft_ind	char(1) = null,                       
	     @usak_inbn_ac_ty_cd	char(1) = null,                      
	     @usak_inbnd_fxd_amt	decimal(7) = null,                     
	     @usak_inbn_af_dy_cd	char(2) = null,                       
	     @usak_inbnd_freq_cd	char(2) = null,                       
	     @usak_inbnd_bnk_nbr	char(4) = null,                       
	     @usak_inbn_trns_nbr	char(5) = null,                       
	     @usak_inbn_acct_nbr	char(12) = null,
	     @usak_inbnd_dnus_dt	datetime = null,
	     @usak_inbnd_dnue_dt	datetime = null,
	     @usal_inbnd_eft_ind	char(1) = null,                       
	     @usal_inbn_ac_ty_cd	char(1) = null,                       
	     @usal_inbnd_fxd_amt	decimal(7) = null,                  
	     @usal_inbn_af_dy_cd	char(2) = null,                  
	     @usal_inbnd_freq_cd	char(2) = null,                  
	     @usal_inbnd_bnk_nbr	char(4) = null,                 
	     @usal_inbn_trns_nbr	char(5) = null,                  
	     @usal_inbn_acct_nbr	char(12) = null,
	     @usal_inbnd_dnus_dt	datetime = null,
	     @usal_inbnd_dnue_dt	datetime = null,
	     @usam_inbnd_eft_ind	char(1) = null,                 
	     @usam_inbn_ac_ty_cd	char(1) = null,                 
	     @usam_inbnd_fxd_amt	decimal(7) = null,             
	     @usam_inbn_af_dy_cd	char(2) = null,                  
	     @usam_inbnd_freq_cd	char(2) = null,                  
	     @usam_inbnd_bnk_nbr	char(4) = null,                  
	     @usam_inbn_trns_nbr	char(5) = null,                  
	     @usam_inbn_acct_nbr	char(12) = null,
	     @usam_inbnd_dnus_dt	datetime = null,
	     @usam_inbnd_dnue_dt	datetime = null
      
      
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM tacct_inbnd_otbnd
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 
			   
		SELECT @tbl_rowcount = @@rowcount
				
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_naf
			
						
			/* insert into realtime table */
			INSERT INTO tacct_inbnd_otbnd (client_nbr ,
					branch_cd ,
					account_cd ,
					record_type_cd ,
					action_cd ,
					cana_otbd_fxd_amt,                          
	     				cana_otbd_bnk_nbr,                          
	     				cana_otbd_trns_nbr,                           
	    	 			cana_otbd_acct_nbr,                          
	     				usag_otbd_bnk_nbr,                
	     				usag_otbd_trns_nbr,                 
	     				usag_otbd_acct_nbr,             
	     				cana_otbd_af_dy_cd,                 
	     				cana_otbd_pymnt_cd,                  
	     				cana_otbd_freq_cd,  
	     				cana_otbd_dnus_dt,  
	     				cana_otbd_dnue_dt,
	     				canb_otbd_fxd_amt,            
	     				canb_otbd_af_dy_cd,                 
	     				canb_otbd_pymnt_cd,                  
	     				canb_otbd_freq_cd,               
	     				canb_otbd_bnk_nbr,                 
	     				canb_otbd_trns_nbr,             
	     				canb_otbd_acct_nbr,
	     				canb_otbd_dnus_dt,
	     				canb_otbd_dnue_dt,
	     				canc_otbd_fxd_amt,            
	     				canc_otbd_af_dy_cd,                
	     				canc_otbd_pymnt_cd,                
	     				canc_otbd_freq_cd,                 
	     				canc_otbd_bnk_nbr,                
	     				canc_otbd_trns_nbr,                 
	     				canc_otbd_acct_nbr,
	     				canc_otbd_dnus_dt,
	     				canc_otbd_dnue_dt,     
	     				cand_inbnd_dnus_dt,
	     				cand_inbnd_dnue_dt,
	     				cane_inbnd_eft_ind,                         
	     				cane_inbn_ac_ty_cd,                        
	     				cane_inbnd_fxd_amt,                     
	     				cane_inbn_af_dy_cd,                         
	     				cane_inbnd_freq_cd,                         
	     				cane_inbnd_bnk_nbr,                         
	     				cane_inbn_trns_nbr,                         
	     				cane_inbn_acct_nbr,
	     				cane_inbnd_dnus_dt,
	     				cane_inbnd_dnue_dt,
	     				canf_inbnd_eft_ind,                        
	     				canf_inbn_ac_ty_cd,                        
	     				canf_inbnd_fxd_amt,                   
	     				canf_inbn_af_dy_cd,                        
	     				canf_inbnd_freq_cd,                         
	     				canf_inbnd_bnk_nbr,                         
	     				canf_inbn_trns_nbr,                          
	     				canf_inbn_acct_nbr,
	     				canf_inbnd_dnus_dt,
	     				canf_inbnd_dnue_dt,
	     				usag_otbd_fxd_amt,                    
	     				usag_otbd_af_dy_cd,                         
	     				usag_otbd_pymnt_cd,                         
	     				usag_otbd_freq_cd,
	     				usag_otbd_dnus_dt,
	     				usag_otbd_dnue_dt,
	     				usah_otbd_fxd_amt,                     
	     				usah_otbd_af_dy_cd,                          
	     				usah_otbd_pymnt_cd,                     
	     				usah_otbd_freq_cd,                      
	     				usah_otbd_bnk_nbr,                      
	     				usah_otbd_trns_nbr,                      
	     				usah_otbd_acct_nbr,
	     				usah_otbd_dnus_dt,
	     				usah_otbd_dnue_dt,
	     				usaj_otbd_fxd_amt,                  
	     				usaj_otbd_af_dy_cd,                      
	    	 			usaj_otbd_pymnt_cd,                      
	     				usaj_otbd_freq_cd,                      
	     				usaj_otbd_bnk_nbr,                      
	     				usaj_otbd_trns_nbr,                      
	     				usaj_otbd_acct_nbr,
	     				usaj_otbd_dnus_dt,
	     				usaj_otbd_dnue_dt,
	     				usak_inbnd_eft_ind,                       
	     				usak_inbn_ac_ty_cd,                      
	     				usak_inbnd_fxd_amt,                     
	     				usak_inbn_af_dy_cd,                       
	     				usak_inbnd_freq_cd,                       
	     				usak_inbnd_bnk_nbr,                       
	     				usak_inbn_trns_nbr,                       
	     				usak_inbn_acct_nbr,
	     				usak_inbnd_dnus_dt,
	     				usak_inbnd_dnue_dt,
	     				usal_inbnd_eft_ind,                       
	     				usal_inbn_ac_ty_cd,                       
	     				usal_inbnd_fxd_amt,                  
	     				usal_inbn_af_dy_cd,                  
	     				usal_inbnd_freq_cd,                  
	     				usal_inbnd_bnk_nbr,                 
	     				usal_inbn_trns_nbr,                  
	     				usal_inbn_acct_nbr,
	     				usal_inbnd_dnus_dt,
	     				usal_inbnd_dnue_dt,
	     				usam_inbnd_eft_ind,                 
	     				usam_inbn_ac_ty_cd,                 
	     				usam_inbnd_fxd_amt,             
	     				usam_inbn_af_dy_cd,                  
	     				usam_inbnd_freq_cd,                  
	     				usam_inbnd_bnk_nbr,                  
	    				usam_inbn_trns_nbr,                  
	     				usam_inbn_acct_nbr,
	     				usam_inbnd_dnus_dt,
	     				usam_inbnd_dnue_dt,
						     updt_last_tmstp)
					VALUES (@client_nbr ,
						@branch_cd ,
					@account_cd ,
					'NAF',
					'I' ,
					@cana_otbd_fxd_amt,                          
	     				@cana_otbd_bnk_nbr,                          
	     				@cana_otbd_trns_nbr,                           
	    	 			@cana_otbd_acct_nbr,                          
	     				@usag_otbd_bnk_nbr,                
	     				@usag_otbd_trns_nbr,                 
	     				@usag_otbd_acct_nbr,             
	     				@cana_otbd_af_dy_cd,                 
	     				@cana_otbd_pymnt_cd,                  
	     				@cana_otbd_freq_cd,  
	     				@cana_otbd_dnus_dt,  
	     				@cana_otbd_dnue_dt,
	     				@canb_otbd_fxd_amt,            
	     				@canb_otbd_af_dy_cd,                 
	     				@canb_otbd_pymnt_cd,                  
	     				@canb_otbd_freq_cd,               
	     				@canb_otbd_bnk_nbr,                 
	     				@canb_otbd_trns_nbr,             
	     				@canb_otbd_acct_nbr,
	     				@canb_otbd_dnus_dt,
	     				@canb_otbd_dnue_dt,
	     				@canc_otbd_fxd_amt,            
	     				@canc_otbd_af_dy_cd,                
	     				@canc_otbd_pymnt_cd,                
	     				@canc_otbd_freq_cd,                 
	     				@canc_otbd_bnk_nbr,                
	     				@canc_otbd_trns_nbr,                 
	     				@canc_otbd_acct_nbr,
	     				@canc_otbd_dnus_dt,
	     				@canc_otbd_dnue_dt,     
	     				@cand_inbnd_dnus_dt,
	     				@cand_inbnd_dnue_dt,
	     				@cane_inbnd_eft_ind,                         
	     				@cane_inbn_ac_ty_cd,                        
	     				@cane_inbnd_fxd_amt,                     
	     				@cane_inbn_af_dy_cd,                         
	     				@cane_inbnd_freq_cd,                         
	     				@cane_inbnd_bnk_nbr,                         
	     				@cane_inbn_trns_nbr,                         
	     				@cane_inbn_acct_nbr,
	     				@cane_inbnd_dnus_dt,
	     				@cane_inbnd_dnue_dt,
	     				@canf_inbnd_eft_ind,                        
	     				@canf_inbn_ac_ty_cd,                        
	     				@canf_inbnd_fxd_amt,                   
	     				@canf_inbn_af_dy_cd,                        
	     				@canf_inbnd_freq_cd,                         
	     				@canf_inbnd_bnk_nbr,                         
	     				@canf_inbn_trns_nbr,                          
	     				@canf_inbn_acct_nbr,
	     				@canf_inbnd_dnus_dt,
	     				@canf_inbnd_dnue_dt,
	     				@usag_otbd_fxd_amt,                    
	     				@usag_otbd_af_dy_cd,                         
	     				@usag_otbd_pymnt_cd,                         
	     				@usag_otbd_freq_cd,
	     				@usag_otbd_dnus_dt,
	     				@usag_otbd_dnue_dt,
	     				@usah_otbd_fxd_amt,                     
	     				@usah_otbd_af_dy_cd,                          
	     				@usah_otbd_pymnt_cd,                     
	     				@usah_otbd_freq_cd,                      
	     				@usah_otbd_bnk_nbr,                      
	     				@usah_otbd_trns_nbr,                      
	     				@usah_otbd_acct_nbr,
	     				@usah_otbd_dnus_dt,
	     				@usah_otbd_dnue_dt,
	     				@usaj_otbd_fxd_amt,                  
	     				@usaj_otbd_af_dy_cd,                      
	    	 			@usaj_otbd_pymnt_cd,                      
	     				@usaj_otbd_freq_cd,                      
	     				@usaj_otbd_bnk_nbr,                      
	     				@usaj_otbd_trns_nbr,                      
	     				@usaj_otbd_acct_nbr,
	     				@usaj_otbd_dnus_dt,
	     				@usaj_otbd_dnue_dt,
	     				@usak_inbnd_eft_ind,                       
	     				@usak_inbn_ac_ty_cd,                      
	     				@usak_inbnd_fxd_amt,                     
	     				@usak_inbn_af_dy_cd,                       
	     				@usak_inbnd_freq_cd,                       
	     				@usak_inbnd_bnk_nbr,                       
	     				@usak_inbn_trns_nbr,                       
	     				@usak_inbn_acct_nbr,
	     				@usak_inbnd_dnus_dt,
	     				@usak_inbnd_dnue_dt,
	     				@usal_inbnd_eft_ind,                       
	     				@usal_inbn_ac_ty_cd,                       
	     				@usal_inbnd_fxd_amt,                  
	     				@usal_inbn_af_dy_cd,                  
	     				@usal_inbnd_freq_cd,                  
	     				@usal_inbnd_bnk_nbr,                 
	     				@usal_inbn_trns_nbr,                  
	     				@usal_inbn_acct_nbr,
	     				@usal_inbnd_dnus_dt,
	     				@usal_inbnd_dnue_dt,
	     				@usam_inbnd_eft_ind,                 
	     				@usam_inbn_ac_ty_cd,                 
	     				@usam_inbnd_fxd_amt,             
	     				@usam_inbn_af_dy_cd,                  
	     				@usam_inbnd_freq_cd,                  
	     				@usam_inbnd_bnk_nbr,                  
	    				@usam_inbn_trns_nbr,                  
	     				@usam_inbn_acct_nbr,
	     				@usam_inbnd_dnus_dt,
	     				@usam_inbnd_dnue_dt,
					             getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_naf
				
				select @error_description = 'update_naf : tacct_inbnd_otbnd : Insert operation'
				
				raiserror 20061 "Insert operation to tacct_inbnd_otbnd failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_naf
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_naf			
			/* update */

			/* now update realtime table row */
			UPDATE tacct_inbnd_otbnd
			SET record_type_cd = 'NAF',
	                    action_cd = 'U' ,
	                    cana_otbd_fxd_amt = @cana_otbd_fxd_amt,                          
	     			cana_otbd_bnk_nbr = @cana_otbd_bnk_nbr,                          
	     			cana_otbd_trns_nbr = @cana_otbd_trns_nbr,                           
	    	 		cana_otbd_acct_nbr = @cana_otbd_acct_nbr,                          
	     			usag_otbd_bnk_nbr = @usag_otbd_bnk_nbr,                
	     			usag_otbd_trns_nbr = @usag_otbd_trns_nbr,                 
	     			usag_otbd_acct_nbr = @usag_otbd_acct_nbr,             
	     			cana_otbd_af_dy_cd = @cana_otbd_af_dy_cd,                 
	     			cana_otbd_pymnt_cd = @cana_otbd_pymnt_cd,                  
	     			cana_otbd_freq_cd = @cana_otbd_freq_cd,  
	     			cana_otbd_dnus_dt = @cana_otbd_dnus_dt,  
	     			cana_otbd_dnue_dt = @cana_otbd_dnue_dt,
	     			canb_otbd_fxd_amt = @canb_otbd_fxd_amt,            
	     			canb_otbd_af_dy_cd = @canb_otbd_af_dy_cd,                 
	     			canb_otbd_pymnt_cd = @canb_otbd_pymnt_cd,                  
	     			canb_otbd_freq_cd = @canb_otbd_freq_cd,               
	     			canb_otbd_bnk_nbr = @canb_otbd_bnk_nbr,                 
	     			canb_otbd_trns_nbr = @canb_otbd_trns_nbr,             
	     			canb_otbd_acct_nbr = @canb_otbd_acct_nbr,
	     			canb_otbd_dnus_dt = @canb_otbd_dnus_dt,
	     			canb_otbd_dnue_dt = @canb_otbd_dnue_dt,
	     			canc_otbd_fxd_amt = @canc_otbd_fxd_amt,            
	     			canc_otbd_af_dy_cd = @canc_otbd_af_dy_cd,                
	     			canc_otbd_pymnt_cd = @canc_otbd_pymnt_cd,                
	     			canc_otbd_freq_cd = @canc_otbd_freq_cd,                 
	     			canc_otbd_bnk_nbr = @canc_otbd_bnk_nbr,                
	     			canc_otbd_trns_nbr = @canc_otbd_trns_nbr,                 
	     			canc_otbd_acct_nbr = @canc_otbd_acct_nbr,
	     			canc_otbd_dnus_dt = @canc_otbd_dnus_dt,
	     			canc_otbd_dnue_dt = @canc_otbd_dnue_dt,     
	     			cand_inbnd_dnus_dt = @cand_inbnd_dnus_dt,
	     			cand_inbnd_dnue_dt = @cand_inbnd_dnue_dt,
	     			cane_inbnd_eft_ind = @cane_inbnd_eft_ind,                         
	     			cane_inbn_ac_ty_cd = @cane_inbn_ac_ty_cd,                        
	     			cane_inbnd_fxd_amt = @cane_inbnd_fxd_amt,                     
	     			cane_inbn_af_dy_cd = @cane_inbn_af_dy_cd,                         
	     			cane_inbnd_freq_cd = @cane_inbnd_freq_cd,                         
	     			cane_inbnd_bnk_nbr = @cane_inbnd_bnk_nbr,                         
	     			cane_inbn_trns_nbr = @cane_inbn_trns_nbr,                         
	     			cane_inbn_acct_nbr = @cane_inbn_acct_nbr,
	     			cane_inbnd_dnus_dt = @cane_inbnd_dnus_dt,
	     			cane_inbnd_dnue_dt = @cane_inbnd_dnue_dt,
	     			canf_inbnd_eft_ind = @canf_inbnd_eft_ind,                        
	     			canf_inbn_ac_ty_cd = @canf_inbn_ac_ty_cd,                        
	     			canf_inbnd_fxd_amt = @canf_inbnd_fxd_amt,                   
	     			canf_inbn_af_dy_cd = @canf_inbn_af_dy_cd,                        
	     			canf_inbnd_freq_cd = @canf_inbnd_freq_cd,                         
	     			canf_inbnd_bnk_nbr = @canf_inbnd_bnk_nbr,                         
	     			canf_inbn_trns_nbr = @canf_inbn_trns_nbr,                          
	     			canf_inbn_acct_nbr = @canf_inbn_acct_nbr,
	     			canf_inbnd_dnus_dt = @canf_inbnd_dnus_dt,
	     			canf_inbnd_dnue_dt = @canf_inbnd_dnue_dt,
	     			usag_otbd_fxd_amt = @usag_otbd_fxd_amt,                    
	     			usag_otbd_af_dy_cd = @usag_otbd_af_dy_cd,                         
	     			usag_otbd_pymnt_cd = @usag_otbd_pymnt_cd,                         
	     			usag_otbd_freq_cd = @usag_otbd_freq_cd,
	     			usag_otbd_dnus_dt = @usag_otbd_dnus_dt,
	     			usag_otbd_dnue_dt = @usag_otbd_dnue_dt,
	     			usah_otbd_fxd_amt = @usah_otbd_fxd_amt,                     
	     			usah_otbd_af_dy_cd = @usah_otbd_af_dy_cd,                          
	     			usah_otbd_pymnt_cd = @usah_otbd_pymnt_cd,                     
	     			usah_otbd_freq_cd = @usah_otbd_freq_cd,                      
	     			usah_otbd_bnk_nbr = @usah_otbd_bnk_nbr,                      
	     			usah_otbd_trns_nbr = @usah_otbd_trns_nbr,                      
	     			usah_otbd_acct_nbr = @usah_otbd_acct_nbr,
	     			usah_otbd_dnus_dt = @usah_otbd_dnus_dt,
	     			usah_otbd_dnue_dt = @usah_otbd_dnue_dt,
	     			usaj_otbd_fxd_amt = @usaj_otbd_fxd_amt,                  
	     			usaj_otbd_af_dy_cd = @usaj_otbd_af_dy_cd,                      
	    	 		usaj_otbd_pymnt_cd = @usaj_otbd_pymnt_cd,                      
	     			usaj_otbd_freq_cd = @usaj_otbd_freq_cd,                      
	     			usaj_otbd_bnk_nbr = @usaj_otbd_bnk_nbr,                      
	     			usaj_otbd_trns_nbr = @usaj_otbd_trns_nbr,                      
	     			usaj_otbd_acct_nbr = @usaj_otbd_acct_nbr,
	     			usaj_otbd_dnus_dt = @usaj_otbd_dnus_dt,
	     			usaj_otbd_dnue_dt = @usaj_otbd_dnue_dt,
	     			usak_inbnd_eft_ind = @usak_inbnd_eft_ind,                       
	     			usak_inbn_ac_ty_cd = @usak_inbn_ac_ty_cd,                      
	     			usak_inbnd_fxd_amt = @usak_inbnd_fxd_amt,                    
	     			usak_inbn_af_dy_cd = @usak_inbn_af_dy_cd,                       
	     			usak_inbnd_freq_cd = @usak_inbnd_freq_cd,                       
	     			usak_inbnd_bnk_nbr = @usak_inbnd_bnk_nbr,                       
	     			usak_inbn_trns_nbr = @usak_inbn_trns_nbr,                       
	     			usak_inbn_acct_nbr = @usak_inbn_acct_nbr,
	     			usak_inbnd_dnus_dt = @usak_inbnd_dnus_dt,
	     			usak_inbnd_dnue_dt = @usak_inbnd_dnue_dt,
	     			usal_inbnd_eft_ind = @usal_inbnd_eft_ind,                       
	     			usal_inbn_ac_ty_cd = @usal_inbn_ac_ty_cd,                       
	     			usal_inbnd_fxd_amt = @usal_inbnd_fxd_amt,                  
	     			usal_inbn_af_dy_cd = @usal_inbn_af_dy_cd,                  
	     			usal_inbnd_freq_cd = @usal_inbnd_freq_cd,                  
	     			usal_inbnd_bnk_nbr = @usal_inbnd_bnk_nbr,                 
	     			usal_inbn_trns_nbr = @usal_inbn_trns_nbr,                  
	     			usal_inbn_acct_nbr = @usal_inbn_acct_nbr,
	     			usal_inbnd_dnus_dt = @usal_inbnd_dnus_dt,
	     			usal_inbnd_dnue_dt = @usal_inbnd_dnue_dt,
	     			usam_inbnd_eft_ind = @usam_inbnd_eft_ind,                 
	     			usam_inbn_ac_ty_cd = @usam_inbn_ac_ty_cd,                 
	     			usam_inbnd_fxd_amt = @usam_inbnd_fxd_amt,             
	     			usam_inbn_af_dy_cd = @usam_inbn_af_dy_cd,                  
	     			usam_inbnd_freq_cd = @usam_inbnd_freq_cd,                  
	     			usam_inbnd_bnk_nbr = @usam_inbnd_bnk_nbr,                  
	    			usam_inbn_trns_nbr = @usam_inbn_trns_nbr,                  
	     			usam_inbn_acct_nbr = @usam_inbn_acct_nbr,
	     			usam_inbnd_dnus_dt = @usam_inbnd_dnus_dt,
	     			usam_inbnd_dnue_dt = @usam_inbnd_dnue_dt,
		             updt_last_tmstp = getdate()			
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd  

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_naf
				
				select @error_description = 'update_naf : tacct_inbnd_otbnd : Update operation'
				
				raiserror 20062 "Update operation to tacct_inbnd_otbnd failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		COMMIT TRAN update_naf

		END	
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
	
		BEGIN TRAN update_naf

		/* now delete realtime table row */
		DELETE tacct_inbnd_otbnd
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_naf
			
			select @error_description = 'update_naf : tacct_inbnd_otbnd : Delete operation'
			
			raiserror 20063 "Delete operation to tacct_inbnd_otbnd failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_naf
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
 
END

go

grant execute on update_naf to fbi
go

IF OBJECT_ID('dbo.update_naf') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_naf >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_naf >>>'
go
