/*
$Header: /rtapp/stp/update_nrt.sql 1     3/25/02 10:46a Tbprven $
$Log: /rtapp/stp/update_nrt.sql $
 * 
 * 1     3/25/02 10:46a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrt') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrt
    IF OBJECT_ID('dbo.update_nrt') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrt >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrt >>>'
END
go

CREATE PROC update_nrt
      @client_nbr	char(4)  ,
      @branch_cd char(3)  ,
      @account_cd char(5)  ,
      @rr_cd char(3)  ,
      @action char(1)  ,
      @ap_seq_nbr smallint   = null ,
      @birth_dt datetime   = null ,
      @last_nm char(30)   = null ,
      @mailing_address_cd char(3)   = null ,
      @tax_address_cd char(3)   = null ,
      @residency_cd char(1)   = null ,
      @state_cd char(2)   = null ,
      @zip5_cd char(5)   = null ,
      @zip4_cd char(4)   = null ,
      @marital_status_cd char(1)   = null ,
      @mrtl_stts_chng_dt datetime   = null ,
      @dependents_qty smallint   = null ,
      @dpndt_chng_dt datetime   = null ,
      @income_lvl_cd char(2)   = null ,
      @income_lvl_chng_dt datetime   = null ,
      @net_worth_cd char(2)   = null ,
      @net_worth_chng_dt datetime   = null ,
      @lqd_net_worth_cd char(2)   = null ,
      @short_nm char(20)   = null ,
      @lqd_net_chng_dt datetime   = null ,
      @tax_sps_id char(9)   = null ,
      @tax_brkt_cd char(2)   = null ,
      @tax_brkt_chng_dt datetime   = null ,
      @rent_own_cd char(1)   = null ,
      @rent_own_chng_dt datetime   = null ,
      @profession_cd char(2)   = null ,
      @prfsn_chng_dt datetime   = null ,
      @edctn_lvl_cd char(2)   = null ,
      @edctn_chng_dt datetime   = null ,
      @cust_rspns_cd char(2)   = null ,
      @cust_rspns_chng_dt datetime   = null ,
      @referal_cd char(2)   = null ,
      @cntry_rsdnc_cd char(2)   = null ,
      @home_net_worth_cd char(2)   = null ,
      @found_cust_cd char(2)   = null ,
      @addrs_unknw_dt datetime   = null ,
      @pin_nbr char(20)   = null ,
      @pin_chng_dt datetime   = null ,
      @mother_maiden_nm char(30)   = null ,
      @cr_bank_branch_nm char(20)   = null ,
      @cr_contact_nm char(20)   = null ,
      @profession_sps_cd char(2)   = null ,
      @employed_since_dt datetime   = null ,
      @account_sps_cd char(5)   = null ,
      @branch2_sps_cd char(3)   = null ,
      @account2_sps_cd char(5)   = null ,
      @prfsn_chng_sps_dt datetime   = null ,
      @first_sps_nm char(20)   = null ,
      @mi_initial_sps_txt char(1)   = null ,
      @last_sps_nm char(20)   = null ,
      @birth_sps_dt datetime   = null ,
      @branch_sps_cd char(3)   = null ,
      @cr_check_ind char(1)   = null ,
      @cr_acct_open_yr_cd char(4)   = null ,
      @cr_bank_nm char(20)   = null ,
      @cr_rating_cd char(2)   = null ,
      @emp_rltd_nm char(20)   = null ,
      @exch_emp_ind char(1)   = null ,
      @rltd_emp_desc_txt char(20)   = null ,
      @exch_emp_dtl1_txt char(30)   = null ,
      @exch_emp_dtl2_txt char(30)   = null ,
      @cust_met_ind char(1)   = null ,
      @cust_known_dt datetime   = null ,
      @cr_rgltr_cnstr_cd char(4)   = null ,
      @postal6_canada_cd char(6)  = null ,
      @zip_foreign_cd char(10) = null,
      @proxy_mail_cd char(1) = null,
      @cmmsn_stk_ovrrd_cd char(2) = null,
      @cmmsn_bnd_ovrrd_cd char(2) = null
 AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@ap_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tpp_info
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
		           ap_seq_nbr = @ap_seq_nbr
		           
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
                        
            BEGIN TRAN update_nrt
                        
			/* insert, first into realtime table */
			INSERT INTO tpp_info (client_nbr  ,
			      branch_cd  ,
			      account_cd  ,
			      ap_seq_nbr  ,
			      action ,
			      record_type_cd ,
			      rr_cd ,
			      birth_dt ,
			      last_nm ,
			      mailing_address_cd ,
			      tax_address_cd ,
			      residency_cd ,
			      state_cd,
			      zip5_cd ,
			      zip4_cd  ,
			      marital_status_cd ,
			      mrtl_stts_chng_dt ,
			      dependents_qty ,
			      dpndt_chng_dt ,
			      income_lvl_cd  ,
			      income_lvl_chng_dt,
			      net_worth_cd ,
			      net_worth_chng_dt ,
			      lqd_net_worth_cd  ,
			      short_nm ,
			      lqd_net_chng_dt ,
			      tax_sps_id ,
			      tax_brkt_cd ,
			      tax_brkt_chng_dt ,
			      rent_own_cd ,
			      rent_own_chng_dt ,
			      profession_cd ,
			      prfsn_chng_dt ,
			      edctn_lvl_cd ,
			      edctn_chng_dt ,
			      cust_rspns_cd ,
			      cust_rspns_chng_dt ,
			      referal_cd ,
			      cntry_rsdnc_cd ,
			      home_net_worth_cd ,
			      found_cust_cd ,
			      addrs_unknw_dt,
			      pin_nbr ,
			      pin_chng_dt ,
			      mother_maiden_nm  ,
			      cr_bank_branch_nm ,
			      cr_contact_nm ,
			      profession_sps_cd ,
			      employed_since_dt,
			      account_sps_cd ,
			      branch2_sps_cd ,
			      account2_sps_cd ,
			      prfsn_chng_sps_dt,
			      first_sps_nm ,
			      mi_initial_sps_txt ,
			      last_sps_nm ,
			      birth_sps_dt  ,
			      branch_sps_cd ,
			      cr_check_ind ,
			      cr_acct_open_yr_cd ,
			      cr_bank_nm ,
			      cr_rating_cd ,
			      emp_rltd_nm  ,
			      exch_emp_ind ,
			      rltd_emp_desc_txt  ,
			      exch_emp_dtl1_txt ,
			      exch_emp_dtl2_txt ,
			      cust_met_ind ,
			      cust_known_dt,
			      cr_rgltr_cnstr_cd ,
			      zip_foreign_cd ,
			      postal6_canada_cd,
				proxy_mail_cd,
				cmmsn_stk_ovrrd_cd,
				cmmsn_bnd_ovrrd_cd,
				updt_last_tmstp)
			VALUES (@client_nbr  ,
			      @branch_cd  ,
			      @account_cd  ,
			      @ap_seq_nbr  ,
			      'I' ,
			      'NRT' ,
			      @rr_cd ,
			      @birth_dt ,
			      @last_nm ,
			      @mailing_address_cd ,
			      @tax_address_cd ,
			      @residency_cd ,
			      @state_cd,
			      @zip5_cd ,
			      @zip4_cd  ,
			      @marital_status_cd ,
			      @mrtl_stts_chng_dt ,
			      @dependents_qty ,
			      @dpndt_chng_dt ,
			      @income_lvl_cd  ,
			      @income_lvl_chng_dt,
			      @net_worth_cd ,
			      @net_worth_chng_dt ,
			      @lqd_net_worth_cd  ,
			      @short_nm ,
			      @lqd_net_chng_dt ,
			      @tax_sps_id ,
			      @tax_brkt_cd ,
			      @tax_brkt_chng_dt ,
			      @rent_own_cd ,
			      @rent_own_chng_dt ,
			      @profession_cd ,
			      @prfsn_chng_dt ,
			      @edctn_lvl_cd ,
			      @edctn_chng_dt ,
			      @cust_rspns_cd ,
			      @cust_rspns_chng_dt ,
			      @referal_cd ,
			      @cntry_rsdnc_cd ,
			      @home_net_worth_cd ,
			      @found_cust_cd ,
			      @addrs_unknw_dt,
			      @pin_nbr ,
			      @pin_chng_dt ,
			      @mother_maiden_nm  ,
			      @cr_bank_branch_nm ,
			      @cr_contact_nm ,
			      @profession_sps_cd ,
			      @employed_since_dt,
			      @account_sps_cd ,
			      @branch2_sps_cd ,
			      @account2_sps_cd ,
			      @prfsn_chng_sps_dt,
			      @first_sps_nm ,
			      @mi_initial_sps_txt ,
			      @last_sps_nm ,
			      @birth_sps_dt  ,
			      @branch_sps_cd ,
			      @cr_check_ind ,
			      @cr_acct_open_yr_cd ,
			      @cr_bank_nm ,
			      @cr_rating_cd ,
			      @emp_rltd_nm  ,
			      @exch_emp_ind ,
			      @rltd_emp_desc_txt  ,
			      @exch_emp_dtl1_txt ,
			      @exch_emp_dtl2_txt ,
			      @cust_met_ind ,
			      @cust_known_dt,
			      @cr_rgltr_cnstr_cd ,
			      @zip_foreign_cd ,
			      @postal6_canada_cd,
				@proxy_mail_cd,
				@cmmsn_stk_ovrrd_cd,
				@cmmsn_bnd_ovrrd_cd,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrt
				
				select @error_description = 'update_nrt : tpp_info : Insert operation'
				
				raiserror 20133 "Insert operation to tpp_info failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nrt
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nrt			
			/* update */

			/* now update realtime table row */
			UPDATE tpp_info
			SET action = 'U' ,
			      record_type_cd = 'NRT',
			      rr_cd = @rr_cd,
			      birth_dt = @birth_dt ,
			      last_nm = @last_nm,
			      mailing_address_cd  = @mailing_address_cd,
			      tax_address_cd = @tax_address_cd,
			      residency_cd = @residency_cd,
			      state_cd = @state_cd,
			      zip5_cd = @zip5_cd,
			      zip4_cd = @zip4_cd ,
			      marital_status_cd = @marital_status_cd,
			      mrtl_stts_chng_dt = @mrtl_stts_chng_dt,
			      dependents_qty = @dependents_qty,
			      dpndt_chng_dt = @dpndt_chng_dt,
			      income_lvl_cd = @income_lvl_cd ,
			      income_lvl_chng_dt = @income_lvl_chng_dt,
			      net_worth_cd = @net_worth_cd,
			      net_worth_chng_dt = @net_worth_chng_dt,
			      lqd_net_worth_cd = @lqd_net_worth_cd ,
			      short_nm = @short_nm,
			      lqd_net_chng_dt = @lqd_net_chng_dt,
			      tax_sps_id = @tax_sps_id,
			      tax_brkt_cd = @tax_brkt_cd,
			      tax_brkt_chng_dt = @tax_brkt_chng_dt,
			      rent_own_cd = @rent_own_cd,
			      rent_own_chng_dt = @rent_own_chng_dt,
			      profession_cd = @profession_cd,
			      prfsn_chng_dt = @prfsn_chng_dt,
			      edctn_lvl_cd = @edctn_lvl_cd,
			      edctn_chng_dt = @edctn_chng_dt,
			      cust_rspns_cd = @cust_rspns_cd,
			      cust_rspns_chng_dt = @cust_rspns_chng_dt,
			      referal_cd = @referal_cd,
			      cntry_rsdnc_cd = @cntry_rsdnc_cd,
			      home_net_worth_cd = @home_net_worth_cd,
			      found_cust_cd = @found_cust_cd,
			      addrs_unknw_dt= @addrs_unknw_dt,
			      pin_nbr = @pin_nbr,
			      pin_chng_dt = @pin_chng_dt,
			      mother_maiden_nm  = @mother_maiden_nm,
			      cr_bank_branch_nm = @cr_bank_branch_nm,
			      cr_contact_nm = @cr_contact_nm,
			      profession_sps_cd = @profession_sps_cd,
			      employed_since_dt= @employed_since_dt,
			      account_sps_cd = @account_sps_cd,
			      branch2_sps_cd = @branch2_sps_cd,
			      account2_sps_cd = @account2_sps_cd,
			      prfsn_chng_sps_dt= @prfsn_chng_sps_dt,
			      first_sps_nm = @first_sps_nm,
			      mi_initial_sps_txt = @mi_initial_sps_txt,
			      last_sps_nm = @last_sps_nm,
			      birth_sps_dt  = @birth_sps_dt,
			      branch_sps_cd = @branch_sps_cd,
			      cr_check_ind = @cr_check_ind,
			      cr_acct_open_yr_cd = @cr_acct_open_yr_cd,
			      cr_bank_nm = @cr_bank_nm,
			      cr_rating_cd = @cr_rating_cd,
			      emp_rltd_nm  = @emp_rltd_nm,
			      exch_emp_ind = @exch_emp_ind,
			      rltd_emp_desc_txt  = @rltd_emp_desc_txt,
			      exch_emp_dtl1_txt = @exch_emp_dtl1_txt,
			      exch_emp_dtl2_txt = @exch_emp_dtl2_txt,
			      cust_met_ind = @cust_met_ind,
			      cust_known_dt = @cust_known_dt,
			      cr_rgltr_cnstr_cd = @cr_rgltr_cnstr_cd,
			      zip_foreign_cd = @zip_foreign_cd,
			      postal6_canada_cd = @postal6_canada_cd,
				proxy_mail_cd = @proxy_mail_cd,
				cmmsn_stk_ovrrd_cd = @cmmsn_stk_ovrrd_cd,
				cmmsn_bnd_ovrrd_cd = @cmmsn_bnd_ovrrd_cd,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
		           	ap_seq_nbr = @ap_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrt
				
				select @error_description = 'update_nrt : tpp_info : Update operation'
				
				raiserror 20134 "Update operation to tpp_info failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

            COMMIT TRAN update_nrt

		END
				
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		 
		 /*SELECT @db_action_cd = action
		 FROM tpp_info
		 WHERE      client_nbr = @client_nbr and 
		   branch_cd = @branch_cd and 
		   account_cd = @account_cd and
		   action IN ('A','C')
				           
		SELECT @tbl_rowcount = @@rowcount*/
						
		BEGIN TRAN update_nrt

		/* now delete realtime table row */
		DELETE tpp_info
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrt
			
			select @error_description = 'update_nrt : tpp_info : Delete operation'
			
			raiserror 20135 "Delete operation to tpp_info failed"
			select @custom_error_code=@@error				
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
	
		COMMIT TRAN update_nrt
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
 
END

go

grant execute on update_nrt to fbi
go

IF OBJECT_ID('dbo.update_nrt') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrt >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrt >>>'
go
