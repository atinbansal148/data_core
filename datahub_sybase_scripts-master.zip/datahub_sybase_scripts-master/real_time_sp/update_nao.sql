/*****************************************************************************
NAME: update_nao.sql
PURPOSE: Insert and update toecd_crs table
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	3495781	08/06/2017	J. sid		New Table
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nao') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nao
    IF OBJECT_ID('dbo.update_nao') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nao >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nao >>>'
END
go

CREATE PROC update_nao

    @client_nbr           char(4),
	@branch_cd            char(3),
	@account_cd           char(5),
	@ap_type_cd           char(1),
	@record_seq_nbr       smallint ,
	@action            char(1),
	@geo_res_cd       char(3) =null,
	@crs_type_cd      char(4) =null,
	@crs_sbtype_cd    char(4) =null,
	@tin_cd           char(30) =null,
	@last_updt_dt     datetime =null



					
AS
BEGIN
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	

	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)

	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)	

	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		
		
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM toecd_crs
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			ap_type_cd = @ap_type_cd AND
           record_seq_nbr = @record_seq_nbr 
           
           
			
		SELECT @tbl_rowcount = @@rowcount
		
		

		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nao
			
			/* insert into realtime table */
			INSERT INTO toecd_crs ( client_nbr ,           
					branch_cd,
					account_cd,
					ap_type_cd,
					record_seq_nbr,
					record_type_cd,
					action_cd,
					geo_res_cd,
                                crs_type_cd,
                                crs_sbtype_cd,
                                tin_cd,
                                last_updt_dt,
					updt_last_tmstp)
				VALUES     ( @client_nbr,
					         @branch_cd,
					         @account_cd,
					         @ap_type_cd,
                                @record_seq_nbr,
                                  'NAO', 
					               'I',
								@geo_res_cd,
                                @crs_type_cd,
                                @crs_sbtype_cd,
                                @tin_cd,
                                @last_updt_dt,
					            getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nao
				
				select @error_description = 'update_nao : toecd_crs : Insert operation'
				
				raiserror 20192 "Insert operation to toecd_crs failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nao
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nao
			
			/* now update realtime table row */


			UPDATE toecd_crs 
                         SET record_type_cd   ='NAO',
                             action_cd        = 'U',
                             geo_res_cd   =@geo_res_cd ,
                             crs_type_cd   =@crs_type_cd,
                            crs_sbtype_cd  =@crs_sbtype_cd  ,
                              tin_cd      =@tin_cd ,
                            last_updt_dt   =@last_updt_dt,
				              updt_last_tmstp	= getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND 
				ap_type_cd = @ap_type_cd AND
               record_seq_nbr = @record_seq_nbr 


			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nao
				
				select @error_description = 'update_nao : toecd_crs : Update operation'
				
				raiserror 20193 "Update operation to toecd_crs failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			   
			COMMIT TRAN update_nao  
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nao
		
		/* now delete realtime table row */

		DELETE toecd_crs 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			ap_type_cd = @ap_type_cd AND
                   record_seq_nbr = @record_seq_nbr


		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nao
			
			select @error_description = 'update_nao : toecd_crs : Delete operation'
			
			raiserror 20194 "Delete operation to toecd_crs failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
	        
	        COMMIT TRAN update_nao
	
	END

	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
   
END


go

grant execute on update_nao to fbi
go

IF OBJECT_ID('dbo.update_nao') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nao >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nao >>>'
go
