/************************************************************************************
NAME: add_history.sql
PURPOSE: Insert and update history and joiner tables
REVISIONS:
Ver	SSR	Date	 Author		 Description
-------	-------	-------- --------------- --------------------------------------------
1.0	87896	10/4/12	 Judy Shen	 Add the full 25 byte trans_control_id field
2.0	89218	10/23/12 Judy Shen	 INTACT Trade Synch message in own field
2.1	110940	11/05/15 Kannan	 	 Added ROLLBACK
**************************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.add_history') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.add_history
    IF OBJECT_ID('dbo.add_history') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.add_history >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.add_history >>>'
END
go

CREATE PROC add_history	@tag_dcltn_nbr   	char(5)	,        
                        @online_add_ind  	char(1)	,        
                        @processing_dt   	datetime,      
                        @item_dcltn_nbr  	char(4)	,        
                        @batch_dcltn_nbr 	char(4)	,        
                        @type_dcltn_cd   	char(2)	,        
                        @location_cd     	char(3)	,        
                        @rr_trans_cd     	char(3)	,        
                        @credit_gross_amt 	decimal(14,2),       
                        @comm_amt        	decimal(14,2),       
                        @trade_settle_dt 	datetime,        
                        @activity_ch_cd  	char(2)	,        
                        @batch_cd        	char(2)	,        
                        @entry_cd        	char(3)	,        
                        @transaction_amt 	decimal(17,2),        
                        @transaction_qty 	decimal(17,5),        
                        @trade_dt        	datetime,       
                        @type_tran_ch_cd 	char(1)	,        
                        @transaction_dt  	datetime,        
                        @currency_cd     	char(3)	,     
                        @price_trd_amt_txt 	char(9)	,       
                        @account_cd      	char(5)	,       
                        @branch_cd       	char(3)	,       
                        @client_nbr      	char(4)	,       
                        @type_account_cd 	char(1)	,       
                        @security_adp_nbr 	char(7)	,       
                        @record_type_cd  	char(3)	,       
                        @action          	char(1)	,
                        @rr_cd           	char(3)	,
                        @chk_brch_acct_nbr 	char(1)	,       
                        @tax_wthld_dvd_amt 	decimal(17,2)	,
                        /* up to 6 lines of history text */
                        @desc_history_txt1	char(30),
                        @desc_history_txt2	char(30),
                        @desc_history_txt3	char(30),
                        @desc_history_txt4	char(30),
                        @desc_history_txt5	char(30),
                        @desc_history_txt6	char(30),
                        @desc_history_txt7	char(30),
                        @desc_history_txt8	char(30),
                        @desc_history_txt9	char(30),
                        @desc_history_txt10	char(30),
                        @desc_history_txt11	char(30),
                        @desc_history_txt12	char(30),
                        @desc_history_txt13	char(30),
                        @desc_history_txt14	char(30),
                        @desc_history_txt15	char(30),
                        @desc_history_txt16	char(30),
                        @desc_history_txt17	char(30),
                        @desc_history_txt18	char(30),
                        @desc_history_txt19	char(30),
                        @desc_history_txt20	char(30),
                        @desc_history_txt21	char(30),
                        @desc_history_txt22	char(30),
                        @desc_history_txt23	char(30),
                        @desc_history_txt24	char(30),
                        @desc_history_txt25	char(30),
                        @rfrn_id		char(14),
                        @client_use_txt		char(20),
                        @join_proc_flag		char(1),
						@trans_control_id	char(25),
						@tables_for_master_process char(50) /* Don't use X-table if table listed */
	                
AS
BEGIN
    
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	DECLARE @seq_nbr	smallint			
	DECLARE @msdrqst int,
	@start_time             datetime,
	@proc_name              varchar(35),
	@input_parm             varchar(800),
	@debug_flag             char(1),
	@syb_error_code         int ,
	@custom_error_code      int,
	@error_description	varchar(150)

	/* realtime logging initialization */
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
						
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @currency_cd + "," + convert(char(30),@transaction_dt,116) + "," + @security_adp_nbr + "," + @type_tran_ch_cd + "," + @type_account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	/* select msdrqst */
	select @msdrqst = 0	
	
	if (@security_adp_nbr != '       ')
	begin
		select @msdrqst = count(*) 
		from tmsd_base
		where security_adp_nbr = @security_adp_nbr
	end
	else
	begin
		select @msdrqst = 1
	end 

	select @tables_for_master_process = RTRIM(LTRIM(@tables_for_master_process))

	/* find next sequence number to use */
	SELECT @seq_nbr = MAX(seq_nbr) FROM taccount_history WHERE 
		client_nbr 			= @client_nbr 		AND 
		branch_cd 			= @branch_cd 		AND 
		account_cd 			= @account_cd 		AND 
		currency_cd 		= @currency_cd 		AND 
		transaction_dt 		= @transaction_dt 	AND 
		security_adp_nbr	= @security_adp_nbr AND 
		type_tran_ch_cd 	= @type_tran_ch_cd 	AND 
		type_account_cd 	= @type_account_cd
	SELECT @seq_nbr = ISNULL(@seq_nbr,0)
	SELECT @seq_nbr = @seq_nbr + 1
	
	IF @desc_history_txt1 IS NOT NULL 
	BEGIN
		CREATE TABLE #add_history_txt
		(
			desc_history_txt char(30) NULL,
			seq_nbr          smallint NOT NULL,
			type_account_cd  char(1)  NOT NULL,
			account_cd       char(5)  NOT NULL,
			branch_cd        char(3)  NOT NULL,
			client_nbr       char(4)  NOT NULL,
			currency_cd      char(3)  NOT NULL,
			type_tran_ch_cd  char(1)  NOT NULL,
			security_adp_nbr char(7)  NULL,
			transaction_dt   datetime NOT NULL,
			txt_line_nbr     smallint NOT NULL,
			record_type_cd   char(3)  NULL,
			action           char(1)  NULL,
			rr_cd            char(3)  NULL
		)
            
		DECLARE @tmpLineNbr smallint
		DECLARE @tmpHistDesc char(30)
		SELECT @tmpLineNbr = 1
            
		/* while loop begins */
        while ( @tmpLineNbr  < 26 )
        BEGIN	
            SELECT @tmpHistDesc  = 
                            CASE @tmpLineNbr
                                WHEN    1   THEN   @desc_history_txt1
                                WHEN    2   THEN   @desc_history_txt2
                                WHEN    3   THEN   @desc_history_txt3
                                WHEN    4   THEN   @desc_history_txt4
                                WHEN    5   THEN   @desc_history_txt5
                                WHEN    6   THEN   @desc_history_txt6
                                WHEN    7   THEN   @desc_history_txt7
                                WHEN    8   THEN   @desc_history_txt8
                                WHEN    9   THEN   @desc_history_txt9
                                WHEN    10  THEN   @desc_history_txt10
                                WHEN    11  THEN   @desc_history_txt11
                                WHEN    12  THEN   @desc_history_txt12
                                WHEN    13  THEN   @desc_history_txt13
                                WHEN    14  THEN   @desc_history_txt14
                                WHEN    15  THEN   @desc_history_txt15
                                WHEN    16  THEN   @desc_history_txt16
                                WHEN    17  THEN   @desc_history_txt17
                                WHEN    18  THEN   @desc_history_txt18
                                WHEN    19  THEN   @desc_history_txt19
                                WHEN    20  THEN   @desc_history_txt20
                                WHEN    21  THEN   @desc_history_txt21
                                WHEN    22  THEN   @desc_history_txt22
                                WHEN    23  THEN   @desc_history_txt23
                                WHEN    24  THEN   @desc_history_txt24
                                WHEN    25  THEN   @desc_history_txt25
                                ELSE    NULL
                            END
							
            IF(@tmpHistDesc is NULL)
            BEGIN
               BREAK
            END

            INSERT INTO #add_history_txt ( desc_history_txt, 
                                            seq_nbr, 
                                            type_account_cd, 
                                            account_cd, 
                                            branch_cd, 
                                            client_nbr, 
                                            currency_cd,  
                                            type_tran_ch_cd, 
                                            security_adp_nbr, 
                                            transaction_dt, 
                                            txt_line_nbr, 
                                            record_type_cd, 
                                            action,
                                            rr_cd) 
            VALUES (    @tmpHistDesc, 
                        @seq_nbr, 
                        @type_account_cd, 
                        @account_cd, 
                        @branch_cd, 
                        @client_nbr, 
                        @currency_cd,  
                        @type_tran_ch_cd, 
                        @security_adp_nbr, 
                        @transaction_dt, 
                        @tmpLineNbr, 
                        @record_type_cd, 
                        @action,
                        @rr_cd)
            
			SELECT @tmpLineNbr = @tmpLineNbr + 1
                                            
		END /* end of while loop */

    END

    BEGIN TRANSACTION tran_add_history

	/* add row to taccount_history using seq_nbr we just found */
	INSERT INTO taccount_history (  record_type_cd, 
									client_nbr, 
									branch_cd, 
									account_cd, 
									currency_cd, 
									transaction_dt, 
									security_adp_nbr, 
									type_tran_ch_cd, 
									type_account_cd, 
									seq_nbr, 
									action, 
									tag_dcltn_nbr, 
									online_add_ind, 
									processing_dt, 
									item_dcltn_nbr, 
									batch_dcltn_nbr, 
									type_dcltn_cd, 
									location_cd, 
									rr_trans_cd, 
									credit_gross_amt, 
									comm_amt, 
									trade_settle_dt, 
									activity_ch_cd, 
									batch_cd, 
									entry_cd, 
									transaction_amt, 
									transaction_qty, 
									trade_dt, 
									price_trd_amt_txt, 
									rr_cd, 
									chk_brch_acct_nbr, 
									tax_wthld_dvd_amt) 
		VALUES (    @record_type_cd, 
					@client_nbr, 
					@branch_cd, 
					@account_cd, 
					@currency_cd, 
					@transaction_dt, 
					@security_adp_nbr, 
					@type_tran_ch_cd, 
					@type_account_cd, 
					@seq_nbr, 
					@action, 
					@tag_dcltn_nbr, 
					@online_add_ind, 
					@processing_dt, 
					@item_dcltn_nbr, 
					@batch_dcltn_nbr, 
					@type_dcltn_cd, 
					@location_cd, 
					@rr_trans_cd, 
					@credit_gross_amt, 
					@comm_amt, 
					@trade_settle_dt, 
					@activity_ch_cd, 
					@batch_cd, 
					@entry_cd, 
					@transaction_amt, 
					@transaction_qty, 
					@trade_dt, 
					@price_trd_amt_txt, 
					@rr_cd, 
					@chk_brch_acct_nbr, 
					@tax_wthld_dvd_amt)
					
		SELECT @syb_error_code = @@error

		if @syb_error_code != 0
		BEGIN
		
			ROLLBACK TRAN tran_add_history
		
			select @error_description = 'add_history : taccount_history : Insert operation'
		
			raiserror 20190 "Insert operation to taccount_history failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
					INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN -99
		
		END
				
				
    /* insert rows into taccount_hist_txt (and corresponding rollback table if no   */
    /* entry already exists in that table) if we received non-null text. Once we    */
    /* see a null string, we're done. no more strings are expected after a null     */
    /* string. 								                                        */
    IF @desc_history_txt1 IS NOT NULL 
    BEGIN
		INSERT INTO taccount_hist_txt
		SELECT * FROM #add_history_txt

		SELECT @syb_error_code = @@error
		
		IF @syb_error_code != 0
		BEGIN
		
			ROLLBACK TRAN tran_add_history
		
			select @error_description = 'add_history : taccount_hist_txt : Insert operation'
		
			raiserror 20191 "Insert operation to taccount_hist_txt failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
					INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN -99
		
		END

		DELETE #add_history_txt
	
    END
 
	select @msdrqst
	
	COMMIT TRANSACTION tran_add_history
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
	return 0
END

go

grant execute on add_history to fbi
go

IF OBJECT_ID('dbo.add_history') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.add_history >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.add_history >>>'
go

