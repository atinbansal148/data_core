/********************************************************************************************
NAME: update_nrb.sql
PURPOSE: Insert and update TACCOUNT_NEW table
REVISIONS:
Ver	SSR	Date		Author		Description
-------	-------	------------------------------------------------------------------------------
1.0	80735	03/01/13	J Shen		Added 1 new field funds_exp_slot_nbr
1.1	93885	09/26/13	J Shen		Added 3 new fields rylty_wthld_frg_rt, 
						reit_wthld_frgn_rt, mlp_wthld_frgn_rt
1.2	108505	12/30/15	J.Shen		Added 1 new field reig_wthld_frgn_rt
*********************************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrb') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrb
    IF OBJECT_ID('dbo.update_nrb') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrb >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrb >>>'
END
go

CREATE PROC update_nrb
	   @client_nbr          char(4),
	   @branch_cd           char(3),
	   @account_cd          char(5),
	   @rr_cd              char(3), 
           @action              char(1),
	   @account_clsfn_cd    char(3),
	   @sell_cd             char(2),
	   @buy_cd              char(2),
	   @dividend_cd         char(1),
	   @credit_interest_cd  char(1), 
	   @credit_interest_rt   decimal(10,7),
	   @debit_interest_cd   char(1),
	   @debit_interest_rt  decimal(10,7),
	   @spreading_ind      char(1), 
	   @prospectus_ind     char(1),
	   @optn_no_trdg_ind   char(1),
	   @cash_no_bsns_ind   char(1),
	   @margin_no_bsns_ind char(1),
	   @cmdty_no_bsns_ind  char(1),
	   @restriction_90_ind char(1),
	   @tax_usa_wthld_s_cd char(1),
	   @cash_management_cd char(1),
	   @cash_sweep_cd      char(1),
	   @ach_accounts_cd    char(1),
	   @grnte_grntr_cd     char(1),
	   @loan_agreement_cd  char(1),
	   @joint_agreement_cd char(1),
	   @margin_agrmt_ind   char(1),
	   @trust_agrmt_ind    char(1),
	   @corp_resolution_cd char(1),
	   @know_your_cust_ind char(1),
	   @bnd_wthld_frgn_rt  decimal(8,6),
	   @stk_wthld_frgn_rt  decimal(8,6),
	   @cmmsn_stk_spcl_cd  char(1),
	   @cmmsn_bnd_spcl_cd  char(1),
	   @hold_confirm_cd    char(1),
	   @currency_cd        char(3),
	   @branch_prft_ctr_cd char(3),
	   @prvdt_fund_prev_cd char(1),
	   @provident_fund_cd  char(1),
	   @year_end_record_cd char(1),
	   @broker_book_ind    char(1),
	   @individual_cd      char(1),
	   @proxy_dscls_cd     char(1),
	   @tefra_change_dt    datetime,
	   @rdmpt_check_cd     char(1),
	   @reinvestment_cd    char(1),
	   @funds_slot_nbr     char(3),
	   @mrgn_acct_ins_cd   char(1),
	   @sttlm_office_cd    char(3),
	   @buy_dvdnd_frctn_cd char(1),
	   @prospectus_sent_dt datetime,
	   @optional_aprvl_dt datetime,
	   @income_optn_cr_ind char(1),
	   @put_sllng_nkd_ind  char(1),
	   @writing_cvrd_ind   char(1),
	   @writing_naked_ind  char(1),
	   @purchase_ind       char(1),
	   @active_last_dt     datetime,
	   @due_dlgnc_prev_dt  datetime,
	   @due_dlgnc_sent_dt  datetime,
	   @due_diligence_cd   char(1),
	   @transfer_cd        char(1),
	   @postal_fee_cd      char(2),
	   @acat_cd            char(1),
	   @adt_dcmnt_spcl_cd  char(3),
	   @adt_customer_cd    char(3),
	   @account_option_cd  char(1),
	   @mail_list_cd       char(1),
	   @invoice_confirm_cd char(1), 
	   @settlement_cd      char(1),
	   @idntf_intrl_cd     char(5),
	   @wrap_fee_exmpt_ind char(1),
	   @wrap_fee_amt       decimal(5,3),
	   @record_changed_dt  datetime,
	   @record_added_dt    datetime,
	   @adjmt_dtl_1099_ind char(1),
	   @federal_nbr        char(3),
	   @irs_1042_rcpnt_cd  char(2),
	   @attorney_power_dt  datetime,
	   @attorney_power_cd  char(1),
	   @acat_rcv_brkr_nbr  char(4),
	   @acat_dlvr_brkr_nbr char(4),
	   @atmtc_prd_pymnt_cd char(2),
	   @money_mgr_cd       char(3),
	   @amex_transmit_cd   char(1),
	   @acm_cancel_cd      char(2),
	   @account_close_dt   datetime,
	   @bsns_stopped_dt   datetime,
	   @bsns_rnstt_dt      datetime,
	   @user_ff_txt        char(4),
	   @record_opened_dt   datetime,
	   @due_diligence2_cd  char(1),
	   @user_stts_acct_txt char(3),
	   @autx_access_cd     char(12),
	   @autx_acronym_cd    char(8),
	   @dvdnd_notice_ind   char(1),
	   @erisa_ind          char(1),
	   @hold_stmnt_ind     char(1),
	   @stmnt_last_dt	datetime,
	   @origin_broker_cd   char(1),
	   @name_control_cd    char(4),
	   @dscrt_acct_ind     char(1),
	   @opt_trdg_agrmt_ind char(1),
	   @portfolio_svc_1_cd char(1),
	   @cash_agrmt_ind     char(1),
	   @atty_paper_ind     char(1),
	   @last_day_stmt_ind  char(1),
	   @mult_dlvry_cd     char(2),
	   @olts_ind           char(1),
	   @fee_cd             char(2),
	   @fee_exmpt_ind      char(1),
	   @fee_freq_cd        char(2),
	   @fee_override_pct   decimal(5,3),
	   @del_after_tax_ind  char(1),
	   @ira_mtr_plan_cd    char(1),
	   @rtrmt_pln_sbjct_cd char(1),
	   @rtrmt_plan_cd      char(1),
	   @rtrmt_pln_clnt_cd  char(1),
	   @invst_advsr_ind    char(1),
	   @psr_ind            char(1),
	   @rule_351_cd        char(3),
	   @rule_80a_cd        char(3),
	   @portfolio_svc_2_cd char(1),
	   @cmdty_aprvl_cd     char(1),
	   @rr_prev_cd         char(3),
	   @cmdty_acct_ind     char(1),
	   @custody_acct_cd    char(3),
	   @acct_internal_cd   char(16),
	   @activity_last_dt   datetime,
	   @custodial_flip_ind char(1),
	   @cstd_fee_exempt_cd char(1),
	   @related_cd         char(1),
	   @brkr_exec_prim_cd  char(1),
	   @cstd_fee_status_cd char(1),
	   @entitlement_ach_cd char(1),
	   @term_updt_last_id  char(4),
	   @private_txt        char(10),
	   @cmmsn_shr_stock_rt decimal(8,5),
	   @cmmsn_shr_bond_rt  decimal(8,5),
	   @rio_ind            char(1),
	   @invst_advsr_cd     char(4),
	   @acct_aa_adv_cd     char(6),
	   @acct_aa_adv_cdg_cd char(1),
	   @direct_dep_acct_cd char(1),
	   @tax_lot_ind        char(1),
	   @acct_aa_adv_nm     char(20),
	   @brkr_clearing_id   char(4),
	   @clnt_hhld_key_cd  char(1),
	   @clnt_hhld_updt_dt  datetime,
	   @cr_chck_stts_cd          char(1),
	   @cr_chck_rvw_dt     datetime,
	   @funds_advn_ind     char(1),
	   @ps_trd_cmprs_cd    char(1),
	   @tax_usa_wthld_l_cd char(1),
	   @w8_s_cd             char(1), 
	   @w8_s_cert_dt        datetime,
	   @w8_chg_dt           datetime,
	   @w8_l_cd             char(1),
	   @eqty_cmmsn_ovrd_cd char(1),
	   @ina_ind             char(1),
	   @tefra_sub_cd        char(1),
	   @srce_of_add_cd      char(4),
	   @brkr_prim_nbr	char(4),
	   @acm_vndr_nbr	char(3),
	   @cncl_acm_vndr_nbr	char(3),
	   @funds_exp_slot_nbr	char(4),
	   @rylty_wthld_frg_rt	decimal(7,5),
	   @reit_wthld_frgn_rt	decimal(7,5),
	   @mlp_wthld_frgn_rt	decimal(7,5),
	   @reig_wthld_frgn_rt	decimal(7,5)
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description	varchar(150)	
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
			
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM taccount_new
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd 
			
		SELECT @tbl_rowcount = @@rowcount
                
        BEGIN TRAN update_nrb
                          
		IF @tbl_rowcount = 0
		BEGIN

			/* insert into realtime table */
			INSERT INTO taccount_new (
			                           client_nbr,
						   branch_cd,
						   account_cd,
					           account_clsfn_cd,
						   sell_cd,
						   buy_cd,
						   dividend_cd,
						   credit_interest_cd, 
						   credit_interest_rt,
						   debit_interest_cd,
						   debit_interest_rt,
						   rr_cd,            
						   spreading_ind, 
						   prospectus_ind,
						   optn_no_trdg_ind,
						   cash_no_bsns_ind,
						   margin_no_bsns_ind,
						   cmdty_no_bsns_ind,
						   restriction_90_ind,
						   tax_usa_wthld_s_cd,
						   cash_management_cd,
						   cash_sweep_cd,
						   ach_accounts_cd,
						   grnte_grntr_cd,
						   loan_agreement_cd,
						   joint_agreement_cd,
						   margin_agrmt_ind,
						   trust_agrmt_ind,
						   corp_resolution_cd,
						   know_your_cust_ind,
						   bnd_wthld_frgn_rt,
						   stk_wthld_frgn_rt,
						   cmmsn_stk_spcl_cd,
						   cmmsn_bnd_spcl_cd,
						   hold_confirm_cd,
						   currency_cd,
						   branch_prft_ctr_cd,
						   prvdt_fund_prev_cd,
						   provident_fund_cd ,
						   year_end_record_cd,
						   broker_book_ind,
						   individual_cd,
						   proxy_dscls_cd ,
						   tefra_change_dt,
						   rdmpt_check_cd,
						   reinvestment_cd,
						   funds_slot_nbr ,
						   mrgn_acct_ins_cd ,
						   sttlm_office_cd,
						   buy_dvdnd_frctn_cd ,
						   prospectus_sent_dt,
						   optional_aprvl_dt,
						   income_optn_cr_ind,
						   put_sllng_nkd_ind,
						   writing_cvrd_ind,
						   writing_naked_ind ,
						   purchase_ind ,
						   active_last_dt,
						   due_dlgnc_prev_dt,
						   due_dlgnc_sent_dt,
						   due_diligence_cd ,
						   transfer_cd,
						   postal_fee_cd ,
						   acat_cd ,
						   adt_dcmnt_spcl_cd,
						   adt_customer_cd,
						   account_option_cd,
						   mail_list_cd,
						   invoice_confirm_cd , 
						   settlement_cd,
						   idntf_intrl_cd ,
						   wrap_fee_exmpt_ind,
						   wrap_fee_amt,
						   record_changed_dt,
						   record_added_dt,
						   adjmt_dtl_1099_ind,
						   federal_nbr,
						   irs_1042_rcpnt_cd,
						   attorney_power_dt,
						   attorney_power_cd ,
						   record_type_cd,
						   action,
						   acat_rcv_brkr_nbr,
						   acat_dlvr_brkr_nbr,
						   atmtc_prd_pymnt_cd,
						   money_mgr_cd ,
						   amex_transmit_cd,
						   acm_cancel_cd,
						   account_close_dt,
						   bsns_stopped_dt ,
						   bsns_rnstt_dt,
						   user_ff_txt,
						   record_opened_dt,
						   due_diligence2_cd,
						   user_stts_acct_txt,
						   autx_access_cd,
						   autx_acronym_cd,
						   dvdnd_notice_ind,
						   erisa_ind,
						   hold_stmnt_ind,
						   stmnt_last_dt,
						   origin_broker_cd ,
						   name_control_cd,
						   dscrt_acct_ind,
						   opt_trdg_agrmt_ind,
						   portfolio_svc_1_cd,
						   cash_agrmt_ind,
						   atty_paper_ind,
						   last_day_stmt_ind,
						   mult_dlvry_cd,
						   olts_ind,
						   fee_cd,
						   fee_exmpt_ind,
						   fee_freq_cd,
						   fee_override_pct,
						   del_after_tax_ind,
						   ira_mtr_plan_cd,
						   rtrmt_pln_sbjct_cd,
						   rtrmt_plan_cd,
						   rtrmt_pln_clnt_cd,
						   invst_advsr_ind,
						   psr_ind,
						   rule_351_cd,
						   rule_80a_cd,
						   portfolio_svc_2_cd ,
						   cmdty_aprvl_cd,
						   rr_prev_cd,
						   cmdty_acct_ind,
						   custody_acct_cd,
						   acct_internal_cd,
						   activity_last_dt,
						   custodial_flip_ind,
						   cstd_fee_exempt_cd ,
						   related_cd,
						   brkr_exec_prim_cd,
						   cstd_fee_status_cd,
						   entitlement_ach_cd,
						   term_updt_last_id,
						   private_txt,
						   cmmsn_shr_stock_rt,
						   cmmsn_shr_bond_rt,
						   rio_ind,
						   invst_advsr_cd,
						   acct_aa_adv_cd ,
						   acct_aa_adv_cdg_cd,
						   direct_dep_acct_cd,
						   tax_lot_ind ,
						   acct_aa_adv_nm,
						   brkr_clearing_id,
						   clnt_hhld_key_cd,
						   clnt_hhld_updt_dt,
						   cr_chck_stts_cd ,
						   cr_chck_rvw_dt,
						   funds_advn_ind,
						   ps_trd_cmprs_cd,
						   tax_usa_wthld_l_cd,
						   w8_s_cd , 
						   w8_s_cert_dt,
						   w8_chg_dt,
						   w8_l_cd,
						   eqty_cmmsn_ovrd_cd,
                                                   ina_ind,
                                                   tefra_sub_cd,
	                                           srce_of_add_cd,
	                                           brkr_prim_nbr,
	                                           acm_vndr_nbr,
	                                           cncl_acm_vndr_nbr,
	                                           funds_exp_slot_nbr,
	                                           rylty_wthld_frg_rt,
	                                           reit_wthld_frgn_rt,
	                                           mlp_wthld_frgn_rt,
	                                           reig_wthld_frgn_rt,
					           updt_last_tmstp )
			VALUES (@client_nbr,
						   @branch_cd,
						   @account_cd,
					           @account_clsfn_cd,
						   @sell_cd,
						   @buy_cd,
						   @dividend_cd,
						   @credit_interest_cd, 
						   @credit_interest_rt,
						   @debit_interest_cd,
						   @debit_interest_rt,
						   @rr_cd,            
						   @spreading_ind, 
						   @prospectus_ind,
						   @optn_no_trdg_ind,
						   @cash_no_bsns_ind,
						   @margin_no_bsns_ind,
						   @cmdty_no_bsns_ind,
						   @restriction_90_ind,
						   @tax_usa_wthld_s_cd,
						   @cash_management_cd,
						   @cash_sweep_cd,
						   @ach_accounts_cd,
						   @grnte_grntr_cd,
						   @loan_agreement_cd,
						   @joint_agreement_cd,
						   @margin_agrmt_ind,
						   @trust_agrmt_ind,
						   @corp_resolution_cd,
						   @know_your_cust_ind,
						   @bnd_wthld_frgn_rt,
						   @stk_wthld_frgn_rt,
						   @cmmsn_stk_spcl_cd,
						   @cmmsn_bnd_spcl_cd,
						   @hold_confirm_cd,
						   @currency_cd,
						   @branch_prft_ctr_cd,
						   @prvdt_fund_prev_cd,
						   @provident_fund_cd ,
						   @year_end_record_cd,
						   @broker_book_ind,
						   @individual_cd,
						   @proxy_dscls_cd ,
						   @tefra_change_dt,
						   @rdmpt_check_cd,
						   @reinvestment_cd,
						   @funds_slot_nbr ,
						   @mrgn_acct_ins_cd ,
						   @sttlm_office_cd,
						   @buy_dvdnd_frctn_cd ,
						   @prospectus_sent_dt,
						   @optional_aprvl_dt,
						   @income_optn_cr_ind,
						   @put_sllng_nkd_ind,
						   @writing_cvrd_ind,
						   @writing_naked_ind ,
						   @purchase_ind ,
						   @active_last_dt,
						   @due_dlgnc_prev_dt,
						   @due_dlgnc_sent_dt,
						   @due_diligence_cd ,
						   @transfer_cd,
						   @postal_fee_cd ,
						   @acat_cd ,
						   @adt_dcmnt_spcl_cd,
						   @adt_customer_cd,
						   @account_option_cd,
						   @mail_list_cd,
						   @invoice_confirm_cd , 
						   @settlement_cd,
						   @idntf_intrl_cd ,
						   @wrap_fee_exmpt_ind,
						   @wrap_fee_amt,
						   @record_changed_dt,
						   @record_added_dt,
						   @adjmt_dtl_1099_ind,
						   @federal_nbr,
						   @irs_1042_rcpnt_cd,
						   @attorney_power_dt,
						   @attorney_power_cd ,
						   'NRB',
						   'I',
						   @acat_rcv_brkr_nbr,
						   @acat_dlvr_brkr_nbr,
						   @atmtc_prd_pymnt_cd,
						   @money_mgr_cd ,
						   @amex_transmit_cd,
						   @acm_cancel_cd,
						   @account_close_dt,
						   @bsns_stopped_dt ,
						   @bsns_rnstt_dt,
						   @user_ff_txt,
						   @record_opened_dt,
						   @due_diligence2_cd,
						   @user_stts_acct_txt,
						   @autx_access_cd,
						   @autx_acronym_cd,
						   @dvdnd_notice_ind,
						   @erisa_ind,
						   @hold_stmnt_ind,
						   @stmnt_last_dt,
						   @origin_broker_cd ,
						   @name_control_cd,
						   @dscrt_acct_ind,
						   @opt_trdg_agrmt_ind,
						   @portfolio_svc_1_cd,
						   @cash_agrmt_ind,
						   @atty_paper_ind,
						   @last_day_stmt_ind,
						   @mult_dlvry_cd,
						   @olts_ind,
						   @fee_cd,
						   @fee_exmpt_ind,
						   @fee_freq_cd,
						   @fee_override_pct,
						   @del_after_tax_ind,
						   @ira_mtr_plan_cd,
						   @rtrmt_pln_sbjct_cd,
						   @rtrmt_plan_cd,
						   @rtrmt_pln_clnt_cd,
						   @invst_advsr_ind,
						   @psr_ind,
						   @rule_351_cd,
						   @rule_80a_cd,
						   @portfolio_svc_2_cd ,
						   @cmdty_aprvl_cd,
						   @rr_prev_cd,
						   @cmdty_acct_ind,
						   @custody_acct_cd,
						   @acct_internal_cd,
						   @activity_last_dt,
						   @custodial_flip_ind,
						   @cstd_fee_exempt_cd ,
						   @related_cd,
						   @brkr_exec_prim_cd,
						   @cstd_fee_status_cd,
						   @entitlement_ach_cd,
						   @term_updt_last_id,
						   @private_txt,
						   @cmmsn_shr_stock_rt,
						   @cmmsn_shr_bond_rt,
						   @rio_ind,
						   @invst_advsr_cd,
						   @acct_aa_adv_cd ,
						   @acct_aa_adv_cdg_cd,
						   @direct_dep_acct_cd,
						   @tax_lot_ind ,
						   @acct_aa_adv_nm,
						   @brkr_clearing_id,
						   @clnt_hhld_key_cd,
						   @clnt_hhld_updt_dt,
						   @cr_chck_stts_cd ,
						   @cr_chck_rvw_dt,
						   @funds_advn_ind,
						   @ps_trd_cmprs_cd,
						   @tax_usa_wthld_l_cd,
						   @w8_s_cd , 
						   @w8_s_cert_dt,
						   @w8_chg_dt,
						   @w8_l_cd,
						   @eqty_cmmsn_ovrd_cd,
                                                   @ina_ind,
                                                   @tefra_sub_cd,
	                                           @srce_of_add_cd,
	                                           @brkr_prim_nbr,
	                                           @acm_vndr_nbr,
	                                           @cncl_acm_vndr_nbr,
	                                           @funds_exp_slot_nbr,
	                                           @rylty_wthld_frg_rt,
	                                           @reit_wthld_frgn_rt,
	                                           @mlp_wthld_frgn_rt,
	                                           @reig_wthld_frgn_rt,
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrb
				
				select @error_description = 'update_nrb : taccount_new : Insert operation'
				
				raiserror 20109 "Insert operation to taccount_new failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
	
		END
		ELSE
		BEGIN
			/* update */

			/* now update realtime table row */
			UPDATE taccount_new
			SET     action = 'U',
			record_type_cd = 'NRB',
	   account_clsfn_cd = @account_clsfn_cd,
	   sell_cd = @sell_cd,
	   buy_cd = @buy_cd,
	   dividend_cd = @dividend_cd,
	   credit_interest_cd = @credit_interest_cd, 
	   credit_interest_rt = @credit_interest_rt,
	   debit_interest_cd = @debit_interest_cd,
	   debit_interest_rt = @debit_interest_rt,
	   rr_cd = @rr_cd,            
	   spreading_ind = @spreading_ind, 
	   prospectus_ind = @prospectus_ind,
	   optn_no_trdg_ind = @optn_no_trdg_ind,
	   cash_no_bsns_ind = @cash_no_bsns_ind,
	   margin_no_bsns_ind = @margin_no_bsns_ind,
	   cmdty_no_bsns_ind = @cmdty_no_bsns_ind,
	   restriction_90_ind = @restriction_90_ind,
	   tax_usa_wthld_s_cd = @tax_usa_wthld_s_cd,
	   cash_management_cd  = @cash_management_cd ,
	   cash_sweep_cd       = @cash_sweep_cd      ,
	   ach_accounts_cd     = @ach_accounts_cd    ,
	   grnte_grntr_cd      = @grnte_grntr_cd     ,
	   loan_agreement_cd   = @loan_agreement_cd  ,
	   joint_agreement_cd  = @joint_agreement_cd ,
	   margin_agrmt_ind    = @margin_agrmt_ind   ,
	   trust_agrmt_ind     = @trust_agrmt_ind    ,
	   corp_resolution_cd  = @corp_resolution_cd ,
	   know_your_cust_ind  = @know_your_cust_ind ,
	   bnd_wthld_frgn_rt   = @bnd_wthld_frgn_rt  ,
	   stk_wthld_frgn_rt   = @stk_wthld_frgn_rt  ,
	   cmmsn_stk_spcl_cd   = @cmmsn_stk_spcl_cd  ,
	   cmmsn_bnd_spcl_cd   = @cmmsn_bnd_spcl_cd  ,
	   hold_confirm_cd     = @hold_confirm_cd    ,
	   currency_cd         = @currency_cd        ,
	   branch_prft_ctr_cd  = @branch_prft_ctr_cd ,
	   prvdt_fund_prev_cd  = @prvdt_fund_prev_cd ,
	   provident_fund_cd   = @provident_fund_cd  ,
	   year_end_record_cd  = @year_end_record_cd ,
	   broker_book_ind     = @broker_book_ind    ,
	   individual_cd       = @individual_cd      ,
	   proxy_dscls_cd      = @proxy_dscls_cd     ,
	   tefra_change_dt     = @tefra_change_dt    ,
	   rdmpt_check_cd      = @rdmpt_check_cd     ,
	   reinvestment_cd     = @reinvestment_cd    ,
	   funds_slot_nbr      = @funds_slot_nbr     ,
	   mrgn_acct_ins_cd    = @mrgn_acct_ins_cd   ,
	   sttlm_office_cd     = @sttlm_office_cd    ,
	   buy_dvdnd_frctn_cd  = @buy_dvdnd_frctn_cd ,
	   prospectus_sent_dt  = @prospectus_sent_dt ,
	   optional_aprvl_dt  = @optional_aprvl_dt ,
	   income_optn_cr_ind  = @income_optn_cr_ind ,
	   put_sllng_nkd_ind   = @put_sllng_nkd_ind  ,
	   writing_cvrd_ind    = @writing_cvrd_ind   ,
	   writing_naked_ind   = @writing_naked_ind  ,
	   purchase_ind        = @purchase_ind       ,
	   active_last_dt      = @active_last_dt     ,
	   due_dlgnc_prev_dt   = @due_dlgnc_prev_dt  ,
	   due_dlgnc_sent_dt   = @due_dlgnc_sent_dt  ,
	   due_diligence_cd    = @due_diligence_cd   ,
	   transfer_cd         = @transfer_cd        ,
	   postal_fee_cd       = @postal_fee_cd      ,
	   acat_cd             = @acat_cd            ,
	   adt_dcmnt_spcl_cd   = @adt_dcmnt_spcl_cd  ,
	   adt_customer_cd     = @adt_customer_cd    ,
	   account_option_cd   = @account_option_cd  ,
	   mail_list_cd        = @mail_list_cd       ,
	   invoice_confirm_cd  = @invoice_confirm_cd , 
	   settlement_cd       = @settlement_cd      ,
	   idntf_intrl_cd      = @idntf_intrl_cd     ,
	   wrap_fee_exmpt_ind  = @wrap_fee_exmpt_ind ,
	   wrap_fee_amt        = @wrap_fee_amt       ,
	   record_changed_dt   = @record_changed_dt  ,
	   record_added_dt     = @record_added_dt    ,
	   adjmt_dtl_1099_ind  = @adjmt_dtl_1099_ind ,
	   federal_nbr         = @federal_nbr        ,
	   irs_1042_rcpnt_cd   = @irs_1042_rcpnt_cd  ,
	   attorney_power_dt   = @attorney_power_dt  ,
	   attorney_power_cd   = @attorney_power_cd  ,
	   acat_rcv_brkr_nbr   = @acat_rcv_brkr_nbr  ,
	   acat_dlvr_brkr_nbr  = @acat_dlvr_brkr_nbr ,
	   atmtc_prd_pymnt_cd  = @atmtc_prd_pymnt_cd ,
	   money_mgr_cd        = @money_mgr_cd       ,
	   amex_transmit_cd    = @amex_transmit_cd   ,
	   acm_cancel_cd       = @acm_cancel_cd      ,
	   account_close_dt    = @account_close_dt   ,
	   bsns_stopped_dt    = @bsns_stopped_dt   ,
	   bsns_rnstt_dt       = @bsns_rnstt_dt      ,
	   user_ff_txt         = @user_ff_txt        ,
	   record_opened_dt    = @record_opened_dt   ,
	   due_diligence2_cd   = @due_diligence2_cd  ,
	   user_stts_acct_txt  = @user_stts_acct_txt ,
	   autx_access_cd      = @autx_access_cd     ,
	   autx_acronym_cd     = @autx_acronym_cd    ,
	   dvdnd_notice_ind    = @dvdnd_notice_ind   ,
	   erisa_ind           = @erisa_ind          ,
	   hold_stmnt_ind      = @hold_stmnt_ind     ,
	   stmnt_last_dt       = @stmnt_last_dt	 ,
	   origin_broker_cd    = @origin_broker_cd   ,
	   name_control_cd     = @name_control_cd    ,
	   dscrt_acct_ind      = @dscrt_acct_ind     ,
	   opt_trdg_agrmt_ind  = @opt_trdg_agrmt_ind ,
	   portfolio_svc_1_cd  = @portfolio_svc_1_cd ,
	   cash_agrmt_ind      = @cash_agrmt_ind     ,
	   atty_paper_ind      = @atty_paper_ind     ,
	   last_day_stmt_ind   = @last_day_stmt_ind  ,
	   mult_dlvry_cd      = @mult_dlvry_cd     ,
	   olts_ind            = @olts_ind           ,
	   fee_cd              = @fee_cd             ,
	   fee_exmpt_ind       = @fee_exmpt_ind      ,
	   fee_freq_cd         = @fee_freq_cd        ,
	   fee_override_pct    = @fee_override_pct   ,
	   del_after_tax_ind   = @del_after_tax_ind  ,
	   ira_mtr_plan_cd     = @ira_mtr_plan_cd    ,
	   rtrmt_pln_sbjct_cd  = @rtrmt_pln_sbjct_cd ,
	   rtrmt_plan_cd       = @rtrmt_plan_cd      ,
	   rtrmt_pln_clnt_cd   = @rtrmt_pln_clnt_cd  ,
	   invst_advsr_ind     = @invst_advsr_ind    ,
	   psr_ind             = @psr_ind            ,
	   rule_351_cd         = @rule_351_cd        ,
	   rule_80a_cd         = @rule_80a_cd        ,
	   portfolio_svc_2_cd  = @portfolio_svc_2_cd ,
	   cmdty_aprvl_cd      = @cmdty_aprvl_cd     ,
	   rr_prev_cd          = @rr_prev_cd         ,
	   cmdty_acct_ind      = @cmdty_acct_ind     ,
	   custody_acct_cd     = @custody_acct_cd    ,
	   acct_internal_cd    = @acct_internal_cd   ,
	   activity_last_dt    = @activity_last_dt   ,
	   custodial_flip_ind  = @custodial_flip_ind ,
	   cstd_fee_exempt_cd  = @cstd_fee_exempt_cd ,
	   related_cd          = @related_cd         ,
	   brkr_exec_prim_cd   = @brkr_exec_prim_cd  ,
	   cstd_fee_status_cd  = @cstd_fee_status_cd ,
	   entitlement_ach_cd  = @entitlement_ach_cd ,
	   term_updt_last_id   = @term_updt_last_id  ,
	   private_txt         = @private_txt        ,
	   cmmsn_shr_stock_rt  = @cmmsn_shr_stock_rt ,
	   cmmsn_shr_bond_rt   = @cmmsn_shr_bond_rt  ,
	   rio_ind             = @rio_ind            ,
	   invst_advsr_cd      = @invst_advsr_cd     ,
	   acct_aa_adv_cd      = @acct_aa_adv_cd     ,
	   acct_aa_adv_cdg_cd  = @acct_aa_adv_cdg_cd ,
	   direct_dep_acct_cd  = @direct_dep_acct_cd ,
	   tax_lot_ind         = @tax_lot_ind        ,
	   acct_aa_adv_nm      = @acct_aa_adv_nm ,
	   brkr_clearing_id    = @brkr_clearing_id   ,
	   clnt_hhld_key_cd   = @clnt_hhld_key_cd  ,
	   clnt_hhld_updt_dt   = @clnt_hhld_updt_dt  ,
	   cr_chck_stts_cd           = @cr_chck_stts_cd          ,
	   cr_chck_rvw_dt      = @cr_chck_rvw_dt     ,
	   funds_advn_ind      = @funds_advn_ind     ,
	   eqty_cmmsn_ovrd_cd  = @eqty_cmmsn_ovrd_cd ,
	   ps_trd_cmprs_cd      = @ps_trd_cmprs_cd     ,
	   tax_usa_wthld_l_cd  = @tax_usa_wthld_l_cd ,
	   w8_s_cd              = @w8_s_cd             , 
	   w8_s_cert_dt         = @w8_s_cert_dt        ,
	   w8_chg_dt            = @w8_chg_dt           ,
	   w8_l_cd              = @w8_l_cd             ,
           ina_ind              = @ina_ind             ,
           tefra_sub_cd =  @tefra_sub_cd,
	   srce_of_add_cd = @srce_of_add_cd ,
	   brkr_prim_nbr = @brkr_prim_nbr,
	   acm_vndr_nbr = @acm_vndr_nbr,
	   cncl_acm_vndr_nbr = @cncl_acm_vndr_nbr,
	   funds_exp_slot_nbr = @funds_exp_slot_nbr,
	   rylty_wthld_frg_rt = @rylty_wthld_frg_rt,
	   reit_wthld_frgn_rt = @reit_wthld_frgn_rt,
	   mlp_wthld_frgn_rt = @mlp_wthld_frgn_rt,
	   reig_wthld_frgn_rt = @reig_wthld_frgn_rt,
           updt_last_tmstp	   = getdate()	
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd 

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrb
				
				select @error_description = 'update_nrb : taccount_new : Update operation'
				
				raiserror 20110 "Update operation to taccount_new failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		END
		
		COMMIT TRAN update_nrb
	END
	ELSE
	IF (@action = 'D')
	BEGIN

		BEGIN TRAN update_nrb
		
		/* delete realtime record */
		
		/* now delete realtime table row */
		DELETE taccount_new  
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd 


		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrb
			
			select @error_description = 'update_nrb : taccount_new : Delete operation'
			
			raiserror 20111 "Delete operation to taccount_new failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
			    
		COMMIT TRAN update_nrb
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END

END

go

grant execute on update_nrb to fbi
go

IF OBJECT_ID('dbo.update_nrb') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrb >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrb >>>'
go