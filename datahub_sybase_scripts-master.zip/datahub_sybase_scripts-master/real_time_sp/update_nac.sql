/*
$Header: /rtapp/stp/update_nac.sql 1     3/25/02 10:39a Tbprven $
$Log: /rtapp/stp/update_nac.sql $
 * 
 * 1     3/25/02 10:39a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nac') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nac
    IF OBJECT_ID('dbo.update_nac') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nac >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nac >>>'
END
go

CREATE PROC update_nac
    @client_nbr         char(4),
    @branch_cd          char(3),
    @account_cd        	char(5),
    @rr_cd              char(3),
    @action             char(1),
    @ap_seq_nbr        	smallint = null ,
    @type_cd            char(3) = null ,
    @location_cd		char(1) = null ,
    @telephone_seq_nbr 	smallint = null ,
    @telephone_pp_cd    char(1)  = null,
    @telephone_pp_nbr  	char(15) = null,
    @phone_type_cd     	char(1) = null,
    @phone_area5_cd    	char(5) = null,
    @phone_exchange_cd 	char(3) = null,
    @phone_ext_cd      	char(4) = null,
    @phone_ext2_cd     	char(4) = null,
    @tlx_fax_swift_id   char(24) = null,
    @tlx_fax_addr_1_txt char(30) = null,
    @tlx_fax_addr_2_txt	char(30) = null,
    @email_address_id   char(40) = null,
    @email_addr_exp_id   char(100) = null
   
AS
BEGIN
   
   SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
   if @ap_seq_nbr is null 
	select @ap_seq_nbr = 1

	DECLARE @db_action_cd 	char(1)
	DECLARE @tbl_rowcount 	smallint,
		@start_time         datetime,
		@proc_name          varchar(35),
		@input_parm         varchar(800),
		@debug_flag         char(1),
		@syb_error_code     int ,
		@custom_error_code  int,
		@error_description	varchar(150)
	
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@ap_seq_nbr) + "," + @type_cd + "," + @location_cd + "," + convert(varchar(8),@telephone_seq_nbr) 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacc_party_phn
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			ap_seq_nbr = @ap_seq_nbr and
			telephone_seq_nbr = @telephone_seq_nbr and
			type_cd = @type_cd and
			location_cd = @location_cd
			
	    SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nac

			/* now insert into realtime table */
			INSERT INTO tacc_party_phn (client_nbr,
				    branch_cd,
				    account_cd,
				    ap_seq_nbr,
				    telephone_seq_nbr,
				    action,
				    record_type_cd,
				    rr_cd,
				    phone_type_cd,
				    telephone_pp_nbr,
				    phone_area5_cd,
				    phone_exchange_cd,
				    phone_ext_cd,
				    phone_ext2_cd,
				    tlx_fax_swift_id,
				    tlx_fax_addr_1_txt,
				    tlx_fax_addr_2_txt,
				    telephone_pp_cd,
				    type_cd,
				    location_cd,
				    email_address_id,
					email_addr_exp_id,
				    updt_last_tmstp)
			VALUES (@client_nbr,
				    @branch_cd,
				    @account_cd,
				    @ap_seq_nbr,
				    @telephone_seq_nbr,
				    'I',
				    'NAC',
				    @rr_cd,
				    @phone_type_cd,
				    @telephone_pp_nbr,
				    @phone_area5_cd,
				    @phone_exchange_cd,
				    @phone_ext_cd,
				    @phone_ext2_cd,
				    @tlx_fax_swift_id,
				    @tlx_fax_addr_1_txt,
				    @tlx_fax_addr_2_txt,
				    @telephone_pp_cd,
				    @type_cd,
					@location_cd,
				    @email_address_id,
					@email_addr_exp_id,
				    getdate())

			SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nac
				
				select @error_description = 'update_nac : tacc_party_phn : Insert operation'
				
				raiserror 20052 "Insert operation to tacc_party_phn failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nac
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nac			
			/* update */
			
			/* now update realtime table row */
			UPDATE tacc_party_phn 
			SET action = "U",
				    record_type_cd = "NAC",
				    rr_cd = @rr_cd,
				    phone_type_cd = @phone_type_cd,
				    telephone_pp_nbr = @telephone_pp_nbr,
				    phone_area5_cd = @phone_area5_cd,
				    phone_exchange_cd = @phone_exchange_cd,
				    phone_ext_cd = @phone_ext_cd,
				    phone_ext2_cd = @phone_ext2_cd,
				    tlx_fax_swift_id = @tlx_fax_swift_id,
				    tlx_fax_addr_1_txt = @tlx_fax_addr_1_txt,
				    tlx_fax_addr_2_txt = @tlx_fax_addr_2_txt,
				    telephone_pp_cd = @telephone_pp_cd,
					type_cd = @type_cd, 
					location_cd = @location_cd,
					email_address_id = @email_address_id,
					email_addr_exp_id = @email_addr_exp_id,
					updt_last_tmstp = getdate()				
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
				ap_seq_nbr = @ap_seq_nbr and
				telephone_seq_nbr = @telephone_seq_nbr and
				type_cd = @type_cd and
				location_cd = @location_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nac
				
				select @error_description = 'update_nac : tacc_party_phn : Update operation'
				
				raiserror 20053 "Update operation to tacc_party_phn failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

		    COMMIT TRAN update_nac
		
		END
	 
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		SELECT @db_action_cd = action
		FROM tacc_party_phn
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			action IN ('A','C')
					
		SELECT @tbl_rowcount = @@rowcount
		
		BEGIN TRAN update_nac
		
		if @tbl_rowcount != 0 
		BEGIN

			/* now delete realtime table row */
			DELETE tacc_party_phn 
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd 
	
			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nac
				
				select @error_description = 'update_nac : tacc_party_phn : Delete operation'
				
				raiserror 20054 "Delete operation to tacc_party_phn failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		END	

		COMMIT TRAN update_nac 
	
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nac to fbi
go

IF OBJECT_ID('dbo.update_nac') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nac >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nac >>>'
go
