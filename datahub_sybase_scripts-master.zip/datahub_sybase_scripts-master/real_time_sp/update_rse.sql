/*
$Header: /rtapp/stp/update_rse.sql $
$Log: /rtapp/stp/update_rse.sql $
 * 
 * 
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_rse') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_rse
    IF OBJECT_ID('dbo.update_rse') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_rse >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_rse >>>'
END
go

CREATE PROC update_rse
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@action 	        char(1),
	@sccsr_opn_dt		datetime,
	@death_dt			datetime			
AS
BEGIN
	
	DECLARE @action_cd char(1),
                @tbl_security_adp_nbr char(7),
                @start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)

			
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)

			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @action_cd = action_cd
		FROM trrif_dcsd_info
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd
			
		IF @@rowcount = 0
		BEGIN
			
			BEGIN TRAN update_rse
			/* insert, first into realtime table */
			INSERT INTO trrif_dcsd_info (client_nbr,
					branch_cd,
					account_cd,
					sccsr_opn_dt,
					death_dt,
					action_cd,
					record_type_cd,
					updt_last_tmstp )
			VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					@sccsr_opn_dt,
					@death_dt,
					'I',
					'RSE',
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rse
				
				select @error_description = 'update_rse : trrif_dcsd_info : Insert operation'
				
				raiserror 20163 "Insert operation to trrif_dcsd_info failed"
				select @custom_error_code=@@error
				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
			COMMIT TRAN update_rse
		END
		ELSE
		BEGIN
			BEGIN TRAN update_rse
			
			/* update */
		
			/*  update realtime table row */
			UPDATE trrif_dcsd_info 
			SET client_nbr = @client_nbr,
				branch_cd = @branch_cd,
				account_cd = @account_cd,
				sccsr_opn_dt = @sccsr_opn_dt,
				death_dt = @death_dt,
				action_cd = 'U',
				record_type_cd = 'RSE',
				updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rse
				
				select @error_description = 'update_rse : trrif_dcsd_info : Update operation'
				
				raiserror 20164 "Update operation to trrif_dcsd_info failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			    
			COMMIT TRAN update_rse    
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN		
		BEGIN TRAN update_rse
		/* delete realtime record */
	
		/*  delete realtime table row */
		DELETE trrif_dcsd_info 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_rse
			
			select @error_description = 'update_rse : trrif_dcsd_info : Delete operation'
			
			raiserror 20165 "Delete operation to trrif_dcsd_info failed"
			select @custom_error_code=@@error
						
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_rse			    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_rse to fbi
go

IF OBJECT_ID('dbo.update_rse') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_rse >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_rse >>>'
go