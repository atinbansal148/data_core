/*
$Header: /Realtime/Realtime/stp/update_msd.sql 4     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msd.sql $
 * 
 * 4     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 3     6/29/00 5:18p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msd') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msd
    IF OBJECT_ID('dbo.update_msd') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msd >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msd >>>'
END
go

CREATE PROC update_msd
	@security_adp_nbr	char(7),
	@exchange_msd_cd	char(10),
	@country_cd			char(2),
	@exch_primary_ind	char(1)
	
AS
BEGIN
    
	DECLARE @action_cd char(1),
		@tbl_security_adp_nbr 	char(7),
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description		varchar(150)
		
	
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @exchange_msd_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tsec_trd_exchange WHERE
		exchange_msd_cd = @exchange_msd_cd AND
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msd
		/* insert */
		INSERT INTO tsec_trd_exchange (	exchange_msd_cd,
						security_adp_nbr,
						country_cd,
						exch_primary_ind,
						record_type_cd,
						action_cd )
		VALUES (	@exchange_msd_cd,
					@security_adp_nbr,
					@country_cd,
					@exch_primary_ind,
					'MSD',
					'I' )
					
		SELECT @syb_error_code = @@error
		
		IF @syb_error_code != 0
		BEGIN
		
			ROLLBACK TRAN update_msd
			
			select @error_description = 'update_msd : tsec_trd_exchange : Insert operation'
			
			raiserror 20031 "Insert operation to tsec_trd_exchange failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END

		COMMIT TRAN update_msd    
	END
	ELSE
	BEGIN
		
		BEGIN TRAN update_msd
		/* update */

		/* now update real-time table */
		UPDATE tsec_trd_exchange SET
			country_cd = @country_cd,
			exch_primary_ind = @exch_primary_ind,
			record_type_cd = 'MSD',
			action_cd = 'U'
		WHERE exchange_msd_cd = @exchange_msd_cd AND
			security_adp_nbr = @security_adp_nbr
			
		SELECT @syb_error_code = @@error

		IF @syb_error_code != 0
		
		BEGIN
		
			ROLLBACK TRAN update_msd
		
			select @error_description = 'update_msd : tsec_trd_exchange : Update operation'
			
			raiserror 20032 "Update operation to tsec_trd_exchange failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN -99
			
		END
		    
		COMMIT TRAN update_msd    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
    
END

go

grant execute on update_msd to fbi
go

IF OBJECT_ID('dbo.update_msd') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msd >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msd >>>'
go