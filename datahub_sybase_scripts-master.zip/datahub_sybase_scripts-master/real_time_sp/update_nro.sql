/*****************************************************************************
NAME: update_nro.sql
PURPOSE: Insert and update TACC_PARTY_NAME table
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	99785	7/24/14	J.Shen		add 3 new fields
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nro') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nro
    IF OBJECT_ID('dbo.update_nro') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nro >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nro >>>'
END
go

CREATE PROC update_nro
      @client_nbr	char(4) ,
      @branch_cd char(3) ,
      @account_cd char(5) ,
      @rr_cd char(3) ,
      @action char(1) ,
      @ap_seq_nbr smallint  = null ,
      @ap_type_cd char(1)  = null ,
      @person_cmpy_cd char(1)  = null ,
      @confirm_qty smallint  = null ,
      @statement_qty smallint  = null ,
      @transfers_ip_ind char(1)  = null ,
      @proxies_ip_ind char(1)  = null ,
      @income_chck_ip_ind char(1)  = null ,
      @online_chck_ip_ind char(1)  = null ,
      @id_system_ip_ind char(1)  = null ,
      @cod_ip_ind char(1)  = null ,
      @cor_ip_ind char(1)  = null ,
      @prcss_1099_ind char(1)  = null ,
      @ip_seg_added_dt datetime  = null ,
      @ip_seg_add_rt_dt datetime  = null ,
      @ip_seg_changed_dt datetime  = null ,
      @ip_seg_chng_rt_dt datetime  = null ,
      @first_nm char(20)  = null ,
      @mi_initial_txt char(1)  = null ,
      @last_nm char(20)  = null ,
      @title_sffx3_txt char(3)  = null ,
      @title_prfx4_txt char(4)  = null ,
      @title_prfx8_txt char(8)  = null ,
      @company_nm char(35)  = null ,
      @language_cd char(1)  = null ,
      @dtc_id char(5)  = null ,
      @soc_sec_tax_cd char(1)  = null ,
      @participant_cd char(5)  = null ,
      @branch_ip_rotng_cd char(3)  = null ,
      @soc_sec_nbr char(9)  = null ,
      @householding_cd char(4)  = null ,
      @print_trid_cd char(1)  = null ,
      @customer_nbr char(12)  = null ,
      @dtc_clearing_id char(5) = null ,
      @eltro_stmt_cd char(1) = null ,
      @eltro_cnfrm_cd char(1) = null ,
      @soc_sec2_nbr char(9) = null ,
      @soc_sec2_tax_cd char(1) = null ,
      @soc_sec3_nbr char(9) = null ,
      @soc_sec3_tax_cd char(1) = null ,
      @soc_sec4_nbr char(9) = null ,
      @soc_sec4_tax_cd char(1) = null,
      @ina_ip_tag_cd char(1) = null,
      @birth_joint_dt datetime = null,
      @na_line_chng_dt datetime = null,
      @eltro_1099_cd char(1) = null,
      @eltro_proxy_cd char(1) = null,
      @eltro_prspc_cd char(1) = null
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@ap_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacc_party_name
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   ap_seq_nbr = @ap_seq_nbr 
			   
		SELECT @tbl_rowcount = @@rowcount
		
		IF @tbl_rowcount = 0
		BEGIN
                        
            BEGIN TRAN update_nro
                                       
			/* insert into realtime table */
			INSERT INTO tacc_party_name (client_nbr  ,
			      branch_cd  ,
			      account_cd ,
			      ap_seq_nbr ,
			      action  ,
			      record_type_cd ,
			      rr_cd ,
			      ap_type_cd ,
			      person_cmpy_cd ,
			      confirm_qty ,
			      statement_qty ,
			      transfers_ip_ind ,
			      proxies_ip_ind  ,
			      income_chck_ip_ind  ,
			      online_chck_ip_ind ,
			      id_system_ip_ind  ,
			      cod_ip_ind ,
			      cor_ip_ind  ,
			      prcss_1099_ind ,
			      ip_seg_added_dt ,
			      ip_seg_add_rt_dt ,
			      ip_seg_changed_dt ,
			      ip_seg_chng_rt_dt ,
			      first_nm  ,
			      mi_initial_txt ,
			      last_nm  ,
			      title_sffx3_txt ,
			      title_prfx4_txt ,
			      title_prfx8_txt ,
			      company_nm  ,
			      language_cd ,
			      dtc_id ,
			      soc_sec_tax_cd ,
			      participant_cd ,
			      branch_ip_rotng_cd ,
			      soc_sec_nbr ,
			      householding_cd ,
			      print_trid_cd ,
			      customer_nbr  ,
			      dtc_clearing_id	,
				  eltro_stmt_cd	,
				  eltro_cnfrm_cd	,
				  soc_sec2_nbr,
				  soc_sec2_tax_cd,
				  soc_sec3_nbr,
				  soc_sec3_tax_cd,
				  soc_sec4_nbr,
				  soc_sec4_tax_cd,
				ina_ip_tag_cd,
				birth_joint_dt,
				na_line_chng_dt,
				eltro_1099_cd,
				eltro_proxy_cd,
				eltro_prspc_cd,
		             updt_last_tmstp)
			VALUES (@client_nbr  ,
			      @branch_cd  ,
			      @account_cd ,
			      @ap_seq_nbr ,
			      'I'  ,
			      'NRO' ,
			      @rr_cd ,
			      @ap_type_cd ,
			      @person_cmpy_cd ,
			      @confirm_qty ,
			      @statement_qty ,
			      @transfers_ip_ind ,
			      @proxies_ip_ind  ,
			      @income_chck_ip_ind  ,
			      @online_chck_ip_ind ,
			      @id_system_ip_ind  ,
			      @cod_ip_ind ,
			      @cor_ip_ind  ,
			      @prcss_1099_ind ,
			      @ip_seg_added_dt ,
			      @ip_seg_add_rt_dt ,
			      @ip_seg_changed_dt ,
			      @ip_seg_chng_rt_dt ,
			      @first_nm  ,
			      @mi_initial_txt ,
			      @last_nm  ,
			      @title_sffx3_txt ,
			      @title_prfx4_txt ,
			      @title_prfx8_txt ,
			      @company_nm  ,
			      @language_cd ,
			      @dtc_id ,
			      @soc_sec_tax_cd ,
			      @participant_cd ,
			      @branch_ip_rotng_cd ,
			      @soc_sec_nbr ,
			      @householding_cd ,
			      @print_trid_cd ,
			      @customer_nbr  ,
			      @dtc_clearing_id	,
				  @eltro_stmt_cd	,
				  @eltro_cnfrm_cd	,
				  @soc_sec2_nbr,
				  @soc_sec2_tax_cd,
				  @soc_sec3_nbr,
				  @soc_sec3_tax_cd,
				  @soc_sec4_nbr,
				  @soc_sec4_tax_cd,
				@ina_ip_tag_cd,
				@birth_joint_dt,
				@na_line_chng_dt,
				@eltro_1099_cd,
				@eltro_proxy_cd,
				@eltro_prspc_cd,
                              getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nro
				
				select @error_description = 'update_nro : tacc_party_name : Insert operation'
				
				raiserror 20118 "Insert operation to tacc_party_name failed"
				select @custom_error_code=@@error
								
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

            COMMIT TRAN update_nro
			
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nro			
			/* update */
	
			/* now update realtime table row */
			UPDATE tacc_party_name
			SET action = 'U' ,
			      record_type_cd = 'NRO',
			      rr_cd = @rr_cd ,
			      ap_type_cd = @ap_type_cd,
			  person_cmpy_cd = @person_cmpy_cd,
			      confirm_qty = @confirm_qty,
			      statement_qty = @statement_qty,
			      transfers_ip_ind = @transfers_ip_ind,
			      proxies_ip_ind  = @proxies_ip_ind,
			      income_chck_ip_ind = @income_chck_ip_ind ,
			      online_chck_ip_ind = @online_chck_ip_ind,
			      id_system_ip_ind = @id_system_ip_ind ,
			      cod_ip_ind = @cod_ip_ind,
			      cor_ip_ind = @cor_ip_ind ,
			      prcss_1099_ind = @prcss_1099_ind,
			      ip_seg_added_dt = @ip_seg_added_dt,
			      ip_seg_add_rt_dt = @ip_seg_add_rt_dt,
			      ip_seg_changed_dt = @ip_seg_changed_dt,
			      ip_seg_chng_rt_dt = @ip_seg_chng_rt_dt,
			      first_nm = @first_nm ,
			      mi_initial_txt = @mi_initial_txt,
			      last_nm = @last_nm ,
			      title_sffx3_txt = @title_sffx3_txt,
			      title_prfx4_txt = @title_prfx4_txt,
			      title_prfx8_txt = @title_prfx8_txt,
			      company_nm = @company_nm ,
			      language_cd = @language_cd,
			      dtc_id = @dtc_id,
			      soc_sec_tax_cd = @soc_sec_tax_cd,
			      participant_cd = @participant_cd,
			      branch_ip_rotng_cd = @branch_ip_rotng_cd,
			      soc_sec_nbr = @soc_sec_nbr,
			      householding_cd = @householding_cd,
			      print_trid_cd = @print_trid_cd,
			      customer_nbr = @customer_nbr ,
			      dtc_clearing_id = @dtc_clearing_id,
				  eltro_stmt_cd	= isnull(@eltro_stmt_cd,eltro_stmt_cd),
				  eltro_cnfrm_cd = isnull(@eltro_cnfrm_cd,eltro_cnfrm_cd),
				  soc_sec2_nbr	= @soc_sec2_nbr,
				  soc_sec2_tax_cd = @soc_sec2_tax_cd,
				  soc_sec3_nbr = isnull(@soc_sec3_nbr,soc_sec3_nbr),
				  soc_sec3_tax_cd = isnull(@soc_sec3_tax_cd,soc_sec3_tax_cd),
				  soc_sec4_nbr = isnull(@soc_sec4_nbr,soc_sec4_nbr),
				  soc_sec4_tax_cd = isnull(@soc_sec4_tax_cd,soc_sec4_tax_cd),
				ina_ip_tag_cd = @ina_ip_tag_cd,
				birth_joint_dt = @birth_joint_dt,
				na_line_chng_dt = @na_line_chng_dt,
				eltro_1099_cd = @eltro_1099_cd,
				eltro_proxy_cd = @eltro_proxy_cd,
				eltro_prspc_cd = @eltro_prspc_cd,
				  updt_last_tmstp	   = getdate()	
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
			   	ap_seq_nbr = @ap_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nro
				
				select @error_description = 'update_nro : tacc_party_name : Update operation'
				
				raiserror 20119 "Update operation to tacc_party_name failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

            COMMIT TRAN update_nro
                
		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
				
		/*SELECT @db_action_cd = action
		FROM tacc_party_name
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   action IN ('A','C') 

		SELECT @tbl_rowcount = @@rowcount*/

		BEGIN TRAN update_nro

		/* now delete realtime table row */
		DELETE tacc_party_name
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 
			   
		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nro
			
			select @error_description = 'update_nro : tacc_party_name : Delete operation'
			
			raiserror 20120 "Delete operation to tacc_party_name failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
	    
	    COMMIT TRAN update_nro

	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_nro to fbi
go

IF OBJECT_ID('dbo.update_nro') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nro >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nro >>>'
go
