/*
$Header: /rtapp/stp/update_nr0.sql 1     3/25/02 10:42a Tbprven $
$Log: /rtapp/stp/update_nr0.sql $
 * 
 * 1     3/25/02 10:42a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nr0') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nr0
    IF OBJECT_ID('dbo.update_nr0') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nr0 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nr0 >>>'
END
go

CREATE PROC update_nr0
      @client_nbr	char(4)   ,
      @branch_cd	char(3)   ,
      @account_cd	char(5)   ,
      @rr_cd		char(3),
      @action		char(1)  ,
      @currency_cd	char(3)  = null ,
      @fund_nbr		char(2)  = null 
      
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @currency_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tsweep_fund
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   currency_cd = @currency_cd
			   
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
		
			BEGIN TRAN update_nr0
			
			/* insert into realtime table */
			INSERT INTO tsweep_fund (client_nbr ,
			      branch_cd ,
			      account_cd ,
			      currency_cd ,
			      fund_nbr ,
			      action,
			      record_type_cd,
			      rr_cd,
			      updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd ,
			      @account_cd ,
			      @currency_cd ,
			      @fund_nbr ,
			      'I',
			      'NR0',
			      @rr_cd,
			      getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr0
				
				select @error_description = 'update_nr0 : tsweep_fund : Insert operation'
				
				raiserror 20079 "Insert operation to tsweep_fund failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			COMMIT TRAN update_nr0
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nr0			
			/* update */

			/* now update realtime table row */
			UPDATE tsweep_fund
			SET fund_nbr = @fund_nbr,
			      action = 'U',
			      record_type_cd = 'NR0',
			      rr_cd = @rr_cd,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
				currency_cd = @currency_cd
 
			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr0
				
				select @error_description = 'update_nr0 : tsweep_fund : Update operation'
				
				raiserror 20080 "Update operation to tsweep_fund failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
		COMMIT TRAN update_nr0
		
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nr0

		/* now delete realtime table row */
		DELETE tsweep_fund
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nr0
			
			select @error_description = 'update_nr0 : tsweep_fund : Delete operation'
			
			raiserror 20081 "Delete operation to tsweep_fund failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		COMMIT TRAN update_nr0

	END
  
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_nr0 to fbi
go

IF OBJECT_ID('dbo.update_nr0') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nr0 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nr0 >>>'
go