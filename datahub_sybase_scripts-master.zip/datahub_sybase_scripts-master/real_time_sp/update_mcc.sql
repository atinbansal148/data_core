/*
$Header: /Realtime/Realtime/stp/update_mcc.sql 1     10/19/01 4:22p Tbjuhu $
$Log: /Realtime/Realtime/stp/update_mcc.sql $
 * 
 * 1     10/19/01 4:22p Tbjuhu
 * 4th Qtr Data model changes
 *  
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_mcc') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_mcc
    IF OBJECT_ID('dbo.update_mcc') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_mcc >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_mcc >>>'
END
go

CREATE PROC update_mcc
	@security_adp_nbr	char(7),
	@agent_transfer_nbr	int,
	@clearing_cdcc_cd	char(1),
	@elig_rsp_cd		char(1),
	@province_cd		char(2),
	@day_settle_qty		decimal(1,0),
	@elig_qssp_ind		char(1),
	@elig_isip_ind		char(1),
	@process_dt		datetime,
	@elig_rsp_dt		datetime,
	@prev_elig_rsp_cd	char(1),
	@prev_elig_rsp_dt	datetime,
	@override_rsp_cd	char(1)
							
AS
BEGIN
    
	DECLARE @action_cd char(1),
		@tbl_security_adp_nbr char(7),
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
			
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
						
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM ttrnsfr_client_dat 
	WHERE security_adp_nbr = @security_adp_nbr
		
	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_mcc
		/* insert */
		INSERT INTO ttrnsfr_client_dat (security_adp_nbr,
						record_type_cd,
						action_cd,
						agent_transfer_nbr,
						clearing_cdcc_cd,
						elig_rsp_cd,
						province_cd,
						day_settle_qty,
						elig_qssp_ind,
						elig_isip_ind,
						process_dt,
						elig_rsp_dt,
						prev_elig_rsp_cd,
						prev_elig_rsp_dt,
						override_rsp_cd,
						updt_last_tmstp)
				VALUES (	@security_adp_nbr,
						'MCC',
						'I',
						@agent_transfer_nbr,
						@clearing_cdcc_cd,
						@elig_rsp_cd,
						@province_cd,
						@day_settle_qty,
						@elig_qssp_ind,
						@elig_isip_ind,
						@process_dt,
						@elig_rsp_dt,
						@prev_elig_rsp_cd,
						@prev_elig_rsp_dt,
						@override_rsp_cd,
						getdate())

		SELECT @syb_error_code = @@error
	
		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_mcc
			
			select @error_description = 'update_mcc : ttrnsfr_client_dat : Insert operation'
			
			raiserror 20015 "Insert operation to ttrnsfr_client_dat failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
					
			RETURN -99
		END

	    COMMIT TRAN update_mcc	
	END
	ELSE
	BEGIN
		/* update */
		BEGIN TRAN update_mcc

		/* now update tmsd_base */
		UPDATE ttrnsfr_client_dat SET record_type_cd = 'MCC',
					action_cd = 'U',
					agent_transfer_nbr = @agent_transfer_nbr,
					clearing_cdcc_cd = @clearing_cdcc_cd,
					elig_rsp_cd = @elig_rsp_cd,
					province_cd = @province_cd,
					day_settle_qty = @day_settle_qty,
					elig_qssp_ind = @elig_qssp_ind,
					elig_isip_ind = @elig_isip_ind,
					process_dt = @process_dt,
					elig_rsp_dt = @elig_rsp_dt,
					prev_elig_rsp_cd = @prev_elig_rsp_cd,
					prev_elig_rsp_dt = @prev_elig_rsp_dt,
					override_rsp_cd = @override_rsp_cd,
					updt_last_tmstp = getdate()		
		WHERE security_adp_nbr = @security_adp_nbr
		
		SELECT @syb_error_code = @@error
		
		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
	    BEGIN
		
			ROLLBACK TRAN update_mcc
		
			select @error_description = 'update_mcc : ttrnsfr_client_dat : Update operation'
			
			raiserror 20016 "Update operation to ttrnsfr_client_dat failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN -99
		
	    END

	    COMMIT TRAN update_mcc
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)

	END
   
END

go

grant execute on update_mcc to fbi
go

IF OBJECT_ID('dbo.update_mcc') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_mcc >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_mcc >>>'
go
