/*
$Header: /rtapp/stp/update_rsg.sql $
$Log: /rtapp/stp/update_rsg.sql $
 * 
 * 
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_rsg') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_rsg
    IF OBJECT_ID('dbo.update_rsg') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_rsg >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_rsg >>>'
END
go

CREATE PROC update_rsg
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@action 	        char(1),
	@mo_cd				char(2),
	@pymnt_ever_alt_ind	char(1)
AS
BEGIN
	

	DECLARE @action_cd char(1),
            @tbl_security_adp_nbr char(7),
            @start_time             datetime,
		    @proc_name              varchar(35),
		    @input_parm             varchar(800),
		    @debug_flag             char(1),
		    @syb_error_code         int ,
		    @custom_error_code      int,
		    @error_description	varchar(150)

			
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @mo_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @action_cd = action_cd
		FROM trrif_pymnt_ever
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			mo_cd = @mo_cd

		IF @@rowcount = 0
		BEGIN
			BEGIN TRAN update_rsg
			
			/* insert, first into realtime table */
			INSERT INTO trrif_pymnt_ever (client_nbr,
					branch_cd,
					account_cd,
					mo_cd,
					pymnt_ever_alt_ind,
					action_cd,
					record_type_cd,
					updt_last_tmstp )
			VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					@mo_cd,
					@pymnt_ever_alt_ind,
					'I',
					'RSG',
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsg
				
				select @error_description = 'update_rsg : trrif_pymnt_ever : Insert operation'
				
				raiserror 20169 "Insert operation to trrif_pymnt_ever failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
	
			COMMIT TRAN update_rsg
		END
		ELSE
		BEGIN
			BEGIN TRAN update_rsg
			
			/*update realtime table row */
			UPDATE trrif_pymnt_ever 
			SET client_nbr = @client_nbr,
				branch_cd = @branch_cd,
				account_cd = @account_cd,
				mo_cd = @mo_cd,
				pymnt_ever_alt_ind = @pymnt_ever_alt_ind,
				action_cd = 'U',
				record_type_cd = 'RSG',
				updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
				mo_cd = @mo_cd
			
			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsg
				
				select @error_description = 'update_rsg : trrif_pymnt_ever : Update operation'
				
				raiserror 20170 "Update operation to trrif_pymnt_ever failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_rsg    
		END
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		BEGIN TRAN update_rsg
		
		/* delete realtime record */	
		DELETE trrif_pymnt_ever 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			mo_cd = @mo_cd

			SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_rsg
			
			select @error_description = 'update_rsg : trrif_pymnt_ever : Delete operation'
			
			raiserror 20171 "Delete operation to trrif_pymnt_ever failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
			    
		COMMIT TRAN update_rsg	    
	END

	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_rsg to fbi
go

IF OBJECT_ID('dbo.update_rsg') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_rsg >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_rsg >>>'
go