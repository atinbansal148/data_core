/*
$Header: /Realtime/Realtime/stp/update_msb.sql 3     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msb.sql $
 * 
 * 3     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 2     6/29/00 5:18p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msb') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msb
    IF OBJECT_ID('dbo.update_msb') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msb >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msb >>>'
END
go

CREATE PROC update_msb
	@security_adp_nbr	char(7),
	@desc_sec_txt		char(30),
	@line_txt_nbr		smallint,
	@language_cd		char(1)

AS
BEGIN
    
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr 	char(7),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)

	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @language_cd + "," + convert(varchar(8),@line_txt_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end
		
	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tsecurity_desc WHERE
		language_cd = @language_cd AND
		line_txt_nbr = @line_txt_nbr AND
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msb
		/* insert */
		INSERT INTO tsecurity_desc (	language_cd,
						line_txt_nbr,
						security_adp_nbr,
						desc_sec_txt,
						record_type_cd,
						action_cd )
		VALUES (	@language_cd,
					@line_txt_nbr,
					@security_adp_nbr,
					@desc_sec_txt,
					'MSB',
					'I' )
					
		SELECT @syb_error_code = @@error

		IF @syb_error_code != 0
		BEGIN
		
			ROLLBACK TRAN update_msb
			
			select @error_description = 'update_msb : tsecurity_desc : Insert operation'
			
			raiserror 20027 "Insert operation to tsecurity_desc failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN  -99
		
		END

		COMMIT TRAN update_msb    
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msb
		/* update */
		
		/* now update real-time table */
		UPDATE tsecurity_desc SET desc_sec_txt = @desc_sec_txt,
							record_type_cd = 'MSB',
							action_cd = 'U'
		WHERE language_cd = @language_cd AND
				line_txt_nbr = @line_txt_nbr AND
				security_adp_nbr = @security_adp_nbr
				
		SELECT @syb_error_code = @@error

		IF @syb_error_code != 0
		BEGIN
		
			ROLLBACK TRAN update_msb
			
			select @error_description = 'update_msb : tsecurity_desc : Update operation'
			
			raiserror 20028 "Update operation to tsecurity_desc failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END

			RETURN  -99
		END
		    
		COMMIT TRAN update_msb	    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
    
END

go

grant execute on update_msb to fbi
go

IF OBJECT_ID('dbo.update_msb') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msb >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msb >>>'
go