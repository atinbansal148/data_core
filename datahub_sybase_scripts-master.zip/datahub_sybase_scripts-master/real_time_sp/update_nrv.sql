/*
$Header: /rtapp/stp/update_nrv.sql 1     3/25/02 10:46a Tbprven $
$Log: /rtapp/stp/update_nrv.sql $
 * 
 * 1     3/25/02 10:46a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrv') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrv
    IF OBJECT_ID('dbo.update_nrv') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrv >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrv >>>'
END
go

CREATE PROC update_nrv
      @client_nbr	char(4)   ,
      @branch_cd char(3)   ,
      @account_cd char(5)   ,
      @rr_cd char(3)  ,
      @action char(1)  ,
      @athrz_nm_seq_nbr smallint    = null ,
      @trading_athry_cd char(1)   = null ,
      @person_nm char(20)   = null ,
      @dscrt_exptn_dt datetime   = null ,
      @dscrt_athry_ind char(1) = null
 AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)	
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@athrz_nm_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tauthorized_person
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
		           athrz_nm_seq_nbr = @athrz_nm_seq_nbr
		           		           
		SELECT @tbl_rowcount = @@rowcount
		
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nrv
					
			/* insert into realtime table */
			INSERT INTO tauthorized_person (client_nbr ,
			      branch_cd ,
			      account_cd ,
			      athrz_nm_seq_nbr ,
			      action  ,
			      record_type_cd ,
			      rr_cd ,
			      trading_athry_cd ,
			      person_nm  ,
			      dscrt_exptn_dt ,
			      dscrt_athry_ind,
				updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd ,
			      @account_cd ,
			      @athrz_nm_seq_nbr ,
			      'I'  ,
			      'NRV' ,
			      @rr_cd ,
			      @trading_athry_cd ,
			      @person_nm  ,
			      @dscrt_exptn_dt ,
			      @dscrt_athry_ind,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrv
				
				select @error_description = 'update_nrv : tauthorized_person : Insert operation'
				
				raiserror 20139 "Insert operation to tauthorized_person failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			COMMIT TRAN update_nrv
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nrv			
			/* update */

			/* now update realtime table row */
			UPDATE tauthorized_person
			SET action = 'U' ,
			      record_type_cd = 'NRV',
			      rr_cd = @rr_cd,
			      trading_athry_cd = @trading_athry_cd,
			      person_nm  = @person_nm,
			      dscrt_exptn_dt = @dscrt_exptn_dt,
			      dscrt_athry_ind = @dscrt_athry_ind,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
		           	athrz_nm_seq_nbr = @athrz_nm_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrv
				
				select @error_description = 'update_nrv : tauthorized_person : Update operation'
				
				raiserror 20140 "Update operation to tauthorized_person failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		        
		    COMMIT TRAN update_nrv
		
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nrv

		/* now delete realtime table row */
		DELETE tauthorized_person
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrv
			
			select @error_description = 'update_nrv : tauthorized_person : Delete operation'
			
			raiserror 20141 "Delete operation to tauthorized_person failed"
			select @custom_error_code=@@error				
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
             
        COMMIT TRAN update_nrv
		
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_nrv to fbi
go

IF OBJECT_ID('dbo.update_nrv') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrv >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrv >>>'
go
