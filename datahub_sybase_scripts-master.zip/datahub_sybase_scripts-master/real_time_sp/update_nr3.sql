/*
$Header: /rtapp/stp/update_nr3.sql 1     3/25/02 10:43a Tbprven $
$Log: /rtapp/stp/update_nr3.sql $
 * 
 * 1     3/25/02 10:43a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nr3') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nr3
    IF OBJECT_ID('dbo.update_nr3') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nr3 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nr3 >>>'
END
go

CREATE PROC update_nr3
       @client_nbr      char(4),
      	 @branch_cd     char(3),
      	 @account_cd    char(5),
      	 @rr_cd          char(3),
      	 @action        char(1),
      	@rec_added_dt   datetime = null ,
      	@rec_changed_dt datetime = null ,
      	@updt_signon_id char(4) = null ,
      	@updt_term_id   char(4) = null ,
      	@waive_fee_chk_cd  char(1) = null ,
      	@fee_b1_chk_ind  char(1) = null ,
      	@status_checking_cd  char(1) = null ,
      	@acct_checking_cd  char(16) = null ,
      	@acct_chck_prev_cd   char(16) = null ,
      	@checking_prim_nm  char(30) = null ,
      	@checking_secnd_nm char(30) = null ,
      	@ownership_chk_cd  char(1) = null ,
      	@close_checking_cd char(1) = null ,
      	@foreign_chk_ind   char(1) = null ,
      	@credit_ln_chk_amt decimal(17,2) = null ,
      	@open_checking_dt  datetime = null ,
      	@close_checking_dt datetime = null ,
      	@approve_chkg_dt   datetime = null ,
      	@reinstate_chkg_dt datetime = null ,
      	@suspend_chk_dt    datetime = null ,
        @aba_cd            char(10) = null ,
      	@check_start_nbr   char(6) = null ,
      	@check_last_ord_nbr char(6) = null ,
      	@check_order_dt     datetime = null ,
      	@style_check_cd    char(1) = null ,
      	@multi_sgnr_chk_ind char(1) = null ,
      	@cover_check_cd     char(1) = null ,
      	@address_check_ind  char(1) = null ,
      	@na_line1_txt       char(35) = null ,
      	@na_line2_txt       char(35) = null ,
      	@na_line3_txt       char(35) = null ,
      	@na_line4_txt       char(35) = null ,
	@na_line5_txt       char(35) = null ,
	@valid_signtr_ind 	char(1) = null ,
	@imaging_dt	datetime = null ,
	@posting_cd	char(1) = null ,
	@ent1_txt char(6) = null ,
	@ent2_txt char(3) = null ,
	@ln_bsns_txt char(3) = null ,
	@occd_txt char(5) = null ,
	@emea_txt char(2) = null ,
	@desk_txt char(30) = null ,
	@portfolio_type_cd char(10) = null ,
	@book_id_txt char(12) = null ,
	@book_nm_txt char(32) = null ,
	@fid_txt char(8) = null ,
	@sfid_txt char(8) = null       
      
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	  
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tbanking_data
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 
			   
		SELECT @tbl_rowcount = @@rowcount
                 
		IF @tbl_rowcount = 0
		BEGIN
			
			BEGIN TRAN update_nr3
			
			/* insert into realtime table */
			INSERT INTO tbanking_data (client_nbr,
					 branch_cd,
					 account_cd,
					 record_type_cd,
					 action        ,
					rr_cd          ,
					rec_added_dt   ,
					rec_changed_dt ,
					updt_signon_id ,
					updt_term_id   ,
					waive_fee_chk_cd  ,
					fee_b1_chk_ind  ,
					status_checking_cd  ,
					acct_checking_cd  ,
					acct_chck_prev_cd   ,
					checking_prim_nm  ,
					checking_secnd_nm ,
					ownership_chk_cd  ,
					close_checking_cd ,
					foreign_chk_ind   ,
					credit_ln_chk_amt ,
					open_checking_dt  ,
					close_checking_dt ,
					approve_chkg_dt   ,
					reinstate_chkg_dt ,
					suspend_chk_dt,
					aba_cd            ,
					check_start_nbr   ,
					check_last_ord_nbr ,
					check_order_dt     ,
					style_check_cd    ,
					multi_sgnr_chk_ind ,
					cover_check_cd    ,
					address_check_ind  ,
					na_line1_txt       ,
					na_line2_txt       ,
					na_line3_txt       ,
					na_line4_txt       ,
					na_line5_txt       ,
					valid_signtr_ind ,
					imaging_dt ,
					posting_cd ,
					ent1_txt  ,
					ent2_txt  ,
					ln_bsns_txt  ,
					occd_txt  ,
					emea_txt  ,
					desk_txt  ,
					portfolio_type_cd  ,
					book_id_txt  ,
					book_nm_txt  ,
					fid_txt  ,
					sfid_txt ,
					updt_last_tmstp)
			       VALUES (@client_nbr,
					 @branch_cd     ,
					 @account_cd    ,
					 'NR3',
					 'I'        ,
					@rr_cd          ,
					@rec_added_dt   ,
					@rec_changed_dt ,
					@updt_signon_id ,
					@updt_term_id   ,
					@waive_fee_chk_cd  ,
					@fee_b1_chk_ind  ,
					@status_checking_cd  ,
					@acct_checking_cd  ,
					@acct_chck_prev_cd   ,
					@checking_prim_nm ,
					@checking_secnd_nm ,
					@ownership_chk_cd  ,
					@close_checking_cd ,
					@foreign_chk_ind   ,
					@credit_ln_chk_amt ,
					@open_checking_dt ,
					@close_checking_dt ,
					@approve_chkg_dt   ,
					@reinstate_chkg_dt ,
					@suspend_chk_dt,
					@aba_cd           ,
					@check_start_nbr  ,
					@check_last_ord_nbr ,
					@check_order_dt     ,
					@style_check_cd    ,
					@multi_sgnr_chk_ind ,
					@cover_check_cd     ,
					@address_check_ind ,
					@na_line1_txt       ,
					@na_line2_txt       ,
					@na_line3_txt       ,
					@na_line4_txt       ,
					@na_line5_txt       ,
					@valid_signtr_ind ,
					@imaging_dt ,
					@posting_cd ,
					@ent1_txt  ,
					@ent2_txt  ,
					@ln_bsns_txt  ,
					@occd_txt  ,
					@emea_txt  ,
					@desk_txt  ,
					@portfolio_type_cd  ,
					@book_id_txt  ,
					@book_nm_txt  ,
					@fid_txt  ,
					@sfid_txt ,
					getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr3
				
				select @error_description = 'update_nr3 : tbanking_data : Insert operation'
				
				raiserror 20088 "Insert operation to tbanking_data failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
                        
            COMMIT TRAN update_nr3
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nr3
			/* update */

			/* now update realtime table row */
			UPDATE tbanking_data
			SET action = 'U',
			      record_type_cd = 'NR3',
			      rr_cd     = @rr_cd     ,
			            	rec_added_dt = @rec_added_dt  ,
			            	rec_changed_dt = @rec_changed_dt ,
			            	updt_signon_id =@updt_signon_id,
			            	updt_term_id  = @updt_term_id ,
			            	waive_fee_chk_cd = @waive_fee_chk_cd ,
			            	fee_b1_chk_ind = @fee_b1_chk_ind ,
			            	status_checking_cd = @status_checking_cd ,
			            	acct_checking_cd = @acct_checking_cd ,
			            	acct_chck_prev_cd = @acct_chck_prev_cd  ,
			            	checking_prim_nm  = @checking_prim_nm,
			            	checking_secnd_nm = @checking_secnd_nm,
			            	ownership_chk_cd = @ownership_chk_cd ,
			            	close_checking_cd = @close_checking_cd,
			            	foreign_chk_ind = @foreign_chk_ind  ,
			            	credit_ln_chk_amt  = @credit_ln_chk_amt,
			            	open_checking_dt  = @open_checking_dt,
			            	close_checking_dt = @close_checking_dt,
			            	approve_chkg_dt  = @approve_chkg_dt ,
			            	reinstate_chkg_dt = @reinstate_chkg_dt,
                                        suspend_chk_dt = @suspend_chk_dt,
			            	aba_cd   = @aba_cd         ,
			            	check_start_nbr  = @check_start_nbr ,
			            	check_last_ord_nbr = @check_last_ord_nbr,
			            	check_order_dt  = @check_order_dt   ,
			            	style_check_cd = @style_check_cd   ,
			            	multi_sgnr_chk_ind = @multi_sgnr_chk_ind,
			            	cover_check_cd = @cover_check_cd   ,
			            	address_check_ind = @address_check_ind ,
			            	na_line1_txt   = @na_line1_txt    ,
			            	na_line2_txt   = @na_line2_txt    ,
			            	na_line3_txt   = @na_line3_txt    ,
			            	na_line4_txt   = @na_line4_txt    ,				
	                        	na_line5_txt   = @na_line5_txt	  ,
					valid_signtr_ind = @valid_signtr_ind,
					imaging_dt = @imaging_dt,
					posting_cd = @posting_cd,
					ent1_txt = @ent1_txt ,
					ent2_txt = @ent2_txt ,
					ln_bsns_txt = @ln_bsns_txt ,
					occd_txt = @occd_txt ,
					emea_txt = @emea_txt ,
					desk_txt = @desk_txt ,
					portfolio_type_cd = @portfolio_type_cd ,
					book_id_txt = @book_id_txt ,
					book_nm_txt = @book_nm_txt ,
					fid_txt = @fid_txt ,
					sfid_txt = @sfid_txt ,
							updt_last_tmstp	   = getdate()			
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd 

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr3
				
				select @error_description = 'update_nr3 : tbanking_data : Update operation'
				
				raiserror 20089 "Update operation to tbanking_data failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
               
            COMMIT TRAN update_nr3
                
		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nr3

		/* now delete realtime table row */
		DELETE tbanking_data
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nr3
			
			select @error_description = 'update_nr3 : tbanking_data : Delete operation'
			
			raiserror 20090 "Delete operation to tbanking_data failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nr3
	END
 
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
 
END

go

grant execute on update_nr3 to fbi
go

IF OBJECT_ID('dbo.update_nr3') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nr3 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nr3 >>>'
go
