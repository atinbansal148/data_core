/*
$Header: /rtapp/stp/update_naa.sql 1     3/25/02 10:39a Tbprven $
$Log: /rtapp/stp/update_naa.sql $
 * 
 * 1     3/25/02 10:39a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_naa') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_naa
    IF OBJECT_ID('dbo.update_naa') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_naa >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_naa >>>'
END
go

CREATE PROC update_naa
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@rr_cd                          char(3),
	@action 	          	char(1),
	@record_seq_nbr			smallint = null ,
	@csfund_aex_nbr			char(3) = null ,		
	@zip4_cd			char(4) = null ,
	@zip5_cd			char(5) = null ,
	@city_state_aex_txt		char(20) = null ,
	@street_aex_txt			char(20) = null ,
	@ttl_optnl_aex_txt		char(20) = null ,
	@title_aex_txt			char(20) = null ,
	@acct_reinstated_dt		datetime = null ,
	@account_on_hold_dt		datetime = null ,
	@account_suspend_cd		char(1) = null ,
	@acm_cd				char(2) = null ,
	@account_changed_dt		datetime = null ,
	@account_opened_dt		datetime = null ,
	@account_prvdt_cd		char(10) = null ,
	@account_aex_cd			char(15) = null ,
	@record_changed_dt		datetime = null ,
	@record_added_dt		datetime = null ,
	@print_trid_cd 			char(1) = null,
	@emboss_cd			char(1) = null,
	@change_address_ind		char(1) = null,
	@cancel_card_cd			char(2) = null
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
	
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@record_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end
 

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM taccount_amex
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			record_seq_nbr = @record_seq_nbr
			
		SELECT @tbl_rowcount = @@rowcount	
		
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_naa

			/* now insert into realtime table */
			INSERT INTO taccount_amex (record_seq_nbr,
			                account_cd,
			                branch_cd,	
					client_nbr,
					csfund_aex_nbr	  ,	
					zip4_cd			  ,	
					zip5_cd			  ,	
					city_state_aex_txt,	
					street_aex_txt	  ,	
					ttl_optnl_aex_txt ,	
					title_aex_txt	  ,	
					acct_reinstated_dt,	
					account_on_hold_dt,	
					account_suspend_cd,	
					acm_cd			  ,	
					account_changed_dt,	
					account_opened_dt ,	
					account_prvdt_cd  ,	
					account_aex_cd	  ,	
					record_changed_dt ,	
					record_added_dt	  ,	
					record_type_cd    ,
					action,
					rr_cd,
					print_trid_cd,
					emboss_cd,
					change_address_ind,
					cancel_card_cd,
					updt_last_tmstp )
			VALUES (@record_seq_nbr    ,	
			                @account_cd		   ,
			                @branch_cd		   ,	
			                @client_nbr		   ,
					@csfund_aex_nbr	   ,	
					@zip4_cd		   ,	
					@zip5_cd		   ,	
					@city_state_aex_txt,	
					@street_aex_txt	   ,	
					@ttl_optnl_aex_txt ,	
					@title_aex_txt	   ,	
					@acct_reinstated_dt,	
					@account_on_hold_dt,	
					@account_suspend_cd,	
					@acm_cd			   ,	
					@account_changed_dt,	
					@account_opened_dt ,	
					@account_prvdt_cd  ,	
					@account_aex_cd	   ,	
					@record_changed_dt ,	
					@record_added_dt   ,
					'NAA',
					'I',
					@rr_cd,	
					@print_trid_cd,
					@emboss_cd,
					@change_address_ind,
					@cancel_card_cd,
					getdate() )
					
			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */

			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_naa
				
				select @error_description = 'update_naa : taccount_amex : Insert operation'
				
				raiserror 20049 "Insert operation to taccount_amex failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
 
			COMMIT TRAN update_naa
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_naa			
			/* update */

			/* now update realtime table row */
			UPDATE taccount_amex 
			SET     csfund_aex_nbr	   = @csfund_aex_nbr ,	
				zip4_cd			   = @zip4_cd ,	
				zip5_cd			   = @zip5_cd ,	
				city_state_aex_txt = @city_state_aex_txt ,	
				street_aex_txt	   = @street_aex_txt ,	
				ttl_optnl_aex_txt  = @ttl_optnl_aex_txt ,	
				title_aex_txt	   = @title_aex_txt ,	
				acct_reinstated_dt = @acct_reinstated_dt ,	
				account_on_hold_dt = @account_on_hold_dt ,	
				account_suspend_cd = @account_suspend_cd ,	
				acm_cd			   = @acm_cd ,	
				account_changed_dt = @account_changed_dt ,	
				account_opened_dt  = @account_opened_dt ,	
				account_prvdt_cd   = @account_prvdt_cd ,	
				account_aex_cd	   = @account_aex_cd ,	
				record_changed_dt  = @record_changed_dt ,	
				record_added_dt	   = @record_added_dt ,	
				record_type_cd     = 'NAA',
				action		   = 'U',
				rr_cd		   = @rr_cd ,
				print_trid_cd	   = @print_trid_cd,
				emboss_cd	   = @emboss_cd,
				change_address_ind = @change_address_ind,
				cancel_card_cd     = @cancel_card_cd,
				updt_last_tmstp	   = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
				record_seq_nbr = @record_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_naa
				
				select @error_description = 'update_naa : taccount_amex : Update operation'
				
				raiserror 20050 "Update operation to taccount_amex failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_naa    
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_naa
		
		/* now delete realtime table row */
		DELETE taccount_amex 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_naa
			
			select @error_description = 'update_naa : taccount_amex : Delete operation'
			
			raiserror 20051 "Delete operation to taccount_amex failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
   
		COMMIT TRAN update_naa		    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_naa to fbi
go

go
IF OBJECT_ID('dbo.update_naa') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_naa >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_naa >>>'
go
