/*****************************************************************************
NAME: add_hist2tr.sql
PURPOSE: Insert and update hist2 trade tables
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	87896	10/5/12	Judy Shen	Add the full 25 byte trans_control_id field
	86760	10/6/12	Judy Shen	Add STREET CONTROL NUMBER to ths2_ps_sale_tran
1.1	92235	3/21/12	Judy Shen	Add MSRB_CONTROL_NBR to ths2_ps_sale_tran
1.2		7/1/13	Judy Shen	Align indexes for better performance
1.3	89575	9/25/13	Judy Shen	Add mnr_clr_sym_txt and mnr_exctg_brkr_cd
					to ths2_splt_brkr; can be up to 20 occurrances
1.4	90694	12/3/13	J.Shen		Add client_order_id and execution_id to ths2_ps_sale_tran
1.5	104952	5/25/15	J.Shen		Add additional GPF Fields to ths2_ps_sale_tran
1.6	108981	11/4/15	J.Shen		Add a new field leaves_quantity to ths2_ps_sale_tran
	109084	11/4/15	J.Shen		Add a new field option_open_code to ths2_ps_sale_tran
1.7	112174	5/25/16	J.Shen		Add a new field utc_trade_tmstp to ths2_ps_sale_tran
1.8	3857222	7/26/17	J.Shen		Add a new field dns_station_nbr to ths2_sale_fee
1.9	3668986	2/26/18	J.Shen		Add 2 new fields dol_ind and prte_ind to ths2_ps_sale_tran
2.0	4035600	2/27/18	J.Shen		Add a new field sdi_ind to ths2_ps_sale_tran
2.1	3999401 5/24/18	J.Shen		Add 3 new fields pmp_amt, non_ins_ind, pmp_step_ind to ths2_ps_sale_tran
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.add_hist2tr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.add_hist2tr
    IF OBJECT_ID('dbo.add_hist2tr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.add_hist2tr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.add_hist2tr >>>'
END
go

CREATE PROC add_hist2tr	
			@account_cd	char(5),
			@branch_cd char(3),
			@chck_brch_acct_nbr char(1),
			@client_nbr	char(4),
			@currency_cd char(3),
			@debit_credit_cd char(1),
			@security_adp_nbr char(7),
			@trans_acct_hist_cd char(1),
			@transaction_dt	datetime,
			@type_account_cd	char(1),
			@processing_dt	datetime,
			@action_cd	char(1),
			@prc_sec_amt decimal(16,8),
			@blttr_mrkt_cd char(1),
			@blttr_cpcty_cd char(1),
			@rr_cd char(3),
			@int_accrd_bond_amt decimal(17,2),
			@pstg_chrg_amt decimal(11,2),
			@desc_add_prnt_cd char(2),
			@broker_exec_cd char(5),
			@frst_mny_amt decimal(17,2),
			@branch_prft_ctr_cd char(3),
			@cusip_nbr char(8),
			@share_trans_qty decimal(17,5),
			@spcl_prcs_cd char(2),
			@currency_trd_cd char(3),
			@cdg_cusip_cd char(1),
			@cusip_extend_nbr char(3),
			@issue_when_ind char(1),
			@trailer2_cd char(2),
			@trailer3_cd char(2),
			@cncl_cmmsn_trd_cd char(1),
			@ggrph_lctn_cd char(3),
			@tran_total_amt decimal(17,2),
			@rfrn_id char(14),
			@ticker_symbol_cd char(12),
			@client_use_txt char(20),
			@trade_tmstp_txt char(19),
			@dtc_actvty_cd char(3),
			@acct_splmtl_cd char(11),
			@fee_type_cd1 char(3),
			@fee_type_cd2 char(3),
			@fee_type_cd3 char(3),
			@fee_type_cd4 char(3),
			@fee_type_cd5 char(3),
			@fee_type_cd6 char(3),
			@fee_type_cd7 char(3),
			@fee_type_cd8 char(3),
			@fee_type_cd9 char(3),
			@fee_type_cd10 char(3),
			@fee_type_cd11 char(3),
			@fee_type_cd12 char(3),
			@fee_type_cd13 char(3),
			@fee_type_cd14 char(3),
			@fee_type_cd15 char(3),
			@fee_type_cd16 char(3),
			@fee_type_cd17 char(3),
			@fee_type_cd18 char(3),
			@fee_type_cd19 char(3),
			@fee_type_cd20 char(3),
			@fee_amt1 decimal(13,2),
			@fee_amt2 decimal(13,2),
			@fee_amt3 decimal(13,2),
			@fee_amt4 decimal(13,2),
			@fee_amt5 decimal(13,2),
			@fee_amt6 decimal(13,2),
			@fee_amt7 decimal(13,2),
			@fee_amt8 decimal(13,2),
			@fee_amt9 decimal(13,2),
			@fee_amt10 decimal(13,2),
			@fee_amt11 decimal(13,2),
			@fee_amt12 decimal(13,2),
			@fee_amt13 decimal(13,2),
			@fee_amt14 decimal(13,2),
			@fee_amt15 decimal(13,2),
			@fee_amt16 decimal(13,2),
			@fee_amt17 decimal(13,2),
			@fee_amt18 decimal(13,2),
			@fee_amt19 decimal(13,2),
			@fee_amt20 decimal(13,2),
			@broker_split_cd1 char(5) = null,
			@mnr_clr_sym_txt1 char(5) = null,
			@mnr_exctg_brkr_cd1 char(5) = null,
			@broker_split_cd2 char(5) = null,
			@mnr_clr_sym_txt2 char(5) = null,
			@mnr_exctg_brkr_cd2 char(5) = null,
			@broker_split_cd3 char(5) = null,
			@mnr_clr_sym_txt3 char(5) = null,
			@mnr_exctg_brkr_cd3 char(5) = null,
			@broker_split_cd4 char(5) = null,
			@mnr_clr_sym_txt4 char(5) = null,
			@mnr_exctg_brkr_cd4 char(5) = null,
			@broker_split_cd5 char(5) = null,
			@mnr_clr_sym_txt5 char(5) = null,
			@mnr_exctg_brkr_cd5 char(5) = null,
			@broker_split_cd6 char(5) = null,
			@mnr_clr_sym_txt6 char(5) = null,
			@mnr_exctg_brkr_cd6 char(5) = null,
			@broker_split_cd7 char(5) = null,
			@mnr_clr_sym_txt7 char(5) = null,
			@mnr_exctg_brkr_cd7 char(5) = null,
			@broker_split_cd8 char(5) = null,
			@mnr_clr_sym_txt8 char(5) = null,
			@mnr_exctg_brkr_cd8 char(5) = null,
			@broker_split_cd9 char(5) = null,
			@mnr_clr_sym_txt9 char(5) = null,
			@mnr_exctg_brkr_cd9 char(5) = null,
			@broker_split_cd10 char(5) = null,
			@mnr_clr_sym_txt10 char(5) = null,
			@mnr_exctg_brkr_cd10 char(5) = null,
			@broker_split_cd11 char(5) = null,
			@mnr_clr_sym_txt11 char(5) = null,
			@mnr_exctg_brkr_cd11 char(5) = null,
			@broker_split_cd12 char(5) = null,
			@mnr_clr_sym_txt12 char(5) = null,
			@mnr_exctg_brkr_cd12 char(5) = null,
			@broker_split_cd13 char(5) = null,
			@mnr_clr_sym_txt13 char(5) = null,
			@mnr_exctg_brkr_cd13 char(5) = null,
			@broker_split_cd14 char(5) = null,
			@mnr_clr_sym_txt14 char(5) = null,
			@mnr_exctg_brkr_cd14 char(5) = null,
			@broker_split_cd15 char(5) = null,
			@mnr_clr_sym_txt15 char(5) = null,
			@mnr_exctg_brkr_cd15 char(5) = null,
			@broker_split_cd16 char(5) = null,
			@mnr_clr_sym_txt16 char(5) = null,
			@mnr_exctg_brkr_cd16 char(5) = null,
			@broker_split_cd17 char(5) = null,
			@mnr_clr_sym_txt17 char(5) = null,
			@mnr_exctg_brkr_cd17 char(5) = null,
			@broker_split_cd18 char(5) = null,
			@mnr_clr_sym_txt18 char(5) = null,
			@mnr_exctg_brkr_cd18 char(5) = null,
			@broker_split_cd19 char(5) = null,
			@mnr_clr_sym_txt19 char(5) = null,
			@mnr_exctg_brkr_cd19 char(5) = null,
			@broker_split_cd20 char(5) = null,
			@mnr_clr_sym_txt20 char(5) = null,
			@mnr_exctg_brkr_cd20 char(5) = null,
			@srce_trans_cd char(8) = null,
			@trailer4_cd char(2)  = null,
			@trailer5_cd char(2)  = null,
			@crrn_cvrsn_rt decimal(15,8) = null,
			@trailer6_cd char(2) = null,
			@trailer7_cd char(2) = null,
			@trailer8_cd char(2) = null,
			@trailer9_cd char(2) = null,
			@trailer10_cd char(2) = null,
			@ctgy_cd char(5) = null,
			@yield_pct decimal(11,7) = null,
 			@yield_type_cd char(1) = null,
			@tle_misc_txt char(20) = null,
			@exp_trd_ordr_nbr char(32) = null,
			@rttm_str_cntl_nbr char(20) = null,
			@trans_control_id char(25) = null,
			@msrb_control_nbr char(20) = null,
			@client_order_id char(23) = null,
			@execution_id char(23) = null,
                        @option_open_code char(1) = null,
                        @leaves_quantity decimal(17,5) = null,
                        @utc_trade_tmstp char(20) = null,
                        @dns_station_nbr char(3) = null,
                        @dol_ind char(1) = null,
                        @prte_ind char(1) = null,
                        @sdi_ind char(1) = null,
                        @pmp_amt decimal(16,8) = null,
			@non_ins_ind char(1) = null,
			@pmp_step_ind char(2) = null,
			@tables_for_master_process char(50) = null
												
AS
BEGIN    

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
    DECLARE @trans_hist_seq_nbr int,
	        @rec_type_cd char(3),
	        @counter int,
	        @param1  char(3),
	        @param2  decimal(13,2),
	        @param3  char(5),
	        @param4  char(5),
	        @param5  char(5),
	        @seq_nbr smallint,
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description	varchar(150)
			
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
						
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @chck_brch_acct_nbr + "," + @currency_cd + "," + @debit_credit_cd + "," + @security_adp_nbr + "," + @trans_acct_hist_cd + "," + convert(char(30),@transaction_dt,116) + "," + @type_account_cd + "," + convert(char(30),@processing_dt,116)
		select @error_description = ''
		select @custom_error_code = 0
	end

	select @rec_type_cd = 'H2R'

	/* find next sequence number to use */
	/* needs to verify the search condition to find the next sequence number to use */
	SELECT @trans_hist_seq_nbr = MAX(trans_hist_seq_nbr) 
	FROM ths2_ps_sale_tran 
	WHERE
			client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			chck_brch_acct_nbr = @chck_brch_acct_nbr AND
			currency_cd = @currency_cd AND
			debit_credit_cd = @debit_credit_cd AND
			security_adp_nbr = @security_adp_nbr AND
			trans_acct_hist_cd = @trans_acct_hist_cd AND
			transaction_dt = @transaction_dt AND
			type_account_cd = @type_account_cd AND
			processing_dt = @processing_dt

	SELECT @trans_hist_seq_nbr = ISNULL(@trans_hist_seq_nbr,0)

	SELECT @trans_hist_seq_nbr = @trans_hist_seq_nbr + 1	

	BEGIN TRANSACTION add_hist2tr 

		/* add row to ths2_ps_sale_tran*/	     
		INSERT INTO ths2_ps_sale_tran (account_cd,
					branch_cd,
					chck_brch_acct_nbr,
					client_nbr,
					currency_cd,
					debit_credit_cd,
					trans_hist_seq_nbr,
					security_adp_nbr,
					trans_acct_hist_cd,
					transaction_dt,
					type_account_cd,
					processing_dt,
					action_cd,
					rec_type_cd,
					prc_sec_amt,
					blttr_mrkt_cd,
					blttr_cpcty_cd,
					rr_cd,
					int_accrd_bond_amt,
					pstg_chrg_amt,
					desc_add_prnt_cd,
					broker_exec_cd,
					frst_mny_amt,
					branch_prft_ctr_cd,
					cusip_nbr,
					share_trans_qty,
					spcl_prcs_cd,
					currency_trd_cd,
					cdg_cusip_cd,
					cusip_extend_nbr,
					issue_when_ind,
					trailer2_cd,
					trailer3_cd,
					cncl_cmmsn_trd_cd,
					ggrph_lctn_cd,
					tran_total_amt,
					rfrn_id,
					ticker_symbol_cd,
					client_use_txt,
					trade_tmstp_txt,
					dtc_actvty_cd,
					acct_splmtl_cd,
					srce_trans_cd,
					trailer4_cd,
					trailer5_cd,
					crrn_cvrsn_rt,
					trailer6_cd,
					trailer7_cd,
					trailer8_cd,
					trailer9_cd,
					trailer10_cd,
					ctgy_cd,
					yield_pct,
 					yield_type_cd,
					tle_misc_txt,
					exp_trd_ordr_nbr,
					rttm_str_cntl_nbr,
					trans_control_id,
					msrb_control_nbr,
					client_order_id,
					execution_id,
					option_open_code,
					leaves_quantity,
					utc_trade_tmstp,
					dol_ind ,
					prte_ind ,
					sdi_ind ,
					pmp_amt,
					non_ins_ind,
					pmp_step_ind,
					updt_last_tmstp)
				VALUES (@account_cd,
					@branch_cd,
					@chck_brch_acct_nbr,
					@client_nbr,
					@currency_cd,
					@debit_credit_cd,
					@trans_hist_seq_nbr,
					@security_adp_nbr,
					@trans_acct_hist_cd,
					@transaction_dt,
					@type_account_cd,
					@processing_dt,
					@action_cd,
					@rec_type_cd,
					@prc_sec_amt,
					@blttr_mrkt_cd,
					@blttr_cpcty_cd,
					@rr_cd,
					@int_accrd_bond_amt,
					@pstg_chrg_amt,
					@desc_add_prnt_cd,
					@broker_exec_cd,
					@frst_mny_amt,
					@branch_prft_ctr_cd,
					@cusip_nbr,
					@share_trans_qty,
					@spcl_prcs_cd,
					@currency_trd_cd,
					@cdg_cusip_cd,
					@cusip_extend_nbr,
					@issue_when_ind,
					@trailer2_cd,
					@trailer3_cd,
					@cncl_cmmsn_trd_cd,
					@ggrph_lctn_cd,
					@tran_total_amt,
					@rfrn_id,
					@ticker_symbol_cd,
					@client_use_txt,
					@trade_tmstp_txt,
					@dtc_actvty_cd,
					@acct_splmtl_cd,
					@srce_trans_cd,
					@trailer4_cd,
					@trailer5_cd,
					@crrn_cvrsn_rt,
					@trailer6_cd,
					@trailer7_cd,
					@trailer8_cd,
					@trailer9_cd,
					@trailer10_cd,
					@ctgy_cd,
					@yield_pct,
 					@yield_type_cd,
					@tle_misc_txt,
					@exp_trd_ordr_nbr,
					@rttm_str_cntl_nbr,
					@trans_control_id,
					@msrb_control_nbr,
					@client_order_id,
					@execution_id,
					@option_open_code,
					@leaves_quantity,
					@utc_trade_tmstp,
					@dol_ind ,
					@prte_ind ,
					@sdi_ind ,
					@pmp_amt,
					@non_ins_ind,
					@pmp_step_ind,
					getdate())

		SELECT @syb_error_code = @@error
					
		if @syb_error_code != 0
	    BEGIN
		     
			ROLLBACK TRAN add_hist2tr
			 
			select @error_description = 'add_hist2tr : ths2_ps_sale_tran : Insert operation'
			
			raiserror 20183 "Insert operation to ths2_ps_sale_tran failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			 
		    RETURN -99
			 
	    END			

    COMMIT TRANSACTION add_hist2tr

	/* check if need to add to H2C */
	select @counter = 1 
           
	while @counter <= 20
	begin
		  
		if (@counter = 1) 
		begin
			select @param1 = @fee_type_cd1
			select @param2 = @fee_amt1
		end
		else if (@counter = 2) 
		begin
			select @param1 = @fee_type_cd2
			select @param2 = @fee_amt2
		end
		else if (@counter = 3) 
		begin
			select @param1 = @fee_type_cd3
			select @param2 = @fee_amt3
		end
		else if (@counter = 4) 
		begin
			select @param1 = @fee_type_cd4
			select @param2 = @fee_amt4
		end
		else if (@counter = 5) 
		begin
			select @param1 = @fee_type_cd5
			select @param2 = @fee_amt5
		end 
		else if (@counter = 6) 
		begin
			select @param1 = @fee_type_cd6
			select @param2 = @fee_amt6
		end
		 else if (@counter = 7) 
		  begin
		   select @param1 = @fee_type_cd7
		   select @param2 = @fee_amt7
		  end
		 else if (@counter = 8) 
		  begin
		   select @param1 = @fee_type_cd8
		   select @param2 = @fee_amt8
		  end
		 else if (@counter = 9) 
		  begin
		   select @param1 = @fee_type_cd9
		   select @param2 = @fee_amt9
		  end
		 else if (@counter = 10) 
		  begin
		   select @param1 = @fee_type_cd10
		   select @param2 = @fee_amt10
		  end
		 else if (@counter = 11) 
		  begin
		   select @param1 = @fee_type_cd11
		   select @param2 = @fee_amt11
		  end
		 else if (@counter = 12) 
		  begin
		   select @param1 = @fee_type_cd12
		   select @param2 = @fee_amt12
		  end
		 else if (@counter = 13) 
		  begin
		   select @param1 = @fee_type_cd13
		   select @param2 = @fee_amt13
		  end
		 else if (@counter = 14) 
		  begin
		   select @param1 = @fee_type_cd14
		   select @param2 = @fee_amt14
		  end
		 else if (@counter = 15) 
		  begin
		   select @param1 = @fee_type_cd15
		   select @param2 = @fee_amt15
		  end
		 else if (@counter = 16) 
		  begin
		   select @param1 = @fee_type_cd16
		   select @param2 = @fee_amt16
		  end
		 else if (@counter = 17) 
		  begin
		   select @param1 = @fee_type_cd17
		   select @param2 = @fee_amt17
		  end
		 else if (@counter = 18) 
		  begin
		   select @param1 = @fee_type_cd18
		   select @param2 = @fee_amt18
		  end
		 else if (@counter = 19) 
		  begin
		   select @param1 = @fee_type_cd19
		   select @param2 = @fee_amt19
		  end
		 else if (@counter = 20) 
		  begin
		   select @param1 = @fee_type_cd20
		   select @param2 = @fee_amt20
		  end
		else 
		begin
			select @param1 = null
			select @param2 = null
		end
                    
		if @param1 IS NOT NULL	       			
		BEGIN
			BEGIN TRANSACTION add_hist2tr
	       				
			select @rec_type_cd = 'H2R'
							
			/* add row to ths2_sale_fee*/	       
			INSERT INTO ths2_sale_fee (account_cd,
					branch_cd,
					chck_brch_acct_nbr,
					client_nbr,
					currency_cd,
					debit_credit_cd,
					trans_hist_seq_nbr,
					security_adp_nbr,
					trans_acct_hist_cd,
					transaction_dt,
					type_account_cd,
					processing_dt,
					fee_type_cd,
					action_cd,
					rec_type_cd,
					rr_cd,
					fee_amt,
					trans_control_id,
					dns_station_nbr,
					updt_last_tmstp)
			VALUES (@account_cd,
					@branch_cd,
					@chck_brch_acct_nbr,
					@client_nbr,
					@currency_cd,
					@debit_credit_cd,
					@trans_hist_seq_nbr,
					@security_adp_nbr,
					@trans_acct_hist_cd,
					@transaction_dt,
					@type_account_cd,
					@processing_dt,
					@param1,
					@action_cd,
					@rec_type_cd,
					@rr_cd,
					@param2,
					@trans_control_id,
					@dns_station_nbr,
					getdate())
			
			SELECT @syb_error_code = @@error
			
			if @syb_error_code != 0
			BEGIN
				
				ROLLBACK TRAN add_hist2tr
				
				select @error_description = 'add_hist2tr : ths2_sale_fee : Insert operation'
				
				raiserror 20184 "Insert operation to ths2_sale_fee failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				
				RETURN -99
				
			END		

			COMMIT TRANSACTION add_hist2tr	       			
		
		END /* end of adding to H2C */			
        
		select  @counter = @counter + 1 
             
    end /* end of while loop */     
         
    /* check if need to add to H2D */
    select  @counter = 1 
		
	while @counter <= 20
	begin
	       
		     if @counter = 1 
			begin
		       select  @param3 = @broker_split_cd1
		       select  @param4 = @mnr_clr_sym_txt1
		       select  @param5 = @mnr_exctg_brkr_cd1
			end
		     else if @counter = 2 
			begin
		       select  @param3 = @broker_split_cd2
		       select  @param4 = @mnr_clr_sym_txt2
		       select  @param5 = @mnr_exctg_brkr_cd2
			end
		     else if @counter = 3 
			begin
		       select  @param3 = @broker_split_cd3
		       select  @param4 = @mnr_clr_sym_txt3
		       select  @param5 = @mnr_exctg_brkr_cd3
			end
		     else if @counter = 4 
			begin
		       select  @param3 = @broker_split_cd4
		       select  @param4 = @mnr_clr_sym_txt4
		       select  @param5 = @mnr_exctg_brkr_cd4
			end
		     else if @counter = 5 
			begin
		       select  @param3 = @broker_split_cd5
		       select  @param4 = @mnr_clr_sym_txt5
		       select  @param5 = @mnr_exctg_brkr_cd5
			end
		     else if @counter = 6 
			begin
		       select  @param3 = @broker_split_cd6
		       select  @param4 = @mnr_clr_sym_txt6
		       select  @param5 = @mnr_exctg_brkr_cd6
			end
		     else if @counter = 7 
			begin
		       select  @param3 = @broker_split_cd7
		       select  @param4 = @mnr_clr_sym_txt7
		       select  @param5 = @mnr_exctg_brkr_cd7
			end
		     else if @counter = 8 
			begin
		       select  @param3 = @broker_split_cd8
		       select  @param4 = @mnr_clr_sym_txt8
		       select  @param5 = @mnr_exctg_brkr_cd8
			end
		     else if @counter = 9 
			begin
		       select  @param3 = @broker_split_cd9
		       select  @param4 = @mnr_clr_sym_txt9
		       select  @param5 = @mnr_exctg_brkr_cd9
			end
		     else if @counter = 10 
			begin
		       select  @param3 = @broker_split_cd10
		       select  @param4 = @mnr_clr_sym_txt10
		       select  @param5 = @mnr_exctg_brkr_cd10
			end
		     else if @counter = 11 
			begin
		       select  @param3 = @broker_split_cd11
		       select  @param4 = @mnr_clr_sym_txt11
		       select  @param5 = @mnr_exctg_brkr_cd11
			end
		     else if @counter = 12 
			begin
		       select  @param3 = @broker_split_cd12
		       select  @param4 = @mnr_clr_sym_txt12
		       select  @param5 = @mnr_exctg_brkr_cd12
			end
		     else if @counter = 13 
			begin
		       select  @param3 = @broker_split_cd13
		       select  @param4 = @mnr_clr_sym_txt13
		       select  @param5 = @mnr_exctg_brkr_cd13
			end
		     else if @counter = 14 
			begin
		       select  @param3 = @broker_split_cd14
		       select  @param4 = @mnr_clr_sym_txt14
		       select  @param5 = @mnr_exctg_brkr_cd14
			end
		     else if @counter = 15 
			begin
		       select  @param3 = @broker_split_cd15
		       select  @param4 = @mnr_clr_sym_txt15
		       select  @param5 = @mnr_exctg_brkr_cd15
			end
		     else if @counter = 16 
			begin
		       select  @param3 = @broker_split_cd16
		       select  @param4 = @mnr_clr_sym_txt16
		       select  @param5 = @mnr_exctg_brkr_cd16
			end
		     else if @counter = 17 
			begin
		       select  @param3 = @broker_split_cd17
		       select  @param4 = @mnr_clr_sym_txt17
		       select  @param5 = @mnr_exctg_brkr_cd17
			end
		     else if @counter = 18 
			begin
		       select  @param3 = @broker_split_cd18
		       select  @param4 = @mnr_clr_sym_txt18
		       select  @param5 = @mnr_exctg_brkr_cd18
			end
		     else if @counter = 19 
			begin
		       select  @param3 = @broker_split_cd19
		       select  @param4 = @mnr_clr_sym_txt19
		       select  @param5 = @mnr_exctg_brkr_cd19
			end
		     else if @counter = 20
			begin
		       select  @param3 = @broker_split_cd20
		       select  @param4 = @mnr_clr_sym_txt20
		       select  @param5 = @mnr_exctg_brkr_cd20
			end
		     else
			begin
		       select  @param3 = null
		       select  @param4 = null
		       select  @param5 = null
			end		
	       				       
		if @param3 is NOT NULL OR @param4 is NOT NULL OR @param5 is NOT NULL
		BEGIN
			select @rec_type_cd = 'H2R'

			/* find next sequence number to use */
			/* needs to verify the search condition to find the next sequence number to use */
			SELECT @seq_nbr = MAX(splt_brkr_seq_nbr) FROM ths2_splt_brkr WHERE
				client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
				chck_brch_acct_nbr = @chck_brch_acct_nbr AND
				currency_cd = @currency_cd AND
				debit_credit_cd = @debit_credit_cd AND
				trans_hist_seq_nbr = @trans_hist_seq_nbr AND
				security_adp_nbr = @security_adp_nbr AND
				trans_acct_hist_cd = @trans_acct_hist_cd AND
				transaction_dt = @transaction_dt AND
				type_account_cd = @type_account_cd AND
				processing_dt = @processing_dt
	
			SELECT @seq_nbr = ISNULL(@seq_nbr,0)
	
			SELECT @seq_nbr = @seq_nbr + 1	
	
			BEGIN TRANSACTION add_hist2tr

			/* add row to ths2_splt_brkr*/
	
			INSERT INTO ths2_splt_brkr (account_cd,
						branch_cd,
						chck_brch_acct_nbr,
						client_nbr,
						currency_cd,
						debit_credit_cd,
						trans_hist_seq_nbr,
						security_adp_nbr,
						trans_acct_hist_cd,
						transaction_dt,
						type_account_cd,
						processing_dt,
						splt_brkr_seq_nbr,
						action_cd,
						rec_type_cd,
						rr_cd,
						broker_split_cd,
						trans_control_id,
						mnr_clr_sym_txt,
						mnr_exctg_brkr_cd,
						updt_last_tmstp)
				VALUES (@account_cd,
						@branch_cd,
						@chck_brch_acct_nbr,
						@client_nbr,
						@currency_cd,
						@debit_credit_cd,
						@trans_hist_seq_nbr,
						@security_adp_nbr,
						@trans_acct_hist_cd,
						@transaction_dt,
						@type_account_cd,
						@processing_dt,
						@seq_nbr,
						@action_cd,
						@rec_type_cd,
						@rr_cd,
						@param3,
						@trans_control_id,
						@param4,
						@param5,
						getdate())
				
			SELECT @syb_error_code = @@error
			
			if @syb_error_code != 0
			BEGIN
			
					ROLLBACK TRAN add_hist2tr
			
					select @error_description = 'add_hist2tr : ths2_splt_brkr : Insert operation'
					
					raiserror 20185 "Insert operation to ths2_splt_brkr failed"
					select @custom_error_code=@@error
					
					IF (@debug_flag="Y")
					BEGIN
						INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
					END
			
					RETURN -99
					
			END	
					           	
			COMMIT TRANSACTION add_hist2tr        

	    END /* end of the adding to h2d*/			
		      
		select  @counter = @counter + 1

    end  /* end of while loop */

	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END		
		
END

go

grant execute on add_hist2tr to fbi
go

IF OBJECT_ID('dbo.add_hist2tr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.add_hist2tr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.add_hist2tr >>>'
go
