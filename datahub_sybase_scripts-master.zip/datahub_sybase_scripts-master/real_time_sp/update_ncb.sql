/*
$Header: /rtapp/stp/update_ncb.sql 1     01/14/03 10:41a Tbprven $
$Log: /rtapp/stp/update_ncb.sql $
 * 
 * 1     01/14/03 11:15a Tbprven
 * Canadian Name and Address Category
 * 
 * 1     01/14/03 11:15a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_ncb') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_ncb
    IF OBJECT_ID('dbo.update_ncb') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_ncb >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_ncb >>>'
END
go

CREATE PROC update_ncb
					@client_nbr			char(4),
					@branch_cd			char(3),
					@account_cd			char(5),
					@action	         	        char(1),
					@stmt_freq_cd                    char(1) = null,               
					@stmt_fscl_mo_dy_cd              char(4) = null,     
					@prod_type_cd                    char(2) = null,
					@srvc_type_cd               char(2) = null,               
					@fee_cmmsn_cd               char(2) = null,              
					@pro_stts_cd                char(2) = null,               
					@acct_stts_cd               char(2) = null,                 
					@pldg_acct_cd               char(2) = null,                 
					@crdtr_prf_cd               char(2) = null,                 
					@prc_dscrt_disc_cd          char(2) = null,                 
					@fee_rltsh_cd               char(2) = null,                 
					@rfrl_type_cd               char(2) = null,                 
                                        @dvsn_cd                    char(2) = null,
					@formal_agreement           char(1) = null,                 
					@line_of_business           char(2) = null,                 
        				@prod_cd                    char(3) = null
					
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN

		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM tcan_stmt_prod
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd 
			
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN

			BEGIN TRAN update_ncb
			
			/* insert into realtime table */
			INSERT INTO tcan_stmt_prod (client_nbr,
					branch_cd,
					account_cd,
					action_cd,
					record_type_cd,
					stmt_freq_cd,               
					stmt_fscl_mo_dy_cd,     
					prod_type_cd,
					srvc_type_cd,               
					fee_cmmsn_cd,              
					pro_stts_cd,               
					acct_stts_cd,                 
					pldg_acct_cd,                 
					crdtr_prf_cd,                 
					prc_dscrt_disc_cd,                 
					fee_rltsh_cd,                 
					rfrl_type_cd,
					dvsn_cd,
					formal_agreement,                 
					line_of_business,                 
        				prod_cd,
					updt_last_tmstp)
				VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					'I',
					'NCB',
					@stmt_freq_cd,               
					@stmt_fscl_mo_dy_cd,     
					@prod_type_cd,
					@srvc_type_cd,               
					@fee_cmmsn_cd,              
					@pro_stts_cd,               
					@acct_stts_cd,                 
					@pldg_acct_cd,                 
					@crdtr_prf_cd,                 
					@prc_dscrt_disc_cd,                 
					@fee_rltsh_cd,                 
					@rfrl_type_cd,
					@dvsn_cd,
					@formal_agreement,                 
					@line_of_business,                 
        				@prod_cd,
					getdate())

			SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_ncb
				
				select @error_description = 'update_ncb : tcan_stmt_prod : Insert operation'
				
				raiserror 20022 "Insert operation to tcan_stmt_prod failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			COMMIT TRAN update_ncb
		END
		ELSE
		BEGIN
			BEGIN TRAN update_ncb
			
			/* update */
			
			/* now update realtime table row */
			UPDATE tcan_stmt_prod 
			SET     record_type_cd = 'NCB',
				action_cd= 'U',
				stmt_freq_cd = @stmt_freq_cd,               
				stmt_fscl_mo_dy_cd = @stmt_fscl_mo_dy_cd,     
				prod_type_cd = @prod_type_cd,
				srvc_type_cd = @srvc_type_cd,               
				fee_cmmsn_cd = @fee_cmmsn_cd,              
				pro_stts_cd = @pro_stts_cd,               
				acct_stts_cd = @acct_stts_cd,                 
				pldg_acct_cd = @pldg_acct_cd,                 
				crdtr_prf_cd = @crdtr_prf_cd,                 
				prc_dscrt_disc_cd = @prc_dscrt_disc_cd,                 
				fee_rltsh_cd = @fee_rltsh_cd,                 
				rfrl_type_cd = @rfrl_type_cd,
				dvsn_cd      = @dvsn_cd,
				formal_agreement = @formal_agreement,                 
				line_of_business = @line_of_business,                 
        			prod_cd = @prod_cd,
				updt_last_tmstp	= getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd  

			SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_ncb
				
				select @error_description = 'update_ncb : tcan_stmt_prod : Update operation'
				
				raiserror 20023 "Update operation to tcan_stmt_prod failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			   
			COMMIT TRAN update_ncb   
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_ncb

		/* now delete realtime table row */
		DELETE tcan_stmt_prod 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd 


		SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_ncb
			
			select @error_description = 'update_ncb : tcan_stmt_prod : Delete operation'
			
			raiserror 20023 "Delete operation to tcan_stmt_prod failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
	COMMIT TRAN update_ncb
	
	END
   
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_ncb to fbi
go

IF OBJECT_ID('dbo.update_ncb') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_ncb >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_ncb >>>'
go