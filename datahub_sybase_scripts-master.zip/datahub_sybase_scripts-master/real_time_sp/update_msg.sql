/*
$Header: /Realtime/Realtime/stp/update_msg.sql 5     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msg.sql $
 * 
 * 5     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 4     6/29/00 5:20p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msg') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msg
    IF OBJECT_ID('dbo.update_msg') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msg >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msg >>>'
END
go

CREATE PROC update_msg
	@security_adp_nbr		char(7),
	@periodic_cd			char,
	@factor_rt				decimal(12,10),
	@factor_dt				datetime

AS
BEGIN
  
	DECLARE @action_cd char(1),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
		
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @periodic_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	
	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	
	SELECT @action_cd = action_cd
	FROM tfactor_rate WHERE
		security_adp_nbr = @security_adp_nbr
		AND periodic_cd = @periodic_cd

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msg
		
		/* insert */
		INSERT INTO tfactor_rate (	security_adp_nbr,
						periodic_cd,
						factor_rt,
						factor_dt,
						rec_type_cd,
						action_cd )
		VALUES (	@security_adp_nbr,
					@periodic_cd,
					@factor_rt,
					@factor_dt,
					'MSG',
					'I' )
					
		SELECT @syb_error_code = @@error

		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msg
			
			select @error_description = 'update_msg : tfactor_rate : Insert operation'
			
			raiserror 20037 "Insert operation to tfactor_rate failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
	
		COMMIT TRAN update_msg
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msg
		/* update */

		/* now update real-time table */
		UPDATE tfactor_rate SET
			periodic_cd = @periodic_cd, 
			factor_rt = @factor_rt,
			factor_dt = @factor_dt,
			rec_type_cd = 'MSG',
			action_cd = 'U'
		WHERE security_adp_nbr = @security_adp_nbr
			AND periodic_cd = @periodic_cd
			
		SELECT @syb_error_code = @@error
		
		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msg
			
			select @error_description = 'update_msg : tfactor_rate : Update operation'
			
			raiserror 20038 "Update operation to tfactor_rate failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_msg

	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_msg to fbi
go

IF OBJECT_ID('dbo.update_msg') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msg >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msg >>>'
go