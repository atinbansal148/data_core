/*
$Header: /rtapp/stp/update_nr5.sql 1     3/25/02 10:44a Tbprven $
$Log: /rtapp/stp/update_nr5.sql $
 * 
 * 1     3/25/02 10:44a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nr5') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nr5
    IF OBJECT_ID('dbo.update_nr5') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nr5 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nr5 >>>'
END
go

CREATE PROC update_nr5
        @client_nbr  char(4),
       	@branch_cd  char(3),
       	@account_cd  char(5),
       	@rr_cd  char(3),
       	@action   char,
       	@seq_nbr  smallint = null ,
       	@stmt_val1_cd  char(1) = null ,
       	@stmt_val2_cd  char(2) = null
	 
      
      
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)	
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacct_statement_cd
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and 
			   seq_nbr = @seq_nbr
			   
		SELECT @tbl_rowcount = @@rowcount
                
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nr5
			
			/* insert into realtime table */
			INSERT INTO tacct_statement_cd (client_nbr ,
				 branch_cd ,
				 account_cd ,
				 seq_nbr ,
				 record_type_cd,
				 action   ,
				 stmt_val1_cd  ,
				 stmt_val2_cd  ,
				 rr_cd  ,
				updt_last_tmstp)
			VALUES (@client_nbr ,
				 @branch_cd ,
				 @account_cd ,
				 @seq_nbr ,
				 'NR5',
				 'I'   ,
				 @stmt_val1_cd  ,
				 @stmt_val2_cd  ,
				 @rr_cd  ,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr5
				
				select @error_description = 'update_nr5 : tacct_statement_cd : Insert operation'
				
				raiserror 20094 "Insert operation to tacct_statement_cd failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
            COMMIT TRAN update_nr5
			
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nr5			
			/* update */
				
			/* now update realtime table row */
			UPDATE tacct_statement_cd
			SET record_type_cd = 'NR5',
       	                    action = 'U'  ,
       	                    stmt_val1_cd = @stmt_val1_cd ,
       	                    stmt_val2_cd = @stmt_val2_cd ,
							rr_cd = @rr_cd ,
							updt_last_tmstp	= getdate()			
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and 
			        seq_nbr = @seq_nbr 

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr5
				
				select @error_description = 'update_nr5 : tacct_statement_cd : Update operation'			
				
				raiserror 20095 "Update operation to tacct_statement_cd failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
			COMMIT TRAN update_nr5

		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nr5
		
		/* now delete realtime table row */
		DELETE tacct_statement_cd
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nr5
			
			select @error_description = 'update_nr5 : tacct_statement_cd : Delete operation'
			
			raiserror 20096 "Delete operation to tacct_statement_cd failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nr5
	END
 
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
 
END

go

grant execute on update_nr5 to fbi
go

IF OBJECT_ID('dbo.update_nr5') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nr5 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nr5 >>>'
go
