/*
$Header: /rtapp/stp/update_nr4.sql 1     3/25/02 10:43a Tbprven $
$Log: /rtapp/stp/update_nr4.sql $
 * 
 * 1     3/25/02 10:43a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nr4') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nr4
    IF OBJECT_ID('dbo.update_nr4') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nr4 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nr4 >>>'
END
go

CREATE PROC update_nr4
       	@client_nbr   char(4),
       	@branch_cd  char(3),
       	@account_cd  char(5),
       	@rr_cd  char(3),
       	@action   char(1),
       	@seq_nbr  smallint = null ,
       	@type_card_cd   char(1) = null ,
       	@db_cr_card_cd  char(1) = null ,
       	@status_card_cd char(1) = null ,
       	@card_nbr  char(16) = null ,
       	@card_prev1_nbr  char(16) = null ,
       	@card_prev2_nbr  char(16) = null ,
       	@card_prim_nm  char(30) = null ,
       	@card_scnd_nm  char(30) = null ,
       	@card_closed_cd char(1) = null ,
       	@cr_lmt_card_amt  decimal(17,2) = null ,
        @card_qty  smallint = null ,
       	@open_card_dt  datetime = null ,
       	@close_card_dt  datetime = null ,
       	@approve_card_dt  datetime = null ,
       	@reinstate_card_dt  datetime = null ,
       	@suspend_card_dt  datetime = null ,
	@expire_card_dt  datetime  = null
      
      
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	DECLARE @db_action_cd char(1)
        DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end
        
	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tcard_data
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   seq_nbr = @seq_nbr
			   
                SELECT @tbl_rowcount = @@rowcount
                        
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nr4
			
			/* insert into realtime table */
			INSERT INTO tcard_data (client_nbr,
					 branch_cd,
					 account_cd,
					 seq_nbr,
					 record_type_cd,
					 action,
					 rr_cd,
					 type_card_cd,
					 db_cr_card_cd,
					 status_card_cd,
					 card_nbr,
					 card_prev1_nbr,
					 card_prev2_nbr,
					 card_prim_nm,
					 card_scnd_nm,
					 card_closed_cd,
					 cr_lmt_card_amt,
					 card_qty,
					 open_card_dt,
					 close_card_dt,
					 approve_card_dt,
					 reinstate_card_dt,
					 suspend_card_dt,
					 expire_card_dt,
					 updt_last_tmstp)
			VALUES (@client_nbr,
				 @branch_cd,
				 @account_cd,
				 @seq_nbr,
				 'NR4',
				 'I',
				 @rr_cd,
				 @type_card_cd,
				 @db_cr_card_cd,
				 @status_card_cd,
				 @card_nbr,
				 @card_prev1_nbr,
				 @card_prev2_nbr,
				 @card_prim_nm,
				 @card_scnd_nm,
				 @card_closed_cd,
				 @cr_lmt_card_amt,
				 @card_qty,
				 @open_card_dt,
				 @close_card_dt,
				 @approve_card_dt,
				 @reinstate_card_dt,
				 @suspend_card_dt,
				 @expire_card_dt,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr4
				
				select @error_description = 'update_nr4 : tcard_data : Insert operation'
				
				raiserror 20091 "Insert operation to tcard_data failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nr4
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nr4			
			/* update */

			/* now update realtime table row */
			UPDATE tcard_data
			SET record_type_cd ='NR4',
				 action = 'U',
				 rr_cd = @rr_cd,
				 type_card_cd = @type_card_cd,
				 db_cr_card_cd = @db_cr_card_cd,
				 status_card_cd = @status_card_cd,
				 card_nbr = @card_nbr,
				 card_prev1_nbr = @card_prev1_nbr,
				 card_prev2_nbr = @card_prev2_nbr,
				 card_prim_nm = @card_prim_nm,
				 card_scnd_nm = @card_scnd_nm,
				 card_closed_cd = @card_closed_cd,
				 cr_lmt_card_amt = @cr_lmt_card_amt,
				 card_qty = @card_qty,
				 open_card_dt = @open_card_dt,
				 close_card_dt = @close_card_dt,
				 approve_card_dt = @approve_card_dt,
				 reinstate_card_dt = @reinstate_card_dt,
				 suspend_card_dt = @suspend_card_dt,
				 expire_card_dt = @expire_card_dt,
				 updt_last_tmstp	   = getdate()			
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd  and
			        seq_nbr =    @seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr4
				
				select @error_description = 'update_nr4 : tcard_data : Update operation'
				
				raiserror 20092 "Update operation to tcard_data failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
			COMMIT TRAN update_nr4

		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nr4
		
		/* now delete realtime table row */
		DELETE tcard_data
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nr4
			
			select @error_description = 'update_nr4 : tcard_data : Delete operation'
			
			raiserror 20093 "Delete operation to tcard_data failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nr4
	END
 
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nr4 to fbi
go

IF OBJECT_ID('dbo.update_nr4') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nr4 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nr4 >>>'
go
