/*
$Header: /rtapp/stp/update_nrw.sql 1     3/25/02 10:47a Tbprven $
$Log: /rtapp/stp/update_nrw.sql $
 * 
 * 1     3/25/02 10:47a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrw') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrw
    IF OBJECT_ID('dbo.update_nrw') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrw >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrw >>>'
END
go

CREATE PROC update_nrw
      @client_nbr	char(4)  ,
      @branch_cd char(3)  ,
      @account_cd char(5)  ,
      @rr_cd char(3)  ,
      @action char(1)  ,
      @ap_seq_nbr smallint   = null ,
      @addr_seq_nbr smallint   = null ,
      @mailing_addrs_ind char(1)   = null ,
      @legal_addrs_ind char(1)   = null ,
      @apartment_nbr char(5)   = null ,
      @city_nm char(29)   = null ,
      @state_cd char(2)   = null ,
      @zip5_cd char(5)   = null ,
      @zip4_cd char(4)   = null ,
      @zip3_cd char(3)   = null ,
      @postal6_canada_cd char(6)   = null ,
      @postal4_canada_cd char(4)   = null ,
      @zip_foreign_cd char(10)   = null ,
      @street_nm char(30)   = null ,
      @alc_cd char(3)   = null ,
      @geo_cd char(3)   = null ,
      @country_foreign_nm char(20) = null
 AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@ap_seq_nbr) + "," + convert(varchar(8),@addr_seq_nbr) 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
				
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacc_party_address
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   ap_seq_nbr = @ap_seq_nbr and
			   addr_seq_nbr = @addr_seq_nbr
			 
        SELECT @tbl_rowcount = @@rowcount
                                			 
		IF @tbl_rowcount = 0
		BEGIN
                        
            BEGIN TRAN update_nrw
           
			/* insert into realtime table */
			INSERT INTO tacc_party_address (client_nbr  ,
			      branch_cd ,
			      account_cd ,
			      ap_seq_nbr ,
			      addr_seq_nbr ,
			      action ,
			      record_type_cd ,
			      rr_cd  ,
			      mailing_addrs_ind ,
			      legal_addrs_ind ,
			      apartment_nbr ,
			      city_nm ,
			      state_cd ,
			      zip5_cd ,
			      zip4_cd ,
			      zip3_cd ,
			      postal6_canada_cd ,
			      postal4_canada_cd ,
			      zip_foreign_cd  ,
			      street_nm ,
			      alc_cd ,
			      geo_cd ,
			      country_foreign_nm,
				updt_last_tmstp)
			VALUES (@client_nbr  ,
			      @branch_cd ,
			      @account_cd ,
			      @ap_seq_nbr ,
			      @addr_seq_nbr ,
			      'I' ,
			      'NRW' ,
			      @rr_cd  ,
			      @mailing_addrs_ind ,
			      @legal_addrs_ind ,
			      @apartment_nbr ,
			      @city_nm ,
			      @state_cd ,
			      @zip5_cd ,
			      @zip4_cd ,
			      @zip3_cd ,
			      @postal6_canada_cd ,
			      @postal4_canada_cd ,
			      @zip_foreign_cd  ,
			      @street_nm ,
			      @alc_cd ,
			      @geo_cd ,
			      @country_foreign_nm,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrw
				
				select @error_description = 'update_nrw : tacc_party_address : Insert operation'
				
				raiserror 20142 "Insert operation to tacc_party_address failed"
				select @custom_error_code=@@error
							
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nrw	
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nrw			
			/* update */

			/* now update realtime table row */
			UPDATE tacc_party_address
			SET action = 'U',
			      record_type_cd = 'NRW',
			      rr_cd = @rr_cd ,
			      mailing_addrs_ind = @mailing_addrs_ind,
			      legal_addrs_ind = @legal_addrs_ind,
			      apartment_nbr = @apartment_nbr,
			      city_nm = @city_nm,
			      state_cd = @state_cd ,
			      zip5_cd = @zip5_cd,
			      zip4_cd = @zip4_cd,
			      zip3_cd = @zip3_cd,
			      postal6_canada_cd = @postal6_canada_cd,
			      postal4_canada_cd = @postal4_canada_cd,
			      zip_foreign_cd = @zip_foreign_cd  ,
			      street_nm = @street_nm,
			      alc_cd = @alc_cd,
			      geo_cd = @geo_cd,
			      country_foreign_nm = @country_foreign_nm,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
				ap_seq_nbr = @ap_seq_nbr and
				addr_seq_nbr = @addr_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrw
				
				select @error_description = 'update_nrw : tacc_party_address : Update operation'
				
				raiserror 20143 "Update operation to tacc_party_address failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
			COMMIT TRAN update_nrw	

		END		
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		/*SELECT @db_action_cd = action
		FROM tacc_party_address
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   action IN ('A','C')
					 
                SELECT @tbl_rowcount = @@rowcount*/
				
		BEGIN TRAN update_nrw
		
		/* now delete realtime table row */
		DELETE tacc_party_address
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrw
			
			select @error_description = 'update_nrw : tacc_party_address : Delete operation'
			
			raiserror 20144 "Delete operation to tacc_party_address failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
			
	    COMMIT TRAN update_nrw	
		
	END
  
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nrw to fbi
go

IF OBJECT_ID('dbo.update_nrw') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrw >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrw >>>'
go
