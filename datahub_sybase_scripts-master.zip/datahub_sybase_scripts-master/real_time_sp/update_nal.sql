/*
$Header: /rtapp/stp/update_nal.sql 1     3/25/02 10:41a Tbprven $
$Log: /rtapp/stp/update_nal.sql $
 * 
 * 1     3/25/02 10:41a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nal') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nal
    IF OBJECT_ID('dbo.update_nal') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nal >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nal >>>'
END
go

CREATE PROC update_nal
	@client_nbr				char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@rr_cd				char(3),
	@action		          	char(1),
	@prvdt_rcrd_add_dt		datetime = null ,
	@prvdt_rcrd_chng_dt		datetime = null ,
	@account_prvdt_cd		char(9) = null ,
	@acct_prvdt_cdg_cd		char(1) = null ,
	@acct_prvdt_opnd_dt		datetime = null ,
	@acct_prvdt_clsd_dt		datetime = null ,
	@acct_prvdt_rsn_cd		char(1) = null ,
	@account_rnstt_ind		char(1) = null ,
	@acct_type_prvdt_cd		char(1) = null ,
	@product_prvdt_cd		char(1) = null ,
	@check_stl_prvdt_cd		char(1) = null ,
	@signers_prvdt_ind		char(1) = null ,
	@check_cvr_prvdt_cd		char(1) = null ,
	@address_prvdt_ind		char(1) = null ,
	@cr_line_prvdt_amt		decimal(10,2) = null ,
	@na_ln_1_prvdt_txt		char(30) = null ,
	@na_ln_2_prvdt_txt		char(30) = null ,
	@na_ln_3_prvdt_txt		char(30) = null ,
	@na_ln_4_prvdt_txt		char(30) = null ,
	@na_ln_5_prvdt_txt		char(30) = null ,
	@zip5_cd			char(5) = null ,
	@zip4_cd			char(4) = null ,
	@acct_foreign_ind		char(1) = null ,
	@phn_prvdt_bsns_txt		char(10) = null ,
	@phn_prvdt_home_txt		char(10) = null ,
	@brch_prvdt_old_cd		char(3) = null ,
	@acct_prvdt_old_cd		char(5) = null ,
	@acm_prvdt_old_cd		char(1) = null ,
	@csfund_prvdt_nbr		char(3) = null ,
	@print_trid_cd			char(1) = null,
	@waive_fee_ind			char(1) = null,
	@reduce_fee_ind 		char(1) = null,
	@update_source_cd		char(1) = null,
	@status_chck_cd			char(1) = null,
	@approve_chk_dt			datetime = null,
	@close_chk_dt			datetime = null,
	@rnstt_debit_dt			datetime = null,
	@closed_debit_dt		datetime = null,
	@approve_debit_dt		datetime = null,
	@status_debit_cd		char(1) = null,
	@exptn_debit_dt			datetime = null,
	@card_debit_1_qty		smallint = null,
	@card_debit_2_qty		smallint = null,
	@ach_ind			char(1) = null,
	@rnstt_chk_dt			datetime = null,
	@debit_card_cd			char(16) = null,
	@branch_swing_to_cd		char(3) = null,
	@acct_swing_to_cd		char(5) = null,
	@chking_ind			char(1) = null
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM taccount_prv_bank
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd
			
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
	
			BEGIN TRAN update_nal
                       
			/* now insert into realtime table */
			INSERT INTO taccount_prv_bank (client_nbr  ,
				branch_cd          ,
				account_cd         ,
				prvdt_rcrd_add_dt  ,
				prvdt_rcrd_chng_dt ,
				account_prvdt_cd   ,
				acct_prvdt_cdg_cd  ,
				acct_prvdt_opnd_dt ,
				acct_prvdt_clsd_dt ,
				acct_prvdt_rsn_cd  ,
				account_rnstt_ind  ,
				acct_type_prvdt_cd ,
				product_prvdt_cd   ,
				check_stl_prvdt_cd ,
				signers_prvdt_ind  ,
				check_cvr_prvdt_cd ,
				address_prvdt_ind  ,
				cr_line_prvdt_amt  ,
				na_ln_1_prvdt_txt  ,
				na_ln_2_prvdt_txt  ,
				na_ln_3_prvdt_txt  ,
				na_ln_4_prvdt_txt  ,
				na_ln_5_prvdt_txt  ,
				zip5_cd			   ,
				zip4_cd			   ,
				acct_foreign_ind   ,
				phn_prvdt_bsns_txt ,
				phn_prvdt_home_txt ,
				brch_prvdt_old_cd   ,
				acct_prvdt_old_cd   ,
				acm_prvdt_old_cd   ,
				csfund_prvdt_nbr   ,
				record_type_cd,
				action		,
				rr_cd              ,
				print_trid_cd	,
				waive_fee_ind	,
				reduce_fee_ind 	,
				update_source_cd,
				status_chck_cd	,
				approve_chk_dt	,
				close_chk_dt	,
				rnstt_debit_dt	,
				closed_debit_dt	,
				approve_debit_dt,
				status_debit_cd	,
				exptn_debit_dt	,
				card_debit_1_qty,
				card_debit_2_qty,
				ach_ind		,
				rnstt_chk_dt	,
				debit_card_cd	,
				branch_swing_to_cd,
				acct_swing_to_cd,
				chking_ind,
				updt_last_tmstp)
			VALUES (@client_nbr         ,
				@branch_cd          ,
				@account_cd         ,
				@prvdt_rcrd_add_dt  ,
				@prvdt_rcrd_chng_dt ,
				@account_prvdt_cd   ,
				@acct_prvdt_cdg_cd  ,
				@acct_prvdt_opnd_dt ,
				@acct_prvdt_clsd_dt ,
				@acct_prvdt_rsn_cd  ,
				@account_rnstt_ind  ,
				@acct_type_prvdt_cd ,
				@product_prvdt_cd   ,
				@check_stl_prvdt_cd ,
				@signers_prvdt_ind  ,
				@check_cvr_prvdt_cd ,
				@address_prvdt_ind  ,
				@cr_line_prvdt_amt  ,
				@na_ln_1_prvdt_txt  ,
				@na_ln_2_prvdt_txt  ,
				@na_ln_3_prvdt_txt  ,
				@na_ln_4_prvdt_txt  ,
				@na_ln_5_prvdt_txt  ,
				@zip5_cd			,
				@zip4_cd			,
				@acct_foreign_ind   ,
				@phn_prvdt_bsns_txt ,
				@phn_prvdt_home_txt ,
				@brch_prvdt_old_cd   ,
				@acct_prvdt_old_cd   ,
				@acm_prvdt_old_cd   ,
				@csfund_prvdt_nbr   ,
				'NAL'               ,
				'I'			,
				@rr_cd              ,
				@print_trid_cd		,
				@waive_fee_ind	,
				@reduce_fee_ind 	,
				@update_source_cd	,
				@status_chck_cd		,
				@approve_chk_dt		,
				@close_chk_dt		,
				@rnstt_debit_dt		,
				@closed_debit_dt	,
				@approve_debit_dt	,
				@status_debit_cd	,
				@exptn_debit_dt		,
				@card_debit_1_qty	,
				@card_debit_2_qty	,
				@ach_ind		,
				@rnstt_chk_dt		,
				@debit_card_cd		,
				@branch_swing_to_cd	,
				@acct_swing_to_cd	,
				@chking_ind		,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nal
				
				select @error_description = 'update_nal : taccount_prv_bank : Insert operation'
				
				raiserror 20070 "Insert operation to taccount_prv_bank failed"
				select @custom_error_code=@@error
								
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
		    COMMIT TRAN update_nal
			
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nal			
			/* update */
				
			/* now update realtime table row */
			UPDATE taccount_prv_bank 
			SET     prvdt_rcrd_add_dt  = @prvdt_rcrd_add_dt,
				prvdt_rcrd_chng_dt = @prvdt_rcrd_chng_dt,
				account_prvdt_cd   = @account_prvdt_cd,
				acct_prvdt_cdg_cd  = @acct_prvdt_cdg_cd,
				acct_prvdt_opnd_dt = @acct_prvdt_opnd_dt,
				acct_prvdt_clsd_dt = @acct_prvdt_clsd_dt,
				acct_prvdt_rsn_cd  = @acct_prvdt_rsn_cd,
				account_rnstt_ind  = @account_rnstt_ind,
				acct_type_prvdt_cd = @acct_type_prvdt_cd,
				product_prvdt_cd   = @product_prvdt_cd,
				check_stl_prvdt_cd = @check_stl_prvdt_cd,
				signers_prvdt_ind  = @signers_prvdt_ind,
				check_cvr_prvdt_cd = @check_cvr_prvdt_cd,
				address_prvdt_ind  = @address_prvdt_ind,
				cr_line_prvdt_amt  = @cr_line_prvdt_amt,
				na_ln_1_prvdt_txt  = @na_ln_1_prvdt_txt,
				na_ln_2_prvdt_txt  = @na_ln_2_prvdt_txt,
				na_ln_3_prvdt_txt  = @na_ln_3_prvdt_txt,
				na_ln_4_prvdt_txt  = @na_ln_4_prvdt_txt,
				na_ln_5_prvdt_txt  = @na_ln_5_prvdt_txt,
				zip5_cd			   = @zip5_cd,
				zip4_cd			   = @zip4_cd,
				acct_foreign_ind   = @acct_foreign_ind,
				phn_prvdt_bsns_txt = @phn_prvdt_bsns_txt,
				phn_prvdt_home_txt = @phn_prvdt_home_txt,
				brch_prvdt_old_cd  = @brch_prvdt_old_cd,
				acct_prvdt_old_cd  = @acct_prvdt_old_cd,
				acm_prvdt_old_cd   = @acm_prvdt_old_cd,
				csfund_prvdt_nbr   = @csfund_prvdt_nbr,
				record_type_cd	   = 'NAL',
				action			= 'I',
				rr_cd              = @rr_cd,
				print_trid_cd	= @print_trid_cd,
				waive_fee_ind	= @waive_fee_ind,
				reduce_fee_ind 	= @reduce_fee_ind,
				update_source_cd = @update_source_cd,
				status_chck_cd	= @status_chck_cd,
				approve_chk_dt	= @approve_chk_dt,
				close_chk_dt	= @close_chk_dt,
				rnstt_debit_dt	= @rnstt_debit_dt,
				closed_debit_dt	= @closed_debit_dt,
				approve_debit_dt = @approve_debit_dt,
				status_debit_cd	= @status_debit_cd,
				exptn_debit_dt	= @exptn_debit_dt,
				card_debit_1_qty = @card_debit_1_qty,
				card_debit_2_qty = @card_debit_2_qty,
				ach_ind	= @ach_ind,
				rnstt_chk_dt = @rnstt_chk_dt,
				debit_card_cd	= @debit_card_cd,
				branch_swing_to_cd	= @branch_swing_to_cd,
				acct_swing_to_cd = @acct_swing_to_cd,
				chking_ind = @chking_ind,
				updt_last_tmstp	= getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nal
				
				select @error_description = 'update_nal : taccount_prv_bank : Update operation'
				
				raiserror 20071 "Update operation to taccount_prv_bank failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nal
		
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nal

		/* now delete realtime table row */
		DELETE taccount_prv_bank 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nal
			
			select @error_description = 'update_nal : taccount_prv_bank : Delete operation'
			
			raiserror 20072 "Delete operation to taccount_prv_bank failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END

		COMMIT TRAN update_nal
	
	END
  
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_nal to fbi
go

IF OBJECT_ID('dbo.update_nal') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nal >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nal >>>'
go
