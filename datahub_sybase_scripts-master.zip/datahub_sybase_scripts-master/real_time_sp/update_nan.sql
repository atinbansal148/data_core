/*****************************************************************************
NAME: update_nan.sql
PURPOSE: Insert and update TACCOUNT_YR_END table
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	98582	3/19/14	Judy Shen	add 10 new fields
1.1	102043	7/24/14	J.Shen		add 2 new fields
1.2	102043	7/24/14	J.Shen		add 2 new fields
1.3	108505	12/30/15J.Shen		Added 1 new field nra_reig_wthld_rt
1.4	3458587	2/3/17	J.Shen		add 2 new fields nra_stk_wh_rt_exp & nra_bnd_wh_rt_exp	
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nan') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nan
    IF OBJECT_ID('dbo.update_nan') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nan >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nan >>>'
END
go

CREATE PROC update_nan
			@client_nbr				char(4),
			@branch_cd				char(3),
			@account_cd				char(5),
			@rr_cd					char(3),
			@action		          	char(1),
			@mailing_address_cd		char(3) = null ,
			@last_nm				char(30) = null ,
			@zip4_cd				char(4) = null ,
			@zip5_cd				char(5) = null ,
			@na_ln_1_yrend_txt		char(30) = null ,
			@na_ln_2_yrend_txt		char(30) = null ,
			@na_ln_3_yrend_txt		char(30) = null ,
			@na_ln_4_yrend_txt		char(30) = null ,
			@na_ln_5_yrend_txt		char(30) = null ,
			@na_ln_6_yrend_txt		char(30) = null,
			@stmnt_last_dt                datetime = null,
			@fatca_wthld_cd 		char(1) = null,
			@nra_1042s_stts_cd 		char(2) = null,
			@fatca_1042s_sts_cd 		char(2) = null,	
			@fatca_giin_nbr 		char(19) = null,
			@nra_rylty_wthld_rt 		decimal(7,5) = null,
			@nra_reit_wthld_rt 		decimal(7,5) = null,
			@fatca_hldr_type_cd 		char(4) = null,
			@fatca_hldr_styp_cd 		char(4) = null,
			@frgn_tax_id 			char(17) = null,
			@nra_mlp_wthld_rt		decimal(7,5) = null,
			@nra_stk_wthld_rt		decimal(3,1) = null,
			@nra_bnd_wthld_rt		decimal(3,1) = null,
			@nra_reig_wthld_rt		decimal(7,5) = null,
			@nra_stk_wh_rt_exp		decimal(7,5) = null,
			@nra_bnd_wh_rt_exp		decimal(7,5) = null
AS
BEGIN
    
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM taccount_yr_end
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd
			
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nan
			
			/* insert into realtime table */
			INSERT INTO taccount_yr_end (client_nbr	  ,
						branch_cd		  ,
						account_cd		  ,
						mailing_address_cd, 
						last_nm			  , 
						zip4_cd			  , 
						zip5_cd			  , 
						na_ln_1_yrend_txt , 
						na_ln_2_yrend_txt , 
						na_ln_3_yrend_txt , 
						na_ln_4_yrend_txt , 
						na_ln_5_yrend_txt , 
						na_ln_6_yrend_txt ,
						record_type_cd	  ,
						action,
						rr_cd			  ,
						stmnt_last_dt,
						fatca_wthld_cd,
						nra_1042s_stts_cd,											
						fatca_1042s_sts_cd,	
						fatca_giin_nbr,
						nra_rylty_wthld_rt,
						nra_reit_wthld_rt,
						fatca_hldr_type_cd,
						fatca_hldr_styp_cd,
						frgn_tax_id,
						nra_mlp_wthld_rt,
						nra_stk_wthld_rt,
						nra_bnd_wthld_rt,
						nra_reig_wthld_rt,
						nra_stk_wh_rt_exp,
						nra_bnd_wh_rt_exp,
						updt_last_tmstp)  
				VALUES (@client_nbr		   ,
					@branch_cd		   ,
					@account_cd		   ,
					@mailing_address_cd,
					@last_nm		   ,
					@zip4_cd		   ,
					@zip5_cd		   ,
					@na_ln_1_yrend_txt ,
					@na_ln_2_yrend_txt ,
					@na_ln_3_yrend_txt ,
					@na_ln_4_yrend_txt ,
					@na_ln_5_yrend_txt ,
					@na_ln_6_yrend_txt ,
					'NAN'			   ,
					'I',
					@rr_cd			   ,
					@stmnt_last_dt,
					@fatca_wthld_cd,
					@nra_1042s_stts_cd,
					@fatca_1042s_sts_cd,	
					@fatca_giin_nbr,
					@nra_rylty_wthld_rt,
					@nra_reit_wthld_rt,
					@fatca_hldr_type_cd,
					@fatca_hldr_styp_cd,
					@frgn_tax_id,
					@nra_mlp_wthld_rt,
					@nra_stk_wthld_rt,
					@nra_bnd_wthld_rt,
					@nra_reig_wthld_rt,
					@nra_stk_wh_rt_exp,
					@nra_bnd_wh_rt_exp,
					getdate()) 

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nan
				
				select @error_description = 'update_nan : taccount_yr_end : Insert operation'
				
				raiserror 20076 "Insert operation to taccount_yr_end failed"
				select @custom_error_code=@@error
								
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			COMMIT TRAN update_nan
			
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nan			
			/* update */

			/* now update realtime table row */
			UPDATE taccount_yr_end 
			SET     mailing_address_cd = @mailing_address_cd, 
				last_nm			   = @last_nm, 
				zip4_cd			   = @zip4_cd, 
				zip5_cd			   = @zip5_cd, 
				na_ln_1_yrend_txt  = @na_ln_1_yrend_txt, 
				na_ln_2_yrend_txt  = @na_ln_2_yrend_txt, 
				na_ln_3_yrend_txt  = @na_ln_3_yrend_txt, 
				na_ln_4_yrend_txt  = @na_ln_4_yrend_txt, 
				na_ln_5_yrend_txt  = @na_ln_5_yrend_txt, 
				na_ln_6_yrend_txt  = @na_ln_6_yrend_txt,
				record_type_cd	   = 'NAN',
				action  		   = 'U',
				rr_cd              = @rr_cd ,
				stmnt_last_dt    = @stmnt_last_dt,
				fatca_wthld_cd = @fatca_wthld_cd,
				nra_1042s_stts_cd = @nra_1042s_stts_cd,
				fatca_1042s_sts_cd = @fatca_1042s_sts_cd,	
				fatca_giin_nbr = @fatca_giin_nbr,
				nra_rylty_wthld_rt = @nra_rylty_wthld_rt,
				nra_reit_wthld_rt = @nra_reit_wthld_rt,
				fatca_hldr_type_cd = @fatca_hldr_type_cd,
				fatca_hldr_styp_cd = @fatca_hldr_styp_cd,
				frgn_tax_id = @frgn_tax_id,
				nra_mlp_wthld_rt = @nra_mlp_wthld_rt,
				nra_stk_wthld_rt = @nra_stk_wthld_rt,
				nra_bnd_wthld_rt = @nra_bnd_wthld_rt,
				nra_reig_wthld_rt = @nra_reig_wthld_rt,
				nra_stk_wh_rt_exp = @nra_stk_wh_rt_exp,
				nra_bnd_wh_rt_exp = @nra_bnd_wh_rt_exp,
				updt_last_tmstp	   = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nan
				
				select @error_description = 'update_nan : taccount_yr_end : Update operation'
				
				raiserror 20077 "Update operation to taccount_yr_end failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nan
		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nan
		
		/* now delete realtime table row */
		DELETE taccount_yr_end 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nan
			
			select @error_description = 'update_nan : taccount_yr_end : Delete operation'
			
			raiserror 20078 "Delete operation to taccount_yr_end failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nan
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nan to fbi
go

IF OBJECT_ID('dbo.update_nan') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nan >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nan >>>'
go
