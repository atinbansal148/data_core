/*
$Header: /rtapp/stp/update_rsb.sql $
$Log: /rtapp/stp/update_rsb.sql $
 * 
 * 
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_rsb') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_rsb
    IF OBJECT_ID('dbo.update_rsb') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_rsb >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_rsb >>>'
END
go

CREATE PROC update_rsb
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@action 	        char(1),
	@type_acct_cd       char(3),
	@ltrtr_ind			char(1),
	@plan_type_cd		char(1),		
	@acct_stts_cd		char(1),
	@rrif_successor_ind	char(1),
	@rsp_aplct_ind		char(1),
	@rsp_type_cd		char(2),
	@tax_cd				char(3),
	@plan_locked_cd		char(1),
	@plan_locked_dt		datetime,
	@pbsa_cd			char(2),
	@cls_rsn_cd			char(2),
	@fee_paid_cd		char(1),
	@fee_type_cd		char(1),
	@sps_nm				char(30),
	@sps_sin_cd			char(9),
	@sps_ever_ind		char(1),
	@sps_birth_dt		datetime,
	@sps_annty_ind		char(1),
	@geo_prev_cd		char(3),
	@geo_chng_dt		datetime,
	@plan_opn_dt		datetime,
	@plan_cls_dt		datetime,
	@na_chng_dt			datetime,
	@rgstn_ind			char(1),
	@sibling_qty		smallint,
	@resp_bnfcr_qty		smallint,
	@grsp_grp_nbr		char(6),
	@trsp_rl_dt			datetime,
	@rgstn_dt			datetime,
	@rgstn_swtch_cd		char(1),	
	@trnfr_in_intd_dt	datetime,
	@trnfr_in_cmplt_dt	datetime,
	@trnfr_ot_intd_dt	datetime,
	@trnfr_ot_cmplt_dt	datetime,
	@trnfr_sys_fm_cd	char(1),
	@auto_sw_ind		char(1),
	@auto_sw_dt		datetime,
	@prev_plan_cd		char(4)
AS
BEGIN
	

	DECLARE @action_cd char(1),
                @tbl_security_adp_nbr char(7),
	        @start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @type_acct_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @action_cd = action_cd
		FROM tregister_plan
		WHERE   client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			type_acct_cd = @type_acct_cd
			
		IF @@rowcount = 0
		BEGIN
			BEGIN TRAN update_rsb
			
			/* insert, first into realtime table */
			INSERT INTO tregister_plan (client_nbr,
					branch_cd,
					account_cd,
					type_acct_cd,
					ltrtr_ind,
					plan_type_cd,		
					acct_stts_cd,
					rrif_successor_ind,
					rsp_aplct_ind,
					rsp_type_cd,
					tax_cd,
					plan_locked_cd,
					plan_locked_dt,
					pbsa_cd,
					cls_rsn_cd,
					fee_paid_cd,
					fee_type_cd,
					sps_nm,
					sps_sin_cd,
					sps_ever_ind,
					sps_birth_dt,
					sps_annty_ind,
					geo_prev_cd,
					geo_chng_dt,
					plan_opn_dt,
					plan_cls_dt,
					na_chng_dt,
					rgstn_ind,
					sibling_qty,
					resp_bnfcr_qty,
					grsp_grp_nbr,
					trsp_rl_dt,
					rgstn_dt,
					rgstn_swtch_cd,
					trnfr_in_intd_dt,
					trnfr_in_cmplt_dt,
					trnfr_ot_intd_dt,
					trnfr_ot_cmplt_dt,
					trnfr_sys_fm_cd,
					action_cd,
					record_type_cd,
					auto_sw_ind,
					auto_sw_dt,
					prev_plan_cd,
					updt_last_tmstp )
			VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					@type_acct_cd,
					@ltrtr_ind,
					@plan_type_cd,		
					@acct_stts_cd,
					@rrif_successor_ind,
					@rsp_aplct_ind,
					@rsp_type_cd,
					@tax_cd,
					@plan_locked_cd,
					@plan_locked_dt,
					@pbsa_cd,
					@cls_rsn_cd,
					@fee_paid_cd,
					@fee_type_cd,
					@sps_nm,
					@sps_sin_cd,
					@sps_ever_ind,
					@sps_birth_dt,
					@sps_annty_ind,
					@geo_prev_cd,
					@geo_chng_dt,
					@plan_opn_dt,
					@plan_cls_dt,
					@na_chng_dt,
					@rgstn_ind,
					@sibling_qty,
					@resp_bnfcr_qty,
					@grsp_grp_nbr,
					@trsp_rl_dt,
					@rgstn_dt,
					@rgstn_swtch_cd,
					@trnfr_in_intd_dt,
					@trnfr_in_cmplt_dt,
					@trnfr_ot_intd_dt,
					@trnfr_ot_cmplt_dt,
					@trnfr_sys_fm_cd,
					'I',
					'RSB',
					@auto_sw_ind,
					@auto_sw_dt,
					@prev_plan_cd,
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsb
				
				select @error_description = 'update_rsb : tregister_plan : Insert operation'
				
				raiserror 20154 "Insert operation to tregister_plan failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END 

			COMMIT TRAN update_rsb
		END
		ELSE
		BEGIN
			BEGIN TRAN update_rsb
						
			/* update realtime table row */
			UPDATE tregister_plan 
			SET client_nbr = @client_nbr,
				branch_cd = @branch_cd,
				account_cd = @account_cd,
				type_acct_cd = @type_acct_cd,
				ltrtr_ind = @ltrtr_ind,
				plan_type_cd = @plan_type_cd,		
				acct_stts_cd = @acct_stts_cd,
				rrif_successor_ind = @rrif_successor_ind,
				rsp_aplct_ind = @rsp_aplct_ind,
				rsp_type_cd = @rsp_type_cd,
				tax_cd = @tax_cd,
				plan_locked_cd = @plan_locked_cd,
				plan_locked_dt = @plan_locked_dt,
				pbsa_cd = @pbsa_cd,
				cls_rsn_cd = @cls_rsn_cd,
				fee_paid_cd = @fee_paid_cd,
				fee_type_cd = @fee_type_cd,
				sps_nm = @sps_nm,
				sps_sin_cd = @sps_sin_cd,
				sps_ever_ind = @sps_ever_ind,
				sps_birth_dt = @sps_birth_dt,
				sps_annty_ind = @sps_annty_ind,
				geo_prev_cd = @geo_prev_cd,
				geo_chng_dt = geo_chng_dt,
				plan_opn_dt = @plan_opn_dt,
				plan_cls_dt = @plan_cls_dt,
				na_chng_dt = @na_chng_dt,
				rgstn_ind = @rgstn_ind,
				sibling_qty = @sibling_qty,
				resp_bnfcr_qty = @resp_bnfcr_qty,
				grsp_grp_nbr = @grsp_grp_nbr,
				trsp_rl_dt = @trsp_rl_dt,
				rgstn_dt = @rgstn_dt,
				rgstn_swtch_cd = @rgstn_swtch_cd,
				trnfr_in_intd_dt = @trnfr_in_intd_dt,
				trnfr_in_cmplt_dt = @trnfr_in_cmplt_dt,
				trnfr_ot_intd_dt = @trnfr_ot_intd_dt,
				trnfr_ot_cmplt_dt = @trnfr_ot_cmplt_dt,
				trnfr_sys_fm_cd = @trnfr_sys_fm_cd,
				action_cd = 'U',
				record_type_cd = 'RSB',	
				auto_sw_ind = @auto_sw_ind,
				auto_sw_dt = @auto_sw_dt,
				prev_plan_cd = @prev_plan_cd,
				updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
				type_acct_cd = @type_acct_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsb
				
				select @error_description = 'update_rsb : tregister_plan : Update operation'
				
				raiserror 20155 "Update operation to tregister_plan failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
			COMMIT TRAN update_rsb    
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		BEGIN TRAN update_rsb
		
		/* now delete realtime table row */
		DELETE tregister_plan 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			type_acct_cd = @type_acct_cd


		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_rsb
			
			select @error_description = 'update_rsb : tregister_plan : Delete operation'
			
			raiserror 20156 "Delete operation to tregister_plan failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_rsb	    			    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_rsb to fbi
go

IF OBJECT_ID('dbo.update_rsb') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_rsb >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_rsb >>>'
go