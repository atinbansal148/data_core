/*
$Header: /rtapp/stp/update_nca.sql 1     01/14/03 10:41a Tbprven $
$Log: /rtapp/stp/update_nca.sql $
 * 
 * 1     01/14/03 11:15a Tbprven
 * Canadian Name and Address Category
 * 
 * 1     01/14/03 11:15a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nca') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nca
    IF OBJECT_ID('dbo.update_nca') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nca >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nca >>>'
END
go

CREATE PROC update_nca
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@action	         	        char(1),
	@fee_schdl_seq_nbr              smallint,              
	@fee_schdl_cd                   char(4) = null,               
	@fee_crncy_sym_cd		char(2) = null,    
	@fee_schdl_freq_cd		char(1) = null,               
	@fee_strt_dt			datetime = null,              
	@fee_nxt_dt                     datetime = null,                
	@fee_lst_dt			datetime = null,               
        @fee_disc_rt			decimal(5,2) = null,
	@fee_fnl_tier_ind		char(1) = null,
       	@fee_reason_cd			char(1) = null,
       	@fee_cash_calc_ind		char(1) = null,
       	@fee_co_tstee_ind		char(1) = null,
       	@fee_inv_mgr_cd			char(3) = null,
       	@fee_im_rt			decimal(5,2) = null,
       	@fee_im_offset_nbr		char(10) = null

					
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@fee_schdl_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
			
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM tcan_fee_schdl
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			fee_schdl_seq_nbr = @fee_schdl_seq_nbr
			
		SELECT @tbl_rowcount = @@rowcount
		
		BEGIN TRAN update_nca

		IF @tbl_rowcount = 0
		BEGIN
			
			/* insert into realtime table */
			INSERT INTO tcan_fee_schdl (client_nbr,
					branch_cd,
					account_cd,
					fee_schdl_seq_nbr,
					action_cd,
					record_type_cd,
					fee_schdl_cd,               
					fee_crncy_sym_cd,    
					fee_schdl_freq_cd,               
					fee_strt_dt,              
					fee_nxt_dt,                
					fee_lst_dt,               
					fee_disc_rt,
					fee_fnl_tier_ind,
       					fee_reason_cd,
       					fee_cash_calc_ind,
       					fee_co_tstee_ind,
       					fee_inv_mgr_cd,
       					fee_im_rt,
       					fee_im_offset_nbr,
					updt_last_tmstp)
				VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					@fee_schdl_seq_nbr,
					'I',
					'NCA',
					@fee_schdl_cd,               
					@fee_crncy_sym_cd,    
					@fee_schdl_freq_cd,               
					@fee_strt_dt,              
					@fee_nxt_dt,                
					@fee_lst_dt,               
					@fee_disc_rt,
					@fee_fnl_tier_ind,
       					@fee_reason_cd,
       					@fee_cash_calc_ind,
       					@fee_co_tstee_ind,
       					@fee_inv_mgr_cd,
       					@fee_im_rt,
       					@fee_im_offset_nbr,
					getdate())

			SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nca
				
				select @error_description = 'update_nca : tcan_fee_schdl : Insert operation'
				
				raiserror 20019 "Insert operation to tcan_fee_schdl failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
		END
		ELSE
		BEGIN
			/* update */
			
			/* now update realtime table row */
			UPDATE tcan_fee_schdl 
			SET     record_type_cd = 'NCA',
				action_cd= 'U',
				fee_schdl_cd = @fee_schdl_cd,               
				fee_crncy_sym_cd = @fee_crncy_sym_cd,    
				fee_schdl_freq_cd = @fee_schdl_freq_cd,               
				fee_strt_dt = @fee_strt_dt,              
				fee_nxt_dt = @fee_nxt_dt,                
				fee_lst_dt = @fee_lst_dt,               
			        fee_disc_rt = @fee_disc_rt,
				fee_fnl_tier_ind = @fee_fnl_tier_ind,
       				fee_reason_cd = @fee_reason_cd,
       				fee_cash_calc_ind = @fee_cash_calc_ind,
       				fee_co_tstee_ind = @fee_co_tstee_ind,
       				fee_inv_mgr_cd = @fee_inv_mgr_cd,
       				fee_im_rt = @fee_im_rt,
       				fee_im_offset_nbr = @fee_im_offset_nbr,
				updt_last_tmstp	= getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
			        fee_schdl_seq_nbr = @fee_schdl_seq_nbr 


			SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nca
				
				select @error_description = 'update_nca:tcan_fee_schdl: Update operation'
				
				raiserror 20020 "Update operation to tcan_fee_schdl failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

		END
		COMMIT TRAN update_nca
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nca
		
		/* delete realtime record */
		
		/* now delete realtime table row */
		DELETE tcan_fee_schdl 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			fee_schdl_seq_nbr = @fee_schdl_seq_nbr


		SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nca
			
			select @error_description = 'update_nca : tcan_fee_schdl : Delete operation'
			
			raiserror 20021 "Delete operation to tcan_fee_schdl failed"
			select @custom_error_code=@@error

			IF (@debug_flag="Y")			
			BEGIN
				INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END

	COMMIT TRAN update_nca
	
	END
   
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CNADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
   
END

go

grant execute on update_nca to fbi
go

IF OBJECT_ID('dbo.update_nca') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nca >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nca >>>'
go
