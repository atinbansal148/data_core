/*****************************************************************************
NAME: update_nry.sql
PURPOSE: Insert and update TFATCA_CMPLN table
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	86217	10/1/12	J Shen		initial version
1.1	91545	5/16/13	J Shen		add new a field giin_nbr
1.2	93885	9/26/13	J Shen		add 6 new fields drop_thru_stk_rt,
      					drop_thru_bnd_rt, drop_thru_rylty_rt,
      					drop_thru_reit_rt, drop_thru_mlp_rt,
      					ownership_wthld_rt
1.3	97247	3/26/14	J Shen		add 5 new fields irs_1042s_ch3_cd,
	96014				irs_1042s_ch4_cd, form_8966_ind, 
					form_8966_strt_dt,form_8966_end_dt
1.4	108505	12/30/15J.Shen		Added 1 new field drop_thru_reig_rt
1.5	3428963	10/27/15	J.Shen	Added 1 new field fatca_lob_cd
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nry') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nry
    IF OBJECT_ID('dbo.update_nry') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nry >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nry >>>'
END
go

CREATE PROC update_nry
      @client_nbr	char(4)  ,
      @branch_cd char(3)  ,
      @account_cd char(5)  ,
      @action_cd char(1)  ,
      @prmry_hld_cntry_cd char(3) = null ,
      @joint_hld_cntry_cd char(3) = null ,
      @prmry_hld_ctzns_cd char(3) = null ,
      @joint_hld_ctzns_cd char(3) = null ,
      @prmry_hld_dual_cd char(3) = null ,
      @joint_hld_dual_cd char(3) = null ,
      @hldr_type_cd char(4) = null ,
      @hldr_sub_type_cd char(4) = null ,
      @flwth_enty_type_cd char(4) = null ,
      @ffi_agrmt_effct_dt datetime = null ,
      @ffi_agrmt_exptn_dt datetime = null ,
      @ffi_ein_nbr char(9) = null ,
      @hldr_frgn_tax_id char(25) = null ,
      @frgn_tax_cntry_cd char(3) = null ,
      @fatca_wthld_cd char(1) = null ,
      @cert_stts_cd char(2) = null ,
      @cert_cmpl_dt datetime = null ,
      @cert_expt_dt datetime = null ,
      @cert_rnwl_dt datetime = null ,
      @cert_type_cd char(2) = null ,
      @cert_dcmnt_txt char(50) = null ,
      @cert_reviewer_nm char(30) = null ,
      @indicia_cmpltn_dt datetime = null ,
      @indicia_retest_dt datetime = null ,
      @dormant_acct_ind char(1) = null ,
      @dormant_act_ind_dt datetime = null ,
      @rncd_us_ctzns_ind char(1) = null ,
      @fatca_id char(17) = null,
      @giin_nbr char(19) = null,
      @drop_thru_stk_rt decimal(7,5) = null,
      @drop_thru_bnd_rt decimal(7,5) = null,
      @drop_thru_rylty_rt decimal(7,5) = null,
      @drop_thru_reit_rt decimal(7,5) = null,
      @drop_thru_mlp_rt decimal(7,5) = null,
      @ownership_wthld_rt decimal(7,5) = null,
      @irs_1042s_ch3_cd	char(2) = null,
      @irs_1042s_ch4_cd	char(2) = null,
      @form_8966_ind char(1) = null,
      @form_8966_strt_dt datetime = null,
      @form_8966_end_dt datetime = null,
	  @drop_thru_reig_rt decimal(7,5) = null,
	  @fatca_lob_cd char(2) = null
	
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action_cd = 'C') OR (@action_cd = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM tfatca_cmpln
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd
			   
		SELECT @tbl_rowcount = @@rowcount
		
		IF @tbl_rowcount = 0
		BEGIN
			
			BEGIN TRAN update_nry

			/* insert, first into realtime table */
			INSERT INTO tfatca_cmpln (client_nbr ,
			      branch_cd ,
			      account_cd ,
				record_type_cd ,
				action_cd,
				prmry_hld_cntry_cd,
      				joint_hld_cntry_cd,
      				prmry_hld_ctzns_cd,
      				joint_hld_ctzns_cd,
      				prmry_hld_dual_cd,
      				joint_hld_dual_cd,
      				hldr_type_cd,
      				hldr_sub_type_cd,
      				flwth_enty_type_cd,
      				ffi_agrmt_effct_dt,
      				ffi_agrmt_exptn_dt,
      				ffi_ein_nbr,
      				hldr_frgn_tax_id,
      				frgn_tax_cntry_cd,
      				fatca_wthld_cd,
      				cert_stts_cd,
      				cert_cmpl_dt,
      				cert_expt_dt,
      				cert_rnwl_dt,
      				cert_type_cd,
      				cert_dcmnt_txt,
      				cert_reviewer_nm,
      				indicia_cmpltn_dt,
      				indicia_retest_dt,
      				dormant_acct_ind,
      				dormant_act_ind_dt,
				rncd_us_ctzns_ind,
				fatca_id,
				giin_nbr,
      				drop_thru_stk_rt,
      				drop_thru_bnd_rt,
      				drop_thru_rylty_rt,
      				drop_thru_reit_rt,
      				drop_thru_mlp_rt,
      				ownership_wthld_rt,
				irs_1042s_ch3_cd,
      				irs_1042s_ch4_cd,
      				form_8966_ind,
      				form_8966_strt_dt,
      				form_8966_end_dt,
					drop_thru_reig_rt,
					fatca_lob_cd,
				updt_last_tmstp)	
			VALUES (@client_nbr ,
			      @branch_cd ,
			      @account_cd ,
				'NRY' ,
				'I',
				@prmry_hld_cntry_cd,
      				@joint_hld_cntry_cd,
      				@prmry_hld_ctzns_cd,
      				@joint_hld_ctzns_cd,
      				@prmry_hld_dual_cd,
      				@joint_hld_dual_cd,
      				@hldr_type_cd,
      				@hldr_sub_type_cd,
      				@flwth_enty_type_cd,
      				@ffi_agrmt_effct_dt,
      				@ffi_agrmt_exptn_dt,
      				@ffi_ein_nbr,
      				@hldr_frgn_tax_id,
      				@frgn_tax_cntry_cd,
      				@fatca_wthld_cd,
      				@cert_stts_cd,
      				@cert_cmpl_dt,
      				@cert_expt_dt,
      				@cert_rnwl_dt,
      				@cert_type_cd,
      				@cert_dcmnt_txt,
      				@cert_reviewer_nm,
      				@indicia_cmpltn_dt,
      				@indicia_retest_dt,
      				@dormant_acct_ind,
      				@dormant_act_ind_dt,
				@rncd_us_ctzns_ind,
				@fatca_id,
				@giin_nbr,
      				@drop_thru_stk_rt,
      				@drop_thru_bnd_rt,
      				@drop_thru_rylty_rt,
      				@drop_thru_reit_rt,
      				@drop_thru_mlp_rt,
      				@ownership_wthld_rt,
				@irs_1042s_ch3_cd,
      				@irs_1042s_ch4_cd,
      				@form_8966_ind,
      				@form_8966_strt_dt,
      				@form_8966_end_dt,
					@drop_thru_reig_rt,
				@fatca_lob_cd,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nry
				
				select @error_description = 'update_nry : tfatca_cmpln : Insert operation'
				
				raiserror 20145 "Insert operation to tfatca_cmpln failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nry
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nry			
			/* update */

			/* now update realtime table row */
			UPDATE tfatca_cmpln
			SET action_cd = 'U',
			      record_type_cd = 'NRY',
				prmry_hld_cntry_cd = @prmry_hld_cntry_cd,
      				joint_hld_cntry_cd = @joint_hld_cntry_cd,
      				prmry_hld_ctzns_cd = @prmry_hld_ctzns_cd,
      				joint_hld_ctzns_cd = @joint_hld_ctzns_cd,
      				prmry_hld_dual_cd = @prmry_hld_dual_cd,
      				joint_hld_dual_cd = @joint_hld_dual_cd,
      				hldr_type_cd = @hldr_type_cd,
      				hldr_sub_type_cd = @hldr_sub_type_cd,
      				flwth_enty_type_cd = @flwth_enty_type_cd,
      				ffi_agrmt_effct_dt = @ffi_agrmt_effct_dt,
      				ffi_agrmt_exptn_dt = @ffi_agrmt_exptn_dt,
      				ffi_ein_nbr = @ffi_ein_nbr,
      				hldr_frgn_tax_id = @hldr_frgn_tax_id,
      				frgn_tax_cntry_cd = @frgn_tax_cntry_cd,
      				fatca_wthld_cd = @fatca_wthld_cd,
      				cert_stts_cd = @cert_stts_cd,
      				cert_cmpl_dt = @cert_cmpl_dt,
      				cert_expt_dt = @cert_expt_dt,
      				cert_rnwl_dt = @cert_rnwl_dt,
      				cert_type_cd = @cert_type_cd,
      				cert_dcmnt_txt = @cert_dcmnt_txt,
      				cert_reviewer_nm = @cert_reviewer_nm,
      				indicia_cmpltn_dt = @indicia_cmpltn_dt,
      				indicia_retest_dt = @indicia_retest_dt,
      				dormant_acct_ind = @dormant_acct_ind,
      				dormant_act_ind_dt = @dormant_act_ind_dt,
				rncd_us_ctzns_ind = @rncd_us_ctzns_ind,
				fatca_id = @fatca_id,
				giin_nbr = @giin_nbr,
      				drop_thru_stk_rt = @drop_thru_stk_rt,
      				drop_thru_bnd_rt = @drop_thru_bnd_rt,
      				drop_thru_rylty_rt = @drop_thru_rylty_rt,
      				drop_thru_reit_rt = @drop_thru_reit_rt,
      				drop_thru_mlp_rt = @drop_thru_mlp_rt,
      				ownership_wthld_rt = @ownership_wthld_rt,
				irs_1042s_ch3_cd = @irs_1042s_ch3_cd,
      				irs_1042s_ch4_cd = @irs_1042s_ch4_cd,
      				form_8966_ind = @form_8966_ind,
      				form_8966_strt_dt = @form_8966_strt_dt,
      				form_8966_end_dt = @form_8966_end_dt,
					drop_thru_reig_rt = @drop_thru_reig_rt,
					fatca_lob_cd = @fatca_lob_cd,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nry
				
				select @error_description = 'update_nry : tfatca_cmpln : Update operation'
				
				raiserror 20146 "Update operation to tfatca_cmpln failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
				
			COMMIT TRAN update_nry
		
		END
				
	END
	ELSE
	IF (@action_cd = 'D')
	BEGIN
		
		BEGIN TRAN update_nry

		/* now delete realtime table row */
		DELETE tfatca_cmpln
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nry
			
			select @error_description = 'update_nry : tfatca_cmpln : Delete operation'
			
			raiserror 20147 "Delete operation to tfatca_cmpln failed"
			select @custom_error_code=@@error				
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nry
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nry to fbi
go

IF OBJECT_ID('dbo.update_nry') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nry >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nry >>>'
go
