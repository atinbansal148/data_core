/*
$Header: /Realtime/Realtime/stp/update_msh.sql 3     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msh.sql $
 * 
 * 3     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 2     6/29/00 5:20p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msh') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msh
    IF OBJECT_ID('dbo.update_msh') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msh >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msh >>>'
END
go

CREATE PROC update_msh
	@security_adp_nbr	char(7),
	@vendor_cd			char(5),
	@rating_cd			char(5)

AS
BEGIN
  
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr 	char(7),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
		
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @vendor_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tsecurity_rating WHERE
		vendor_cd = @vendor_cd AND
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msh
		/* insert */
		INSERT INTO tsecurity_rating (	security_adp_nbr,
						vendor_cd,
						rating_cd,
						record_type_cd,
						action_cd )
		VALUES (	@security_adp_nbr,
					@vendor_cd,
					@rating_cd,
					'MSH',
					'I' )
					
		SELECT @syb_error_code = @@error

		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msh
			
			select @error_description = 'update_msh : tsecurity_rating : Insert operation'
			
			raiserror 20039 "Insert operation to tsecurity_rating failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_msh
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msh
		/* update */

		/* now update real-time table */
		UPDATE tsecurity_rating SET
			rating_cd = @rating_cd,
			record_type_cd = 'MSH',
			action_cd = 'U'
		WHERE vendor_cd = @vendor_cd AND
			security_adp_nbr = @security_adp_nbr
			
		SELECT @syb_error_code = @@error

		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msh
			
			select @error_description = 'update_msh : tsecurity_rating : Update operation'
			
			raiserror 20040 "Update operation to tsecurity_rating failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_msh
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_msh to fbi
go

IF OBJECT_ID('dbo.update_msh') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msh >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msh >>>'
go