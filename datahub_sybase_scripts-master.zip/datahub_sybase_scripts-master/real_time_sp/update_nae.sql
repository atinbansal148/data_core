/*
$Header: /rtapp/stp/update_nae.sql 1     3/25/02 10:40a Tbprven $
$Log: /rtapp/stp/update_nae.sql $
 * 
 * 1     3/25/02 10:40a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nae') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nae
    IF OBJECT_ID('dbo.update_nae') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nae >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nae >>>'
END
go

CREATE PROC update_nae
      @client_nbr			char(4),
      @branch_cd			char(3),
      @account_cd			char(5),
      @rr_cd				char(3),
      @action				char(1) ,
      @branch_xfer_cd		char(3) = null,
      @account_xfer_cd		char(5) = null,
      @rr_transfer_to_cd	char(3) = null,
      @transfered_to_dt		datetime = null,
      @rr_trnfr_from_cd		char(3) = null,
      @transfered_from_dt	datetime = null
      
      
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
        
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @branch_xfer_cd + "," + @account_xfer_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM taccount_xfer
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			branch_xfer_cd = @branch_xfer_cd AND
			account_xfer_cd = @account_xfer_cd
			
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
                        
			BEGIN TRAN update_nae
                        
			/* now insert into realtime table */
			INSERT INTO taccount_xfer (client_nbr ,
			      branch_cd ,
			      account_cd ,
			      branch_xfer_cd,
			      account_xfer_cd,
			      rr_transfer_to_cd,
			      transfered_to_dt,
			      rr_trnfr_from_cd,
			      transfered_from_dt,
			      record_type_cd,
			      action,
			      rr_cd,
				updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd ,
			      @account_cd ,
			      @branch_xfer_cd,
			      @account_xfer_cd,
			      @rr_transfer_to_cd,
			      @transfered_to_dt,
			      @rr_trnfr_from_cd,
			      @transfered_from_dt,
			      'NAE',
			      'I',
			      @rr_cd,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nae
				
				select @error_description = 'update_nae : taccount_xfer : Insert operation'
				
				raiserror 20058 "Insert operation to taccount_xfer failed"
				select @custom_error_code=@@error

				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
	
            COMMIT TRAN update_nae
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nae		
			/* update */

			/* now update realtime table row */
			UPDATE taccount_xfer
			SET branch_xfer_cd = @branch_xfer_cd,
			      account_xfer_cd = @account_xfer_cd,
			      rr_transfer_to_cd = @rr_transfer_to_cd,
			      transfered_to_dt = @transfered_to_dt,
			      record_type_cd = 'NAE',
			      rr_trnfr_from_cd = @rr_trnfr_from_cd,
			      transfered_from_dt = @transfered_from_dt,
			      action = 'U',
			      rr_cd = @rr_cd,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
			        branch_xfer_cd = @branch_xfer_cd AND
			        account_xfer_cd = @account_xfer_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nae
				
				select @error_description = 'update_nae : taccount_xfer : Update operation'
				
				raiserror 20059 "Update operation to taccount_xfer failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

		    COMMIT TRAN update_nae
		
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nae

		/* now delete realtime table row */
		DELETE taccount_xfer
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd 

		SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nae
			
			select @error_description = 'update_nae : taccount_xfer : Delete operation'
			
			raiserror 20060 "Delete operation to taccount_xfer failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END

	    COMMIT TRAN update_nae
	
	END
   
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nae to fbi
go

IF OBJECT_ID('dbo.update_nae') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nae >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nae >>>'
go
