/*****************************************************************************
NAME: update_pbb.sql
PURPOSE: Insert and update TPAT_XREF table
REVISIONS:
Ver	SSR	Date	  Author	Description
-------	-------	--------- ------------- -------------------------------------
1.0	108810	09/01/15  J.Shen	Added 3 new fields usbo_cd, app_id & rel_id
    3495781 08/06/2017 Siddhardha Added 1 new field    cp_type
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_pbb') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_pbb
    IF OBJECT_ID('dbo.update_pbb') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_pbb >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_pbb >>>'
END
go

create proc update_pbb 
    @client_nbr         char(4),
    @branch_cd		char(3),
    @account_cd		char(5),
    @soc_sec_nbr	char(9),
    @soc_sec_tax_cd	char(1),
    @action_cd 		char(1),
    @role_type_cd 	char(2) = null,
    @pp_rltsh_txt 	char(30) = null,
    @last_updt_tmstp 	char(26) = null,
    @last_updt_id	char(8) = null,
    @ownrshp_pct	decimal(8,5) = null,
    @w8_type_cd		char(1) = null,
    @tex_cd		char(3) = null,
    @usbo_cd 		char(1) = null,
    @app_id 		char(4) = null,
    @rel_id		char(16) = null,
    @cp_type    char(6) = null

as

BEGIN
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
        
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)

	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)	

	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action_cd = 'C') OR (@action_cd = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM tpat_xref
		WHERE    
			client_nbr = @client_nbr and 
			branch_cd = @branch_cd and
			account_cd = @account_cd and
			soc_sec_nbr = @soc_sec_nbr and
			soc_sec_tax_cd = @soc_sec_tax_cd



                SELECT @tbl_rowcount = @@rowcount
                 
                
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_pbb
			
			/* insert into realtime table */
			INSERT INTO tpat_xref (client_nbr,
				branch_cd,
				account_cd,
				soc_sec_nbr,
				soc_sec_tax_cd,
				rec_type_cd,
				action_cd,
				role_type_cd,
				pp_rltsh_txt,
				last_updt_tmstp,
				last_updt_id,
				ownrshp_pct,
				w8_type_cd,
				tex_cd,
				usbo_cd,
    				app_id,
    				rel_id,
    				cp_type,
		                updt_last_tmstp)
			       VALUES (
				@client_nbr,
				@branch_cd,
				@account_cd,
				@soc_sec_nbr,
				@soc_sec_tax_cd,
				'PBB',
				'I',
				@role_type_cd,
				@pp_rltsh_txt,
				@last_updt_tmstp,
				@last_updt_id,
				@ownrshp_pct,
				@w8_type_cd,
				@tex_cd,
				@usbo_cd,
    				@app_id,
    				@rel_id,
    				@cp_type,
			        getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_pbb
				
				select @error_description = 'update_pbb : tpat_xref : Insert operation'
				
				raiserror 20195 "Insert operation to tpat_xref failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
                        
                        COMMIT TRAN update_pbb
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_pbb
			/* now update realtime table row */

			UPDATE tpat_xref
			SET action_cd = 'U',
			      	rec_type_cd = 'PBB',
				role_type_cd = @role_type_cd,
				pp_rltsh_txt = @pp_rltsh_txt,
				last_updt_tmstp = @last_updt_tmstp,
				last_updt_id = @last_updt_id,
				ownrshp_pct = @ownrshp_pct,
				w8_type_cd = @w8_type_cd,
				tex_cd = @tex_cd,
				usbo_cd = @usbo_cd,
    				app_id = @app_id,
    				rel_id = @rel_id,
    				cp_type = @cp_type,
				updt_last_tmstp = getdate()			
			WHERE client_nbr = @client_nbr and 
				branch_cd = @branch_cd and
				account_cd = @account_cd and
				soc_sec_nbr = @soc_sec_nbr and
				soc_sec_tax_cd = @soc_sec_tax_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_pbb
				
				select @error_description = 'update_pbb : tpat_xref : Update operation'
				
				raiserror 20196 "Update operation to tpat_xref failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
               
                COMMIT TRAN update_pbb
                
		END
		
		
	END
	ELSE
	IF (@action_cd = 'D')
	BEGIN
		
		BEGIN TRAN update_pbb

		/* now delete realtime table row */


		DELETE tpat_xref
		WHERE client_nbr = @client_nbr and 
			branch_cd = @branch_cd and
			account_cd = @account_cd and
			soc_sec_nbr = @soc_sec_nbr and
			soc_sec_tax_cd = @soc_sec_tax_cd
			

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_pbb
			
			select @error_description = 'update_pbb : tpat_xref : Delete operation'
			
			raiserror 20197 "Delete operation to tpat_xref failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_pbb
	END

	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END

END


go

grant execute on update_pbb to fbi
go

IF OBJECT_ID('dbo.update_pbb') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_pbb >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_pbb >>>'
go