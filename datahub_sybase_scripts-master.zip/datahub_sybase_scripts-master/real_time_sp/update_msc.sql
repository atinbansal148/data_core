/*
$Header: /Realtime/Realtime/stp/update_msc.sql 3     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msc.sql $
 * 
 * 3     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 2     6/29/00 5:18p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msc') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msc
    IF OBJECT_ID('dbo.update_msc') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msc >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msc >>>'
END
go

CREATE PROC update_msc
	@security_adp_nbr	char(7),
	@type_xref_cd		char(2),
	@cross_reference_cd	char(20)

AS
BEGIN
    
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr 	char(7),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
		
	
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @type_xref_cd + "," + @cross_reference_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tsec_xref_key WHERE
		type_xref_cd = @type_xref_cd AND
		cross_reference_cd = @cross_reference_cd AND
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msc
		/* insert */
		INSERT INTO tsec_xref_key (	type_xref_cd,
						cross_reference_cd,
						security_adp_nbr,
						record_type_cd,
						action_cd )
		VALUES (	@type_xref_cd,
					@cross_reference_cd,
					@security_adp_nbr,
					'MSC',
					'I' )
					
		SELECT @syb_error_code = @@error
		
		IF @syb_error_code != 0
		BEGIN
		
			ROLLBACK TRAN update_msc
			
			select @error_description = 'update_msc : tsec_xref_key : Insert operation'
			
			raiserror 20029 "Insert operation to tsec_xref_key failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END

		COMMIT TRAN update_msc    
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msc
		/* update */

		/* now update real-time table */
		UPDATE tsec_xref_key SET record_type_cd = 'MSC',
				  	  action_cd = 'U'
		WHERE type_xref_cd = @type_xref_cd AND
				cross_reference_cd = @cross_reference_cd AND
				security_adp_nbr = @security_adp_nbr
				
		SELECT @syb_error_code = @@error
		
		IF @syb_error_code != 0
		
		BEGIN
		
			ROLLBACK TRAN update_msc
			
			select @error_description = 'update_msc : tsec_xref_key : Update operation'
			
			raiserror 20030 "Update operation to tsec_xref_key failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_msc    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
    
END

go

grant execute on update_msc to fbi
go

IF OBJECT_ID('dbo.update_msc') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msc >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msc >>>'
go