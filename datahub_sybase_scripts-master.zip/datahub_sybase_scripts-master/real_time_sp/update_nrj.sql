/*
$Header: /rtserver/stp/update_nrj.sql 1 $
$Log: /rtserver/stp/update_nrj.sql $
 * 
 * 
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrj') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrj
    IF OBJECT_ID('dbo.update_nrj') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrj >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrj >>>'
END
go

CREATE PROC update_nrj
	     @client_nbr char(4),
	     @branch_cd char(3),
	     @account_cd char(5),
	     @ap_seq_nbr smallint,
	     @action char,
	     @nm_cd char(1) = null,                
	     @cmpy_emplr_nm char(35) = null,              
	     @first_emplr_nm char(20) = null,              
	     @mi_emplr_txt char(1) = null,                
	     @last_emplr_nm char(20) = null,               
	     @apt_emplr_nbr char(5) = null,                
	     @street_emplr_nm char(30) = null,            
	     @city_emplr_nm char(29) = null,            
	     @state_emplr_cd char(2) = null,             
	     @zip5_emplr_cd char(5) = null,             
	     @zip4_emplr_cd char(4) = null,             
	     @zip3_emplr_cd char(3) = null,             
	     @pstl6_can_emplr_cd char(6) = null,            
	     @pstl4_can_emplr_cd char(4) = null,            
	     @prev_nm_cd char(1) = null,            
	     @prev_cmpy_emplr_nm char(35) = null,           
	     @prev_frst_emplr_nm char(20) = null,            
	     @prev_mi_emplr_txt char(1) = null,            
	     @prev_last_emplr_nm char(20) = null		
      
      
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@ap_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
			
		/* insert or update record */
		SELECT @db_action = action
		FROM tacc_party_emplr
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   ap_seq_nbr = @ap_seq_nbr				
			   
		SELECT @tbl_rowcount = @@rowcount
		
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nrj
			
			/* insert into realtime table */
			INSERT INTO tacc_party_emplr (client_nbr ,
						     branch_cd ,
						     account_cd ,
						     ap_seq_nbr ,
						     action ,
						     record_type_cd,
						     nm_cd ,                
						     cmpy_emplr_nm ,              
						     first_emplr_nm ,              
						     mi_emplr_txt ,                
						     last_emplr_nm ,               
						     apt_emplr_nbr ,                
						     street_emplr_nm ,            
						     city_emplr_nm ,            
						     state_emplr_cd ,             
						     zip5_emplr_cd ,             
						     zip4_emplr_cd ,             
						     zip3_emplr_cd ,             
						     pstl6_can_emplr_cd ,            
						     pstl4_can_emplr_cd ,            
						     prev_nm_cd ,            
						     prev_cmpy_emplr_nm ,           
						     prev_frst_emplr_nm ,            
						     prev_mi_emplr_txt ,            
						     prev_last_emplr_nm ,
						     updt_last_tmstp)
					VALUES (@client_nbr ,
						     @branch_cd ,
						     @account_cd ,
						     @ap_seq_nbr ,
						     'I' ,
						     'NRJ',
						     @nm_cd ,                
						     @cmpy_emplr_nm ,              
						     @first_emplr_nm ,              
						     @mi_emplr_txt ,                
						     @last_emplr_nm ,               
						     @apt_emplr_nbr ,                
						     @street_emplr_nm ,            
						     @city_emplr_nm ,            
						     @state_emplr_cd ,             
						     @zip5_emplr_cd ,             
						     @zip4_emplr_cd ,             
						     @zip3_emplr_cd ,             
						     @pstl6_can_emplr_cd ,            
						     @pstl4_can_emplr_cd ,            
						     @prev_nm_cd ,            
						     @prev_cmpy_emplr_nm ,           
						     @prev_frst_emplr_nm ,            
						     @prev_mi_emplr_txt ,            
						     @prev_last_emplr_nm ,
					             getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrj
				
				select @error_description = 'update_nrj : tacc_party_emplr : Insert operation'
				
				raiserror 20112 "Insert operation to tacc_party_emplr failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nrj
		END
		ELSE
		BEGIN
					
			BEGIN TRAN update_nrj			
			/* update */

			/* now update realtime table row */
			UPDATE tacc_party_emplr
			SET record_type_cd = 'NRJ',
	                    action = 'U' ,
				nm_cd = @nm_cd ,                
				cmpy_emplr_nm = @cmpy_emplr_nm ,              
				first_emplr_nm = @first_emplr_nm ,              
				mi_emplr_txt = @mi_emplr_txt ,                
				last_emplr_nm = @last_emplr_nm ,               
				apt_emplr_nbr = @apt_emplr_nbr ,                
				street_emplr_nm = @street_emplr_nm ,            
				city_emplr_nm = @city_emplr_nm ,            
				state_emplr_cd = @state_emplr_cd ,             
				zip5_emplr_cd = @zip5_emplr_cd ,             
				zip4_emplr_cd = @zip4_emplr_cd ,             
				zip3_emplr_cd = @zip3_emplr_cd ,             
				pstl6_can_emplr_cd = @pstl6_can_emplr_cd ,            
				pstl4_can_emplr_cd = @pstl4_can_emplr_cd ,            
				prev_nm_cd = @prev_nm_cd ,            
				prev_cmpy_emplr_nm = @prev_cmpy_emplr_nm ,           
				prev_frst_emplr_nm = @prev_frst_emplr_nm ,            
				prev_mi_emplr_txt = @prev_mi_emplr_txt ,            
				prev_last_emplr_nm = @prev_last_emplr_nm ,
		             updt_last_tmstp = getdate()			
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and 
				ap_seq_nbr = @ap_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrj
				
				select @error_description = 'update_nrj : tacc_party_emplr : Update operation'
				
				raiserror 20113 "Update operation to tacc_party_emplr failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

		
		COMMIT TRAN update_nrj

		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
	
	    BEGIN TRAN update_nrj

		/* now delete realtime table row */
		DELETE tacc_party_emplr
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrj
			
			select @error_description = 'update_nrj : tacc_party_emplr : Delete operation'
			
			raiserror 20114 "Delete operation to tacc_party_emplr failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nrj
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
 
END

go

grant execute on update_nrj to fbi
go

IF OBJECT_ID('dbo.update_nrj') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrj >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrj >>>'
go
