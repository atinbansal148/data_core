/*
$Header: /Realtime/Realtime/stp/update_mca.sql 1     10/19/01 4:22p Tbjuhu $
$Log: /Realtime/Realtime/stp/update_mca.sql $
 * 
 * 1     10/19/01 4:22p Tbjuhu
 * 4th Qtr Data model changes
 *  
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_mca') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_mca
    IF OBJECT_ID('dbo.update_mca') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_mca >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_mca >>>'
END
go

CREATE PROC update_mca
	@security_adp_nbr	char(7),
	@cls_books_bond_dt	datetime,
	@offering_bond_dt	datetime,
	@par_fctr_pct		float,
	@pay_made_nbr		decimal(2,0)
						
AS
BEGIN
	DECLARE @action_cd char(1),
		@tbl_security_adp_nbr char(7),
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tcanada_bond_data 
	WHERE security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		
		BEGIN TRAN update_mca
		/* insert */
		INSERT INTO tcanada_bond_data (	security_adp_nbr,
						record_type_cd,
						action_cd,
						cls_books_bond_dt,
						offering_bond_dt,
						par_fctr_pct,
						pay_made_nbr,
						updt_last_tmstp)
				VALUES (	@security_adp_nbr,
						'MCA',
						'I',
						@cls_books_bond_dt,
						@offering_bond_dt,
						@par_fctr_pct,
						@pay_made_nbr,
						getdate())

		SELECT @syb_error_code = @@error
	
		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_mca
			
			select @error_description = 'update_mca:tcanada_bond_data: Insert operation'
			
			raiserror 20011 "Insert operation to tcanada_bond_data failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
		END
             
		COMMIT TRAN update_mca
		
	END
	ELSE
	BEGIN
		BEGIN TRAN update_mca
		/* update */

		/* now update tmsd_base */
		UPDATE tcanada_bond_data SET record_type_cd = 'MCA',
					action_cd = 'U',
					cls_books_bond_dt = @cls_books_bond_dt,
					offering_bond_dt = @offering_bond_dt,
					par_fctr_pct = @par_fctr_pct,
					pay_made_nbr = @pay_made_nbr,
					updt_last_tmstp = getdate()
		
		WHERE security_adp_nbr = @security_adp_nbr
		
		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
	    BEGIN
		
			ROLLBACK TRAN update_mca
		
			select @error_description = 'update_mca:tcanada_bond_data: Update operation'
			
			raiserror 20012 "Update operation to tcanada_bond_data failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN -99
		
	    END
	    
	    COMMIT TRAN update_mca
	    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
   
END

go

grant execute on update_mca to fbi
go

IF OBJECT_ID('dbo.update_mca') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_mca >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_mca >>>'
go
