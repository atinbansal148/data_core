/*****************************************************************************
NAME: update_nrz.sql
PURPOSE: Insert and update TOFAC_DATA_STATUS table
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	82332	1/2/13	Judy Shen	initial version
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrz') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrz
    IF OBJECT_ID('dbo.update_nrz') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrz >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrz >>>'
END
go

CREATE PROC update_nrz
      @client_nbr	char(4)   ,
      @branch_cd char(3)   ,
      @account_cd char(5)   ,
      @action_cd char(1)  ,
      @indifren_stts_cd char(1) = null ,
      @indifren_updt_dt datetime = null ,
      @indifrec_stts_cd char(1) = null ,
      @indifrec_updt_dt datetime = null ,
      @indifxdn_stts_cd char(1) = null ,
      @indifxdn_updt_dt datetime = null ,
      @indifxdc_stts_cd char(1) = null ,
      @indifxdc_updt_dt datetime = null ,
      @indiipcy_stts_cd char(1) = null ,
      @indiipcy_updt_dt datetime = null ,
      @cpd1mmnm_stts_cd char(1) = null ,
      @cpd1mmnm_updt_dt datetime = null ,
      @cpd2spnm_stts_cd char(1) = null ,
      @cpd2spnm_updt_dt datetime = null ,
      @nadpnam1_stts_cd char(1) = null ,
      @nadpnam1_updt_dt datetime = null ,
      @nadpnam2_stts_cd char(1) = null ,
      @nadpnam2_updt_dt datetime = null ,
      @nataslin_stts_cd char(1) = null ,
      @nataslin_updt_dt datetime = null ,
      @nataclin_stts_cd char(1) = null ,
      @nataclin_updt_dt datetime = null,
      @nayesshd_stts_cd char(1) = null ,
      @nayesshd_updt_dt datetime = null,
      @naye2ndp_stts_cd char(1) = null ,
      @naye2ndp_updt_dt datetime = null,
      @nayectry_stts_cd char(1) = null ,
      @nayectry_updt_dt datetime = null,
      @ofac_stts_updt_id char(8) = null ,
      @ofac_stts_updt_dt datetime = null,
      @ofac_stts_cd char(1) = null
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action_cd = 'C') OR (@action_cd = 'A')
	BEGIN
				
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM tofac_data_status
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd
			 
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN

			BEGIN TRAN update_nrz
	
			/* insert, first into realtime table */
			INSERT INTO tofac_data_status (client_nbr,
			      branch_cd,
			      account_cd,
				      record_type_cd,
				      action_cd,
				      indifren_stts_cd,
				      indifren_updt_dt,
				      indifrec_stts_cd,
				      indifrec_updt_dt,
				      indifxdn_stts_cd,
				      indifxdn_updt_dt,
				      indifxdc_stts_cd,
				      indifxdc_updt_dt,
				      indiipcy_stts_cd,
				      indiipcy_updt_dt,
				      cpd1mmnm_stts_cd,
				      cpd1mmnm_updt_dt,
				      cpd2spnm_stts_cd,
				      cpd2spnm_updt_dt,
				      nadpnam1_stts_cd,
				      nadpnam1_updt_dt,
				      nadpnam2_stts_cd,
				      nadpnam2_updt_dt,
				      nataslin_stts_cd,
				      nataslin_updt_dt,
				      nataclin_stts_cd,
				      nataclin_updt_dt,
				      nayesshd_stts_cd,
				      nayesshd_updt_dt,
				      naye2ndp_stts_cd,
				      naye2ndp_updt_dt,
				      nayectry_stts_cd,
				      nayectry_updt_dt,
				      ofac_stts_updt_id,
				      ofac_stts_updt_dt,
				      ofac_stts_cd,
				updt_last_tmstp)
			VALUES (@client_nbr,
			      @branch_cd,
			      @account_cd,
				      'NRZ',
				      'I',
				      @indifren_stts_cd,
				      @indifren_updt_dt,
				      @indifrec_stts_cd,
				      @indifrec_updt_dt,
				      @indifxdn_stts_cd,
				      @indifxdn_updt_dt,
				      @indifxdc_stts_cd,
				      @indifxdc_updt_dt,
				      @indiipcy_stts_cd,
				      @indiipcy_updt_dt,
				      @cpd1mmnm_stts_cd,
				      @cpd1mmnm_updt_dt,
				      @cpd2spnm_stts_cd,
				      @cpd2spnm_updt_dt,
				      @nadpnam1_stts_cd,
				      @nadpnam1_updt_dt,
				      @nadpnam2_stts_cd,
				      @nadpnam2_updt_dt,
				      @nataslin_stts_cd,
				      @nataslin_updt_dt,
				      @nataclin_stts_cd,
				      @nataclin_updt_dt,
				      @nayesshd_stts_cd,
				      @nayesshd_updt_dt,
				      @naye2ndp_stts_cd,
				      @naye2ndp_updt_dt,
				      @nayectry_stts_cd,
				      @nayectry_updt_dt,
				      @ofac_stts_updt_id,
				      @ofac_stts_updt_dt,
				      @ofac_stts_cd,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrz
				
				select @error_description = 'update_nrz : tofac_data_status : Insert operation'
				
				raiserror 20148 "Insert operation to tofac_data_status failed"
				select @custom_error_code=@@error
							
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			COMMIT TRAN update_nrz
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nrz			
			/* update */
			
			/* now update realtime table row */
			UPDATE tofac_data_status
			SET action_cd = 'U',
			      record_type_cd = 'NRZ',
				indifren_stts_cd = @indifren_stts_cd,
				indifren_updt_dt = @indifren_updt_dt,
				indifrec_stts_cd = @indifrec_stts_cd,
				indifrec_updt_dt = @indifrec_updt_dt,
				indifxdn_stts_cd = @indifxdn_stts_cd,
				indifxdn_updt_dt = @indifxdn_updt_dt,
				indifxdc_stts_cd = @indifxdc_stts_cd,
				indifxdc_updt_dt = @indifxdc_updt_dt,
				indiipcy_stts_cd = @indiipcy_stts_cd,
				indiipcy_updt_dt = @indiipcy_updt_dt,
				cpd1mmnm_stts_cd = @cpd1mmnm_stts_cd,
				cpd1mmnm_updt_dt = @cpd1mmnm_updt_dt,
				cpd2spnm_stts_cd = @cpd2spnm_stts_cd,
				cpd2spnm_updt_dt = @cpd2spnm_updt_dt,
				nadpnam1_stts_cd = @nadpnam1_stts_cd,
				nadpnam1_updt_dt = @nadpnam1_updt_dt,
				nadpnam2_stts_cd = @nadpnam2_stts_cd,
				nadpnam2_updt_dt = @nadpnam2_updt_dt,
				nataslin_stts_cd = @nataslin_stts_cd,
				nataslin_updt_dt = @nataslin_updt_dt,
				nataclin_stts_cd = @nataclin_stts_cd,
				nataclin_updt_dt = @nataclin_updt_dt,
				nayesshd_stts_cd = @nayesshd_stts_cd,
				nayesshd_updt_dt = @nayesshd_updt_dt,
				naye2ndp_stts_cd = @naye2ndp_stts_cd,
				naye2ndp_updt_dt = @naye2ndp_updt_dt,
				nayectry_stts_cd = @nayectry_stts_cd,
				nayectry_updt_dt = @nayectry_updt_dt,
				ofac_stts_updt_id = @ofac_stts_updt_id,
				ofac_stts_updt_dt = @ofac_stts_updt_dt,
				ofac_stts_cd = @ofac_stts_cd,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrz
				
				select @error_description = 'update_nrz : tofac_data_status : Update operation'
				
				raiserror 20149 "Update operation to tofac_data_status failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
			COMMIT TRAN update_nrz
		
		END
				
	END
	ELSE
	IF (@action_cd = 'D')
	BEGIN
		
		BEGIN TRAN update_nrz
		
		/* now delete realtime table row */

		DELETE tofac_data_status
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrz
			
			select @error_description = 'update_nrz : tofac_data_status : Delete operation'
			
			raiserror 20150 "Delete operation to tofac_data_status failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nrz
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nrz to fbi
go

IF OBJECT_ID('dbo.update_nrz') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrz >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrz >>>'
go