/*
$Header: /rtapp/stp/update_nah.sql 1     3/25/02 10:41a Tbprven $
$Log: /rtapp/stp/update_nah.sql $
 * 
 * 1     3/25/02 10:41a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nah') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nah
    IF OBJECT_ID('dbo.update_nah') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nah >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nah >>>'
END
go

CREATE PROC update_nah
      @client_nbr	char(4),
      @branch_cd char(3),
      @account_cd char(5),
      @rr_cd char(3) ,
      @action char(1) ,
      @agreement_new_cd char(3) = null,
      @account_prfsn_cd char(1) = null,
      @tse_rama_cd char(3) = null,
      @fins_cd char(4) = null,
      @cdcc_clearing_cd char(1) = null,
      @broker_approved_cd char(1) = null,
      @cmmsn_mnmm_tse_rt decimal(5,3) = null,
      @trd_turnaround_ind char(1) = null,
      @taper_cd char(1) = null,
      @chrg_out_town_amt decimal(7,2) = null,
      @cnclt_charge_amt decimal(7,2) = null,
      @custodial_freq_cd char(1) = null,
      @custodial_chrg_amt decimal(7,2) = null,
      @dvdnd_int_chrg_rt decimal(5,3) = null,
      @credit_limit_amt int = null,
      @deliver_days_qty smallint = null,
      @prospectus_mail_cd char(1) = null,
      @documents_no_cd char(1) = null,
      @spcl_mrgn_rqrd_rt decimal(5,2) = null,
      @spcl_mrgn_rqrd_pct decimal(5,2) = null,
      @branch_parent_cd char(3) = null,
      @account_parent_cd char(5) = null,
      @stock_withhold_rt decimal(9,7) = null,
      @bond_withhold_rt decimal(9,7) = null,
      @brch_rotng_ofc_cd char(3) = null,
      @fixed_amt int = null,
      @key_short_nm char(20) = null,
      @party_rgsty_3_nbr char(5) = null,
      @user_1_cd char(1) = null,
      @user_2_cd char(1) = null,
      @user_3_cd char(1) = null,
      @user_4_cd char(1) = null,
      @user_5_cd char(1) = null,
      @spcl_instn_1_txt char(30) = null,
      @spcl_instn_2_txt char(30) = null,
      @dept_cd char(3) = null,
      @acct_instl_1_cd char(9) = null,
      @short_nm char(14) = null,
      @acct_instl_2_cd char(3) = null,
      @bank_cndn_nbr char(4) = null,
      @transit_cndn_nbr char(5) = null,
      @acct_cndn_bank_cd char(12) = null,
      @bank_usa_nbr char(4) = null,
      @trnst_bank_usa_nbr char(5) = null,
      @acct_bank_usa_cd char(8) = null,
      @minimum_execn_qty smallint = null,
      @aft_dt datetime = null,
      @payment_mode_cd char(1) = null,
      @cuid_cd char(4) = null,
      @corprt_contact_nm char(7) = null,
      @sub_account_cd char(3) = null,
      @issuer_cd char(4) = null,
      @rsp_inst1_nm char(20) = null,
      @rsp_inst2_nm char(20) = null,
      @disc_shr_excl_cd char(3) = null,
      @tex_cd char(3) = null,
      @aft_dt_cd char(2) = null,
      @crarq_cd    char(1) = null,
      @acct_bank_usa_nbr char(12) = null

AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM taccount_canada
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 
			   
		SELECT @tbl_rowcount = @@rowcount
	        
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nah
			
			/* now insert into realtime table */
			INSERT INTO taccount_canada (client_nbr  ,
			      branch_cd  ,
			      account_cd ,
			      agreement_new_cd  ,
			      account_prfsn_cd  ,
			      tse_rama_cd  ,
			      fins_cd  ,
			      cdcc_clearing_cd  ,
			      broker_approved_cd  ,
			      cmmsn_mnmm_tse_rt  ,
			      trd_turnaround_ind  ,
			      taper_cd ,
			      chrg_out_town_amt  ,
			      cnclt_charge_amt  ,
			      custodial_freq_cd  ,
			      custodial_chrg_amt  ,
			      dvdnd_int_chrg_rt  ,
			      credit_limit_amt  ,
			      deliver_days_qty  ,
			      prospectus_mail_cd ,
			      documents_no_cd  ,
			      spcl_mrgn_rqrd_rt  ,
			      spcl_mrgn_rqrd_pct  ,
			      branch_parent_cd  ,
			      account_parent_cd ,
			      stock_withhold_rt  ,
			      bond_withhold_rt  ,
			      brch_rotng_ofc_cd ,
			      fixed_amt ,
			      key_short_nm  ,
			      party_rgsty_3_nbr ,
			      user_1_cd  ,
			      user_2_cd  ,
			      user_3_cd  ,
			      user_4_cd  ,
			      user_5_cd  ,
			      spcl_instn_1_txt  ,
			      spcl_instn_2_txt  ,
			      dept_cd  ,
			      acct_instl_1_cd  ,
			      short_nm  ,
			      acct_instl_2_cd ,
			      bank_cndn_nbr ,
			      transit_cndn_nbr  ,
			      acct_cndn_bank_cd  ,
			      bank_usa_nbr ,
			      trnst_bank_usa_nbr ,
			      acct_bank_usa_cd ,
			      minimum_execn_qty  ,
			      aft_dt ,
			      payment_mode_cd ,
			      record_type_cd ,
			      action ,
			      rr_cd  ,
			      cuid_cd ,
			      corprt_contact_nm ,
			      sub_account_cd ,
			      issuer_cd ,
			      rsp_inst1_nm ,
			      rsp_inst2_nm,
				  disc_shr_excl_cd,
				  tex_cd,
				aft_dt_cd,
				crarq_cd,
				acct_bank_usa_nbr,
				updt_last_tmstp)
			VALUES (@client_nbr  ,
			      @branch_cd  ,
			      @account_cd ,
			      @agreement_new_cd  ,
			      @account_prfsn_cd  ,
			      @tse_rama_cd  ,
			      @fins_cd  ,
			      @cdcc_clearing_cd  ,
			      @broker_approved_cd  ,
			      @cmmsn_mnmm_tse_rt  ,
			      @trd_turnaround_ind  ,
			      @taper_cd ,
			      @chrg_out_town_amt  ,
			      @cnclt_charge_amt  ,
			      @custodial_freq_cd  ,
			      @custodial_chrg_amt  ,
			      @dvdnd_int_chrg_rt  ,
			      @credit_limit_amt  ,
			      @deliver_days_qty  ,
			      @prospectus_mail_cd ,
			      @documents_no_cd  ,
			      @spcl_mrgn_rqrd_rt  ,
			      @spcl_mrgn_rqrd_pct  ,
			      @branch_parent_cd  ,
			      @account_parent_cd ,
			      @stock_withhold_rt  ,
			      @bond_withhold_rt  ,
			      @brch_rotng_ofc_cd ,
			      @fixed_amt ,
			      @key_short_nm  ,
			      @party_rgsty_3_nbr ,
			      @user_1_cd  ,
			      @user_2_cd  ,
			      @user_3_cd  ,
			      @user_4_cd  ,
			      @user_5_cd  ,
			      @spcl_instn_1_txt  ,
			      @spcl_instn_2_txt  ,
			      @dept_cd  ,
			      @acct_instl_1_cd  ,
			      @short_nm  ,
			      @acct_instl_2_cd ,
			      @bank_cndn_nbr ,
			      @transit_cndn_nbr  ,
			      @acct_cndn_bank_cd  ,
			      @bank_usa_nbr ,
			      @trnst_bank_usa_nbr ,
			      @acct_bank_usa_cd ,
			      @minimum_execn_qty  ,
			      @aft_dt,
			      @payment_mode_cd ,
			      'NAH' ,
			      'I' ,
			      @rr_cd  ,
			      @cuid_cd ,
			      @corprt_contact_nm ,
			      @sub_account_cd ,
			      @issuer_cd ,
			      @rsp_inst1_nm ,
			      @rsp_inst2_nm,
				  @disc_shr_excl_cd,
				  @tex_cd,
				@aft_dt_cd,
				@crarq_cd,
				@acct_bank_usa_nbr,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nah
				
				select @error_description = 'update_nah : taccount_canada : Insert operation'
				
				raiserror 20067 "Insert operation to taccount_canada failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nah
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nah			
			/* update */
	
			/* now update realtime table row */
			UPDATE taccount_canada
			SET agreement_new_cd = @agreement_new_cd ,
			      account_prfsn_cd = @account_prfsn_cd ,
			      tse_rama_cd = @tse_rama_cd ,
			      fins_cd = @fins_cd ,
			      cdcc_clearing_cd = @cdcc_clearing_cd ,
			      broker_approved_cd = @broker_approved_cd ,
			      cmmsn_mnmm_tse_rt = @cmmsn_mnmm_tse_rt ,
			      trd_turnaround_ind = @trd_turnaround_ind ,
			      taper_cd = @taper_cd,
			      chrg_out_town_amt = @chrg_out_town_amt ,
			      cnclt_charge_amt = @cnclt_charge_amt ,
			      custodial_freq_cd = @custodial_freq_cd ,
			      custodial_chrg_amt = @custodial_chrg_amt ,
			      dvdnd_int_chrg_rt = @dvdnd_int_chrg_rt ,
			      credit_limit_amt = @credit_limit_amt ,
			      deliver_days_qty = @deliver_days_qty ,
			      prospectus_mail_cd = @prospectus_mail_cd,
			      documents_no_cd = @documents_no_cd ,
			      spcl_mrgn_rqrd_rt = @spcl_mrgn_rqrd_rt ,
			      spcl_mrgn_rqrd_pct = @spcl_mrgn_rqrd_pct ,
			      branch_parent_cd = @branch_parent_cd ,
			      account_parent_cd = @account_parent_cd,
			      stock_withhold_rt = @stock_withhold_rt ,
			      bond_withhold_rt = @bond_withhold_rt ,
			      brch_rotng_ofc_cd = @brch_rotng_ofc_cd,
			      fixed_amt = @fixed_amt,
			      key_short_nm = @key_short_nm ,
			      party_rgsty_3_nbr = @party_rgsty_3_nbr,
			      user_1_cd = @user_1_cd ,
			      user_2_cd = @user_2_cd ,
			      user_3_cd = @user_3_cd ,
			      user_4_cd = @user_4_cd ,
			      user_5_cd = @user_5_cd ,
			      spcl_instn_1_txt = @spcl_instn_1_txt ,
			      spcl_instn_2_txt = @spcl_instn_2_txt ,
			      dept_cd = @dept_cd ,
			      acct_instl_1_cd = @acct_instl_1_cd ,
			      short_nm = @short_nm ,
			      acct_instl_2_cd = @acct_instl_2_cd,
			      bank_cndn_nbr = @bank_cndn_nbr,
			      transit_cndn_nbr = @transit_cndn_nbr ,
			      acct_cndn_bank_cd = @acct_cndn_bank_cd ,
			      bank_usa_nbr = @bank_usa_nbr,
			      trnst_bank_usa_nbr = @trnst_bank_usa_nbr,
			      acct_bank_usa_cd = @acct_bank_usa_cd,
			      minimum_execn_qty = @minimum_execn_qty ,
			      aft_dt = @aft_dt,
			      payment_mode_cd = @payment_mode_cd,
			      record_type_cd = 'NAH',
			      action = 'U',
			      rr_cd = @rr_cd ,
			      cuid_cd = @cuid_cd ,
			      corprt_contact_nm = @corprt_contact_nm ,
			      sub_account_cd = @sub_account_cd,
			      issuer_cd = @issuer_cd,
			      rsp_inst1_nm = @rsp_inst1_nm,
			      rsp_inst2_nm = @rsp_inst2_nm,
				  disc_shr_excl_cd = @disc_shr_excl_cd,
				  tex_cd = @tex_cd,
				aft_dt_cd = @aft_dt_cd,
				crarq_cd = @crarq_cd,
				acct_bank_usa_nbr = @acct_bank_usa_nbr,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd 

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nah
				
				select @error_description = 'update_nah : taccount_canada : Update operation'
				
				raiserror 20068 "Update operation to taccount_canada failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
		 COMMIT TRAN update_nah
		 	 
		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nah
	
		/* now delete realtime table row */
		DELETE taccount_canada
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nah
			
			select @error_description = 'update_nah:taccount_canada: Delete operation'
			
			raiserror 20069 "Delete operation to taccount_canada failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END

		COMMIT TRAN update_nah
		
	END
   
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
   
END

go

grant execute on update_nah to fbi
go

IF OBJECT_ID('dbo.update_nah') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nah >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nah >>>'
go