/*****************************************************************************
NAME: update_rsf.sql
PURPOSE: Insert and update trrif_pymnt table
REVISIONS:
Ver	SSR	Date	  Author	Description
-------	-------	--------- ------------- -------------------------------------
1.0	112029	5/2/16  J Shen	Added a new field pymnt_schdl_crncy
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_rsf') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_rsf
    IF OBJECT_ID('dbo.update_rsf') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_rsf >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_rsf >>>'
END
go

CREATE PROC update_rsf
	@client_nbr		char(4),
	@branch_cd		char(3),
	@account_cd		char(5),
	@action 	        char(1),
	@rrif_pln_yrend_amt	decimal(11,2),        
	@rrif_term_nbr		smallint,
	@pymnt_freq_cd		char(1),
	@pymnt_mthd_cd		char(5),
	@bank_cd		char(4),
	@bank_trnst_cd		char(5),
	@bank_acct_nbr		char(15),
	@grss_net_cd		char(1),
	@wthld_tax_optn_cd	char(1),
	@pymnt_frst_dt		datetime,        
	@pay_amt		decimal(9,2),        
	@elected_pymt_amt	decimal(9,2),        
	@pay_min_amt		decimal(9,2),       
	@pymnt_altnt_dt		datetime,        
	@grss_net_altnt_cd	char(1),        
	@sps_cntrb_ind		char(1),       
	@vrbl_pymnt_cd		char(1),       
	@fdrl_tax_rt		decimal(5,5),        
	@prvnc_tax_rt		decimal(5,5),       
	@flat_tax_amt		decimal(7,2),        
	@br_offst_cd		char(3),        
	@acct_offst_cd		char(5),        
	@type_acct_offst_cd 	char(1),       
	@calc_cd		char(1),        
	@pymnt_altnt_ftr_cd 	char(1),        
	@thrd_prty_inst_ind 	char(1),        
	@wthld_tax_optn_ind 	char(1),        
	@fdrl_tax_altnt_rt	decimal(5,5),        
	@prvnc_tax_altnt_rt 	decimal(5,5),        
	@pymnt_lst_dt		datetime,     
	@pymnt_max_amt		decimal(9,2),      
	@ytd_trnfr_in_amt	decimal(9,2),       
	@ytd_trnfr_ot_amt	decimal(9,2),        
	@ytd_incm_amt		decimal(9,2),      
	@yr_prev_pln_amt	decimal(11,2),        
	@ytd_pymnt_amt		decimal(9,2),        
	@ytd_fdrl_tax_amt	decimal(9,2),        
	@ytd_nr_tax_amt		decimal(9,2),        
	@ytd_prvnc_tax_amt  	decimal(9,2),    
	@pymnt_max_ind		char(1),       
	@tax_id			char(9),      
	@resp_plan_type_cd	char(1),       
	@edctn_inst_id		char(4),        
	@plan_orgn_dt		datetime,        
	@prev_spcmn_plan_nbr	char(10),      
	@prev_cntrt_id      	char(15),
	@dnu_start_dt		char(7) = null,
	@dnu_end_dt		char(7) = null,
	@pymnt_crncy_cd		char(3) = null,
	@resp_sblng_only_cd   char(1) = null,
	@pymnt_schdl_crncy char(1) = null
AS
BEGIN
	
	DECLARE @action_cd char(1),
        @tbl_security_adp_nbr char(7),
        @start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)

	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @action_cd = action_cd
		FROM trrif_pymnt
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd
			
		IF @@rowcount = 0
		BEGIN
			BEGIN TRAN update_rsf
			
			/* insert, first into realtime table */
			INSERT INTO trrif_pymnt (client_nbr,
					branch_cd,
					account_cd,
					rrif_pln_yrend_amt,        
					rrif_term_nbr,
					pymnt_freq_cd,
					pymnt_mthd_cd,
					bank_cd,
					bank_trnst_cd,
					bank_acct_nbr,
					grss_net_cd,
					wthld_tax_optn_cd,
					pymnt_frst_dt,        
					pay_amt,        
					elected_pymt_amt,        
					pay_min_amt,       
					pymnt_altnt_dt,        
					grss_net_altnt_cd,        
					sps_cntrb_ind,       
					vrbl_pymnt_cd,       
					fdrl_tax_rt,        
					prvnc_tax_rt,       
					flat_tax_amt,        
					br_offst_cd,        
					acct_offst_cd,        
					type_acct_offst_cd,       
					calc_cd,        
					pymnt_altnt_ftr_cd,        
					thrd_prty_inst_ind,        
					wthld_tax_optn_ind,        
					fdrl_tax_altnt_rt,        
					prvnc_tax_altnt_rt,        
					pymnt_lst_dt,     
					pymnt_max_amt,      
					ytd_trnfr_in_amt,       
					ytd_trnfr_ot_amt,        
					ytd_incm_amt,      
					yr_prev_pln_amt,        
					ytd_pymnt_amt,        
					ytd_fdrl_tax_amt,        
					ytd_nr_tax_amt,        
					ytd_prvnc_tax_amt,    
					pymnt_max_ind,       
					tax_id,      
					resp_plan_type_cd,       
					edctn_inst_id,        
					plan_orgn_dt,        
					prev_spcmn_plan_nbr,      
					prev_cntrt_id,
					action_cd,
					record_type_cd,
					dnu_start_dt,
					dnu_end_dt,
					pymnt_crncy_cd,
					resp_sblng_only_cd,
					pymnt_schdl_crncy,
					updt_last_tmstp )
			VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					@rrif_pln_yrend_amt,        
					@rrif_term_nbr,
					@pymnt_freq_cd,
					@pymnt_mthd_cd,
					@bank_cd,
					@bank_trnst_cd,
					@bank_acct_nbr,
					@grss_net_cd,
					@wthld_tax_optn_cd,
					@pymnt_frst_dt,        
					@pay_amt,        
					@elected_pymt_amt,        
					@pay_min_amt,       
					@pymnt_altnt_dt,        
					@grss_net_altnt_cd,        
					@sps_cntrb_ind,       
					@vrbl_pymnt_cd,       
					@fdrl_tax_rt,        
					@prvnc_tax_rt,       
					@flat_tax_amt,        
					@br_offst_cd,        
					@acct_offst_cd,        
					@type_acct_offst_cd,       
					@calc_cd,        
					@pymnt_altnt_ftr_cd,        
					@thrd_prty_inst_ind,        
					@wthld_tax_optn_ind,        
					@fdrl_tax_altnt_rt,        
					@prvnc_tax_altnt_rt,        
					@pymnt_lst_dt,     
					@pymnt_max_amt,      
					@ytd_trnfr_in_amt,       
					@ytd_trnfr_ot_amt,        
					@ytd_incm_amt,      
					@yr_prev_pln_amt,        
					@ytd_pymnt_amt,        
					@ytd_fdrl_tax_amt,        
					@ytd_nr_tax_amt,        
					@ytd_prvnc_tax_amt,    
					@pymnt_max_ind,       
					@tax_id,      
					@resp_plan_type_cd,       
					@edctn_inst_id,        
					@plan_orgn_dt,        
					@prev_spcmn_plan_nbr,      
					@prev_cntrt_id,
					'I',
					'RSF',
					@dnu_start_dt,
					@dnu_end_dt,
					@pymnt_crncy_cd,
					@resp_sblng_only_cd,
					@pymnt_schdl_crncy,
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsf
				
				select @error_description = 'update_rsf : trrif_pymnt : Insert operation'
				
				raiserror 20166 "Insert operation to trrif_pymnt failed"
				select @custom_error_code=@@error
								
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
					
			COMMIT TRAN update_rsf
		END
		ELSE
		BEGIN
			BEGIN TRAN update_rsf

			/*  update realtime table row */
			UPDATE trrif_pymnt 
			SET client_nbr = @client_nbr,
				branch_cd = @branch_cd,
				account_cd = @account_cd,
				rrif_pln_yrend_amt = @rrif_pln_yrend_amt,        
				rrif_term_nbr = @rrif_term_nbr,
				pymnt_freq_cd = @pymnt_freq_cd,
				pymnt_mthd_cd = @pymnt_mthd_cd,
				bank_cd = @bank_cd,
				bank_trnst_cd = @bank_trnst_cd,
				bank_acct_nbr = @bank_acct_nbr,
				grss_net_cd = @grss_net_cd,
				wthld_tax_optn_cd = @wthld_tax_optn_cd,
				pymnt_frst_dt = @pymnt_frst_dt,   
				pay_amt = @pay_amt,        
				elected_pymt_amt = @elected_pymt_amt,        
				pay_min_amt = @pay_min_amt,       
				pymnt_altnt_dt = @pymnt_altnt_dt,        
				grss_net_altnt_cd = @grss_net_altnt_cd,        
				sps_cntrb_ind = @sps_cntrb_ind,       
				vrbl_pymnt_cd = @vrbl_pymnt_cd,       
				fdrl_tax_rt = @fdrl_tax_rt,        
				prvnc_tax_rt = @prvnc_tax_rt,       
				flat_tax_amt = @flat_tax_amt,        
				br_offst_cd = @br_offst_cd,        
				acct_offst_cd = @acct_offst_cd,        
				type_acct_offst_cd = @type_acct_offst_cd,       
				calc_cd = @calc_cd,        
				pymnt_altnt_ftr_cd = @pymnt_altnt_ftr_cd,        
				thrd_prty_inst_ind = @thrd_prty_inst_ind,        
				wthld_tax_optn_ind = @wthld_tax_optn_ind,        
				fdrl_tax_altnt_rt = @fdrl_tax_altnt_rt,        
				prvnc_tax_altnt_rt = @prvnc_tax_altnt_rt,        
				pymnt_lst_dt = @pymnt_lst_dt,     
				pymnt_max_amt = @pymnt_max_amt,      
				ytd_trnfr_in_amt = @ytd_trnfr_in_amt,       
				ytd_trnfr_ot_amt = @ytd_trnfr_ot_amt,        
				ytd_incm_amt = @ytd_incm_amt,      
				yr_prev_pln_amt = @yr_prev_pln_amt,        
				ytd_pymnt_amt = @ytd_pymnt_amt,        
				ytd_fdrl_tax_amt = @ytd_fdrl_tax_amt,        
				ytd_nr_tax_amt = @ytd_nr_tax_amt,        
				ytd_prvnc_tax_amt = @ytd_prvnc_tax_amt,    
				pymnt_max_ind = @pymnt_max_ind,       
				tax_id = @tax_id,      
				resp_plan_type_cd = @resp_plan_type_cd,       
				edctn_inst_id = @edctn_inst_id,        
				plan_orgn_dt = @plan_orgn_dt,        
				prev_spcmn_plan_nbr = @prev_spcmn_plan_nbr,      
				prev_cntrt_id = @prev_cntrt_id,
				action_cd = 'U',
				record_type_cd = 'RSF',
				dnu_start_dt = @dnu_start_dt,
				dnu_end_dt = @dnu_end_dt,
				pymnt_crncy_cd = @pymnt_crncy_cd,
				resp_sblng_only_cd = @resp_sblng_only_cd,
				pymnt_schdl_crncy = @pymnt_schdl_crncy,
				updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsf
				
				select @error_description = 'update_rsf : trrif_pymnt : Update operation'
				
				raiserror 20167 "Update operation to trrif_pymnt failed"
                select @custom_error_code=@@error
				
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			    
			COMMIT TRAN update_rsf    
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		BEGIN TRAN update_rsf
		
		/*delete realtime table row */
		DELETE trrif_pymnt 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_rsf
			
			select @error_description = 'update_rsf : trrif_pymnt : Delete operation'
			
			raiserror 20168 "Delete operation to trrif_pymnt failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
					
	    COMMIT TRAN update_rsf		    
	END

	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_rsf to fbi
go

IF OBJECT_ID('dbo.update_rsf') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_rsf >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_rsf >>>'
go