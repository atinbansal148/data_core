/*
$Header: /Realtime/Realtime/stp/update_msi.sql 4     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msi.sql $
 * 
 * 4     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 3     6/29/00 5:20p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msi') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msi
    IF OBJECT_ID('dbo.update_msi') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msi >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msi >>>'
END
go

CREATE PROC update_msi
	@security_adp_nbr		char(7),
	@call_dt				datetime,
	@call_prc_amt			decimal(9,5)

AS
BEGIN
  
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr char(7),
			@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + convert(char(30),@call_dt,116)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tcall_price WHERE
		call_dt = @call_dt AND
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msi
		/* insert */
		INSERT INTO tcall_price (	security_adp_nbr,
						call_dt,
						call_prc_amt,
						record_type_cd,
						action_cd )
		VALUES (	@security_adp_nbr,
					@call_dt,
					@call_prc_amt,
					'MSI',
					'I' )
					
		SELECT @syb_error_code = @@error
		
		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msi
			
			select @error_description = 'update_msi : tcall_price : Insert operation'
			
			raiserror 20041 "Insert operation to tcall_price failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END

		COMMIT TRAN update_msi
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msi
		/* update */

		/* now update real-time table */
		UPDATE tcall_price SET
			call_dt = @call_dt,
			call_prc_amt = @call_prc_amt,
			record_type_cd = 'MSI',
			action_cd = 'U'
		WHERE call_dt = @call_dt AND
			security_adp_nbr = @security_adp_nbr
			
		SELECT @syb_error_code = @@error
		
		if @syb_error_code !=0
		BEGIN
			
			ROLLBACK TRAN update_msi
			
			select @error_description = 'update_msi: tcall_price: Update operation'
			
			raiserror 20042 "Update operation to tcall_price failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		COMMIT TRAN update_msi
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_msi to fbi
go

IF OBJECT_ID('dbo.update_msi') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msi >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msi >>>'
go