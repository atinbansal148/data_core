/*
$Header: /rtapp/stp/update_nru.sql 1     3/25/02 10:46a Tbprven $
$Log: /rtapp/stp/update_nru.sql $
 * 
 * 1     3/25/02 10:46a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nru') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nru
    IF OBJECT_ID('dbo.update_nru') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nru >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nru >>>'
END
go

CREATE PROC update_nru
      @client_nbr	char(4)   ,
      @branch_cd char(3)   ,
      @account_cd char(5)   ,
      @rr_cd char(3)  ,
      @action char(1)  ,
      @trd_inst_seq_nbr smallint    = null ,
      @fins_cd char(4) = null
 AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@trd_inst_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
				
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM ttrdg_fnncl_inst
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
		           trd_inst_seq_nbr = @trd_inst_seq_nbr
		           
		SELECT @tbl_rowcount = @@rowcount
		
		IF @tbl_rowcount = 0
		BEGIN
		
		    BEGIN TRAN update_nru

			/* insert into realtime table */
			INSERT INTO ttrdg_fnncl_inst (client_nbr ,
			      branch_cd  ,
			      account_cd  ,
			      trd_inst_seq_nbr,
			      action ,
			      record_type_cd ,
			      rr_cd ,
			      fins_cd,
				updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd  ,
			      @account_cd  ,
			      @trd_inst_seq_nbr,
			      'I' ,
			      'NRU' ,
			      @rr_cd ,
			      @fins_cd,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nru
				
				select @error_description = 'update_nru : ttrdg_fnncl_inst : Insert operation'
				
				raiserror 20136 "Insert operation to ttrdg_fnncl_inst failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nru
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nru			
			/* update */

			/* now update realtime table row */
			UPDATE ttrdg_fnncl_inst
			SET action = 'U',
			      record_type_cd ='NRU',
			      rr_cd = @rr_cd ,
			      fins_cd = @fins_cd,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
		           	trd_inst_seq_nbr = @trd_inst_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nru
				
				select @error_description = 'update_nru : ttrdg_fnncl_inst : Update operation'
				
				raiserror 20137 "Update operation to ttrdg_fnncl_inst failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
			COMMIT TRAN update_nru
		END
				
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nru

		/* now delete realtime table row */
		DELETE ttrdg_fnncl_inst
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nru
			
			select @error_description = 'update_nru : ttrdg_fnncl_inst : Delete operation'
			
			raiserror 20138 "Delete operation to ttrdg_fnncl_inst failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
	
		COMMIT TRAN update_nru
	END
  
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nru to fbi
go

IF OBJECT_ID('dbo.update_nru') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nru >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nru >>>'
go
