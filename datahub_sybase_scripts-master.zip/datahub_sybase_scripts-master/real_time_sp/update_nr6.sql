/*
$Header: /rtapp/stp/update_nr6.sql 1     3/25/02 10:44a Tbprven $
$Log: /rtapp/stp/update_nr6.sql $
 * 
 * 1     3/25/02 10:44a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nr6') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nr6
    IF OBJECT_ID('dbo.update_nr6') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nr6 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nr6 >>>'
END
go

CREATE PROC update_nr6
	     @client_nbr char(4),
	     @branch_cd char(3),
	     @account_cd char(5),
	     @rr_cd      char(3),
	     @action     char,
	     @ina_tag_cd char(20) = null ,
	     @ina_srce_cd char(4) = null ,
	     @ina_pend_ind  char(1) = null ,
		 @ina_rjct_ind  char(1) = null
      
      
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
					
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM taccount_ina
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 
			   
		SELECT @tbl_rowcount = @@rowcount	
	                
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nr6
			
			/* insert into realtime table */
			INSERT INTO taccount_ina (client_nbr ,
				     branch_cd ,
				     account_cd ,
				     record_type_cd,
				     action_cd ,
				     rr_cd ,
				     ina_tag_cd,
				     ina_srce_cd ,
				     ina_pend_ind,
				     ina_rjct_ind ,
				     updt_last_tmstp)
			VALUES (@client_nbr ,
				     @branch_cd ,
				     @account_cd ,
				     'NR6',
				     'I' ,
				     @rr_cd ,
				     @ina_tag_cd,
				     @ina_srce_cd ,
				     @ina_pend_ind,
				     @ina_rjct_ind ,
				     getdate())
			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr6
				
				select @error_description = 'update_nr6 : taccount_ina : Insert operation'
				
				raiserror 20097 "Insert operation to taccount_ina failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nr6
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nr6
			
			/* update */
			
			/* modify action_cd to reflect update if not inserted today */
			IF @db_action_cd != 'I'
				SELECT @db_action_cd = 'U'
				
			/* now update realtime table row */
			UPDATE taccount_ina
			SET record_type_cd = 'NR6',
	                    action_cd = 'U' ,
	                    rr_cd = @rr_cd,
	                    ina_tag_cd = @ina_tag_cd,
	                    ina_srce_cd = @ina_srce_cd,
	                    ina_pend_ind = @ina_pend_ind,
                        ina_rjct_ind = @ina_rjct_ind,
						updt_last_tmstp	   = getdate()			
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd 

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr6
				
				select @error_description = 'update_nr6 : taccount_ina : Update operation'
				
				raiserror 20098 "Update operation to taccount_ina failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			COMMIT TRAN update_nr6

		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nr6
		
		/* now delete realtime table row */
		DELETE taccount_ina
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nr6
			
			select @error_description = 'update_nr6 : taccount_ina : Delete operation'
			
			raiserror 20099 "Delete operation to taccount_ina failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nr6
	END
 
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
 
END

go

grant execute on update_nr6 to fbi
go

IF OBJECT_ID('dbo.update_nr6') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nr6 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nr6 >>>'
go
