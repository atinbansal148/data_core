/*
$Header: /Realtime/Realtime/stp/update_msf.sql 4     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msf.sql $
 * 
 * 4     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 3     6/29/00 5:18p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msf') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msf
    IF OBJECT_ID('dbo.update_msf') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msf >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msf >>>'
END
go

CREATE PROC update_msf
	@security_adp_nbr		char(7),
	@type_income_cd			char(2),
	@record_dt				datetime,
	@exdividend_dt			datetime,
	@payment_dt				datetime,
	@dividend_rt			decimal(15,8),
	@div_csh1_paytyp_cd		char(3),
	@div_csh2_paytyp_cd		char(3),
	@div_stk_paytyp_cd		char(3),
	@div_rght_paytyp_cd		char(3)

AS
BEGIN
  
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr 	char(7),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
		
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @type_income_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tincome_data WHERE
		type_income_cd = @type_income_cd AND
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msf
		/* insert */
		INSERT INTO tincome_data (security_adp_nbr,
					type_income_cd,
					record_dt,
					exdividend_dt,
					payment_dt,
					dividend_rt,
					record_type_cd,
					action_cd,
					div_csh1_paytyp_cd,
					div_csh2_paytyp_cd,
					div_stk_paytyp_cd,
					div_rght_paytyp_cd)
		VALUES (	@security_adp_nbr,
					@type_income_cd,
					@record_dt,
					@exdividend_dt,
					@payment_dt,
					@dividend_rt,
					'MSF',
					'I',
					@div_csh1_paytyp_cd,
					@div_csh2_paytyp_cd,
					@div_stk_paytyp_cd,
					@div_rght_paytyp_cd)
					
					SELECT @syb_error_code = @@error
					
		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msf
			
			select @error_description = 'update_msf : tincome_data : Insert operation'
			
			raiserror 20035 "Insert operation to tincome_data failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END

		COMMIT TRAN update_msf
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msf
		/* update */

		/* now update real-time table */
		UPDATE tincome_data SET
			exdividend_dt = @exdividend_dt,
			payment_dt = @payment_dt,
			dividend_rt = @dividend_rt,
			record_type_cd = 'MSF',
			action_cd = 'U',
			div_csh1_paytyp_cd = @div_csh1_paytyp_cd,
			div_csh2_paytyp_cd = @div_csh2_paytyp_cd,
			div_stk_paytyp_cd = @div_stk_paytyp_cd,
			div_rght_paytyp_cd = @div_rght_paytyp_cd
		WHERE type_income_cd = @type_income_cd AND
			security_adp_nbr = @security_adp_nbr
			
			SELECT @syb_error_code = @@error

		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msf
			
			select @error_description = 'update_msf : tincome_data : Update operation'
			
			raiserror 20036 "Update operation to tincome_data failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_msf
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_msf to fbi
go

IF OBJECT_ID('dbo.update_msf') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msf >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msf >>>'
go