/*
$Header: /rtapp/stp/update_nrq.sql 1     3/25/02 10:45a Tbprven $
$Log: /rtapp/stp/update_nrq.sql $
 * 
 * 1     3/25/02 10:45a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrq') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrq
    IF OBJECT_ID('dbo.update_nrq') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrq >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrq >>>'
END
go

CREATE PROC update_nrq
      @client_nbr char(4) ,
      @branch_cd char(3) ,
      @account_cd char(5) ,
      @rr_cd char(3) ,
      @action char(1) ,
      @name_seq_nbr		smallint  = null ,
      @ap_type_cd char(1)  = null ,
      @first_nm char(20)  = null ,
      @mi_initial_txt char(1)  = null ,
      @last_nm char(20)  = null ,
      @title_prfx4_txt char(4)  = null ,
      @title_sffx4_txt char(4)  = null ,
      @company_nm char(35) = null
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@name_seq_nbr) 
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN

		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacct_prv_names
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   name_seq_nbr = @name_seq_nbr
			   
		SELECT @tbl_rowcount = @@rowcount
		
		IF @tbl_rowcount = 0
		BEGIN
		
			BEGIN TRAN update_nrq
 
		    /* insert into realtime table */
		    INSERT INTO tacct_prv_names (name_seq_nbr ,
		      client_nbr ,
		      branch_cd  ,
		      account_cd  ,
		      action  ,
		      record_type_cd  ,
		      rr_cd  ,
		      ap_type_cd  ,
		      first_nm ,
		      mi_initial_txt  ,
		      last_nm  ,
		      title_prfx4_txt ,
		      title_sffx4_txt ,
		      company_nm,
			updt_last_tmstp)
		    VALUES (@name_seq_nbr ,
		      @client_nbr ,
		      @branch_cd  ,
		      @account_cd  ,
		      'I'  ,
		      'NRQ' ,
		      @rr_cd  ,
		      @ap_type_cd  ,
		      @first_nm ,
		      @mi_initial_txt  ,
		      @last_nm  ,
		      @title_prfx4_txt ,
		      @title_sffx4_txt ,
		      @company_nm,
			getdate())

		    SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrq
				
				select @error_description = 'update_nrq : tacct_prv_names : Insert operation'
				
				raiserror 20124 "Insert operation to tacct_prv_names failed"
				select @custom_error_code=@@error
								
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		    
		    COMMIT TRAN update_nrq
	
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nrq
			/* update */
			
			/* now update realtime table row */
			UPDATE tacct_prv_names
			SET action = 'U' ,
			      record_type_cd = 'NRQ' ,
			      rr_cd = @rr_cd ,
			      ap_type_cd = @ap_type_cd ,
			      first_nm = @first_nm,
			      mi_initial_txt = @mi_initial_txt ,
			      last_nm = @last_nm ,
			      title_prfx4_txt = @title_prfx4_txt,
			      title_sffx4_txt = @title_sffx4_txt,
			      company_nm = @company_nm,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
				name_seq_nbr = @name_seq_nbr
			
			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrq
				
				select @error_description = 'update_nrq : tacct_prv_names : Update operation'
				
				raiserror 20125 "Update operation to tacct_prv_names failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
		COMMIT TRAN update_nrq
		
		END
				
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nrq
		
		/* now delete realtime table row */
		DELETE tacct_prv_names
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrq
			
			select @error_description = 'update_nrq : tacct_prv_names : Delete operation'
			
			raiserror 20126 "Delete operation to tacct_prv_names failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nrq
	END
  
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nrq to fbi
go

IF OBJECT_ID('dbo.update_nrq') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrq >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrq >>>'
go
