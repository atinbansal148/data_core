/*
$Header: /rtapp/stp/update_nr2.sql 1     3/25/02 10:43a Tbprven $
$Log: /rtapp/stp/update_nr2.sql $
 * 
 * 1     3/25/02 10:43a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nr2') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nr2
    IF OBJECT_ID('dbo.update_nr2') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nr2 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nr2 >>>'
END
go

CREATE PROC update_nr2
      @client_nbr		char(4)  ,
      @branch_cd char(3)  ,
      @account_cd char(5)  ,
      @rr_cd char(3)  ,
      @action char(1)  ,
      @primary_rr_ind char(1)   = null ,
      @rr_payout_net_pct decimal(7,4)   = null ,
      @rr_rgstr_exmpt_ind char(1)   = null ,
      @charge_postage_ind char(1)   = null ,
      @rr_interest_ind char(1)   = null ,
      @acct_exctv_pyt_ind char(1)   = null ,
      @rr_interest_1_txt char(20)   = null ,
      @rr_interest_2_txt char(20)   = null ,
      @rr_interest_3_txt char(20)   = null ,
      @lmt_dscrt_rr_ind char(1)     = null
AS
BEGIN
    
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @rr_cd 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM taccount_rr
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   rr_cd = @rr_cd
	        
		SELECT @tbl_rowcount = @@rowcount
	        
		IF @tbl_rowcount = 0
		BEGIN
			
			BEGIN TRAN update_nr2
			
			/* insert into realtime table */
			INSERT INTO taccount_rr (client_nbr ,
			      branch_cd ,
			      account_cd ,
			      rr_cd ,
			      action ,
			      record_type_cd ,
			      primary_rr_ind ,
			      rr_payout_net_pct,
			      rr_rgstr_exmpt_ind ,
			      charge_postage_ind ,
			      rr_interest_ind ,
			      acct_exctv_pyt_ind ,
			      rr_interest_1_txt ,
			      rr_interest_2_txt ,
			      rr_interest_3_txt ,
			      lmt_dscrt_rr_ind,
				updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd ,
			      @account_cd ,
			      @rr_cd ,
			      'I' ,
			      'NR2' ,
			      @primary_rr_ind ,
			      @rr_payout_net_pct,
			      @rr_rgstr_exmpt_ind ,
			      @charge_postage_ind ,
			      @rr_interest_ind ,
			      @acct_exctv_pyt_ind ,
			      @rr_interest_1_txt ,
			      @rr_interest_2_txt ,
			      @rr_interest_3_txt ,
			      @lmt_dscrt_rr_ind,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr2
				
				select @error_description = 'update_nr2 : taccount_rr : Insert operation'
				
				raiserror 20085 "Insert operation to taccount_rr failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nr2
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nr2			
			/* update */
	
			/* now update realtime table row */
			UPDATE taccount_rr
			SET action = 'U',
			      record_type_cd = 'NR2',
			      primary_rr_ind = @primary_rr_ind,  
			      rr_payout_net_pct = @rr_payout_net_pct,
			      rr_rgstr_exmpt_ind = @rr_rgstr_exmpt_ind,
			      charge_postage_ind = @charge_postage_ind,
			      rr_interest_ind = @rr_interest_ind,
			      acct_exctv_pyt_ind = @acct_exctv_pyt_ind,
			      rr_interest_1_txt = @rr_interest_1_txt,
			      rr_interest_2_txt = @rr_interest_2_txt,
			      rr_interest_3_txt = @rr_interest_3_txt,
			      lmt_dscrt_rr_ind = @lmt_dscrt_rr_ind,
				  updt_last_tmstp  = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and 
			   	rr_cd = @rr_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr2
				
				select @error_description = 'update_nr2 : taccount_rr : Update operation'
				
				raiserror 20086 "Update operation to taccount_rr failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nr2
		
		END	
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nr2

		/* now delete realtime table row */
		DELETE taccount_rr
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nr2
			
			select @error_description = 'update_nr2 : taccount_rr : Delete operation'
			
			raiserror 20087 "Delete operation to taccount_rr failed"
			select @custom_error_code=@@error				
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END

		COMMIT TRAN update_nr2
	END
 
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
 
END

go

grant execute on update_nr2 to fbi
go

IF OBJECT_ID('dbo.update_nr2') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nr2 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nr2 >>>'
go