/*****************************************************************************
NAME: update_nr9.sql
PURPOSE: Insert and update TACCOUNT_EXTNSN table
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	87232	1/7/13	Judy Shen	add 3 new fields div_wthld_pct,
					int_wthld_pct, and grs_prcd_wthld_pct
1.1		10/1/13 J Shen		expand acct_ctgy_cd from 1 byte to 2 bytes
1.2	91287	12/4/13	J.Shen		add a new field coa_cd
1.3	94644	3/19/14	J.Shen		add 2 new fields clnt_asctd_acct_id & cust_firm_cd
1.4	3458587	2/3/17	J.Shen		add 2 new fields stk_wh_frgn_rt_exp & bnd_wh_frgn_rt_exp
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nr9') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nr9
    IF OBJECT_ID('dbo.update_nr9') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nr9 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nr9 >>>'
END
go

CREATE PROC update_nr9
	     @client_nbr char(4),
	     @branch_cd char(3),
	     @account_cd char(5),
	     @rr_cd      char(3),
	     @action     char,
	     @vrfcn_lst_dt   char(10) = null,        
	     @vrfcn_nxt_dt   char(10) = null,        
	     @srce_fnds_txt  char(20) = null,         
	     @tfnds_amt       decimal(13,2) = null,  
	     @ofac_stts_cd   char(1)  = null,         
	     @acct_ctgy_cd   char(2)  = null,       
	     @init_ordr_desc_txt  char(20) = null,         
	     @indvd_int_nm    char(30) = null,                 
	     @txlt_acct_mthd_cd  char(1) = null,                 
	     @txlt_yr_end_mo_cd  char(2) = null,                 
	     @txlt_exmpt_sts_ind char(1) = null,                 
	     @txlt_cvrsn_cd      char(1) = null,                 
	     @txlt_stmt_cd       char(1) = null,                 
             @txlt_dvdnd_disp_cd char(1) = null,
	     @sprs_vrfcn_mlg_ind char(1) = null,
	     @emplr_ind          char(1) = null,
	     @mrrd_put_ind       char(1) = null,               
	     @cash_bkd_put_ind   char(1) = null,                 
	     @idx_wrrnt_prch_ind char(1) = null,                
             @fgn_crncy_opt_ind  char(1) = null,
             @optnl_div_cd 	char(1) = null,
             @prv_cms_stk_spc_cd char(1) = null,
             @prev_money_mgr_cd char(3) = null,
             @otsd_csty_acct_nbr char(10) = null,
             @stmo_clnt1_dt datetime = null,
             @stmo_clnt2_dt datetime = null,
             @ssf_ind char(1) = null,
             @ssf_prchs_ind char(1) = null,
             @ssf_cvrd_wrtng_ind char(1) = null,
             @ssf_nkd_wrtng_ind char(1) = null,	
             @sbscrbr_jnt_chg_dt datetime = null,
             @acct_closed_cd char(1) = null,
             @acct_closed_dt datetime =null,
             @acct_class_sr_cd char(3) = null,
             @inbnd_eft_ind char(1) = null ,
             @inbnd_eft_ac_ty_cd char(1) = null ,
             @inbnd_eft_amt decimal(7,0) = null ,
             @inbnd_eft_days_nbr char(2) = null ,
             @inbnd_frq_cd char(2) = null ,
             @inbnd_bank2_nbr char(4) = null ,
             @inbnd_trnst2_nbr char(5) = null ,
             @inbnd_bk_acct2_nbr char(12) = null ,
             @txlt_uncvr_bss_ind char(1) = null ,
             @txlt_13mo_run_ind char(1) = null ,
             @txlt_td_stmt_cd char(1) = null ,
             @txlt_hldg_stmt_ind char(1) = null ,
             @rstrctn_cd char(1) = null,
             @mtm_ccyy_cd char(4) = null,
             @mtm_updt_dt datetime = null,
             @div_wthld_pct decimal(3,0) = null,
             @int_wthld_pct decimal(3,0) = null,
             @grs_prcd_wthld_pct decimal(3,0) = null,
             @coa_cd char(2) = null,
             @clnt_asctd_acct_id char(70) = null,
             @cust_firm_cd char(2) = null,
             @stk_wh_frgn_rt_exp decimal(7,5) = null,
             @bnd_wh_frgn_rt_exp decimal(7,5) = null
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint
	DECLARE @fnds_amt decimal(13,2),
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	SELECT @fnds_amt = CONVERT(decimal(13,2),@tfnds_amt)

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
				
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM taccount_extnsn
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 
			   
		SELECT @tbl_rowcount = @@rowcount
			
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nr9
						
			/* insert into realtime table */
			INSERT INTO taccount_extnsn (client_nbr ,
						     branch_cd ,
						     account_cd ,
						     record_type_cd ,
						     action_cd ,
						     vrfcn_lst_dt,        
						     vrfcn_nxt_dt,        
						     srce_fnds_txt,         
						     fnds_amt,  
						     ofac_stts_cd,         
						     acct_ctgy_cd,       
						     init_ordr_desc_txt,         
						     indvd_int_nm,                 
						     txlt_acct_mthd_cd,                 
						     txlt_yr_end_mo_cd,                 
						     txlt_exmpt_sts_ind,                 
						     txlt_cvrsn_cd,                 
						     txlt_stmt_cd,                 
						     txlt_dvdnd_disp_cd,
						     rr_cd ,
						     sprs_vrfcn_mlg_ind,
						     emplr_ind,
						     mrrd_put_ind,               
						     cash_bkd_put_ind,                 
						     idx_wrrnt_prch_ind,                
                                                     fgn_crncy_opt_ind, 
                                                     optnl_div_cd,
                                                     prv_cms_stk_spc_cd,
                                                     prev_money_mgr_cd,
                                                     otsd_csty_acct_nbr,
                                                     stmo_clnt1_dt,
                                                     stmo_clnt2_dt,
                                                     ssf_ind,
                                                     ssf_prchs_ind,
                                                     ssf_cvrd_wrtng_ind,
                                                     ssf_nkd_wrtng_ind,
                                                     sbscrbr_jnt_chg_dt,
                                                     acct_closed_cd,
                                                     acct_closed_dt,
                                                     acct_class_sr_cd,
                                             	inbnd_eft_ind,
                                             inbnd_eft_ac_ty_cd,
                                             inbnd_eft_amt,
                                             inbnd_eft_days_nbr,
                                             inbnd_frq_cd,
                                             inbnd_bank2_nbr,
                                             inbnd_trnst2_nbr,
                                             inbnd_bk_acct2_nbr,
                                             txlt_uncvr_bss_ind,
                                             txlt_13mo_run_ind,
                                             txlt_td_stmt_cd,
                                             txlt_hldg_stmt_ind,
                                             rstrctn_cd,
             					mtm_ccyy_cd,
             					mtm_updt_dt,
						div_wthld_pct,
             					int_wthld_pct,
             					grs_prcd_wthld_pct,
						coa_cd,
						clnt_asctd_acct_id,
						cust_firm_cd,
						stk_wh_frgn_rt_exp,
						bnd_wh_frgn_rt_exp,
						     updt_last_tmstp)
					VALUES (@client_nbr ,
						     @branch_cd ,
						     @account_cd ,
						     'NR9',
						     'I' ,
						     @vrfcn_lst_dt,        
						     @vrfcn_nxt_dt,        
						     @srce_fnds_txt,         
						     @fnds_amt,  
						     @ofac_stts_cd,         
						     @acct_ctgy_cd,       
						     @init_ordr_desc_txt,         
						     @indvd_int_nm,                 
						     @txlt_acct_mthd_cd,                 
						     @txlt_yr_end_mo_cd,                 
						     @txlt_exmpt_sts_ind,                 
						     @txlt_cvrsn_cd,                 
						     @txlt_stmt_cd,                 
						     @txlt_dvdnd_disp_cd,
						     @rr_cd ,
						     @sprs_vrfcn_mlg_ind,
						     @emplr_ind,
						     @mrrd_put_ind,               
						     @cash_bkd_put_ind,                 
						     @idx_wrrnt_prch_ind,                
                                                     @fgn_crncy_opt_ind, 
                                                     @optnl_div_cd,
                                                     @prv_cms_stk_spc_cd,
                                                     @prev_money_mgr_cd,
                                                     @otsd_csty_acct_nbr,
                                                     @stmo_clnt1_dt,
                                                     @stmo_clnt2_dt,
                                                     @ssf_ind,
                                                     @ssf_prchs_ind,
                                                     @ssf_cvrd_wrtng_ind,
                                                     @ssf_nkd_wrtng_ind,
                                                     @sbscrbr_jnt_chg_dt,
                                                     @acct_closed_cd,
                                                     @acct_closed_dt,
                                                     @acct_class_sr_cd,
                                             @inbnd_eft_ind,
                                             @inbnd_eft_ac_ty_cd,
                                             @inbnd_eft_amt,
                                             @inbnd_eft_days_nbr,
                                             @inbnd_frq_cd,
                                             @inbnd_bank2_nbr,
                                             @inbnd_trnst2_nbr,
                                             @inbnd_bk_acct2_nbr,
                                             @txlt_uncvr_bss_ind,
                                             @txlt_13mo_run_ind,
                                             @txlt_td_stmt_cd,
                                             @txlt_hldg_stmt_ind,
                                             @rstrctn_cd,
             					@mtm_ccyy_cd,
             					@mtm_updt_dt,
						@div_wthld_pct,
             					@int_wthld_pct,
             					@grs_prcd_wthld_pct,
						@coa_cd,
						@clnt_asctd_acct_id,
						@cust_firm_cd,
						@stk_wh_frgn_rt_exp,
						@bnd_wh_frgn_rt_exp,
					             getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr9
				
				select @error_description = 'update_nr9 : taccount_extnsn : Insert operation'
				
				raiserror 20106 "Insert operation to taccount_extnsn failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_nr9
		END
		ELSE
		BEGIN
			
			
			BEGIN TRAN update_nr9			
			/* update */			

			/* now update realtime table row */
			UPDATE taccount_extnsn
			SET record_type_cd = 'NR9',
	                    action_cd = 'U' ,
	                    rr_cd = @rr_cd,
	                    vrfcn_lst_dt = @vrfcn_lst_dt,        
			     vrfcn_nxt_dt = @vrfcn_nxt_dt,        
			     srce_fnds_txt = @srce_fnds_txt,         
			     fnds_amt = @fnds_amt,  
			     ofac_stts_cd = @ofac_stts_cd,         
			     acct_ctgy_cd = @acct_ctgy_cd,       
			     init_ordr_desc_txt = @init_ordr_desc_txt,         
			     indvd_int_nm = @indvd_int_nm,                 
			     txlt_acct_mthd_cd = @txlt_acct_mthd_cd,                 
			     txlt_yr_end_mo_cd = @txlt_yr_end_mo_cd,                 
			     txlt_exmpt_sts_ind = @txlt_exmpt_sts_ind,                 
			     txlt_cvrsn_cd = @txlt_cvrsn_cd,                 
			     txlt_stmt_cd = @txlt_stmt_cd,                 
		             txlt_dvdnd_disp_cd = @txlt_dvdnd_disp_cd,
		             sprs_vrfcn_mlg_ind = @sprs_vrfcn_mlg_ind,
		             emplr_ind = @emplr_ind,
		             mrrd_put_ind = @mrrd_put_ind,               
			     cash_bkd_put_ind = @cash_bkd_put_ind,                 
			     idx_wrrnt_prch_ind = @idx_wrrnt_prch_ind,                
                             fgn_crncy_opt_ind = @fgn_crncy_opt_ind,
                             optnl_div_cd = @optnl_div_cd,
                             prv_cms_stk_spc_cd = @prv_cms_stk_spc_cd,
                             prev_money_mgr_cd = @prev_money_mgr_cd,
                             otsd_csty_acct_nbr = @otsd_csty_acct_nbr,
                             stmo_clnt1_dt = @stmo_clnt1_dt,
                             stmo_clnt2_dt = @stmo_clnt2_dt,
                             ssf_ind = @ssf_ind,
                             ssf_prchs_ind = @ssf_prchs_ind,
                             ssf_cvrd_wrtng_ind = @ssf_cvrd_wrtng_ind,
                             ssf_nkd_wrtng_ind = @ssf_nkd_wrtng_ind,
                             sbscrbr_jnt_chg_dt = @sbscrbr_jnt_chg_dt,
                             acct_closed_cd = @acct_closed_cd,
                             acct_closed_dt = @acct_closed_dt,
                             acct_class_sr_cd = @acct_class_sr_cd,
                             inbnd_eft_ind = @inbnd_eft_ind,
                             inbnd_eft_ac_ty_cd = @inbnd_eft_ac_ty_cd,
                             inbnd_eft_amt = @inbnd_eft_amt,
                             inbnd_eft_days_nbr = @inbnd_eft_days_nbr,
                             inbnd_frq_cd = @inbnd_frq_cd,
                             inbnd_bank2_nbr = @inbnd_bank2_nbr,
                             inbnd_trnst2_nbr = @inbnd_trnst2_nbr,
                             inbnd_bk_acct2_nbr = @inbnd_bk_acct2_nbr,
                             txlt_uncvr_bss_ind = @txlt_uncvr_bss_ind,
                             txlt_13mo_run_ind = @txlt_13mo_run_ind,
                             txlt_td_stmt_cd = @txlt_td_stmt_cd,
                             txlt_hldg_stmt_ind = @txlt_hldg_stmt_ind,
                             rstrctn_cd = @rstrctn_cd,
             			mtm_ccyy_cd = @mtm_ccyy_cd,
             			mtm_updt_dt = @mtm_updt_dt,
				div_wthld_pct = @div_wthld_pct,
             			int_wthld_pct = @int_wthld_pct,
             			grs_prcd_wthld_pct = @grs_prcd_wthld_pct,
				coa_cd = @coa_cd,
				clnt_asctd_acct_id = @clnt_asctd_acct_id,
				cust_firm_cd = @cust_firm_cd,
				stk_wh_frgn_rt_exp = @stk_wh_frgn_rt_exp,
				bnd_wh_frgn_rt_exp = @bnd_wh_frgn_rt_exp,
		             updt_last_tmstp = getdate()			
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd  

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nr9
				
				select @error_description = 'update_nr9 : taccount_extnsn : Update operation'
				
				raiserror 20107 "Update operation to taccount_extnsn failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

		COMMIT TRAN update_nr9

		END	
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
	
		BEGIN TRAN update_nr9
	        	        	
		/* now delete realtime table row */
		DELETE taccount_extnsn
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nr9
			
			select @error_description = 'update_nr9 : taccount_extnsn : Delete operation'
			
			raiserror 20108 "Delete operation to taccount_extnsn failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END

		
		COMMIT TRAN update_nr9
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nr9 to fbi
go

IF OBJECT_ID('dbo.update_nr9') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nr9 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nr9 >>>'
go
