/*****************************************************************************
NAME: update_pbi.sql
PURPOSE: Insert and update tpat_oecd_crs table
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	3495781	08/06/2017	J. sid		new table
1.1	3952835	02/12/18	J. Shen	add a new field ftr_reason_cd
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_pbi') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_pbi
    IF OBJECT_ID('dbo.update_pbi') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_pbi >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_pbi >>>'
END
go


CREATE PROC update_pbi

    @client_nbr           char(4),
	@crspn_nbr            decimal(5,0),
	@soc_sec_nbr          char(9) ,
	@soc_sec_tax_cd       char(1) ,
	@cres_seq_nbr         smallint ,
	@action               char(1) ,
	@ftr_res_cd           char(3) = null ,
	@ftr_type_cd          char(4) = null ,
	@ftr_sub_type_cd      char(4) = null ,
	@ftr_tin_id           char(30) = null ,
	@last_updt_tmstp      char(26) = null ,
	@last_updt_id         char(8)  = null ,
	@ftr_reason_cd		char(1) = null
						
AS
BEGIN
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	

	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)	
	
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + convert(varchar(8),@crspn_nbr) + "," + @soc_sec_nbr + "," + @soc_sec_tax_cd + "," + convert(varchar(8),@cres_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		
		
		/* insert or update record */
		SELECT @db_action_cd = action_cd
		FROM tpat_oecd_crs
		WHERE client_nbr = @client_nbr AND
			  crspn_nbr  =  @crspn_nbr AND
	        soc_sec_nbr  = @soc_sec_nbr AND
	     soc_sec_tax_cd  = @soc_sec_tax_cd AND
	       cres_seq_nbr  = @cres_seq_nbr

			
		SELECT @tbl_rowcount = @@rowcount
		
		

		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_pbi
			
			/* insert into realtime table */
			INSERT INTO tpat_oecd_crs ( client_nbr ,           
                                       	crspn_nbr,
                                    	soc_sec_nbr,
                                     	soc_sec_tax_cd ,
                                      	cres_seq_nbr,
                                       	rec_type_cd,
                                    	action_cd,
                                    	ftr_res_cd,
                                     	ftr_type_cd,
                                    	ftr_sub_type_cd,
                                       	ftr_tin_id,
                                    	last_updt_tmstp,
                                      	last_updt_id,
                                        ftr_reason_cd,
                                    	updt_last_tmstp)
				VALUES     ( @client_nbr,
					        @crspn_nbr,
	                             @soc_sec_nbr,
	                             @soc_sec_tax_cd ,
	                             @cres_seq_nbr,
                                  'PBI', 
					               'I',
                                 @ftr_res_cd,
	                             @ftr_type_cd,
	                             @ftr_sub_type_cd,
	                             @ftr_tin_id,
	                             @last_updt_tmstp,
	                             @last_updt_id,
                                     @ftr_reason_cd,
					                  getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_pbi
				
				select @error_description = 'update_pbi : tpat_oecd_crs : Insert operation'
				
				raiserror 20198 "Insert operation to tpat_oecd_crs failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_pbi
		END
		ELSE
		BEGIN
			BEGIN TRAN update_pbi
			
			/* now update realtime table row */


			UPDATE tpat_oecd_crs 
                         SET rec_type_cd   ='PBI',
                             action_cd        = 'U',
                             crspn_nbr        =@crspn_nbr,
	                         soc_sec_nbr      =@soc_sec_nbr,
	                         soc_sec_tax_cd   =@soc_sec_tax_cd ,
	                         cres_seq_nbr     =@cres_seq_nbr ,
	                         ftr_res_cd       =@ftr_res_cd,
	                         ftr_type_cd      =@ftr_type_cd,
	                         ftr_sub_type_cd  =@ftr_sub_type_cd,
                             ftr_tin_id       =@ftr_tin_id,
	                         last_updt_tmstp  =@last_updt_tmstp,
	                         last_updt_id     =@last_updt_id,
                                 ftr_reason_cd = @ftr_reason_cd,
				              updt_last_tmstp	= getdate()
			WHERE client_nbr = @client_nbr AND
			  crspn_nbr  =  @crspn_nbr AND
	        soc_sec_nbr  = @soc_sec_nbr AND
	     soc_sec_tax_cd  = @soc_sec_tax_cd AND
	       cres_seq_nbr  = @cres_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_pbi
				
				select @error_description = 'update_pbi : tpat_oecd_crs : Update operation'
				
				raiserror 20199 "Update operation to tpat_oecd_crs failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			   
			COMMIT TRAN update_pbi  
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_pbi

		/* now delete realtime table row */

		DELETE tpat_oecd_crs 
		WHERE client_nbr = @client_nbr AND
			  crspn_nbr  =  @crspn_nbr AND
	        soc_sec_nbr  = @soc_sec_nbr AND
	     soc_sec_tax_cd  = @soc_sec_tax_cd AND
	       cres_seq_nbr  = @cres_seq_nbr


		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_pbi
			
			select @error_description = 'update_pbi : tpat_oecd_crs : Delete operation'
			
			raiserror 20200 "Delete operation to tpat_oecd_crs failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
	        
	        COMMIT TRAN update_pbi
	
	END

	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('OWNERS',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
   
END




go

grant execute on update_pbi to fbi
go

IF OBJECT_ID('dbo.update_pbi') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_pbi >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_pbi >>>'
go
