/*
$Header: /Realtime/Realtime/stp/update_msk.sql 8     10/19/01 4:21p Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msk.sql $
 * 
 * 8     10/19/01 4:21p Tbjuhu
 * 4th Qtr data model changes
 * 
 * 7     6/19/01 3:16p Tbjuhu
 * 2nd Qtr data model changes
 * 
 * 6     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 5     6/29/00 5:20p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msk') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msk
    IF OBJECT_ID('dbo.update_msk') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msk >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msk >>>'
END
go

CREATE PROC update_msk
	@security_adp_nbr		char(7)		,
	@maturity_dt			datetime	,
	@interest_rt			decimal(11,8),
	@coupon_first_dt		datetime	,
	@accrue_start_dt		datetime	,
	@accrue_end_dt			datetime	,
	@dated_dt				datetime	,
	@dated_dt_cd			char(1)		,
	@date_coupon_cd			char (4)	,
	@evaluation_bond_cd		char(1)		,
	@day_delay_qty			smallint	,
	@cmo_ind				char(1)		,
	@pool_nbr				char (8)	,
	@day_wt_avg_mat_qty		decimal(9,5),
	@serial_bond_nbr		char(7),
	@state_cd				char(2),
	@avg_wght_cpn_amt		decimal(9,5),
	@ins_jjk_cd				char(2),
	@date_pay_actual_cd		char(4),
	@prerefunded_dt			datetime,
	@prerefunded_rt			decimal(7,3),
	@int_calcn_cd			char(1),
	@rate_bond_dt			datetime,
	@bond_ext_rt			decimal(5,3),
	@pay_interest_dt		datetime,
	@defease_ind			char(1),
	@int_pay_cd				char(2)
				
AS
BEGIN
  
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr 	char(7),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
		
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
		FROM tbond_data WHERE
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msk
		/* insert */
		INSERT INTO tbond_data (	security_adp_nbr,
						maturity_dt,
						interest_rt,
						coupon_first_dt,
						action_cd,
						record_type_cd,
						accrue_start_dt,
						accrue_end_dt,
						dated_dt,
						dated_dt_cd,
						date_coupon_cd,
						evaluation_bond_cd,
						day_delay_qty,
						cmo_ind,
						pool_nbr,
						day_wt_avg_mat_qty,
						serial_bond_nbr,
						state_cd,
						avg_wght_cpn_amt,
						ins_jjk_cd,
						date_pay_actual_cd,
						prerefunded_dt,
						prerefunded_rt,
                        int_calcn_cd,
						rate_bond_dt,
						bond_ext_rt,
						pay_interest_dt,
						defease_ind,
						int_pay_cd,
						updt_last_tmstp)
		VALUES (	@security_adp_nbr,
					@maturity_dt,
					@interest_rt,
					@coupon_first_dt,
					'I',
					'MSK',
					@accrue_start_dt,
					@accrue_end_dt,
					@dated_dt,
					@dated_dt_cd,
					@date_coupon_cd,
					@evaluation_bond_cd,
					@day_delay_qty,
					@cmo_ind,
					@pool_nbr,
					@day_wt_avg_mat_qty ,
					@serial_bond_nbr,
					@state_cd,
					@avg_wght_cpn_amt,
					@ins_jjk_cd,
					@date_pay_actual_cd,
					@prerefunded_dt,
					@prerefunded_rt,
                    			@int_calcn_cd,
					@rate_bond_dt,
					@bond_ext_rt,
					@pay_interest_dt,
					@defease_ind,
					@int_pay_cd,
					getdate())
					
		SELECT @syb_error_code = @@error
		
		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msk
			
			select @error_description = 'update_msk : tbond_data : Insert operation'
			
			raiserror 20045 "Insert operation to tbond_data failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END

		COMMIT TRAN update_msk
		
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msk
		/* update */

		/* now update real-time table */
		UPDATE tbond_data SET
			maturity_dt = @maturity_dt,
			interest_rt = @interest_rt,
			coupon_first_dt = @coupon_first_dt,
			action_cd = 'U',
			record_type_cd = 'MSK',
			accrue_start_dt = @accrue_start_dt,
			accrue_end_dt = @accrue_end_dt,
			dated_dt = @dated_dt,
			dated_dt_cd = @dated_dt_cd,
			date_coupon_cd = @date_coupon_cd,
			evaluation_bond_cd = @evaluation_bond_cd,
			day_delay_qty = @day_delay_qty,
			cmo_ind = @cmo_ind,
			pool_nbr = @pool_nbr,
			day_wt_avg_mat_qty = @day_wt_avg_mat_qty,
			serial_bond_nbr =@serial_bond_nbr,
			state_cd = @state_cd,
			avg_wght_cpn_amt = @avg_wght_cpn_amt,
			ins_jjk_cd = @ins_jjk_cd,
			date_pay_actual_cd = @date_pay_actual_cd,
			prerefunded_dt = @prerefunded_dt,
			prerefunded_rt = @prerefunded_rt,
			int_calcn_cd = @int_calcn_cd,
			rate_bond_dt = @rate_bond_dt,
			bond_ext_rt = @bond_ext_rt,
			pay_interest_dt = @pay_interest_dt,
			defease_ind = @defease_ind,
			int_pay_cd = @int_pay_cd,
			updt_last_tmstp = getdate()
		WHERE security_adp_nbr = @security_adp_nbr
		
		SELECT @syb_error_code = @@error
		
		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msk
			
			select @error_description = 'update_msk : tbond_data : Update operation'
			
			raiserror 20046 "Update operation to tbond_data failed"
		    select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_msk
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_msk to fbi
go

IF OBJECT_ID('dbo.update_msk') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msk >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msk >>>'
go
