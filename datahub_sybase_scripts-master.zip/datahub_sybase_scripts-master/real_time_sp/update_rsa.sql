/*
$Header: /rtapp/stp/update_rsa.sql $
$Log: /rtapp/stp/update_rsa.sql $
 * 
 * 
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_rsa') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_rsa
    IF OBJECT_ID('dbo.update_rsa') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_rsa >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_rsa >>>'
END
go

CREATE PROC update_rsa
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@action 	        char(1),
	@type_acct_cd       char(3),
	@bnfcr_seq_nbr		smallint,
	@bnfcr_nm			char(30),		
	@bnfcr_rltsh_txt	char(10),
	@bnfcr_misc_txt		char(10),
	@bnfcr_sin_cd		char(9)
AS
BEGIN
	
	DECLARE @action_cd char(1),
                @tbl_security_adp_nbr char(7),      
                @start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
				
	if(@debug_flag='Y')
	begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @type_acct_cd + "," + convert(varchar(8),@bnfcr_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end
	
	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @action_cd = action_cd
		FROM tbeneficiary
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			type_acct_cd = @type_acct_cd AND
			bnfcr_seq_nbr = @bnfcr_seq_nbr

		IF @@rowcount = 0
		BEGIN
			BEGIN TRAN update_rsa
			
			/* insert, first into realtime table */
			INSERT INTO tbeneficiary (client_nbr,
					branch_cd,
					account_cd,
					type_acct_cd,
					bnfcr_seq_nbr,
			        bnfcr_nm,        
			        bnfcr_rltsh_txt,        	
					bnfcr_misc_txt,
					bnfcr_sin_cd,
					action_cd,
					record_type_cd,
					updt_last_tmstp )
			VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					@type_acct_cd,
					@bnfcr_seq_nbr,
			        @bnfcr_nm,        
			        @bnfcr_rltsh_txt,        	
					@bnfcr_misc_txt,
					@bnfcr_sin_cd,
					'I',
					'RSA',
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsa
				
				select @error_description = 'update_rsa : tbeneficiary : Insert operation'
				
				raiserror 20151 "Insert operation to tbeneficiary failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
			COMMIT TRAN update_rsa
			
		END
		ELSE
		BEGIN
			BEGIN TRAN update_rsa
			
			/* now update realtime table row */
			UPDATE tbeneficiary 
			SET     client_nbr = @client_nbr,
				branch_cd = @branch_cd,
				account_cd = @account_cd,
				type_acct_cd = @type_acct_cd,
				bnfcr_seq_nbr = @bnfcr_seq_nbr,
				bnfcr_nm = @bnfcr_nm,        
				bnfcr_rltsh_txt = @bnfcr_rltsh_txt,        	
				bnfcr_misc_txt = @bnfcr_misc_txt,
				bnfcr_sin_cd = @bnfcr_sin_cd,
				action_cd = 'U',
				record_type_cd = 'RSA',
				updt_last_tmstp = getdate()
			WHERE   client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
				type_acct_cd = @type_acct_cd AND
				bnfcr_seq_nbr = @bnfcr_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsa
				
				select @error_description = 'update_rsa : tbeneficiary : Update operation'
				
				raiserror 20152 "Update operation to tbeneficiary failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END

			COMMIT TRAN update_rsa
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		BEGIN TRAN update_rsa
				
		/*delete realtime table row */
		DELETE tbeneficiary 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			type_acct_cd = @type_acct_cd AND
			bnfcr_seq_nbr = @bnfcr_seq_nbr


		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_rsa
			
			select @error_description = 'update_rsa : tbeneficiary : Delete operation'
			
			raiserror 20153 "Delete operation to tbeneficiary failed"
			select @custom_error_code=@@error				
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		    
	    COMMIT TRAN update_rsa		    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_rsa to fbi
go

IF OBJECT_ID('dbo.update_rsa') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_rsa >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_rsa >>>'
go
