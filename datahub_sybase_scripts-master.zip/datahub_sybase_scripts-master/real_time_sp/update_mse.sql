/*
$Header: /Realtime/Realtime/stp/update_mse.sql 5     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_mse.sql $
 * 
 * 5     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 4     6/29/00 5:18p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_mse') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_mse
    IF OBJECT_ID('dbo.update_mse') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_mse >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_mse >>>'
END
go

CREATE PROC update_mse
	@security_adp_nbr	char(7),
	@country_cd			char(2),
	@currency_cd		char(3),
	@issue_when_ind		char(1),
	@type_price_cd		char(1),
	@price_sec_amt		decimal(16,8),
	@price_set_dt		char(10),
	@trdg_sym_cd		char(20)

AS
BEGIN
  
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr 	char(7),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
		
	
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @country_cd + "," + @issue_when_ind + "," + @type_price_cd
		select @error_description = ''
		select @custom_error_code = 0
	end


	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tsec_price WHERE
		country_cd = @country_cd AND
		issue_when_ind = @issue_when_ind AND
		type_price_cd = @type_price_cd AND
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_mse
		/* insert */
		INSERT INTO tsec_price (	country_cd,
						currency_cd,
						issue_when_ind,
						security_adp_nbr,
						type_price_cd,
						price_sec_amt,
						record_type_cd,
						action_cd,
						price_set_dt,
						trdg_sym_cd )
		VALUES (	@country_cd,
					@currency_cd,
					@issue_when_ind,
					@security_adp_nbr,
					@type_price_cd,
					@price_sec_amt,
					'MSE',
					'I',
					@price_set_dt,
					@trdg_sym_cd )
					
		SELECT @syb_error_code = @@error
		
		if @syb_error_code != 0
		BEGIN
		
			ROLLBACK TRAN update_mse
			
			select @error_description = 'update_mse : tsec_price : Insert operation'
			
			raiserror 20033 "Insert operation to tsec_price failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END

		COMMIT TRAN update_mse

	END
	ELSE
	BEGIN
		BEGIN TRAN update_mse
		/* update */

		/* now update real-time table */
		UPDATE tsec_price SET
			currency_cd = @currency_cd,
			price_sec_amt = @price_sec_amt,
			record_type_cd = 'MSE',
			action_cd = 'U',
			price_set_dt = @price_set_dt,
			trdg_sym_cd = @trdg_sym_cd
		WHERE country_cd = @country_cd AND
			issue_when_ind = @issue_when_ind AND
			type_price_cd = @type_price_cd AND
			security_adp_nbr = @security_adp_nbr
			
			SELECT @syb_error_code = @@error

		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_mse
			
			select @error_description = 'update_mse : tsec_price : Update operation'
			
			raiserror 20034 "Update operation to tsec_price failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_mse
	END
  
  	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_mse to fbi
go

IF OBJECT_ID('dbo.update_mse') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_mse >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_mse >>>'
go