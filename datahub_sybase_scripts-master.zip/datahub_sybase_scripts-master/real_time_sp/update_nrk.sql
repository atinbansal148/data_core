/*
$Header: /rtapp/stp/update_nrk.sql 1     3/25/02 10:39a Tbprven $
$Log: /rtapp/stp/update_nrk.sql $
 * 
 * 1     3/25/02 10:39a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrk') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrk
    IF OBJECT_ID('dbo.update_nrk') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrk >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrk >>>'
END
go

CREATE PROC update_nrk
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@rr_cd                          char(3),
	@action 	          	char(1),
	@ap_seq_nbr			smallint = null ,
	@na_line_seq_nbr                smallint = null ,
	@na_line_cd 			char(2) = null,
	@na_line_txt			char(35) = null,
	@title_line_ind		        char(1) = null
AS
BEGIN
	
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@ap_seq_nbr) + "," + convert(varchar(8),@na_line_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN

		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacc_party_ff_na
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			ap_seq_nbr = @ap_seq_nbr AND
			na_line_seq_nbr = @na_line_seq_nbr
			
		SELECT @tbl_rowcount = @@rowcount
			
		IF @tbl_rowcount = 0
		BEGIN
			BEGIN TRAN update_nrk
			
			/* insert, first into realtime table */
			INSERT INTO tacc_party_ff_na (
			                client_nbr,
			                branch_cd,	
			                account_cd,
					ap_seq_nbr,
				        na_line_seq_nbr,
				        action,
				        record_type_cd,
				        rr_cd,
					na_line_cd ,
					na_line_txt,
	                                title_line_ind,	
					updt_last_tmstp )
			VALUES (@client_nbr,
			                @branch_cd,	
			                @account_cd,
					@ap_seq_nbr,
				        @na_line_seq_nbr,
				        'I',
				        'NRK',
				        @rr_cd,
					@na_line_cd ,
					@na_line_txt,
	                                @title_line_ind,	
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrk
				
				select @error_description = 'update_nrk : tacc_party_ff_na : Insert operation'
				
				raiserror 20115 "Insert operation to tacc_party_ff_na failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END	
			
            COMMIT TRAN update_nrk
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nrk
			/* update */

			/* now update realtime table row */
			UPDATE tacc_party_ff_na 
			SET     
			        
				action = 'U',
				record_type_cd = 'NRK',
				rr_cd = @rr_cd,
				na_line_cd = @na_line_cd ,
				na_line_txt = @na_line_txt,
	                        title_line_ind = @title_line_ind,
	                        updt_last_tmstp	   = getdate()	
			        
			        
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd AND
				ap_seq_nbr = @ap_seq_nbr AND
			        na_line_seq_nbr = @na_line_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrk
				
				select @error_description = 'update_nrk : tacc_party_ff_na : Update operation'
				
				raiserror 20116 "Update operation to tacc_party_ff_na failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			    
			COMMIT TRAN update_nrk    
		END
		
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		/*SELECT @db_action_cd = action
		FROM tacc_party_ff_na
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd AND
			action IN ('A','C')
					
		SELECT @tbl_rowcount = @@rowcount*/
				
		BEGIN TRAN update_nrk		
		
		/* now delete realtime table row */

		DELETE tacc_party_ff_na 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd 
			
		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrk
			
			select @error_description = 'update_nrk : tacc_party_ff_na : Delete operation'
			
			raiserror 20117 "Delete operation to tacc_party_ff_na failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nrk	    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nrk to fbi
go

IF OBJECT_ID('dbo.update_nrk') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrk >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrk >>>'
go
