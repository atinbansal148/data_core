/*
$Header: /rtapp/stp/update_rsd.sql $
$Log: /rtapp/stp/update_rsd.sql $
 * 
 * 
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_rsd') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_rsd
    IF OBJECT_ID('dbo.update_rsd') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_rsd >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_rsd >>>'
END
go

CREATE PROC update_rsd
	@client_nbr			char(4),
	@branch_cd			char(3),
	@account_cd			char(5),
	@action 	        char(1),
	@addrs_seq_nbr		smallint,
	@orgnl_addrs_ln_txt	char(30)		
AS
BEGIN
	

	DECLARE @action_cd char(1),
                @tbl_security_adp_nbr char(7),
                @start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)

			
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@addrs_seq_nbr) 
		select @error_description = ''
		select @custom_error_code = 0
	end
	/* check if we're doing an insert/update or a delete */

	IF (@action = 'C') OR (@action = 'A')
	BEGIN

		/* insert or update record */
		SELECT @action_cd = action_cd
		FROM trrif_dcsd_addr
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd
			
		IF @@rowcount = 0
		BEGIN
			BEGIN TRAN update_rsd
			
			/* insert, first into realtime table */
			INSERT INTO trrif_dcsd_addr (client_nbr,
					branch_cd,
					account_cd,
					addrs_seq_nbr,
					orgnl_addrs_ln_txt,
					action_cd,
					record_type_cd,
					updt_last_tmstp )
			VALUES (@client_nbr,
					@branch_cd,
					@account_cd,
					@addrs_seq_nbr,
					@orgnl_addrs_ln_txt,
					'I',
					'RSD',
					getdate() )

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsd
				
				select @error_description = 'update_rsd : trrif_dcsd_addr : Insert operation'
				
				raiserror 20160 "Insert operation to trrif_dcsd_addr failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
			COMMIT TRAN update_rsd		
		END
		ELSE
		BEGIN
			BEGIN TRAN update_rsd
			
			/* now update realtime table row */
			UPDATE trrif_dcsd_addr 
			SET client_nbr = @client_nbr,
				branch_cd = @branch_cd,
				account_cd = @account_cd,
				addrs_seq_nbr = @addrs_seq_nbr,
				orgnl_addrs_ln_txt = @orgnl_addrs_ln_txt,
				action_cd = 'U',
				record_type_cd = 'RSD',
				updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr AND
				branch_cd = @branch_cd AND
				account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_rsd
				
				select @error_description = 'update_rsd : trrif_dcsd_addr : Update operation'
				
				raiserror 20161 "Update operation to trrif_dcsd_addr failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
			COMMIT TRAN update_rsd   
		END
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		BEGIN TRAN update_rsd
		
		/* delete realtime record */
		DELETE trrif_dcsd_addr 
		WHERE client_nbr = @client_nbr AND
			branch_cd = @branch_cd AND
			account_cd = @account_cd

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_rsd
			
			select @error_description = 'update_rsd : trrif_dcsd_addr : Delete operation'
			
			raiserror 20162 "Delete operation to trrif_dcsd_addr failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
	    COMMIT TRAN update_rsd		    
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CRSP',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_rsd to fbi
go

IF OBJECT_ID('dbo.update_rsd') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_rsd >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_rsd >>>'
go
