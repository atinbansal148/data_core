/*****************************************************************************
NAME: update_nrp.sql
PURPOSE: Insert and update TACC_COMPLIANCE table
REVISIONS:
Ver	SSR	Date	  Author	Description
-------	-------	--------- ------------- -------------------------------------
1.0	87560	12/21/12  Judy Shen	Added a new field medium_term_pct
1.1	89278	03/13/13  Judy Shen	Added 2 new fields lp_wthld_pct & lp_wthld_chng_dt
1.2	98095	03/19/14  J. Shen	Added 2 new fields rpo1_dt & rpo2_dt
1.3	108504	08/19/15  J. Shen	Added 3 new fields death_cert_ind, tin_stts_cd & tin_stts_dt
1.4	109413	1/5/16	  J.Shen	Added 1 new field non_mem_affl_ind
1.5	112005	6/29/16		J.Shen	Added 12 new fields large_trdr4_id...large_trdr15_id
1.6 3323547	11/14/16	J.Shen	Added a new field non_tb_comp_ind
1.7	3458587	2/21/17		J.Shen	Added 2 new fields dol_ind & prte_ind
1.8	3925330	2/23/18	J.Shen		Added 1 new field sdi_ind
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrp') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrp
    IF OBJECT_ID('dbo.update_nrp') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrp >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrp >>>'
END
go

CREATE PROC update_nrp
      @client_nbr	char(4)  ,
      @branch_cd char(3)  ,
      @account_cd char(5)  ,
       @rr_cd char(3) ,
      @action char(1) ,
      @invst_exp_chng_dt datetime  = null ,
      @invst_exprn_cd char(1)  = null ,
      @invst_objct_dt datetime  = null ,
      @invst_objective_cd char(4)  = null ,
      @cmdty_hedge_pct decimal(6,3)  = null ,
      @cmdty_spclt_pct decimal(6,3)  = null ,
      @past_exprn_ind char(1)  = null ,
      @cmdty_risk_cptl_cd char(2)  = null ,
      @risk_fctr_hi_nbr decimal(3,0)  = null ,
      @risk_fctr_chng_dt datetime  = null ,
      @risk_fctr_med_nbr decimal(3,0)  = null ,
      @risk_fctr_low_nbr decimal(3,0)  = null ,
      @limit_unit_amt decimal(9,0)  = null ,
      @limit_trade_amt decimal(13,0)  = null ,
      @lmt_opt_expsr_amt decimal(9,0)  = null ,
      @income_pct decimal(6,3)  = null ,
      @capap_pct decimal(6,3)  = null ,
      @spclt_trd_pct decimal(6,3)  = null ,
      @init_order_cd char(1)  = null ,
      @init_ordr_slct_ind char(1)  = null ,
      @init_trd_val_cd char(2)  = null ,
      @init_rcved_val_cd char(2)  = null ,
      @pct_chng_dt datetime  = null ,
      @alt_sec_rgstr_ind char(1)  = null ,
      @alt_pay_dvdnd_ind char(1)  = null ,
      @mail_frwrd_ind char(1)  = null ,
      @trd_brkr_ind char(1)  = null ,
      @trd_brkr_opt_ind char(1)  = null ,
      @trd_brkr_cmdty_ind char(1)  = null ,
      @aprvl_us_acct_ind char(1)  = null ,
      @managed_acct_ind char(1)  = null ,
      @money_manager_nm char(20)  = null ,
      @uk_mrkt_prfsn_cd char(2)  = null ,
      @uk_bsns_cust_cd char(2)  = null ,
      @private_cust_cd char(2)  = null ,
      @brkr_employee_cd char(1) = null,
      @oats_acct_type_cd char(1) = null,
      @large_trdr1_id char(13) = null,
      @large_trdr2_id char(13) = null,
      @large_trdr3_id char(13) = null,
      @mult_lrg_trdr_ind char(1) = null,
      @time_hrzn_yrs_nbr char(2) = null,
      @time_hrzn_updt_dt datetime = null,
      @liquidity_cd char(2) = null,
      @liquidity_updt_dt datetime = null,
      @rsk_tlrnc_cd char(2) = null,
      @rsk_tlrnc_updt_dt datetime = null,
      @fdrl_acct_ty_cd char(1) = null,
      @medium_term_pct decimal(6,3)  = null,
      @lp_wthld_pct decimal(6,2) = null,
      @lp_wthld_chng_dt datetime = null,
      @rpo1_dt datetime = null,
      @rpo2_dt datetime = null,
      @death_cert_ind char(1) = null,
      @tin_stts_cd char(1) = null,
      @tin_stts_dt datetime = null,
      @non_mem_affl_ind char(1) = null,
      @large_trdr4_id char(13) = null,
      @large_trdr5_id char(13) = null,
      @large_trdr6_id char(13) = null,
      @large_trdr7_id char(13) = null,
      @large_trdr8_id char(13) = null,
      @large_trdr9_id char(13) = null,
      @large_trdr10_id char(13) = null,
      @large_trdr11_id char(13) = null,
      @large_trdr12_id char(13) = null,
      @large_trdr13_id char(13) = null,
      @large_trdr14_id char(13) = null,
      @large_trdr15_id char(13) = null,
	  @non_tb_comp_ind char(1) = null,
      @dol_ind char(1) = null,
      @prte_ind char(1) = null ,
      @sdi_ind char(1) = null
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
		
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacc_compliance
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 
			   
	        SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
                        
			BEGIN TRAN update_nrp

			/* insert into realtime table */
			INSERT INTO tacc_compliance (client_nbr ,
			      branch_cd ,
			      account_cd ,
			      action ,
			      record_type_cd ,
			      rr_cd ,
			      invst_exp_chng_dt  ,
			      invst_exprn_cd ,
			      invst_objct_dt ,
			      invst_objective_cd ,
			      cmdty_hedge_pct ,
			      cmdty_spclt_pct ,
			      past_exprn_ind ,
			      cmdty_risk_cptl_cd ,
			      risk_fctr_hi_nbr ,
			      risk_fctr_chng_dt  ,
			      risk_fctr_med_nbr ,
			      risk_fctr_low_nbr ,
			      limit_unit_amt ,
			      limit_trade_amt ,
			      lmt_opt_expsr_amt ,
			      income_pct ,
			      capap_pct ,
			      spclt_trd_pct ,
			      init_order_cd ,
			      init_ordr_slct_ind ,
			      init_trd_val_cd ,
			      init_rcved_val_cd ,
			      pct_chng_dt ,
			      alt_sec_rgstr_ind ,
			      alt_pay_dvdnd_ind ,
			      mail_frwrd_ind ,
			      trd_brkr_ind ,
			      trd_brkr_opt_ind ,
			      trd_brkr_cmdty_ind ,
			      aprvl_us_acct_ind ,
			      managed_acct_ind ,
			      money_manager_nm ,
			      uk_mrkt_prfsn_cd ,
			      uk_bsns_cust_cd ,
			      private_cust_cd,
				brkr_employee_cd,
				oats_acct_type_cd,
				large_trdr1_id,
				large_trdr2_id,
				large_trdr3_id,
				mult_lrg_trdr_ind,
				time_hrzn_yrs_nbr,
				time_hrzn_updt_dt,
				liquidity_cd,
				liquidity_updt_dt,
				rsk_tlrnc_cd,
				rsk_tlrnc_updt_dt,
				fdrl_acct_ty_cd,
				medium_term_pct,
				lp_wthld_pct,
      				lp_wthld_chng_dt,
				rpo1_dt,
      				rpo2_dt,
				death_cert_ind,
      				tin_stts_cd,
      				tin_stts_dt,
				non_mem_affl_ind,
				large_trdr4_id,
				large_trdr5_id,
				large_trdr6_id,
				large_trdr7_id,
				large_trdr8_id,
				large_trdr9_id,
				large_trdr10_id,
				large_trdr11_id,
				large_trdr12_id,
				large_trdr13_id,
				large_trdr14_id,
				large_trdr15_id,
				non_tb_comp_ind,
				dol_ind,
				prte_ind,
				sdi_ind,
				updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd ,
			      @account_cd ,
			      'I',
			      'NRP' ,
			      @rr_cd ,
			      @invst_exp_chng_dt  ,
			      @invst_exprn_cd ,
			      @invst_objct_dt ,
			      @invst_objective_cd ,
			      @cmdty_hedge_pct ,
			      @cmdty_spclt_pct ,
			      @past_exprn_ind ,
			      @cmdty_risk_cptl_cd ,
			      @risk_fctr_hi_nbr ,
			      @risk_fctr_chng_dt  ,
			      @risk_fctr_med_nbr ,
			      @risk_fctr_low_nbr ,
			      @limit_unit_amt ,
			      @limit_trade_amt ,
			      @lmt_opt_expsr_amt ,
			      @income_pct ,
			      @capap_pct ,
			      @spclt_trd_pct ,
			      @init_order_cd ,
			      @init_ordr_slct_ind ,
			      @init_trd_val_cd ,
			      @init_rcved_val_cd ,
			      @pct_chng_dt ,
			      @alt_sec_rgstr_ind ,
			      @alt_pay_dvdnd_ind ,
			      @mail_frwrd_ind ,
			      @trd_brkr_ind ,
			      @trd_brkr_opt_ind ,
			      @trd_brkr_cmdty_ind ,
			      @aprvl_us_acct_ind ,
			      @managed_acct_ind ,
			      @money_manager_nm ,
			      @uk_mrkt_prfsn_cd ,
			      @uk_bsns_cust_cd ,
			      @private_cust_cd,
				@brkr_employee_cd,
				@oats_acct_type_cd,
				@large_trdr1_id,
				@large_trdr2_id,
				@large_trdr3_id,
				@mult_lrg_trdr_ind,
				@time_hrzn_yrs_nbr,
				@time_hrzn_updt_dt,
				@liquidity_cd,
				@liquidity_updt_dt,
				@rsk_tlrnc_cd,
				@rsk_tlrnc_updt_dt,
				@fdrl_acct_ty_cd,
				@medium_term_pct,
				@lp_wthld_pct,
      				@lp_wthld_chng_dt,
				@rpo1_dt,
      				@rpo2_dt,
				@death_cert_ind,
      				@tin_stts_cd,
      				@tin_stts_dt,
					@non_mem_affl_ind,
				@large_trdr4_id,
						@large_trdr5_id,
						@large_trdr6_id,
						@large_trdr7_id,
						@large_trdr8_id,
						@large_trdr9_id,
						@large_trdr10_id,
						@large_trdr11_id,
						@large_trdr12_id,
						@large_trdr13_id,
						@large_trdr14_id,
						@large_trdr15_id,
						@non_tb_comp_ind,
						@dol_ind,
      					@prte_ind,
						@sdi_ind,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrp
				
				select @error_description = 'update_nrp : tacc_compliance : Insert operation'
				
				raiserror 20121 "Insert operation to tacc_compliance failed"
				select @custom_error_code=@@error
							
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
                        
            COMMIT TRAN update_nrp
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nrp			
			/* update */

			/* now update realtime table row */
			UPDATE tacc_compliance
			SET action = 'U',
			      record_type_cd = 'NRP',
			      rr_cd = @rr_cd,
			      invst_exp_chng_dt = @invst_exp_chng_dt ,
			      invst_exprn_cd = @invst_exprn_cd,
			      invst_objct_dt = @invst_objct_dt,
			      invst_objective_cd = @invst_objective_cd,
			      cmdty_hedge_pct = @cmdty_hedge_pct,
			      cmdty_spclt_pct = @cmdty_spclt_pct,
			      past_exprn_ind = @past_exprn_ind,
			      cmdty_risk_cptl_cd = @cmdty_risk_cptl_cd,
			      risk_fctr_hi_nbr = @risk_fctr_hi_nbr,
			      risk_fctr_chng_dt = @risk_fctr_chng_dt,
			      risk_fctr_med_nbr = @risk_fctr_med_nbr,
			      risk_fctr_low_nbr = @risk_fctr_low_nbr,
			      limit_unit_amt = @limit_unit_amt,
			      limit_trade_amt = @limit_trade_amt,
			      lmt_opt_expsr_amt = @lmt_opt_expsr_amt,
			      income_pct = @income_pct,
			      capap_pct = @capap_pct,
			      spclt_trd_pct = @spclt_trd_pct,
			      init_order_cd = @init_order_cd,
			      init_ordr_slct_ind = @init_ordr_slct_ind,
			      init_trd_val_cd = @init_trd_val_cd,
			      init_rcved_val_cd = @init_rcved_val_cd,
			      pct_chng_dt = @pct_chng_dt,
			      alt_sec_rgstr_ind = @alt_sec_rgstr_ind,
			      alt_pay_dvdnd_ind = @alt_pay_dvdnd_ind,
			      mail_frwrd_ind = @mail_frwrd_ind,
			      trd_brkr_ind = @trd_brkr_ind,
			      trd_brkr_opt_ind = @trd_brkr_opt_ind,
			      trd_brkr_cmdty_ind = @trd_brkr_cmdty_ind,
			      aprvl_us_acct_ind = @aprvl_us_acct_ind,
			      managed_acct_ind = @managed_acct_ind,
			      money_manager_nm = @money_manager_nm,
			      uk_mrkt_prfsn_cd = @uk_mrkt_prfsn_cd,
			      uk_bsns_cust_cd = @uk_bsns_cust_cd,
			      private_cust_cd = @private_cust_cd,
				brkr_employee_cd = @brkr_employee_cd,
				oats_acct_type_cd = @oats_acct_type_cd,
				large_trdr1_id = @large_trdr1_id,
				large_trdr2_id = @large_trdr2_id,
				large_trdr3_id = @large_trdr3_id,
				mult_lrg_trdr_ind = @mult_lrg_trdr_ind,
				time_hrzn_yrs_nbr = @time_hrzn_yrs_nbr,
				time_hrzn_updt_dt = @time_hrzn_updt_dt,
				liquidity_cd = @liquidity_cd,
				liquidity_updt_dt= @liquidity_updt_dt,
				rsk_tlrnc_cd = @rsk_tlrnc_cd,
				rsk_tlrnc_updt_dt = @rsk_tlrnc_updt_dt,
				fdrl_acct_ty_cd = @fdrl_acct_ty_cd,
				medium_term_pct = @medium_term_pct,
				lp_wthld_pct = @lp_wthld_pct,
      				lp_wthld_chng_dt = @lp_wthld_chng_dt,
				rpo1_dt = @rpo1_dt,
      				rpo2_dt = @rpo2_dt,
      				death_cert_ind =	@death_cert_ind,
      				tin_stts_cd = @tin_stts_cd,
      				tin_stts_dt = @tin_stts_dt,
					non_mem_affl_ind = @non_mem_affl_ind,
				large_trdr4_id = @large_trdr4_id,
				large_trdr5_id = @large_trdr5_id,
				large_trdr6_id = @large_trdr6_id,
				large_trdr7_id = @large_trdr7_id,
				large_trdr8_id = @large_trdr8_id,
				large_trdr9_id = @large_trdr9_id,
				large_trdr10_id = @large_trdr10_id,
				large_trdr11_id = @large_trdr11_id,
				large_trdr12_id = @large_trdr12_id,
				large_trdr13_id = @large_trdr13_id,
				large_trdr14_id = @large_trdr14_id,
				large_trdr15_id = @large_trdr15_id,
				non_tb_comp_ind = @non_tb_comp_ind,
				dol_ind = @dol_ind,
      			prte_ind = @prte_ind,
				sdi_ind = @sdi_ind,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrp
				
				select @error_description = 'update_nrp : tacc_compliance : Update operation'
				
				raiserror 20122 "Update operation to tacc_compliance failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
		COMMIT TRAN update_nrp
		
		END		
		
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nrp

		/* now delete realtime table row */
		DELETE tacc_compliance
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrp
			
			select @error_description = 'update_nrp : tacc_compliance : Delete operation'
			
			raiserror 20123 "Delete operation to tacc_compliance failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nrp
	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_nrp to fbi
go

IF OBJECT_ID('dbo.update_nrp') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrp >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrp >>>'
go
