/*****************************************************************************
NAME: update_pos.sql
PURPOSE: Insert and update position tables
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	112696	5/25/16	J.Shen		Add 3 new fields non-realtime fields to taccount_sec_hldr
1.1	111043	5/25/17	J.Shen		Change seq_nbr data type from smallint to int
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_pos') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_pos
    IF OBJECT_ID('dbo.update_pos') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_pos >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_pos >>>'
END
go

create proc update_pos  
			@currency_cd          char(3)  ,
            @issue_when_ind       char(1)  ,
			@seq_nbr              int ,
			@type_account_cd      char(1)  ,
			@account_cd           char(5)  ,
			@branch_cd            char(3)  ,
			@client_nbr           char(4)  ,
			@security_adp_nbr     char(7)  ,
			@mrgn_hous_rqmt_amt   decimal(17,2),
			@source_price_cd      char(1)  ,
			@online_add_ind       char(1)  ,
			@free_lock_cd         char(1)  ,
			@holder_price_txt     char(11) ,
			@market_value_amt     decimal(17,2),
			@settlement_dt_qty    decimal(17,5),
			@rr_cd                char(3)  ,
			@cusip_intrl_nbr      char(15) ,
			@symbol_12            char(12) ,
			@exchange_msd_cd      char(1)  ,
			@activity_last_dt     datetime ,
			@record_type_cd       char(3)  ,
			@change_last_dt       datetime ,
			@chk_brch_acct_nbr    char(1)  ,
			@record_type_cd_txt   char(3)  ,
			@desc_holder_txt1     char(30) ,
			@desc_holder_txt2     char(30) ,
			@desc_holder_txt3     char(30) ,
			@desc_holder_txt4     char(30) ,
			@transaction_qty      decimal(17,5), /* signed quantity of this transaction */
			@test_ci_price        float, /* used as additional keys to find matching holding for */
                                         /* when_issued securities */
            @upd_qty_flag         char(1),  /* 'Y' or 'N' */
	    	@tables_for_master_process char(50) /* Don't use X-table if table listed */
            
as
begin
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    declare 
		@wi_seq_nbr            	int,
		@trade_dt_qty          	decimal(17,5),
		@cur_change_last_dt    	datetime,
		@action                	char(1),
		@rowcount             	int,
	   	@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description		varchar(150),
		@T_currency_cd          char(3)    ,
		@T_issue_when_ind       char(1)    ,
		@T_seq_nbr              int   ,
		@T_type_account_cd      char(1)    ,
		@T_account_cd           char(5)    ,
		@T_branch_cd            char(3)    ,
		@T_client_nbr           char(4)    ,
		@T_security_adp_nbr     char(7)    ,
		@T_mrgn_hous_rqmt_amt   decimal(17,2) ,
		@T_source_price_cd      char(1)       ,
		@T_online_add_ind       char(1)       ,
		@T_free_lock_cd         char(1)       ,
		@T_holder_price_txt     char(11)      ,
		@T_market_value_amt     decimal(17,2) ,
		@T_trade_dt_qty         decimal(17,5) ,
		@T_settlement_dt_qty    decimal(17,5) ,
		@T_rr_cd                char(3)       ,
		@T_cusip_intrl_nbr      char(15)      ,
		@T_symbol_12            char(12)      ,
		@T_exchange_msd_cd      char(1)       ,
		@T_activity_last_dt     datetime      ,
		@T_action               char(1)    ,
		@T_change_last_dt       datetime      ,
		@T_today_total_qty      decimal(17,5) ,
		@T_chk_brch_acct_nbr    char(1)       ,
		@T_gi_today_total_qty   decimal(17,5) ,
		@T_mrgn_hous_rqmt_pct   smallint,
		@T_sttlm_dt_mrkt_amt	decimal(17,2),
		@x_sec_hldr		   		char(1),
		@x_sec_hldr_txt		   	char(1),
		@line_txt_nbr		   	smallint,
		@sttlm_dt_mrkt_amt 		decimal(17,2),
		@T_nyse_req decimal(17,2),
		@T_regt_req decimal(17,2),
		@T_dly_accrd_intrst decimal(17,2)
   
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
						
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @currency_cd + "," + @type_account_cd + "," + @security_adp_nbr + "," + @issue_when_ind + "," + convert(varchar(8),@seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
	end
       
    select @wi_seq_nbr = -1

    /* For when issued securities find matching sequence number based on input transaction qty and price */
    /* NOTE: when this was done by the data server, the code only did this seq_nbr stuff */
    /* for trades. but it is thought that transactions invovling when-issued securities */
    /* can ONLY br trades. so we don't check trade vs bkkping here. */
     if @issue_when_ind = "Y"
        begin
           select @wi_seq_nbr = seq_nbr 
		   from taccount_sec_hldr
			where client_nbr     =   @client_nbr
			and branch_cd        =   @branch_cd
			and account_cd       =   @account_cd
			and currency_cd    	 =   @currency_cd
			and type_account_cd  =   @type_account_cd
			and security_adp_nbr =   @security_adp_nbr
			and issue_when_ind   =   @issue_when_ind
			and today_total_qty  =   @transaction_qty
			and ROUND(convert(float,holder_price_txt),5) = ROUND(@test_ci_price,5)

			if @wi_seq_nbr != -1
                select @seq_nbr = @wi_seq_nbr
				
        end

    /* determine if transaction is for a new position. also, get some data */
    /* that we can use later if it is an existing position */
    select     @trade_dt_qty       = trade_dt_qty      ,
		@cur_change_last_dt = change_last_dt,
		@action            = action,
		@T_currency_cd        = currency_cd  ,
		@T_issue_when_ind    = issue_when_ind ,
		@T_seq_nbr        = seq_nbr ,
		@T_type_account_cd     = type_account_cd,
		@T_account_cd         = account_cd,
		@T_branch_cd         = branch_cd,
		@T_client_nbr        = client_nbr,
		@T_security_adp_nbr     = security_adp_nbr,
		@T_mrgn_hous_rqmt_amt    = mrgn_hous_rqmt_amt,
		@T_source_price_cd     = source_price_cd,
		@T_online_add_ind     = online_add_ind,
		@T_free_lock_cd     = free_lock_cd,
		@T_holder_price_txt    = holder_price_txt,
		@T_market_value_amt    = market_value_amt,
		@T_trade_dt_qty        = trade_dt_qty,
		@T_settlement_dt_qty    = settlement_dt_qty,
		@T_rr_cd        = rr_cd,
		@T_cusip_intrl_nbr    = cusip_intrl_nbr,
		@T_symbol_12        = symbol_12,
		@T_exchange_msd_cd    = exchange_msd_cd,
		@T_activity_last_dt    = activity_last_dt,
		@T_action        = action,
		@T_change_last_dt    = change_last_dt,
		@T_today_total_qty    = today_total_qty ,
		@T_chk_brch_acct_nbr     = chk_brch_acct_nbr,
		@T_gi_today_total_qty    = gi_today_total_qty,
		@T_mrgn_hous_rqmt_pct    = mrgn_hous_rqmt_pct,
		@T_sttlm_dt_mrkt_amt = sttlm_dt_mrkt_amt,
		@T_nyse_req = nyse_req,
		@T_regt_req = regt_req,
		@T_dly_accrd_intrst = dly_accrd_intrst

    from taccount_sec_hldr
    where client_nbr     =   @client_nbr
	and branch_cd        =   @branch_cd
	and account_cd       =   @account_cd
	and currency_cd    	 =   @currency_cd
	and type_account_cd  =   @type_account_cd
	and security_adp_nbr =   @security_adp_nbr
	and issue_when_ind   =   @issue_when_ind
	and seq_nbr			 = 	@seq_nbr

    select @rowcount = @@rowcount

	

	if (@rowcount = 0)
	begin
		if @desc_holder_txt1 IS NOT NULL
		begin
			CREATE TABLE #update_pos_txt
			(
				line_txt_nbr     smallint NOT NULL,
				currency_cd      char(3)  NOT NULL,
				issue_when_ind   char(1)  NOT NULL,
				seq_nbr          int NOT NULL,
				type_account_cd  char(1)  NOT NULL,
				account_cd       char(5)  NOT NULL,
				branch_cd        char(3)  NOT NULL,
				client_nbr       char(4)  NOT NULL,
				security_adp_nbr char(7)  NOT NULL,
				desc_holder_txt  char(30) NULL,
				record_type_cd   char(3)  NULL,
				action           char(1)  NULL,
				rr_cd            char(3)  NULL,
				updt_last_tmstp  datetime NULL	       
			)

		    DECLARE @tmpLineNbr smallint
		    DECLARE @tmpHoldTxt char(30)
		    SELECT @tmpLineNbr = 1

		    while ( @tmpLineNbr  < 5 )
		    BEGIN
				SELECT @tmpHoldTxt  =
					CASE @tmpLineNbr
					WHEN    1   THEN   @desc_holder_txt1
					WHEN    2   THEN   @desc_holder_txt2
					WHEN    3   THEN   @desc_holder_txt3
					WHEN    4   THEN   @desc_holder_txt4
					ELSE    NULL
				
				END
				
				IF(@tmpHoldTxt is NULL)
				BEGIN
					BREAK
				END
				
				insert #update_pos_txt (line_txt_nbr    ,
						currency_cd     ,
						issue_when_ind  ,
						seq_nbr         ,
						type_account_cd ,
						account_cd      ,
						branch_cd       ,
						client_nbr      ,
						security_adp_nbr,
						desc_holder_txt ,
						record_type_cd  ,
						action          ,
						rr_cd           ,
						updt_last_tmstp )
				values(@tmpLineNbr      ,
				@currency_cd     ,
				@issue_when_ind  ,
				@seq_nbr         ,
				@type_account_cd ,
				@account_cd      ,
				@branch_cd       ,
				@client_nbr      ,
				@security_adp_nbr,
				@tmpHoldTxt      ,
				@record_type_cd_txt,
				'I'              ,
				@rr_cd           ,
				getdate()	)
	
				SELECT @tmpLineNbr = @tmpLineNbr + 1
		    End /* while ( @tmpLineNbr  < 5 ) */
		End /* if @desc_holder_txt1 IS NOT NULL */
	End /* If @rowcount = 0 */

    begin transaction update_pos
	
    if  @rowcount = 0
        
		begin /* insert holder and text */

            insert taccount_sec_hldr (currency_cd       ,
                                    issue_when_ind    ,
                                    seq_nbr           ,
                                    type_account_cd   ,
                                    account_cd        ,
                                    branch_cd         ,
                                    client_nbr        ,
                                    security_adp_nbr  ,
                                    mrgn_hous_rqmt_amt,
                                    source_price_cd   ,
                                    online_add_ind    ,
                                    free_lock_cd      ,
                                    holder_price_txt  ,
                                    market_value_amt  ,
                                    trade_dt_qty      ,
                                    settlement_dt_qty ,
                                    rr_cd             ,
                                    cusip_intrl_nbr   ,
                                    symbol_12         ,
                                    exchange_msd_cd   ,
                                    activity_last_dt  ,
                                    record_type_cd    ,
                                    action            ,
                                    change_last_dt    ,
                                    today_total_qty   ,
                                    chk_brch_acct_nbr ,
									gi_today_total_qty,
									mrgn_hous_rqmt_pct,
									sttlm_dt_mrkt_amt ,
									nyse_req          ,
									regt_req          ,
									dly_accrd_intrst  ,
									updt_last_tmstp    )
            values(@currency_cd        ,
                   @issue_when_ind     ,
                   @seq_nbr            ,
                   @type_account_cd    ,
                   @account_cd         ,
                   @branch_cd          ,
                   @client_nbr         ,
                   @security_adp_nbr   ,
                   @mrgn_hous_rqmt_amt ,
                   @source_price_cd    ,
                   @online_add_ind     ,
                   @free_lock_cd       ,
                   @holder_price_txt   ,
                   @market_value_amt   ,
                   0                   ,    
                   @settlement_dt_qty  ,
                   @rr_cd              ,
                   @cusip_intrl_nbr    ,
                   @symbol_12          ,
                   @exchange_msd_cd    ,
                   @activity_last_dt   ,
                   @record_type_cd     ,
                   'I'                 ,
                   @change_last_dt     ,
                   @transaction_qty    ,
                   @chk_brch_acct_nbr  ,
				   null,
				   null,
				   @sttlm_dt_mrkt_amt,
				   null,
				   null,
				   null,
				   getdate())
				   
				   SELECT @syb_error_code = @@error
		   
            /* check for each of four possible description lines and insert if text is not blank */
			if @desc_holder_txt1 IS NOT NULL  
			begin
           
				INSERT INTO tacc_sec_hldr_txt (line_txt_nbr    ,
				    currency_cd     ,
				    issue_when_ind  ,
				    seq_nbr         ,
				    type_account_cd ,
				    account_cd      ,
				    branch_cd       ,
				    client_nbr      ,
				    security_adp_nbr,
				    desc_holder_txt ,
				    record_type_cd  ,
				    action          ,
				    rr_cd           ,
				    updt_last_tmstp)
                select #update_pos_txt.line_txt_nbr, 
						#update_pos_txt.currency_cd, 
						#update_pos_txt.issue_when_ind, 
						#update_pos_txt.seq_nbr, 
						#update_pos_txt.type_account_cd, 
						#update_pos_txt.account_cd, 
						#update_pos_txt.branch_cd, 
						#update_pos_txt.client_nbr, 
						#update_pos_txt.security_adp_nbr, 
						#update_pos_txt.desc_holder_txt, 
						#update_pos_txt.record_type_cd, 
						#update_pos_txt.action, 
						#update_pos_txt.rr_cd,
						#update_pos_txt.updt_last_tmstp	
				from #update_pos_txt
				
				SELECT @syb_error_code = @@error
				
                DELETE #update_pos_txt
				
			end /* if @desc_holder_txt1 IS NOT NULL  */
			
        End /* if  @rowcount = 0 */

    else /* update existing holders - Note text table not updated */

		begin

			/* update action to reflect update only if row wasn't inserted today */
			if @action != 'I'
				select @action = 'U'
      
            /* determine new today_total_qty */
			/* check update qty flag. if 'N', leave today_total_qty as is. */
			if @upd_qty_flag = 'Y'
			begin
				/* if today_total_qty is 0 for the position we found and
				* there has been no activity in this position today,
				* use trade_dt_qty in our calculation. it
				* could be 0 as a result of some earlier activity. that's
				* why we check change_last_dt
				*/
				/*
				if (@today_total_qty IS NULL or
					@today_total_qty = ROUND(0.0,5)) and
					(@cur_change_last_dt IS NULL or
					@cur_change_last_dt != @change_last_dt)
					select @today_total_qty = @trade_dt_qty + @transaction_qty
				else
					select @today_total_qty = @today_total_qty + @transaction_qty
				*/
				
				/* 04/26/00 - sainath - update today_total_qty to be the qty accrued for the day including shadows qty but not include trade_qty at all in any case.*/
				select @T_today_total_qty = @T_today_total_qty + @transaction_qty

			end

			update taccount_sec_hldr 
			set activity_last_dt = @activity_last_dt,
                action           = @action          ,
                change_last_dt   = @change_last_dt  ,
                today_total_qty  = @T_today_total_qty,
          		record_type_cd 	 = @record_type_cd,
				updt_last_tmstp  = getdate()
			where client_nbr       =   @client_nbr
			and branch_cd        =   @branch_cd
			and account_cd       =   @account_cd
			and currency_cd    =   @currency_cd
			and type_account_cd  =   @type_account_cd
            and security_adp_nbr =   @security_adp_nbr
            and issue_when_ind   =   @issue_when_ind
            and seq_nbr	= 	@seq_nbr
			
			SELECT @syb_error_code = @@error
				
		end /* else */

	commit transaction update_pos
		
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END	
	
    return 0
	
end
go

grant execute on update_pos to fbi
go

IF OBJECT_ID('dbo.update_pos') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_pos >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_pos >>>'
go
