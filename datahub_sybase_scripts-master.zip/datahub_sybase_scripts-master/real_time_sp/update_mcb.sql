/*
$Header: /Realtime/Realtime/stp/update_mcb.sql 1     10/19/01 4:22p Tbjuhu $
$Log: /Realtime/Realtime/stp/update_mcb.sql $
 * 
 * 1     10/19/01 4:22p Tbjuhu
 * 4th Qtr Data model changes
 *  
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_mcb') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_mcb
    IF OBJECT_ID('dbo.update_mcb') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_mcb >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_mcb >>>'
END
go

CREATE PROC update_mcb
	@security_adp_nbr	char(7),
	@installment_dt		datetime,
	@installment_amt	float	
						
AS
BEGIN
    
	DECLARE @action_cd char(1),
		@tbl_security_adp_nbr char(7),
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
			
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
						
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tbond_instl_prmtr 
	WHERE security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		
		BEGIN TRAN update_mcb
		/* insert */
		INSERT INTO tbond_instl_prmtr (	security_adp_nbr,
						record_type_cd,
						action_cd,
						installment_dt,
						installment_amt,
						updt_last_tmstp)
				VALUES (	@security_adp_nbr,
						'MCB',
						'I',
						@installment_dt,
						@installment_amt,
						getdate())

		SELECT @syb_error_code = @@error
	
		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_mcb
			
			select @error_description = 'update_mcb : tbond_instl_prmtr : Insert operation'
			
			raiserror 20013 "Insert operation to tbond_instl_prmtr failed"
			select @custom_error_code=@@error
	
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
					
			RETURN -99
		END

		COMMIT TRAN update_mcb
		
	END
	ELSE
	BEGIN
		
		BEGIN TRAN update_mcb
		/* update */

		/* now update tmsd_base */
		UPDATE tbond_instl_prmtr SET record_type_cd = 'MCB',
					action_cd = 'U',
					installment_dt = @installment_dt,
					installment_amt = @installment_amt,
					updt_last_tmstp = getdate()		
		WHERE security_adp_nbr = @security_adp_nbr
		
		SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
	    BEGIN
		
			ROLLBACK TRAN update_mcb
		
			select @error_description = 'update_mcb : tbond_instl_prmtr : Update operation'
			
			raiserror 20014 "Update operation to tbond_instl_prmtr failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN -99
		
	    END
	    
	    COMMIT TRAN update_mcb

	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('CMSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)

	END
   
END

go

grant execute on update_mcb to fbi
go

IF OBJECT_ID('dbo.update_mcb') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_mcb >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_mcb >>>'
go
