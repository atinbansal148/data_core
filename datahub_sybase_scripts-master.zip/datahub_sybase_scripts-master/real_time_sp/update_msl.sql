/*
$Header: /Realtime/Realtime/stp/update_msl.sql 8     12/13/00 10:19a Tbjuhu $
$Log: /Realtime/Realtime/stp/update_msl.sql $
 * 
 * 8     12/13/00 10:19a Tbjuhu
 * Version 1.3
 * 
 * 7     6/29/00 5:20p Tbjuhu
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_msl') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msl
    IF OBJECT_ID('dbo.update_msl') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msl >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msl >>>'
END
go

CREATE PROC update_msl
	@security_adp_nbr		char(7),
	@strike_price_amt		decimal(16,8),
	@expiration_dt			datetime,
	@factor_pct			decimal(15,8), 
	@scrty_adp_base_nbr    		char(7), 
	@type_option_cd			char(2)=null,
	@maturity_aclrtd_dt		datetime,
	@dlvrbl_factor_pct    		decimal(15,8),
	@occ_optn_sym_id		char(6)
AS
BEGIN
  
	DECLARE @action_cd char(1),
			@tbl_security_adp_nbr 	char(7),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)
		
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM toption_data WHERE
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msl
		/* insert */
		INSERT INTO toption_data (	security_adp_nbr,
						strike_price_amt,
						expiration_dt,
						record_type_cd,
						action_cd,
						factor_pct, 
						scrty_adp_base_nbr,						
						type_option_cd,
						maturity_aclrtd_dt,
						dlvrbl_factor_pct,
						occ_optn_sym_id )
		VALUES (	@security_adp_nbr,
					@strike_price_amt,
					@expiration_dt,
					'MSL',
					'I',
					@factor_pct, 
					@scrty_adp_base_nbr,
					@type_option_cd,
					@maturity_aclrtd_dt,
					@dlvrbl_factor_pct,
					@occ_optn_sym_id )
					
		SELECT @syb_error_code = @@error
					
		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msl
			
			select @error_description = 'update_msl : toption_data : Insert operation'
			
			raiserror 20047 "Insert operation to toption_data failed"	
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END

		COMMIT TRAN update_msl
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msl
		/* update */

		/* now update real-time table */
		UPDATE toption_data SET
			strike_price_amt = @strike_price_amt,
			expiration_dt = @expiration_dt,
			record_type_cd = 'MSL',
			action_cd = 'U',
			factor_pct = @factor_pct,
			scrty_adp_base_nbr = @scrty_adp_base_nbr,
			type_option_cd = @type_option_cd,
			maturity_aclrtd_dt = @maturity_aclrtd_dt,
			dlvrbl_factor_pct = @dlvrbl_factor_pct,
			occ_optn_sym_id = @occ_optn_sym_id
		WHERE security_adp_nbr = @security_adp_nbr
		
		SELECT @syb_error_code = @@error

		if @syb_error_code !=0
		BEGIN
		
			ROLLBACK TRAN update_msl
			
			select @error_description = 'update_msl : toption_data : Update operation'
			
			raiserror 20048 "Update operation to toption_data failed"	
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			
			RETURN -99
			
		END
		
		COMMIT TRAN update_msl

	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
  
END

go

grant execute on update_msl to fbi
go

IF OBJECT_ID('dbo.update_msl') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msl >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msl >>>'
go