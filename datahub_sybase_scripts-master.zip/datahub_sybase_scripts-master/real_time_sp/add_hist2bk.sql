/*****************************************************************************
NAME: add_hist2bk.sql
PURPOSE: Insert and update hist2 bookkeeping tables
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	87896	10/5/12	Judy Shen	Add the full 25 byte trans_control_id field
1.2	95125	12/2/13	J. Shen		Add fourteen new FATCA Withholding fields
1.3 	3430144	9/28/16	J.Shen		Add one new field option_open_code 
1.4	3668986	2/26/18	J.Shen		Add 2 new fields dol_ind and prte_ind 
1.5	4035600	2/27/18	J.Shen		Add a new field sdi_ind 
1.6	4081714	2/27/18	J.Shen		Add a new field div_pay_ca_id
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.add_hist2bk') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.add_hist2bk
    IF OBJECT_ID('dbo.add_hist2bk') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.add_hist2bk >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.add_hist2bk >>>'
END
go

CREATE PROC add_hist2bk	@account_cd	char(5),
				@branch_cd char(3),
				@chck_brch_acct_nbr char(1),
				@client_nbr	char(4),
				@currency_cd char(3),
				@debit_credit_cd char(1),
				@security_adp_nbr char(7),
				@trans_acct_hist_cd char(1),
				@transaction_dt	datetime,
				@type_account_cd	char(1),
				@processing_dt	datetime,
				@action_cd	char(1),
				@cusip_nbr char(8) = null,
				@cusip_issr_cd char(6) = null,
				@share_trans_qty decimal(17,5) = null,
				@cusip_extend_nbr char(3) = null,
				@cdg_cusip_cd char(1) = null,
				@rr_cd char(3) = null,
				@trailer2_cd char(2) = null,
				@trailer3_cd char(2) = null,
				@rfrn_id char(14) = null,
				@batch_cd char(2) = null,
				@entry_cd char(3) = null,
				@tran_total_amt decimal(17,2) = null,
				@line_desc_msd_qty smallint = null,
				@dtc_actvty_cd char(3) = null,
				@srce_trans_cd char(8) = null,
				@client_use_txt char(20) = null,
				@crrn_cvrsn_rt decimal(15,8) = null,
				@ctgy_cd char(5) = null,
				@tle_misc_txt char(20) = null,
				@tle_trnfr_typ_cd char(1) = null,
				@gift_cd char(1) = null,
				@cbt_control_id char(30) = null,
				@cbt_cntra_pty_cd char(8) = null,
				@instr_spcl_orgn_cd char(1) = null,
				@trans_control_id char(25) = null,
				@us_wthld_cd char(1) = null,
				@fatca_wthld_ind char(1) = null,
				@fatca_elgblty_cd char(1) = null,
				@fatca_wthld_amt decimal(17,2) = null,
				@fatca_wthld_rt decimal(7,5) = null,
				@nra_wthld_amt decimal(17,2) = null,
				@nra_wthld_rt decimal(7,5) = null,
				@nra_drp_thr_wh_amt decimal(17,2) = null,
				@nra_drp_thr_wh_rt decimal(7,5) = null,
				@fatca_tax_cr_amt decimal(17,2) = null,
				@fatca_tax_cr_cd char(1) = null,
				@na_geo_cd char(3) = null,
				@state_wthld_amt decimal(17,2) = null,
				@state_wthld_rt decimal(7,5) = null,
				@option_open_code char(1) = null,
				@dol_ind char(1) = null,
				@prte_ind char(1) = null,
				@sdi_ind char(1) = null,
				@div_pay_ca_id char(16) = null,
				@tables_for_master_process char(50) = null
												
AS
BEGIN    

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    DECLARE @trans_hist_seq_nbr 	int,
			@rec_type_cd 			char(3),
			@start_time             datetime,
			@proc_name              varchar(35),
			@input_parm             varchar(800),
			@debug_flag             char(1),
			@syb_error_code         int ,
			@custom_error_code      int,
			@error_description		varchar(150)			

	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
			
			
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @chck_brch_acct_nbr + "," + @currency_cd + "," + @debit_credit_cd + "," + @security_adp_nbr + "," + @trans_acct_hist_cd + "," + convert(char(30),@transaction_dt,116) + "," + @type_account_cd + "," + convert(char(30),@processing_dt,116)
		select @error_description = ''
		select @custom_error_code = 0
	end
			
	
	select @rec_type_cd = 'H2R'
	      
   			
	/* find next sequence number to use */
	/* needs to verify the search condition to find the next sequence number to use */
	SELECT @trans_hist_seq_nbr = MAX(trans_hist_seq_nbr) 
	FROM ths2_bkpg_trans 
	WHERE
		client_nbr = @client_nbr AND
		branch_cd = @branch_cd AND
		account_cd = @account_cd AND
		chck_brch_acct_nbr = @chck_brch_acct_nbr AND
		currency_cd = @currency_cd AND
		debit_credit_cd = @debit_credit_cd AND
		security_adp_nbr = @security_adp_nbr AND
		trans_acct_hist_cd = @trans_acct_hist_cd AND
		transaction_dt = @transaction_dt AND
		type_account_cd = @type_account_cd AND
		processing_dt = @processing_dt

	SELECT @trans_hist_seq_nbr = ISNULL(@trans_hist_seq_nbr,0)

	SELECT @trans_hist_seq_nbr = @trans_hist_seq_nbr + 1


	BEGIN TRANSACTION add_hist2bk 

	/* add row to ths2_bkpg_trans*/
	      
	INSERT INTO ths2_bkpg_trans (account_cd,
				branch_cd,
				chck_brch_acct_nbr,
				client_nbr,
				currency_cd,
				debit_credit_cd,
				trans_hist_seq_nbr,
				security_adp_nbr,
				trans_acct_hist_cd,
				transaction_dt,
				type_account_cd,
				processing_dt,
				action_cd,
				rec_type_cd,
				cusip_nbr,
				cusip_issr_cd,
				share_trans_qty,
				cusip_extend_nbr,
				cdg_cusip_cd,
				rr_cd,
				trailer2_cd,
				trailer3_cd,
				rfrn_id,
				batch_cd,
				entry_cd,
				tran_total_amt,
				line_desc_msd_qty,
				dtc_actvty_cd,
				srce_trans_cd,
				client_use_txt,
				crrn_cvrsn_rt,
				ctgy_cd,
				tle_misc_txt,
				tle_trnfr_typ_cd,
				gift_cd,
				cbt_control_id,
				cbt_cntra_pty_cd,
				instr_spcl_orgn_cd,
				trans_control_id,
				us_wthld_cd,
				fatca_wthld_ind,
				fatca_elgblty_cd,
				fatca_wthld_amt,
				fatca_wthld_rt,
				nra_wthld_amt,
				nra_wthld_rt,
				nra_drp_thr_wh_amt,
				nra_drp_thr_wh_rt,
				fatca_tax_cr_amt,
				fatca_tax_cr_cd,
				na_geo_cd,
				state_wthld_amt,
				state_wthld_rt,
				option_open_code,
				dol_ind ,
				prte_ind ,
				sdi_ind ,
				div_pay_ca_id,
				updt_last_tmstp)
			VALUES (@account_cd,
				@branch_cd,
				@chck_brch_acct_nbr,
				@client_nbr,
				@currency_cd,
				@debit_credit_cd,
				@trans_hist_seq_nbr,
				@security_adp_nbr,
				@trans_acct_hist_cd,
				@transaction_dt,
				@type_account_cd,
				@processing_dt,
				@action_cd,
				@rec_type_cd,
				@cusip_nbr,
				@cusip_issr_cd,
				@share_trans_qty,
				@cusip_extend_nbr,
				@cdg_cusip_cd,
				@rr_cd,
				@trailer2_cd,
				@trailer3_cd,
				@rfrn_id,
				@batch_cd,
				@entry_cd,
				@tran_total_amt,
				@line_desc_msd_qty,
				@dtc_actvty_cd,
				@srce_trans_cd,
				@client_use_txt,
				@crrn_cvrsn_rt,
				@ctgy_cd,
				@tle_misc_txt,
				@tle_trnfr_typ_cd,
				@gift_cd,
				@cbt_control_id,
				@cbt_cntra_pty_cd,
				@instr_spcl_orgn_cd,
				@trans_control_id,
				@us_wthld_cd,
				@fatca_wthld_ind,
				@fatca_elgblty_cd,
				@fatca_wthld_amt,
				@fatca_wthld_rt,
				@nra_wthld_amt,
				@nra_wthld_rt,
				@nra_drp_thr_wh_amt,
				@nra_drp_thr_wh_rt,
				@fatca_tax_cr_amt,
				@fatca_tax_cr_cd,
				@na_geo_cd,
				@state_wthld_amt,
				@state_wthld_rt,
				@option_open_code,
				@dol_ind ,
				@prte_ind ,
				@sdi_ind ,
				@div_pay_ca_id,
				getdate())
	
	SELECT @syb_error_code = @@error
	
	if @syb_error_code != 0
	BEGIN
	
	    ROLLBACK TRAN add_hist2bk
		
		select @error_description = 'add_hist2bk : ths2_bkpg_trans : Insert operation'
		
		raiserror 20186 "Insert operation to ths2_bkpg_trans failed"
	    select @custom_error_code=@@error
		
		IF (@debug_flag="Y")
		BEGIN
			INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
		END
		
	    RETURN -99
		
	END			
	      

 	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
	COMMIT TRANSACTION add_hist2bk    
  
END

go

grant execute on add_hist2bk to fbi
go

IF OBJECT_ID('dbo.add_hist2bk') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.add_hist2bk >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.add_hist2bk >>>'
go

