/*****************************************************************************
NAME: update_bal.sql
PURPOSE: Insert and update taccount_balance & tacc_type_balance tables
REVISIONS:
Ver	SSR	Date	Author		Description
-------	-------	-------	---------------	--------------------------------------
1.0	80735	5/16/13	Judy Shen	add a new field fund_exp_nbr_cd to taccount_balance table
1.1	108006	9/7/15	J. Shen		add a new field csh_put_frzn_fnds to taccount_balance table; 
					this field is not updated in real-time.
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_bal') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_bal
    IF OBJECT_ID('dbo.update_bal') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_bal >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_bal >>>'
END
go

create proc update_bal @currency_cd			char (3)    ,           
                    @account_cd                char (5)    ,           
                    @branch_cd                 char (3)    ,           
                    @client_nbr                char (4)    ,           
                    @last_bkpg_actv_dt         datetime    ,           
                    @online_add_ind            char (1)    ,
                    @rr_cd                     char (3)    ,
                    @type_account_cd           char(1)     ,
                    @transaction_amt           decimal(17,2),
                    @transaction_settlm_amt    decimal(17,2),
                    @chk_brch_acct_nbr         char(1),
	            @tables_for_master_process char(50) /* Don't use X-table if table listed */

as

begin

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    declare 
		@taccount_balance_rowcount 	smallint,
		@tacc_type_balance_rowcount smallint,
		@start_time             	datetime,
		@proc_name              	varchar(35),
		@input_parm             	varchar(800),
		@debug_flag             	char(1),
		@syb_error_code         	int ,
		@custom_error_code      	int,
		@error_description			varchar(150),
        /* BAA columns */	
		@T_currency_cd              char(3)   ,
		@T_account_cd               char(5)   ,
		@T_branch_cd                char(3)   ,
		@T_client_nbr               char(4)   ,
		@T_last_bsns_actv_dt        datetime ,
		@T_last_bkpg_actv_dt        datetime      ,
		@T_last_mrgn_actv_dt        datetime      ,
		@T_cash_bal_call_amt        decimal(17,2) ,
		@T_house_bal_call_amt       decimal(17,2) ,
		@T_maxcash_type12_amt       decimal(17,2) ,
		@T_mmf_avlbl_tdy_amt        decimal(17,2) ,
		@T_mmf_avlbl_ytdy_amt       decimal(17,2) ,
		@T_ytd_mrgn_int_amt         decimal(17,2) ,
		@T_sma_balance_amt          decimal(17,2) ,
		@T_sma_bal_chg130_amt       decimal(17,2) ,
		@T_same_day_sbst_amt        decimal(17,2) ,
		@T_net_lmv_smv_amt          decimal(17,2) ,
		@T_mrgn_regt_rqmt_amt       decimal(17,2) ,
		@T_market_val_tot_amt       decimal(17,2) ,
		@T_mrgn_csh_avlbl_amt       decimal(17,2) ,
		@T_buying_pwr_tot_amt       decimal(17,2) ,
		@T_tbill_byng_pwr_amt       decimal(17,2) ,
		@T_noncv_bnd_bpwr_amt       decimal(17,2) ,
		@T_muni_byng_pwr_amt        decimal(17,2) ,
		@T_mmf_accmt_txt            char(17)      ,
		@T_new_house_call_amt       decimal(17,2) ,
		@T_house_equity_amt         decimal(17,2) ,
		@T_equity_total_amt         decimal(17,2) ,
		@T_spad_note_ind            char(1)       ,
		@T_problem_note_cd          char(1)       ,
		@T_ulstd_stk_optn_amt       decimal(17,2) ,
		@T_unscr_db_bal_amt         decimal(17,2) ,
		@T_super_rstrd_amt          decimal(17,2) ,
		@T_online_add_ind           char(1)       ,
		@T_reorg_postdt_ind         char(1)       ,
		@T_optn_mrkt_val_amt        decimal(17,2) ,
		@T_lqdtg_eqty_tot_amt       decimal(17,2) ,
		@T_funds_nbr_cd             char(2)       ,
--     	@T_record_type_cd           char(3)       ,
		@T_rr_cd                    char(3)       ,
		@T_action		   			char(1),	
		@T_opt_maint_rqrm_amt       decimal(17,2) ,
		@T_call_nyse_amt            decimal(17,2) ,
		@T_pending_amt              decimal(17,2) ,
		@T_fund_na_cd               char(1)       ,
		@T_fund_held_cd             char(1)       ,
		@T_dytrd_buy_pwr_amt        decimal(17,2) ,
		@T_pttrn_dytrd_ind          char(1)       ,
		@T_dtrd_eqty_vltn_ind       char(1)       ,
		@T_dytrd_rstrtn_ind         char(1)       ,
		@T_dytrd_call_amt           decimal(15,2) ,
		@T_pmv_amt           		decimal(17,2) ,	
		@T_funds_exp_nbr_cd	      	char(3) ,
		@T_csh_put_frzn_fnds	decimal(17,2) ,
		/* BAB Columns */
		@TACC_type_account_cd       char(1)   ,
		@TACC_account_cd            char(5)   ,
		@TACC_branch_cd             char(3)   ,
		@TACC_client_nbr            char(4)   ,
		@TACC_currency_cd           char(3)   ,
		@TACC_ydys_hse_exces_amt    decimal(17,2) ,
		@TACC_ydys_equity_pct       decimal(7,0)  ,
		@TACC_ydys_equity_amt       decimal(17,2) ,
		@TACC_ydys_mrkt_val_amt     decimal(17,2) ,
		@TACC_ydys_trade_dt_amt     decimal(17,2) ,
		@TACC_tdys_trade_dt_amt     decimal(17,2) ,
		@TACC_ydys_settlm_dt_amt    decimal(17,2) ,
		@TACC_tdys_settlm_dt_amt    decimal(17,2) ,
--     	@TACC_record_type_cd        char(3)    ,
		@TACC_rr_cd                 char(3)   ,
		@TACC_action		      	char(1),	
		@TACC_chk_br_acct_ty_nbr   	char(1)   ,
		@TACC_class_acct_mrgn_cd   	char(2)   ,
		@TACC_gi_tdys_trd_dt_amt   	decimal(17,2) ,
		@TACC_gi_tdys_settlm_amt   	decimal(17,2)
	   
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
						
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + @currency_cd
		select @error_description = ''
		select @custom_error_code = 0
	end

    select @tables_for_master_process = RTRIM(LTRIM(@tables_for_master_process))
	
	/* select from taccount_balance */
	select 
		@T_currency_cd         =	currency_cd,         
		@T_account_cd          =	account_cd ,         
		@T_branch_cd           =	branch_cd,           
		@T_client_nbr          =	client_nbr,          
		@T_last_bsns_actv_dt   =	last_bsns_actv_dt ,  
		@T_last_bkpg_actv_dt   =	last_bkpg_actv_dt ,  
		@T_last_mrgn_actv_dt   =	last_mrgn_actv_dt ,  
		@T_cash_bal_call_amt   =	cash_bal_call_amt ,  
		@T_house_bal_call_amt  =	house_bal_call_amt , 
		@T_maxcash_type12_amt  =	maxcash_type12_amt  ,
		@T_mmf_avlbl_tdy_amt   =	mmf_avlbl_tdy_amt   ,
		@T_mmf_avlbl_ytdy_amt  =	mmf_avlbl_ytdy_amt  ,
		@T_ytd_mrgn_int_amt    =	ytd_mrgn_int_amt    ,
		@T_sma_balance_amt     =	sma_balance_amt     ,
		@T_sma_bal_chg130_amt  =	sma_bal_chg130_amt  ,
		@T_same_day_sbst_amt   =	same_day_sbst_amt   ,
		@T_net_lmv_smv_amt     =	net_lmv_smv_amt     ,
		@T_mrgn_regt_rqmt_amt  =	mrgn_regt_rqmt_amt  ,
		@T_market_val_tot_amt  =	market_val_tot_amt  ,
		@T_mrgn_csh_avlbl_amt  =	mrgn_csh_avlbl_amt  ,
		@T_buying_pwr_tot_amt  =	buying_pwr_tot_amt  ,
		@T_tbill_byng_pwr_amt  =	tbill_byng_pwr_amt  ,
		@T_noncv_bnd_bpwr_amt  =	noncv_bnd_bpwr_amt  ,
		@T_muni_byng_pwr_amt   =	muni_byng_pwr_amt   ,
		@T_mmf_accmt_txt       =	mmf_accmt_txt       ,
		@T_new_house_call_amt  =	new_house_call_amt  ,
		@T_house_equity_amt    =	house_equity_amt    ,
		@T_equity_total_amt    =	equity_total_amt    ,
		@T_spad_note_ind       =	spad_note_ind       ,
		@T_problem_note_cd     =	problem_note_cd     ,
		@T_ulstd_stk_optn_amt  =	ulstd_stk_optn_amt  ,
		@T_unscr_db_bal_amt    =	unscr_db_bal_amt    ,
		@T_super_rstrd_amt     =	super_rstrd_amt     ,
		@T_online_add_ind      =	online_add_ind      ,
		@T_reorg_postdt_ind    =	reorg_postdt_ind    ,
		@T_optn_mrkt_val_amt   =	optn_mrkt_val_amt   ,
		@T_lqdtg_eqty_tot_amt  =	lqdtg_eqty_tot_amt  ,
		@T_funds_nbr_cd        =	funds_nbr_cd        ,
--		@T_record_type_cd      =	record_type_cd       ,
		@T_rr_cd               =	rr_cd               ,
		@T_action	       	   =	action		    ,	
		@T_opt_maint_rqrm_amt  =	opt_maint_rqrm_amt  ,
		@T_call_nyse_amt       =	call_nyse_amt       ,
		@T_pending_amt         =	pending_amt         ,
		@T_fund_na_cd          =	fund_na_cd          ,
		@T_fund_held_cd        =	fund_held_cd,
		@T_dytrd_buy_pwr_amt   =	dytrd_buy_pwr_amt   ,
		@T_pttrn_dytrd_ind     =	pttrn_dytrd_ind     ,
		@T_dtrd_eqty_vltn_ind  =	dtrd_eqty_vltn_ind  ,
		@T_dytrd_rstrtn_ind    =	dytrd_rstrtn_ind    ,
		@T_dytrd_call_amt      =	dytrd_call_amt      ,
		@T_pmv_amt			   =	pmv_amt	    ,
		@T_funds_exp_nbr_cd    =	funds_exp_nbr_cd    ,  
		@T_csh_put_frzn_fnds     =	csh_put_frzn_fnds 
	from taccount_balance 
	where client_nbr  =   @client_nbr
	and branch_cd     =   @branch_cd
 	and account_cd    =   @account_cd
	and currency_cd   =   @currency_cd

   	select @taccount_balance_rowcount = @@rowcount

	/* select from tacc_type_balance */
    select  
       @TACC_type_account_cd    =	type_account_cd    ,
       @TACC_account_cd         =	account_cd         ,
       @TACC_branch_cd          =	branch_cd          ,
       @TACC_client_nbr         =	client_nbr         ,
       @TACC_currency_cd        =	currency_cd        ,
       @TACC_ydys_hse_exces_amt =	ydys_hse_exces_amt ,
       @TACC_ydys_equity_pct    =	ydys_equity_pct    ,
       @TACC_ydys_equity_amt    =	ydys_equity_amt    ,
       @TACC_ydys_mrkt_val_amt  =	ydys_mrkt_val_amt  ,
       @TACC_ydys_trade_dt_amt  =	ydys_trade_dt_amt  ,
       @TACC_tdys_trade_dt_amt  =	tdys_trade_dt_amt  ,
       @TACC_ydys_settlm_dt_amt =	ydys_settlm_dt_amt ,
       @TACC_tdys_settlm_dt_amt =	tdys_settlm_dt_amt ,
--     @TACC_record_type_cd     =	record_type_cd     ,
       @TACC_rr_cd              =	rr_cd              ,
       @TACC_action				=	action		   ,
       @TACC_chk_br_acct_ty_nbr =	chk_br_acct_ty_nbr ,
       @TACC_class_acct_mrgn_cd =	class_acct_mrgn_cd ,
       @TACC_gi_tdys_trd_dt_amt =	gi_tdys_trd_dt_amt ,
       @TACC_gi_tdys_settlm_amt =	gi_tdys_settlm_amt
	from tacc_type_balance 
	where client_nbr   	=   @client_nbr
	and branch_cd      	=   @branch_cd
 	and account_cd    	=   @account_cd
	and currency_cd    	=   @currency_cd  
   	and type_account_cd =   @type_account_cd   

	select @tacc_type_balance_rowcount = @@rowcount    

	
	/* This transaction inserts into taccount_balance and */
	/* tacc_type_balance if the row does not exist        */
	/* This transaction updates taccount_balance and 	  */
	/* tacc_type_balance if the row does exist            */
   	begin transaction update_bal

	/* taccount_balance row does not exist so insert it */
	if @taccount_balance_rowcount = 0
        begin /* insert taccount_balance table */		
     			
			insert taccount_balance (currency_cd         ,
                                     account_cd          ,
                                     branch_cd           ,
                                     client_nbr          ,
                                     last_bsns_actv_dt   ,
                                     last_bkpg_actv_dt   ,
                                     last_mrgn_actv_dt   ,
                                     cash_bal_call_amt   ,
                                     house_bal_call_amt  ,
                                     maxcash_type12_amt  ,
                                     mmf_avlbl_tdy_amt   ,
                                     mmf_avlbl_ytdy_amt  ,
                                     ytd_mrgn_int_amt    ,
                                     sma_balance_amt     ,
                                     sma_bal_chg130_amt  ,
                                     same_day_sbst_amt   ,
                                     net_lmv_smv_amt     ,
                                     mrgn_regt_rqmt_amt  ,
                                     market_val_tot_amt  ,
                                     mrgn_csh_avlbl_amt  ,
                                     buying_pwr_tot_amt  ,
                                     tbill_byng_pwr_amt  ,
                                     noncv_bnd_bpwr_amt  ,
                                     muni_byng_pwr_amt   ,
                                     mmf_accmt_txt       ,
                                     new_house_call_amt  ,
                                     house_equity_amt    ,
                                     equity_total_amt    ,
                                     spad_note_ind       ,
                                     problem_note_cd     ,
                                     ulstd_stk_optn_amt  ,
                                     unscr_db_bal_amt    ,
                                     super_rstrd_amt     ,
                                     online_add_ind      ,
                                     reorg_postdt_ind    ,
                                     optn_mrkt_val_amt   ,
                                     lqdtg_eqty_tot_amt  ,
                                     funds_nbr_cd        ,
                                     record_type_cd      ,
                                     action              ,
                                     rr_cd               ,
                                     opt_maint_rqrm_amt  ,
                                     call_nyse_amt       ,
                                     pending_amt         ,
                                     fund_na_cd          ,
                                     fund_held_cd        ,
                                     dytrd_buy_pwr_amt   ,
                                     pttrn_dytrd_ind     ,
                                     dtrd_eqty_vltn_ind  ,
                                     dytrd_rstrtn_ind    ,
                                     dytrd_call_amt      ,
									 pmv_amt,
									 funds_exp_nbr_cd,
				     csh_put_frzn_fnds,
                                     updt_last_tmstp	)
            values(@currency_cd        ,
                   @account_cd         ,
                   @branch_cd          ,
                   @client_nbr         ,
                   null                ,
                   @last_bkpg_actv_dt  , 
                   null                ,
                   0.0                 ,
                   0.0 ,
                   0.0 ,
                   0.0  ,
                   0.0 ,
                   0.0   ,
                   0.0    ,
                   0.0 ,
                   0.0  ,
                   0.0    ,
                   0.0 ,
                   0.0 ,
                   0.0 ,
                   0.0 ,
                   0.0 ,
                   0.0 ,
                   0.0  ,
                   ' '      ,
                   0.0 ,
                   0.0   ,
                   0.0   ,
                   'N'      ,
                   'N'    ,
                   0.0 ,
                   0.0   ,
                   0.0    ,
                   @online_add_ind     ,
                   'N'   ,
                   0.0  ,
                   0.0 ,
                   ' '       ,
                   'BAR'     ,
                   'I'                 ,
                   @rr_cd              ,
                   0.0 ,
                   0.0      ,
                   0.0 ,
				   null ,
				   null  ,
				   0.0 ,
				   'N' ,
				   'N' ,
				   'N' ,
				   0.0 ,
				   0.0 ,
				   '   ',
				   0.0 ,
				   getdate()     )   

		SELECT @syb_error_code = @@error				   
		
		end /* taccount_balance row does not exist */
		
	else /* taccount_balance row does exist so update it */

        begin /* update taccount_balance */

			/* change action to reflect update unless row was inserted today */
            if @T_action != 'I'
                select @T_action = 'U'

			/* only add a rollback record if one does not already exist */
            update taccount_balance 
			set last_bkpg_actv_dt 	= @last_bkpg_actv_dt,
				action            	=  @T_action,
				record_type_cd		= 'BAR',
				updt_last_tmstp 	= getdate()
            where  client_nbr 	=   @client_nbr
			and branch_cd       =   @branch_cd
			and account_cd      =   @account_cd
			and currency_cd    	=   @currency_cd
			
			SELECT @syb_error_code = @@error
		
		end /* update taccount_balance */
			
	
	/* taccount_balance row does not exist so insert it */
	if @tacc_type_balance_rowcount = 0
		
		begin /* insert tacc_type_balance */
           
			insert tacc_type_balance(type_account_cd    ,
                                     account_cd         ,
                                     branch_cd          ,
                                     client_nbr         ,
                                     currency_cd        ,
                                     ydys_hse_exces_amt ,
                                     ydys_equity_pct    ,
                                     ydys_equity_amt    ,
                                     ydys_mrkt_val_amt  ,
                                     ydys_trade_dt_amt  ,
                                     tdys_trade_dt_amt  ,
                                     ydys_settlm_dt_amt ,
                                     tdys_settlm_dt_amt ,
                                     record_type_cd     ,
                                     action             ,
                                     rr_cd              ,
                                     chk_br_acct_ty_nbr ,
                                     class_acct_mrgn_cd ,
									 gi_tdys_trd_dt_amt ,
									 gi_tdys_settlm_amt	,
									 updt_last_tmstp	)
            values(@type_account_cd   ,  
                   @account_cd        , 
                   @branch_cd         , 
                   @client_nbr        , 
                   @currency_cd       , 
                   0.0, 
                   0.0   , 
                   0.0   , 
                   0.0 , 
                   0.0 , 
                   @transaction_amt , 
                   0.0, 
                   @transaction_settlm_amt, 
                   'BAR' ,    
                   'I'                ,    
                   @rr_cd             , 
                   @chk_brch_acct_nbr, 
                   null ,
				   null,
				   null,
				   getdate())
				   
			SELECT @syb_error_code = @@error
				   
	end /* insert tacc_type_balance */
	
	else /* tacc_type_balance row does exist so update it */
	
		begin /* update tacc_type_balance row */

			/* modify action to reflect update only if row was not inserted today */
            if @TACC_action != 'I'
                select @TACC_action = 'U'

            /* determine new tdys_trade_dt_amt. based on either yesterday's */
            /* or today's trade_dt_amt. */
            if @TACC_tdys_trade_dt_amt IS NULL
                select @TACC_tdys_trade_dt_amt = @TACC_ydys_trade_dt_amt + @transaction_amt
            else
                select @TACC_tdys_trade_dt_amt = @TACC_tdys_trade_dt_amt + @transaction_amt

            /* determine new tdys_settlm_dt_amt. based on either yesterday's */
            /* or today's settlm_dt_amt. */
            if @TACC_tdys_settlm_dt_amt IS NULL
                select @TACC_tdys_settlm_dt_amt = @TACC_ydys_settlm_dt_amt + @transaction_settlm_amt
            else
                select @TACC_tdys_settlm_dt_amt = @TACC_tdys_settlm_dt_amt + @transaction_settlm_amt

            update tacc_type_balance 
			set tdys_trade_dt_amt  = @TACC_tdys_trade_dt_amt,
                tdys_settlm_dt_amt = @TACC_tdys_settlm_dt_amt,
                action             = @TACC_action,
				record_type_cd	= 'BAR',
				updt_last_tmstp = getdate()
            where  client_nbr	=   @client_nbr
			and branch_cd      	=   @branch_cd
			and account_cd     	=   @account_cd
			and currency_cd    	=   @currency_cd  
            and type_account_cd =   @type_account_cd
			
			SELECT @syb_error_code = @@error
				
	end /* update tacc_type_balance row */

	commit transaction update_bal
		
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('TRADE',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
	return 0
	
end

go

grant execute on update_bal to fbi
go

IF OBJECT_ID('dbo.update_bal') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_bal >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_bal >>>'
go

