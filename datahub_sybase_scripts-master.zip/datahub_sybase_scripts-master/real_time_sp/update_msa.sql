/*
****************************************************************************
NAME: update_msa.sql
PURPOSE: Insert and update TMSD_BASE table
REVISIONS:
Ver	SSR	Date	  Author	  Description
-------	-------	--------- --------------- -------------------------------------
1.0	83773	12/21/12  Judy Shen	  Added a new field msd_added_dt
1.1	107202	05/25/15  Judy Shen	  Added a new field mfdsc_ind
1.2	108036	08/19/15  J.Shen	  Added a new field llc_ind
1.3	110028	11/19/15  J.Shen	  Added a new field msd_dnu_dt
******************************************************************************/

use #<bp>
go

IF OBJECT_ID('dbo.update_msa') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_msa
    IF OBJECT_ID('dbo.update_msa') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_msa >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_msa >>>'
END
go

CREATE PROC update_msa
	@security_adp_nbr	char(7),
	@country_cd			char(2),
	@currency_cd		char(3),
	@div_ann_est_amt	decimal(17,8),
	@payment_freq_cd	char(1),
	@msd_class1_cd		char(1),
	@msd_class2_cd		char(1),
	@msd_class3_cd		char(1),
	@msd_class4_cd		char(1),
	@msd_class5_cd		char(1),
	@msd_class6_cd		char(1),
	@msd_class7_cd		char(1),
	@class_industry_cd	char(2),
	@sic_cd				char(4),
	@marginability_cd	char(1),
	@source_pricing_cd	char(1),
	@desc_sec_line1_txt	char(30),
	@taxable_cd 		char,
 	@country_origin_cd	char(2),
	@expiration_dt		char(10),
	@royalty_ind		char,
	@remic_ind			char,
	@reit_ind			char,
	@sec_use_ind		char,
	@shr_otstd_thou_qty	int,
	@earning_share_amt	decimal(5,3),
	@redenomination_dt	datetime,
	@currency_legacy_cd	char(3),
	@currency_iso_cd	char(3),
	@curr_legacy_iso_cd	char(3),	
	@uts_canadian_cd	char(1),
	@annuity_cd			char(1),
	@swaps_ind			char(1),
	@oats_nasdaq_cd		char(1),
	@rgstr_bond_cd		char(1),
	@foreign_cd			char(1),
	@security_ida_cd	char(4),
	@depository_cd		char(4),
	@trnfr_dptry_cd		char(4),
	@ibm_cd				char(6),
	@mcgill_cd			decimal(5,0),
	@issue_dt			datetime,
	@elig_tax_crdt_ind	char(1),
	@tax_credit_rt		decimal(5,3),
	@tax_withold_rt		decimal(5,3),
	@symbol_extended_cd	char(18),
	@dllr_us_trade_ind	char(1),
	@taxable_can_cd		char(1),
	@trnfr_chrg_amt		decimal(5,3),
	@fctr_file_rt		decimal(3,2),
	@qssp_crnt_pct		int,
	@qssp_prev_pct		int,
	@sector_cd			char(5),
	@etf_ind			char(1),
	@shrt_sl_elgbl_ind      char(1),              
	@shrt_sl_elgbl_dt       datetime,             
	@multiply_price_cd      char(1),               
    @refer_to_sec_nbr       char(7),               
	@dnu_reason_txt         char(20),             
	@dvdnd_qlfy_ind         char(1),              
	@dvdnd_qlfy_ovr_ind     char(1),               
	@ranking_cd             char(5),
    @bkpg_drs_cd		char(1),
    @pprls_lgl_ind		char(1) ,
	@actual_360_ind     	char(1),
	@drct_rgstn_ind  	char(1),
	@exchg_prime_cd		char(3),
	@mrkt_tier_cd		char(1),
	@mrkt_ind_cd		char(4),
	@prmry_naics_cd		char(6),
	@issr_type_cd		char(1),
	@dly_trd_volume_qty	decimal(9,0),
	@msd_added_dt		datetime,
	@mfdsc_ind		char(1),
	@llc_ind		char(1),
	@msd_dnu_dt		datetime
					
AS
BEGIN
    
	DECLARE @action_cd char(1),
		@tbl_security_adp_nbr char(7),
        @start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
			
	select
		@debug_flag = debug_flag
    FROM
        realtime_debug_config
    WHERE
        service_id= object_name(@@procid)
						
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @security_adp_nbr + "," + @country_cd + "," + @currency_cd
		select @error_description = ''
		select @custom_error_code = 0
	end
	
			
	/* determine if the row is already in the table. also, fetch */
	/* the existing action_cd. we'll use it if we do an update. */
	SELECT @action_cd = action_cd, @tbl_security_adp_nbr = security_adp_nbr 
	FROM tmsd_base WHERE
		security_adp_nbr = @security_adp_nbr

	/* update or insert depending on row existence */
	IF  @@rowcount = 0
	BEGIN
		BEGIN TRAN update_msa
		/* insert */
		INSERT INTO tmsd_base (	security_adp_nbr,
						div_ann_est_amt,
						record_type_cd,
						action_cd,
						payment_freq_cd,
						msd_class1_cd,
						msd_class2_cd,
						msd_class3_cd,
						msd_class4_cd,
						msd_class5_cd,
						msd_class6_cd,
						msd_class7_cd,
						country_cd,
						currency_cd,
						class_industry_cd,
						sic_cd,
						marginability_cd,
						source_pricing_cd,
						desc_sec_line1_txt,
						taxable_cd,
						country_origin_cd,
						expiration_dt, 
						royalty_ind,
						remic_ind,
						reit_ind,
						sec_use_ind,
						shr_otstd_thou_qty,
        					earning_share_amt,
        					redenomination_dt,
        					currency_legacy_cd,
        					currency_iso_cd,
        					curr_legacy_iso_cd,
						uts_canadian_cd,
						annuity_cd,
						swaps_ind,
						oats_nasdaq_cd,
						rgstr_bond_cd,
						foreign_cd,
						security_ida_cd,
						depository_cd,
						trnfr_dptry_cd,
						ibm_cd,
						mcgill_cd,
						issue_dt,
						elig_tax_crdt_ind,
						tax_credit_rt,
						tax_withold_rt,
						symbol_extended_cd,
						dllr_us_trade_ind,
						taxable_can_cd,
						trnfr_chrg_amt,
						fctr_file_rt,
						qssp_crnt_pct,
						qssp_prev_pct,
						sector_cd,
						etf_ind,
						shrt_sl_elgbl_ind,              
						shrt_sl_elgbl_dt,             
						multiply_price_cd,               
						refer_to_sec_nbr,               
					        dnu_reason_txt,             
						dvdnd_qlfy_ind,              
						dvdnd_qlfy_ovr_ind,               
	                                        ranking_cd,
						bkpg_drs_cd,
						pprls_lgl_ind,
						actual_360_ind,
						drct_rgstn_ind,
						exchg_prime_cd,
						mrkt_tier_cd,
						mrkt_ind_cd,
						prmry_naics_cd,
						issr_type_cd,
						dly_trd_volume_qty,
						msd_added_dt,
						mfdsc_ind,
						llc_ind,
						msd_dnu_dt,
						updt_last_tmstp)
				VALUES (	@security_adp_nbr,
						@div_ann_est_amt,
						'MSA',
						'I',
						@payment_freq_cd,
						@msd_class1_cd,
						@msd_class2_cd,
						@msd_class3_cd,
						@msd_class4_cd,
						@msd_class5_cd,
						@msd_class6_cd,
						@msd_class7_cd,
						@country_cd,
						@currency_cd,
						@class_industry_cd,
						@sic_cd,
						@marginability_cd,
						@source_pricing_cd,
						@desc_sec_line1_txt,
						@taxable_cd,
						@country_origin_cd,
						@expiration_dt,
						@royalty_ind,
						@remic_ind,
						@reit_ind,
						@sec_use_ind,
						@shr_otstd_thou_qty,
        					@earning_share_amt,
        					@redenomination_dt,
        					@currency_legacy_cd,
        					@currency_iso_cd,
        					@curr_legacy_iso_cd,
						@uts_canadian_cd,
						@annuity_cd,
						@swaps_ind,
						@oats_nasdaq_cd,
						@rgstr_bond_cd,
						@foreign_cd,
						@security_ida_cd,
						@depository_cd,
						@trnfr_dptry_cd,
						@ibm_cd,
						@mcgill_cd,
						@issue_dt,
						@elig_tax_crdt_ind,
						@tax_credit_rt,
						@tax_withold_rt,
						@symbol_extended_cd,
						@dllr_us_trade_ind,
						@taxable_can_cd,
						@trnfr_chrg_amt,
						@fctr_file_rt,
						@qssp_crnt_pct,
						@qssp_prev_pct,
						@sector_cd,
						@etf_ind,
						@shrt_sl_elgbl_ind,              
						@shrt_sl_elgbl_dt,             
						@multiply_price_cd,               
						@refer_to_sec_nbr,               
						@dnu_reason_txt,             
						@dvdnd_qlfy_ind,              
						@dvdnd_qlfy_ovr_ind,               
	                                        @ranking_cd,
						@bkpg_drs_cd,
						@pprls_lgl_ind,
						@actual_360_ind,
						@drct_rgstn_ind,
						@exchg_prime_cd,
						@mrkt_tier_cd,
						@mrkt_ind_cd,
						@prmry_naics_cd,
						@issr_type_cd,
						@dly_trd_volume_qty,
						@msd_added_dt,
						@mfdsc_ind,
						@llc_ind,
						@msd_dnu_dt,
						getdate())

		SELECT @syb_error_code = @@error
			
							
		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_msa
			
			select @error_description = 'update_msa : tmsd_base : Insert operation'
			
			raiserror 20025 "Insert operation to tmsd_base failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
					
			RETURN -99
		END

		COMMIT TRAN update_msa		
	END
	ELSE
	BEGIN
		BEGIN TRAN update_msa
		/* update */

		/* now update tmsd_base */
		UPDATE tmsd_base SET div_ann_est_amt = @div_ann_est_amt,
					record_type_cd = 'MSA',
					action_cd = 'U',
					payment_freq_cd = @payment_freq_cd,
					msd_class1_cd = @msd_class1_cd,
					msd_class2_cd = @msd_class2_cd,
					msd_class3_cd = @msd_class3_cd,
					msd_class4_cd = @msd_class4_cd,
					msd_class5_cd = @msd_class5_cd,
					msd_class6_cd = @msd_class6_cd,
					msd_class7_cd = @msd_class7_cd,
					country_cd = @country_cd,
					currency_cd = @currency_cd,
					class_industry_cd = @class_industry_cd,
					sic_cd = @sic_cd,
					marginability_cd = @marginability_cd,
					source_pricing_cd = @source_pricing_cd,
					desc_sec_line1_txt = @desc_sec_line1_txt,
					taxable_cd = @taxable_cd,
					country_origin_cd =@country_origin_cd,
					expiration_dt=@expiration_dt,
					royalty_ind=@royalty_ind,
					remic_ind=@remic_ind,
					reit_ind = @reit_ind,
					sec_use_ind = @sec_use_ind,
					shr_otstd_thou_qty = @shr_otstd_thou_qty,
        				earning_share_amt = @earning_share_amt,
        				redenomination_dt = @redenomination_dt,
        				currency_legacy_cd = @currency_legacy_cd,
        				currency_iso_cd = @currency_iso_cd,
        				curr_legacy_iso_cd = @curr_legacy_iso_cd,
					uts_canadian_cd = @uts_canadian_cd,
					annuity_cd = @annuity_cd,
					swaps_ind =	@swaps_ind,
					oats_nasdaq_cd = @oats_nasdaq_cd,
					rgstr_bond_cd = @rgstr_bond_cd,
					foreign_cd = @foreign_cd,
					security_ida_cd = @security_ida_cd,
					depository_cd = @depository_cd,
					trnfr_dptry_cd = @trnfr_dptry_cd,
					ibm_cd = @ibm_cd,
					mcgill_cd = @mcgill_cd,
					issue_dt = @issue_dt,
					elig_tax_crdt_ind = @elig_tax_crdt_ind,
					tax_credit_rt = @tax_credit_rt,
					tax_withold_rt = @tax_withold_rt,
					symbol_extended_cd = @symbol_extended_cd,
					dllr_us_trade_ind = @dllr_us_trade_ind,
					taxable_can_cd = @taxable_can_cd,
					trnfr_chrg_amt = @trnfr_chrg_amt,
					fctr_file_rt = @fctr_file_rt,
					qssp_crnt_pct = @qssp_crnt_pct,
					qssp_prev_pct = @qssp_prev_pct,
					sector_cd = @sector_cd,
					etf_ind = @etf_ind,
					shrt_sl_elgbl_ind=@shrt_sl_elgbl_ind,              
					shrt_sl_elgbl_dt=@shrt_sl_elgbl_dt,             
					multiply_price_cd=@multiply_price_cd,               
					refer_to_sec_nbr=@refer_to_sec_nbr,               
					dnu_reason_txt=@dnu_reason_txt,             
					dvdnd_qlfy_ind=@dvdnd_qlfy_ind,              
					dvdnd_qlfy_ovr_ind=@dvdnd_qlfy_ovr_ind,               
	                                ranking_cd=@ranking_cd,
					bkpg_drs_cd=@bkpg_drs_cd,
        				pprls_lgl_ind=@pprls_lgl_ind,
					actual_360_ind=@actual_360_ind,
					drct_rgstn_ind=@drct_rgstn_ind,
					exchg_prime_cd=@exchg_prime_cd,
					mrkt_tier_cd=@mrkt_tier_cd,
					mrkt_ind_cd=@mrkt_ind_cd,
					prmry_naics_cd=@prmry_naics_cd,
					issr_type_cd=@issr_type_cd,
					dly_trd_volume_qty=@dly_trd_volume_qty,
					msd_added_dt=@msd_added_dt,
					mfdsc_ind = @mfdsc_ind,
					llc_ind = @llc_ind,
					msd_dnu_dt = @msd_dnu_dt,
					updt_last_tmstp = getdate()
		
		WHERE security_adp_nbr = @security_adp_nbr
		
		SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
	    BEGIN
		
			ROLLBACK TRAN update_msa
		
			select @error_description = 'update_msa : tmsd_base : Update operation'
			
			raiserror 20026 "Update operation to tmsd_base failed"
			select @custom_error_code=@@error
		
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
		
			RETURN -99
		
	    END
		  
	    COMMIT TRAN update_msa

	END
	
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('MSD',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
   
END

go

grant execute on update_msa to fbi
go

IF OBJECT_ID('dbo.update_msa') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_msa >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_msa >>>'
go
