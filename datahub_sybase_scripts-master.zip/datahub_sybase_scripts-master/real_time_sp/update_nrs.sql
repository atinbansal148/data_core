/*
$Header: /rtapp/stp/update_nrs.sql 1     3/25/02 10:45a Tbprven $
$Log: /rtapp/stp/update_nrs.sql $
 * 
 * 1     3/25/02 10:45a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrs') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrs
    IF OBJECT_ID('dbo.update_nrs') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrs >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrs >>>'
END
go

CREATE PROC update_nrs
      @client_nbr	char(4)   ,
      @branch_cd char(3)   ,
      @account_cd char(5)   ,
      @rr_cd char(3)  ,
      @action char(1)  ,
      @ap_seq_nbr smallint    = null ,
      @pblc_cmpy_seq_nbr smallint    = null ,
      @public_company_nm char(20)   = null ,
      @offcr_drctr_ind char(1)   = null ,
      @ten_plus_cntl_ind char(1) = null
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
		
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@ap_seq_nbr) + "," + convert(varchar(8),@pblc_cmpy_seq_nbr) 
		select @error_description = ''
		select @custom_error_code = 0
	end

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tpublic_company
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
		           ap_seq_nbr = @ap_seq_nbr and
			   pblc_cmpy_seq_nbr = @pblc_cmpy_seq_nbr
			   
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN
		
			BEGIN TRAN update_nrs

			/* insert into realtime table */
			INSERT INTO tpublic_company (client_nbr ,
			      branch_cd ,
			      account_cd ,
      			      ap_seq_nbr ,
			      pblc_cmpy_seq_nbr  ,
			      action ,
			      record_type_cd ,
			      rr_cd ,
			      public_company_nm ,
			      offcr_drctr_ind ,
			      ten_plus_cntl_ind,
				updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd ,
			      @account_cd ,
      			      @ap_seq_nbr ,
			      @pblc_cmpy_seq_nbr  ,
			      'I' ,
			      'NRS' ,
			      @rr_cd ,
			      @public_company_nm ,
			      @offcr_drctr_ind ,
			      @ten_plus_cntl_ind,
				getdate())


			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrs
				
				select @error_description = 'update_nrs : tpublic_company : Insert operation'
				
				raiserror 20130 "Insert operation to tpublic_company failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END	
			
			COMMIT TRAN update_nrs
			
		END
		ELSE
		BEGIN
			
			BEGIN TRAN update_nrs			
			/* update */

			/* now update realtime table row */
			UPDATE tpublic_company
			SET action = 'U',
			      record_type_cd = 'NRS',
			      rr_cd = @rr_cd ,
			      public_company_nm = @public_company_nm,
			      offcr_drctr_ind = @offcr_drctr_ind,
			      ten_plus_cntl_ind = @ten_plus_cntl_ind,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
		           	ap_seq_nbr = @ap_seq_nbr and
			   	pblc_cmpy_seq_nbr = @pblc_cmpy_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrs
				
				select @error_description = 'update_nrs : tpublic_company : Update operation'
				
				raiserror 20131 "Update operation to tpublic_company failed"
				select @custom_error_code=@@error				
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
			COMMIT TRAN update_nrs

		END
				
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		/*SELECT @db_action_cd = action
		FROM tpublic_company
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   action IN ('A','C')
					   
	        SELECT @tbl_rowcount = @@rowcount*/
			       	        
		BEGIN TRAN update_nrs
		
		/* now delete realtime table row */
		DELETE tpublic_company
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

		/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrs
			
			select @error_description = 'update_nrs : tpublic_company : Delete operation'
			
			raiserror 20132 "Delete operation to tpublic_company failed"
			select @custom_error_code=@@error				
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nrs
	END
  
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nrs to fbi
go

IF OBJECT_ID('dbo.update_nrs') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrs >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrs >>>'
go
