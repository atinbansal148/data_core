/*
$Header: /rtapp/stp/update_nrr.sql 1     3/25/02 10:45a Tbprven $
$Log: /rtapp/stp/update_nrr.sql $
 * 
 * 1     3/25/02 10:45a Tbprven
 * Name & Address Retool stp
 * 
 * 1     03/25/02 10:30a Tbprven
 * Version 1.0
 * 
 * added the header
$NoKeywords: $
*/

use #<bp>
go

IF OBJECT_ID('dbo.update_nrr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.update_nrr
    IF OBJECT_ID('dbo.update_nrr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.update_nrr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.update_nrr >>>'
END
go

CREATE PROC update_nrr
      @client_nbr	char(4)  ,
      @branch_cd char(3)  ,
      @account_cd char(5)  ,
      @rr_cd char(3) ,
      @action char(1) ,
      @rstrs_seq_nbr smallint   = null ,
      @begin_dt datetime  = null ,
      @end_dt datetime  = null ,
      @restriction_cd char(2) = null
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	DECLARE @db_action_cd char(1)
	DECLARE @tbl_rowcount smallint,
		@start_time             datetime,
		@proc_name              varchar(35),
		@input_parm             varchar(800),
		@debug_flag             char(1),
		@syb_error_code         int ,
		@custom_error_code      int,
		@error_description	varchar(150)
	
	select 
		@debug_flag = debug_flag
	FROM 
		realtime_debug_config
	WHERE 
		service_id= object_name(@@procid)
		
	if(@debug_flag='Y')
    begin
        select @start_time=getdate()
        select @proc_name=object_name(@@procid)
        select @input_parm = @client_nbr + "," + @branch_cd + "," + @account_cd + "," + convert(varchar(8),@rstrs_seq_nbr)
		select @error_description = ''
		select @custom_error_code = 0
 	end	

	/* check if we're doing an insert/update or a delete */
	IF (@action = 'C') OR (@action = 'A')
	BEGIN
	
		/* insert or update record */
		SELECT @db_action_cd = action
		FROM tacct_restriction
		WHERE      client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd and
			   rstrs_seq_nbr = @rstrs_seq_nbr
			   
		SELECT @tbl_rowcount = @@rowcount

		IF @tbl_rowcount = 0
		BEGIN

			BEGIN TRAN update_nrr

			/* insert, first into realtime table */
			INSERT INTO tacct_restriction (client_nbr ,
			      branch_cd  ,
			      account_cd  ,
			      rstrs_seq_nbr ,
			      action ,
			      record_type_cd ,
			      rr_cd ,
			      begin_dt ,
			      end_dt ,
			      restriction_cd,
				updt_last_tmstp)
			VALUES (@client_nbr ,
			      @branch_cd  ,
			      @account_cd  ,
			      @rstrs_seq_nbr ,
			      'I',
			      'NRR',
			      @rr_cd ,
			      @begin_dt ,
			      @end_dt ,
			      @restriction_cd,
				getdate())

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrr
				
				select @error_description = 'update_nrr : tacct_restriction : Insert operation'
				
				raiserror 20127 "Insert operation to tacct_restriction failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
			
			COMMIT TRAN update_nrr
		END
		ELSE
		BEGIN
			BEGIN TRAN update_nrr			
			/* update */

			/* now update realtime table row */
			UPDATE tacct_restriction
			SET action = 'U',
			      record_type_cd = 'NRR',
			      rr_cd = @rr_cd,
			      begin_dt = @begin_dt,
			      end_dt = @end_dt,
			      restriction_cd = @restriction_cd,
				  updt_last_tmstp = getdate()
			WHERE client_nbr = @client_nbr and 
			   	branch_cd = @branch_cd and 
			   	account_cd = @account_cd and
				rstrs_seq_nbr = @rstrs_seq_nbr

			SELECT @syb_error_code = @@error

			/* check if successful; else rollback tran and return error code */
			if @syb_error_code != 0
			BEGIN
				ROLLBACK TRAN update_nrr
				
				select @error_description = 'update_nrr : tacct_restriction : Update operation'
				
				raiserror 20128 "Update operation to tacct_restriction failed"
				select @custom_error_code=@@error
				
				IF (@debug_flag="Y")
				BEGIN
					INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
				END
				RETURN -99
			END
		
		COMMIT TRAN update_nrr
		
		END
			
	END
	ELSE
	IF (@action = 'D')
	BEGIN
		
		BEGIN TRAN update_nrr

		/* now delete realtime table row */

		DELETE tacct_restriction
		WHERE client_nbr = @client_nbr and 
			   branch_cd = @branch_cd and 
			   account_cd = @account_cd 

		SELECT @syb_error_code = @@error

/* check if successful; else rollback tran and return error code */
		if @syb_error_code != 0
		BEGIN
			ROLLBACK TRAN update_nrr
			
			select @error_description = 'update_nrr : tacct_restriction : Delete operation'
			
			raiserror 20129 "Delete operation to tacct_restriction failed"
			select @custom_error_code=@@error
			
			IF (@debug_flag="Y")
			BEGIN
				INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
			END
			RETURN -99
		END
		
		COMMIT TRAN update_nrr
	END
 
	IF (@debug_flag="Y")
	BEGIN
		INSERT INTO realtime_log VALUES ('NADDR',@proc_name,@input_parm,@start_time,getdate(),@syb_error_code ,@error_description, @custom_error_code)
	END
	
END

go

grant execute on update_nrr to fbi
go

IF OBJECT_ID('dbo.update_nrr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.update_nrr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.update_nrr >>>'
go
