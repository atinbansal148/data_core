use spica_batch

go

select *
  into #temp_tcan_mrgn_optn
  from spica_batch..tcan_mrgn_optn_vw
  order by client_nbr, branch_cd, account_cd, currency_cd, security_adp_nbr
go

create clustered index temp_tcan_mrgn_optn_idc on #temp_tcan_mrgn_optn(client_nbr, branch_cd, account_cd, currency_cd, security_adp_nbr) with sorted_data

go

SELECT
	a.branch_cd,
	a.account_cd,
	a.currency_cd,
	a.type_account_cd,
	CASE
		WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN
		CASE
			WHEN b.currency_cd in ('000','002') then  'ca'
			ELSE 'us'
		END
		WHEN ltrim(e.type_xref_cd) IS NOT NULL and ltrim(f.type_xref_cd) IS NULL THEN "ca"
		WHEN ltrim(e.type_xref_cd) IS NULL and ltrim(f.type_xref_cd) IS NOT NULL  THEN "us"
		WHEN ltrim(e.type_xref_cd) IS NULL and ltrim(f.type_xref_cd) IS NULL THEN
		CASE
			WHEN b.currency_cd in ('000','002') then 'ca'
			ELSE 'us'
		END
		WHEN ltrim(e.type_xref_cd) IS NOT NULL and ltrim(f.type_xref_cd) IS NOT NULL  then
		CASE
			WHEN a.currency_cd in ('000','002') THEN 'ca'
			WHEN a.currency_cd = '001' THEN 'us'
			WHEN a.currency_cd NOT in ('000','001','002') AND b.currency_cd in ('000','002') THEN 'ca'
			ELSE 'us'
		END
	END market ,
	a.security_adp_nbr,
	a.trade_dt_qty,
	a.today_total_qty,
	a.trade_dt_qty + a.today_total_qty today_total_qty_combined,
	CASE
		WHEN b.security_ida_cd ='8000' OR b.security_ida_cd ='8100' THEN
		CASE
			WHEN ( patindex("%[^0-9.-]%", a.holder_price_txt) > 0) THEN convert(decimal(17,2),0)
			--ELSE CONVERT(money, convert(money,a.holder_price_txt) * a.trade_dt_qty * isnull(g.factor_pct,100))
			ELSE CONVERT(decimal(17,2), convert(money,a.holder_price_txt) * a.trade_dt_qty * isnull(g.factor_pct,100))
		END
		ELSE a.market_value_amt
	END market_value_amt,
	--Code changes by TCS on 10 Jun
	/*
	CASE
		WHEN ( patindex("%[^0-9.-]%", a.holder_price_txt) > 0) THEN convert(money,0)
		ELSE convert(money,a.holder_price_txt)
	END holder_price_txt,*/
	holder_price_txt,
	a.action,
	CASE
		WHEN c.err_cd = 'SE' or c.err_cd = 'ME' or c.err_cd = 'RE' or c.err_cd = 'XE' then 0
		ELSE c.bk_cost_amt
	--Code changes on 16 June
	--END  bk_cost_amt,
	END  bk_cost_amt_trade_dt,
	
	--Added Jun 18 Version 0.70
	CASE
		WHEN c.err_cd = 'SE' or c.err_cd = 'ME' or c.err_cd = 'RE' or c.err_cd = 'XE' then 0
		ELSE c.bk_cst_ntv_cur_amt
	END  bk_cst_ntv_cur_amt_trade_dt,
	c.err_cd err_cd_trade_dt,
	CASE
		WHEN s.err_cd = 'SE' or s.err_cd = 'ME' or s.err_cd = 'RE' or s.err_cd = 'XE' then 0
		ELSE s.bk_cost_amt
	END  bk_cost_amt_settlement_dt,
	CASE
		WHEN s.err_cd = 'SE' or s.err_cd = 'ME' or s.err_cd = 'RE' or s.err_cd = 'XE' then 0
		ELSE s.bk_cst_ntv_cur_amt
	END  bk_cst_ntv_cur_amt_settle_dt,
	s.err_cd err_cd_settlement_dt,
	CASE
		WHEN  b.security_ida_cd ='8000' OR b.security_ida_cd ='8100'  THEN m.house_rqrmt_amt
		ELSE a.mrgn_hous_rqmt_amt
	END position_margin ,
	convert(char(10),a.activity_last_dt,101) activity_last_dt,
	a.settlement_dt_qty,
	a.settlement_dt_qty + a.today_total_qty settlement_dt_qty_combined,
	a.rr_cd,
	a.chk_brch_acct_nbr,
	d.memo_holder_cd_1    ,
	d.memo_holder_sub_cd_1,
	d.memo_holder_qty_1   ,
	d.memo_holder_cd_2    ,
	d.memo_holder_sub_cd_2,
	d.memo_holder_qty_2   ,
	d.memo_holder_cd_3    ,
	d.memo_holder_sub_cd_3,
	d.memo_holder_qty_3   ,
	d.memo_holder_cd_4    ,
	d.memo_holder_sub_cd_4,
	d.memo_holder_qty_4 ,
	
	--Code changes for V1.10 by TCS on 10 Oct 2014
	c.bk_cost_amt bk_cost_amt_trade_dt_org,
	c.bk_cst_ntv_cur_amt bk_cst_ntv_cur_amt_trd_dt_org,
	convert(char(10), c.lmu_dt,101) lmu_dt_trade_dt,
	c.lmu_dt_ind lmu_dt_ind_trade_dt,
	convert(char(10), c.err_dt, 101) err_dt_trade_dt,
	c.err_flag_cd err_flag_cd_trade_dt,
	s.bk_cost_amt bk_cost_amt_settlement_dt_org,
	s.bk_cst_ntv_cur_amt bk_cst_ntv_cur_amt_setl_dt_org,
	convert(char(10), s.lmu_dt,101) lmu_dt_settlement_dt,
	s.lmu_dt_ind lmu_dt_ind_settlement_dt,
	convert(char(10), s.err_dt,101) err_dt_settlement_dt,
	s.err_flag_cd err_flag_cd_settlement_dt,
	"ops       " modify_by,
	getdate() modify_timestamp
INTO spica_batch..sb_si_position
FROM
bpsa..taccount_sec_hldr a
LEFT OUTER JOIN bpsa..tmsd_base b ON a.security_adp_nbr = b.security_adp_nbr
LEFT OUTER JOIN bpsa..toption_data g ON a.security_adp_nbr = g.security_adp_nbr
LEFT OUTER JOIN bpsa..tsec_xref_key e ON b.security_adp_nbr = e.security_adp_nbr and e.type_xref_cd = 'CN'
LEFT OUTER JOIN bpsa..tsec_xref_key f ON b.security_adp_nbr = f.security_adp_nbr and f.type_xref_cd = 'SY'
LEFT OUTER JOIN #temp_tcan_mrgn_optn m ON a.client_nbr   = m.client_nbr AND
                                                a.branch_cd        = m.branch_cd AND
                                                a.account_cd       = m.account_cd AND
                                                a.currency_cd      = m.currency_cd AND
                                                a.security_adp_nbr = m.security_adp_nbr
LEFT OUTER JOIN bpsa..tcan_td_bk_cst_ps c    ON a.client_nbr       = c.client_nbr AND
                                                a.branch_cd        = c.branch_cd AND
                                                a.account_cd       = c.account_cd AND
                                                a.currency_cd      = c.currency_cd AND
                                                a.type_account_cd  = c.type_account_cd AND
                                                a.security_adp_nbr = c.security_adp_nbr
LEFT OUTER JOIN spica_batch..si_tacc_sec_hldr_memo d    ON a.client_nbr  = d.client_nbr AND
                                                a.branch_cd        = d.branch_cd AND
                                                a.account_cd       = d.account_cd AND
                                                a.currency_cd      = d.currency_cd AND
                                                a.type_account_cd  = d.type_account_cd AND
                                                a.security_adp_nbr = d.security_adp_nbr AND
												a.issue_when_ind   = d.issue_when_ind AND
												a.seq_nbr	   		= d.seq_nbr	
--Added Jun 18 Version 0.7
LEFT OUTER JOIN bpsa..tcan_sd_bk_cst_ps s    ON a.client_nbr      = s.client_nbr AND
                                                a.branch_cd        = s.branch_cd AND
                                                a.account_cd       = s.account_cd AND
                                                a.currency_cd      = s.currency_cd AND
                                                a.type_account_cd  = s.type_account_cd AND
                                                a.security_adp_nbr = s.security_adp_nbr						

WHERE a.client_nbr = '0069'
ORDER BY a.branch_cd, a.account_cd, a.currency_cd, a.type_account_cd, a.security_adp_nbr

go

