use #<sb>
go

setuser "dbo"
go


if exists (SELECT 1 from sysobjects where type = 'V' and name = 'security_vw') 
begin
drop VIEW security_vw
end
go 


IF (@@error != 0)
BEGIN
	PRINT "Error DROPPING View 'security_vw'"
	SELECT syb_quit()
END
go

/*
SRS Version 1.70
Changes done by TCS on Dec 31 2015
security_classification_ida field logic has been modified for the Fixed Income Securities. This is to address the discrepancies found in Ralph migration project where the IDA code '00000' is resulting incorrect security classification.

apply below rules in sequence.
1) IF security_ida_cd = '0460' OR '0700' OR  '0800' then  'MUTUAL FUND'
2) ELSE IF security_ida_cd = '8000' OR '8100' then 'OPTION'
3) ELSE [IF security_ida_cd >= '2000' AND security_ida_cd != '5100'  AND security_adp_nbr starts with numeric (from 0 to 9)]
      OR [(IF msd_class1_cd= .2. or .3. or .4.) AND security_adp_nbr starts with numeric (from 0 to 9)], then 'FIXED INCOME'
      4) ELSE 'EQUITY'

*/

/*
SRS Version 1.30
Code Version 1.30
Changes done by TCS on Oct 17 2014
Added new field security_classification_ida for PRISM project. 
Apply below rules in sequence.
1) IF ida_code = 460 OR 700 OR  800 then  “MUTUAL FUND”
2) ELSE IF ida_code = 8000 OR 8100 then "OPTION"
3) ELSE IF Ida_code >= 0 and ida_code <= 900 OR ida_code = 5100 then “EQUITY”
4) ELSE IF ida_code >= 2000 then  “FIXED INCOME”


SRS Version 1.20
Code Version 1.20
Changes done by TCS on Oct 15 2014
1) Added the condition issue_when_ind="N' for all price related fields.
2) Replaced country_cd with currency_cd in the logic for all price related fields.
3) Added sequence for price_set_dt where type_price_cd (Closing, High, Low and Composite)
4) Added 2 new fields for composite prices
a) price_sec_amt_cdn_comp
b) price_sec_amt_usd_comp
 



SRS Version 1.10
Code Version 1.10
Changes done by TCS on Oct 13 2014

'-4 new fields added to table due to Intraday Security Web Service created for SRDR project.
1) tbond_data.accrue_start_dt
2) tbond_data.dated_dt_cd
3) tmsd_base.expiration_dt
4) tmsd_base.updt_last_tmstp
-10 new price related fields added which will be useful to have in Spica security table.
5) price_sec_amt_cdn_closing
6) price_sec_amt_cdn_high
7) price_sec_amt_cdn_low
8) price_set_dt_cdn
9) price_sec_amt_usd_closing
10) price_sec_amt_usd_high
11) price_sec_amt_usd_low
12) price_set_dt_usd
13) source_pricing_cd
14) price_house_amt
*/

print '<<<<< CREATING View - "security_vw" >>>>>'
go 


CREATE VIEW security_vw  
AS 
select 
	ms.security_adp_nbr,
	ms.msd_class1_cd +ms.msd_class2_cd + ms.msd_class3_cd +	ms.msd_class4_cd +ms.msd_class5_cd +ms.msd_class6_cd +ms.msd_class7_cd msd_class_cd,
	ms.security_ida_cd,
	ms.currency_cd,
	ms.country_origin_cd,
	ms.royalty_ind,
	ms.remic_ind,
	ms.reit_ind,
	ms.uts_canadian_cd,
	ms.etf_ind,
	ms.issr_type_cd,
	ms.annuity_cd,
	ms.class_industry_cd,
	ms.sic_cd,
	ms.sector_cd ,
	ms.action_cd ,
	--Added on 12 Jun
	ms.payment_freq_cd ,
	--ms.class_industry_cd , 
	convert(char(10),ms.issue_dt,101) issue_dt,
	--tsec_xref_key details
	b.cross_reference_cd cdn_symbol,
	c.cross_reference_cd us_symbol,
	d.cross_reference_cd isin,
	e.cross_reference_cd cusip,
	f.cross_reference_cd sedol,	
	convert(char(6),isnull(op.occ_optn_sym_id,'')) +  isnull(convert(char(6),op.expiration_dt,12),'      ') +
	case 
	when ms.msd_class1_cd = '6' AND ms.msd_class3_cd = '5' then 'P'
	when ms.msd_class1_cd = '6' AND ms.msd_class3_cd = '4' then 'C'
	else ' '
	end
	+ isnull( cast( (left('00000',5-len(substring(convert(varchar,op.strike_price_amt),1,(charindex(".",convert(varchar,op.strike_price_amt)))-1))) + substring(convert(varchar,op.strike_price_amt),1,(charindex(".",convert(varchar,op.strike_price_amt)))-1)) as char(5)) ,'') 
	+ isnull(substring(convert(varchar,op.strike_price_amt),(charindex(".",convert(varchar,op.strike_price_amt)))+1,3),'') option_symbology,
	--tsecurity_desc details
	g.desc_sec_txt desc_sec_txt_e1,
	h.desc_sec_txt desc_sec_txt_e2,
	i.desc_sec_txt desc_sec_txt_e3,
	j.desc_sec_txt desc_sec_txt_f1,
	k.desc_sec_txt desc_sec_txt_f2,
	l.desc_sec_txt desc_sec_txt_f3,
	--Bond Details
	convert(char(10),bo.maturity_dt,101) maturity_dt,
	bo.interest_rt,
	convert(char(10),bo.coupon_first_dt,101) coupon_first_dt,
	convert(char(10),bo.dated_dt,101) dated_dt,
	bo.date_coupon_cd,
	bo.evaluation_bond_cd,
	bo.cmo_ind,
	bo.pool_nbr,
	convert(char(10),bo.pay_interest_dt,101) pay_interest_dt,	
	--Option details
	CASE
		WHEN ms.security_ida_cd = '8000' THEN 'C'
		WHEN ms.security_ida_cd = '8100' THEN 'P'
	END call_or_put,
	CASE	
		WHEN ms.security_ida_cd ='8000' OR ms.security_ida_cd ='8100' THEN convert(char(10),op.expiration_dt,101) 
	END expiration_dt,
	CASE
		WHEN ms.security_ida_cd ='8000' OR ms.security_ida_cd ='8100' THEN op.strike_price_amt
	END strike_price_amt ,
	op.factor_pct,
	op.scrty_adp_base_nbr,
	op.type_option_cd,
	op.occ_optn_sym_id,
	-- tdvdnd_sec_master details
	convert(char(10),tdv.payable_dt,101) payable_dt,
	tdv.dvdnd_rt ,
	tdv.currency_incm_cd ,
	convert(char(10),tdv.record_dt,101) record_dt,
	convert(char(10),tdv.xdte_dt,101)  xdte_dt,
	--tsec_trd_exchange details
	tec.exchange_msd_cd exchange_msd_cd_cdn,
	teu.exchange_msd_cd exchange_msd_cd_us,
	--factor rate details
	fr.factor_rt,
	convert(char(10),fr.factor_dt,101) factor_dt,											
	--Added on 12 Jun
	convert(char(10),bo.accrue_end_dt,101) accrue_end_dt, 
	convert(char(10),cp.call_dt,101) call_dt, 
	cp.call_prc_amt ,
	convert(char(10),pp.put_dt,101) put_dt, 
	pp.put_prc_amt,	
	--tsecurity_rating details
	sr_m.rating_cd rating_cd_moody,
	sr_s.rating_cd rating_cd_snp,
	--Added 12 June
	tc.elig_rsp_cd, 
	tc.province_cd,
	--Code changes on 14 Nov 2014
	--convert(char(10),ec.effct_dt,101) effct_dt, 
	CASE	
		WHEN ec.effct_dt <> NULL THEN 
			substring(ec.effct_dt, 6,2) +'/'+ substring(ec.effct_dt, 9,2) +'/' + substring(ec.effct_dt, 1,4) 
		ELSE
			ec.effct_dt
	END effct_dt,	
	convert(char(10),ec.trmnt_dt,101) trmnt_dt,
	ec.elgbl_cd,
	--od_mutual_fund_xref details
	mf.company_code,
	mf.fund_code,
	--od_security_master details
	sm.ods_investment_category investment_category,
	--od_security_mapping details
	smp.class_level_one,
	smp.class_level_two,
	smp.class_level_three,
	smp.class_level_four,
	--added on 17 Oct
	--Apply below rules in sequence.
	--code changes in Dec 31 2016

	CASE
		WHEN (ms.security_ida_cd = '0460' OR ms.security_ida_cd = '0700' OR ms.security_ida_cd = '0800') THEN 'MUTUAL FUND'
		WHEN (ms.security_ida_cd = '8000' OR ms.security_ida_cd = '8100')  THEN 'OPTION'
		--WHEN (ms.security_ida_cd >= '2000' AND ms.security_ida_cd != '5100')  THEN 'FIXED INCOME' 
		WHEN (ms.security_ida_cd >= '2000' AND ms.security_ida_cd != '5100' AND patindex('%[0-9]%', substring(ms.security_adp_nbr, 1,1)) >0)  
		OR  (ms.msd_class1_cd IN ('2', '3', '4') AND patindex('%[0-9]%', substring(ms.security_adp_nbr, 1,1)) >0) THEN 'FIXED INCOME'
		ELSE 'EQUITY'
	END security_classification_ida, 	
	--added on 10 Oct
	ms.updt_last_tmstp,
	convert(char(10),ms.expiration_dt, 101) expiration_dt_wrt,
	bo.dated_dt_cd,
	convert(char(10),bo.accrue_start_dt, 101) accrue_start_dt,
	--Added on Oct 13
	spc2.price_sec_amt price_sec_amt_cdn_closing,
	sph2.price_sec_amt price_sec_amt_cdn_high,
	spl2.price_sec_amt price_sec_amt_cdn_low,
	spa2.price_sec_amt price_sec_amt_cdn_comp,
	
	CASE 
		WHEN spc2.price_set_dt <> NULL THEN CONVERT(char(10), spc2.price_set_dt, 101) 
		WHEN sph2.price_set_dt <> NULL THEN CONVERT(char(10), sph2.price_set_dt, 101) 
		WHEN spl2.price_set_dt <> NULL THEN CONVERT(char(10), spl2.price_set_dt, 101) 
		WHEN spa2.price_set_dt <> NULL THEN CONVERT(char(10), spa2.price_set_dt, 101) 
	END price_set_dt_cdn,
	spc1.price_sec_amt price_sec_amt_usd_closing,
	sph1.price_sec_amt price_sec_amt_usd_high,
	spl1.price_sec_amt price_sec_amt_usd_low,
	spa1.price_sec_amt price_sec_amt_usd_comp,
	
	CASE 
		WHEN spc1.price_set_dt <> NULL THEN CONVERT(char(10), spc1.price_set_dt, 101) 
		WHEN sph1.price_set_dt <> NULL THEN CONVERT(char(10), sph1.price_set_dt, 101) 
		WHEN spl1.price_set_dt <> NULL THEN CONVERT(char(10), spl1.price_set_dt, 101) 
		WHEN spa1.price_set_dt <> NULL THEN CONVERT(char(10), spa1.price_set_dt, 101) 
	END price_set_dt_usd,
	hp.source_pricing_cd source_pricing_cd,
	hp.price_house_amt price_house_amt,
	ms.mfdsc_ind mfdsc_ind,
	--Code changes on Sep 5
	m.cross_reference_cd cusip_12,
	--Code changes on Oct 22
	ms.refer_to_sec_nbr refer_to_sec_nbr,
	ms.dnu_reason_txt dnu_reason_txt
From
	#<bp>..tmsd_base ms
	LEFT OUTER JOIN #<bp>..tbond_data bo 	ON ms.security_adp_nbr = bo.security_adp_nbr
	LEFT OUTER JOIN #<bp>..tfactor_rate fr 	ON ms.security_adp_nbr = fr.security_adp_nbr AND fr.periodic_cd='1'
	LEFT OUTER JOIN #<bp>..toption_data op 	ON ms.security_adp_nbr = op.security_adp_nbr
	LEFT OUTER JOIN #<bp>..tsec_trd_exchange tec ON ms.security_adp_nbr = tec.security_adp_nbr 	and tec.country_cd = 'CA' and tec.exch_primary_ind = 'Y' 				
	LEFT OUTER JOIN #<bp>..tsec_trd_exchange teu ON ms.security_adp_nbr = teu.security_adp_nbr 	and teu.country_cd = 'US' and teu.exch_primary_ind = 'Y' 				
	LEFT OUTER JOIN #<bp>..tsec_xref_key b   ON ms.security_adp_nbr = b.security_adp_nbr and b.type_xref_cd ='CN'
	LEFT OUTER JOIN #<bp>..tsec_xref_key c   ON ms.security_adp_nbr = c.security_adp_nbr and c.type_xref_cd ='SY'
	LEFT OUTER JOIN #<bp>..tsec_xref_key d   ON ms.security_adp_nbr = d.security_adp_nbr and d.type_xref_cd ='IS'
	LEFT OUTER JOIN #<bp>..tsec_xref_key e   ON ms.security_adp_nbr = e.security_adp_nbr and e.type_xref_cd ='CU'
	LEFT OUTER JOIN #<bp>..tsec_xref_key f   ON ms.security_adp_nbr = f.security_adp_nbr and f.type_xref_cd ='SD'
	--Code changes on Sep 5-len
	LEFT OUTER JOIN #<bp>..tsec_xref_key m   ON ms.security_adp_nbr = m.security_adp_nbr and m.type_xref_cd ='CB'
	LEFT OUTER JOIN #<bp>..tsecurity_desc g  ON ms.security_adp_nbr = g.security_adp_nbr and g.language_cd='E' and g.line_txt_nbr=1
	LEFT OUTER JOIN #<bp>..tsecurity_desc h  ON ms.security_adp_nbr = h.security_adp_nbr and h.language_cd='E' and h.line_txt_nbr=2
	LEFT OUTER JOIN #<bp>..tsecurity_desc i  ON ms.security_adp_nbr = i.security_adp_nbr and i.language_cd='E' and i.line_txt_nbr=3
	LEFT OUTER JOIN #<bp>..tsecurity_desc j  ON ms.security_adp_nbr = j.security_adp_nbr and j.language_cd='F' and j.line_txt_nbr=1
	LEFT OUTER JOIN #<bp>..tsecurity_desc k  ON ms.security_adp_nbr = k.security_adp_nbr and k.language_cd='F' and k.line_txt_nbr=2
	LEFT OUTER JOIN #<bp>..tsecurity_desc l  ON ms.security_adp_nbr = l.security_adp_nbr and l.language_cd='F' and l.line_txt_nbr=3
	LEFT OUTER JOIN #<bp>..tsecurity_rating sr_m   ON ms.security_adp_nbr = sr_m.security_adp_nbr and sr_m.vendor_cd='MOODY' 
	LEFT OUTER JOIN #<bp>..tsecurity_rating sr_s   ON ms.security_adp_nbr = sr_s.security_adp_nbr and sr_s.vendor_cd='S&P' 
	LEFT OUTER JOIN #<bp>..tdvdnd_sec_master tdv   ON ms.security_adp_nbr = tdv.security_adp_nbr and tdv.sequence_nbr=1
	LEFT OUTER JOIN #<od>..od_mutual_fund_xref mf  ON ms.security_adp_nbr = mf.whole_adp_sec_num
	LEFT OUTER JOIN #<od>..od_security_master sm   ON ms.security_adp_nbr = sm.adp_sec_num
	LEFT OUTER JOIN #<od>..od_security_mapping smp ON ms.security_adp_nbr = smp.adp_sec_num
	--Added on Jun 12
	LEFT OUTER JOIN #<bp>..tcall_price cp ON ms.security_adp_nbr = cp.security_adp_nbr
	LEFT OUTER JOIN #<bp>..tput_price pp ON ms.security_adp_nbr = pp.security_adp_nbr
	LEFT OUTER JOIN #<bp>..ttrnsfr_client_dat tc ON ms.security_adp_nbr = tc.security_adp_nbr
	LEFT OUTER JOIN #<bp>..telgbly_cd_ovrrd ec ON ms.security_adp_nbr = ec.security_adp_nbr AND ec.client_number = '0069' AND
	--Added on Mar 11 2015	
	effct_dt=(select max(effct_dt) effct_dt from #<bp>..telgbly_cd_ovrrd tco where ec.security_adp_nbr=tco.security_adp_nbr and ec.client_number=ec.client_number)
	--Added on Oct 13
	LEFT OUTER JOIN #<bp>..tsec_price spc2 ON ms.security_adp_nbr = spc2.security_adp_nbr AND spc2.country_cd='CA' AND spc2.type_price_cd='C' AND spc2.issue_when_ind='N'
	LEFT OUTER JOIN #<bp>..tsec_price sph2 ON ms.security_adp_nbr = sph2.security_adp_nbr AND sph2.country_cd='CA' AND sph2.type_price_cd='H' AND sph2.issue_when_ind='N'     
	LEFT OUTER JOIN #<bp>..tsec_price spl2 ON ms.security_adp_nbr = spl2.security_adp_nbr AND spl2.country_cd='CA' AND spl2.type_price_cd='L' AND spl2.issue_when_ind='N'
	LEFT OUTER JOIN #<bp>..tsec_price spa2 ON ms.security_adp_nbr = spa2.security_adp_nbr AND spa2.country_cd='CA' AND spa2.type_price_cd='A' AND spa2.issue_when_ind='N'
	
	LEFT OUTER JOIN #<bp>..tsec_price spc1 ON ms.security_adp_nbr = spc1.security_adp_nbr AND spc1.country_cd='US' AND spc1.type_price_cd='C' AND spc1.issue_when_ind='N'
	LEFT OUTER JOIN #<bp>..tsec_price sph1 ON ms.security_adp_nbr = sph1.security_adp_nbr AND sph1.country_cd='US' AND sph1.type_price_cd='H' AND sph1.issue_when_ind='N'
	LEFT OUTER JOIN #<bp>..tsec_price spl1 ON ms.security_adp_nbr = spl1.security_adp_nbr AND spl1.country_cd='US' AND spl1.type_price_cd='L' AND spl1.issue_when_ind='N'
	LEFT OUTER JOIN #<bp>..tsec_price spa1 ON ms.security_adp_nbr = spa1.security_adp_nbr AND spa1.country_cd='US' AND spa1.type_price_cd='A' AND spa1.issue_when_ind='N'
	
	LEFT OUTER JOIN #<bp>..thouse_price hp ON ms.security_adp_nbr = hp.security_adp_nbr AND hp.client_nbr = '0069' AND hp.issue_when_ind='N'
go


grant all  on security_vw to spica_ws
go	
	
