/*<DOC>
*   Program				: sb_sp_balance_vw_SI.sql 
*   Desc.   			: Loader for spica_batch..si_balance table
*   Input   			: None
*   Amendment history		:	
*   Author:         		date:          			event:
*   TCS  					2017 Oct,16 			Initial Creation
*
</DOC>*/

use spica_batch 
go


if exists ( select 1 from sysobjects where type = 'U' and name = "sb_si_balance" )
begin
	drop table sb_si_balance
end
go


select 
type_account_cd,
branch_cd,
account_cd,
case when  currency_cd = '254' then 'FE' else   currency_cd end currency_cd,
convert(decimal(21,4),ydys_trade_dt_amt) ydys_trade_dt_amt,
convert(decimal(21,4),tdys_trade_dt_amt) tdys_trade_dt_amt,
tdys_trade_dt_amt_total = ydys_trade_dt_amt + tdys_trade_dt_amt,
convert(decimal(21,4),ydys_settlm_dt_amt) ydys_settlm_dt_amt,
convert(decimal(21,4),tdys_settlm_dt_amt) tdys_settlm_dt_amt,
tdys_settlm_dt_amt_total = ydys_settlm_dt_amt + tdys_settlm_dt_amt,
convert(decimal(21,4),ydys_equity_amt) ydys_equity_amt ,
convert(decimal(21,4),ydys_mrkt_val_amt) ydys_mrkt_val_amt,
action,
rr_cd
into #type_bal
from bpsa..tacc_type_balance

go

select 
branch_cd,
account_cd,
case when  currency_cd = '254' then 'FE' else   currency_cd end currency_cd,
convert(decimal(21,4),market_val_tot_amt) market_val_tot_amt ,
convert(decimal(21,4),equity_total_amt) equity_total_amt ,
convert(decimal(21,4),house_bal_call_amt) house_bal_call_amt ,
convert(char(10), last_bkpg_actv_dt, 101) last_bkpg_actv_dt,
convert(char(10), last_bsns_actv_dt, 101) last_bsns_actv_dt,
convert(decimal(21,4),sma_balance_amt) sma_balance_amt,
convert(decimal(21,4),new_house_call_amt) new_house_call_amt,
convert(decimal(21,4),cash_bal_call_amt) cash_bal_call_amt,
action
into #acc_bal
from 
bpsa..taccount_balance

go

select
typ.branch_cd,
typ.account_cd,
typ.currency_cd,
typ.ydys_trade_dt_amt,
typ.tdys_trade_dt_amt,
convert(decimal(21,4),tdys_trade_dt_amt_total) tdys_trade_dt_amt_total, 
typ.ydys_settlm_dt_amt,
typ.tdys_settlm_dt_amt,
convert(decimal(21,4),tdys_settlm_dt_amt_total) tdys_settlm_dt_amt_total, 
typ.ydys_equity_amt ,
typ.ydys_mrkt_val_amt,
typ.rr_cd,
acc.market_val_tot_amt ,
acc.equity_total_amt ,
acc.house_bal_call_amt,
acc.last_bkpg_actv_dt,
acc.last_bsns_actv_dt,
acc.sma_balance_amt,
acc.new_house_call_amt,
acc.cash_bal_call_amt,
typ.type_account_cd,
case when typ.action > acc.action then typ.action else acc.action end action
into #typacc_bal
from 
#acc_bal acc
left join
#type_bal typ 
on  acc.branch_cd = typ.branch_cd 
and acc.account_cd = typ.account_cd 
and acc.currency_cd =  typ.currency_cd



go

select
branch_cd,
account_cd,
currency_cd,
max(market_val_tot_amt) market_val_tot_amt,
max(equity_total_amt) equity_total_amt,
sum(case when type_account_cd = '1' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type1,
sum(case when type_account_cd = '1' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type1 ,
sum(case when type_account_cd = '1' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type1 ,
sum(case when type_account_cd = '2' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type2 ,
sum(case when type_account_cd = '2' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type2 ,
sum(case when type_account_cd = '2' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type2 ,
sum(case when type_account_cd = '3' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type3 ,
sum(case when type_account_cd = '3' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type3 ,
sum(case when type_account_cd = '3' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type3 ,
sum(case when type_account_cd = '4' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type4 ,
sum(case when type_account_cd = '4' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type4 ,
sum(case when type_account_cd = '4' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type4 ,
sum(case when type_account_cd = '5' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type5 ,
sum(case when type_account_cd = '5' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type5 ,
sum(case when type_account_cd = '5' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type5 ,
sum(case when type_account_cd = '6' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type6 ,
sum(case when type_account_cd = '6' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type6 ,
sum(case when type_account_cd = '6' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type6 ,
sum(case when type_account_cd = '7' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type7 ,
sum(case when type_account_cd = '7' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type7 ,
sum(case when type_account_cd = '7' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type7 ,
sum(case when type_account_cd = '8' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type8 ,
sum(case when type_account_cd = '8' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type8 ,
sum(case when type_account_cd = '8' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type8,
sum(case when type_account_cd = '9' then ydys_trade_dt_amt else 0 end 		)ydys_trade_dt_amt_type9 ,
sum(case when type_account_cd = '9' then tdys_trade_dt_amt else 0 end 		)tdys_trade_dt_amt_delta_type9 ,
sum(case when type_account_cd = '9' then tdys_trade_dt_amt_total else 0 end )tdys_trade_dt_amt_total_type9,
sum(case when type_account_cd = '1' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type1 ,
sum(case when type_account_cd = '1' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type1 ,
sum(case when type_account_cd = '1' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type1 ,
sum(case when type_account_cd = '2' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type2 ,
sum(case when type_account_cd = '2' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type2 ,
sum(case when type_account_cd = '2' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type2 ,
sum(case when type_account_cd = '3' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type3 ,
sum(case when type_account_cd = '3' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type3 ,
sum(case when type_account_cd = '3' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type3 ,
sum(case when type_account_cd = '4' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type4 ,
sum(case when type_account_cd = '4' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type4 ,
sum(case when type_account_cd = '4' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type4 ,
sum(case when type_account_cd = '5' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type5 ,
sum(case when type_account_cd = '5' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type5 ,
sum(case when type_account_cd = '5' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type5 ,
sum(case when type_account_cd = '6' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type6 ,
sum(case when type_account_cd = '6' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type6 ,
sum(case when type_account_cd = '6' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type6 ,
sum(case when type_account_cd = '7' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type7 ,
sum(case when type_account_cd = '7' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type7 ,
sum(case when type_account_cd = '7' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type7 ,
sum(case when type_account_cd = '8' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type8 ,
sum(case when type_account_cd = '8' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type8 ,
sum(case when type_account_cd = '8' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type8 ,
sum(case when type_account_cd = '9' then ydys_settlm_dt_amt else 0 end 		)ydys_settlm_dt_amt_type9 ,
sum(case when type_account_cd = '9' then tdys_settlm_dt_amt else 0 end 		)tdys_settlm_dt_amt_delta_type9 ,
sum(case when type_account_cd = '9' then tdys_settlm_dt_amt_total else 0 end)tdys_settlm_dt_amt_total_type9 ,
max(house_bal_call_amt) house_bal_call_amt,
max(action) action,
sum(case when type_account_cd = '1' then ydys_equity_amt else 0 end )equity_type1,
sum(case when type_account_cd = '2' then ydys_equity_amt else 0 end )equity_type2,
sum(case when type_account_cd = '3' then ydys_equity_amt else 0 end )equity_type3,
sum(case when type_account_cd = '4' then ydys_equity_amt else 0 end )equity_type4,
sum(case when type_account_cd = '5' then ydys_equity_amt else 0 end )equity_type5,
sum(case when type_account_cd = '6' then ydys_equity_amt else 0 end )equity_type6,
sum(case when type_account_cd = '7' then ydys_equity_amt else 0 end )equity_type7,
sum(case when type_account_cd = '8' then ydys_equity_amt else 0 end )equity_type8,
sum(case when type_account_cd = '9' then ydys_equity_amt else 0 end )equity_type9,
sum(case when type_account_cd = '1' then ydys_mrkt_val_amt else 0 end )market_value_type1,
sum(case when type_account_cd = '2' then ydys_mrkt_val_amt else 0 end )market_value_type2,
sum(case when type_account_cd = '3' then ydys_mrkt_val_amt else 0 end )market_value_type3,
sum(case when type_account_cd = '4' then ydys_mrkt_val_amt else 0 end )market_value_type4,
sum(case when type_account_cd = '5' then ydys_mrkt_val_amt else 0 end )market_value_type5,
sum(case when type_account_cd = '6' then ydys_mrkt_val_amt else 0 end )market_value_type6,
sum(case when type_account_cd = '7' then ydys_mrkt_val_amt else 0 end )market_value_type7,
sum(case when type_account_cd = '8' then ydys_mrkt_val_amt else 0 end )market_value_type8,
sum(case when type_account_cd = '9' then ydys_mrkt_val_amt else 0 end )market_value_type9,
max(last_bkpg_actv_dt) last_bkpg_actv_dt,
max(last_bsns_actv_dt) last_bsns_actv_dt,
max(sma_balance_amt) sma_balance_amt,
max(new_house_call_amt) new_house_call_amt,
max(cash_bal_call_amt) cash_bal_call_amt,
max(rr_cd) rr_cd,
'ops       ' modify_by,
getdate() modify_timestamp
into  spica_batch..sb_si_balance
from #typacc_bal
group by branch_cd,account_cd,currency_cd
order by branch_cd,account_cd,currency_cd


go
